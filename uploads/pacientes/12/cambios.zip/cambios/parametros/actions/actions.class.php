<?php

/**
 * parametros actions.
 *
 * @package    prejuridico
 * @subpackage parametros
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class parametrosActions extends sfActions {

    public function preExecute() {
        $configCache = sfApplicationConfiguration::getActive()->getConfigCache();
        $configCache->registerConfigHandler('config/parametros.yml', 'sfDefineEnvironmentConfigHandler', Array('prefix' => 'parametros_'));
        include $configCache->checkConfig('config/parametros.yml');
    }

    public function executeIndex(sfWebRequest $request) {
        /* $this->defaults_list = Doctrine::getTable('Defaults')
          ->createQuery('a')
          ->select('a.*')
          ->where("id IN (".sfConfig::get("parametros_a_mostrar").")")
          ->orderBy("a.id ASC")
          ->execute(); */

        $queryMP = "SELECT d.*,d.fldvalue as valor,c.accno,c.description 
     FROM defaults d
     LEFT JOIN chart c ON c.id=d.fldvalue
     WHERE d.id in (" . sfConfig::get("parametros_a_mostrar") . ")  order by d.id";
        $this->defaults_list = Doctrine_Manager::getInstance()->getConnection('doctrine')->getDbh()->query($queryMP);
    }

    public function executeNew(sfWebRequest $request) {
        $this->form = new DefaultsForm();
    }

    public function executeCreate(sfWebRequest $request) {
        $this->forward404Unless($request->isMethod('post'));

        $this->form = new DefaultsForm();

        $this->processForm($request, $this->form);

        $this->setTemplate('new');
    }

    public function executeEdit(sfWebRequest $request) { //print ">>"; exit;
        $this->id = $request->getParameter('id');
        $queryMP = "Select *  from defaults where id =" . $this->id;
        $this->defaults = Doctrine_Manager::getInstance()->getConnection('doctrine')->getDbh()->query($queryMP);


        foreach ($this->defaults as $this->form) {
            //print"**".$this->form["fldname"];
            $obj = sfConfig::get("parametros_configuracion_" . $this->form["fldname"]);
            $this->valor = null;
            if ($obj['tipo'] == "cuenta")
                $this->tw = 1;
            else {
                $this->tw = 0;
                $this->valor = $this->form["fldvalue"];
            }
            //var_dump($obj);
        } //exit;
    }

    public function executeUpdate(sfWebRequest $request) {
        // print "update "; 	  
        $queryMP = "update defaults set fldvalue=" . $request->getParameter('defaults_fldvalue') . " where id=" . $request->getParameter('id');
        $chart = Doctrine_Manager::getInstance()->getConnection('doctrine')->getDbh()->query($queryMP);

        $this->redirect('parametros/index?msj=Guardado');
    }

    function cartera() {
        $permisos = $this->getUser()->getAttribute('usuario');
        $sql2 = "select carteras from gca_datos_funcionarios  where id_empleado=$permisos";
        $cartera = parametrosActions::executeConsultasConsul($sql2);
        $sql = "select id,nombre from gca_cartera where id in (" . $cartera[0]['carteras'] . ") order by nombre";
        return $cartera = parametrosActions::executeConsultasConsul($sql);
    }

    public function executeRedistribucionPagosHis() {
        $this->cartera = $this->cartera();
        $this->nombre = $this->nombre_usuarios();
        $this->setTemplate('redistribucionPagosHis');
    }

    public function executeRedistribucionPagos() {
        $this->setTemplate('redistribucionPagos');
    }

    public function executeConsultas() {
        $this->id_user = $this->getUser()->getAttribute('usuario');
        $this->setTemplate('consultas');
    }

    public function executeEstadoCuestaXcliente() {
        $this->cartera = $this->cartera();
        $this->setTemplate('estadoCuestaXcliente');
    }

    public function executeCausales() {
        $this->cartera = $this->cartera();
        $this->setTemplate('causales');
    }

    function ciudad() {
        $sql = "select ciudad from gca_localizaciones group by ciudad order by ciudad";
        return $cartera = parametrosActions::executeConsultasConsul($sql);
    }

    public function executePortafilio_basico() {
        $this->cartera = $this->cartera();
        $this->ciudad = parametrosActions::ciudad();
        $this->setTemplate('portafilio_basico');
    }

    public function executeMostrar_causal() {
        $this->cartera = $this->cartera();
        $this->setTemplate('mostrar_causal');
    }

    public function executeCalculoIntereses() {
//        die(); 
        ini_set('memory_limit', '3G');
        ini_set('memory_limit', '-1');
        if ($_POST['calcular'] == 1)
            $this->Ejecutar_proceso();

        $fecha = date('Y-m-j');
        $nuevafecha = strtotime('-1 month', strtotime($fecha));
        if ($mes == 3) {
            $nuevafecha = date("Y-m-28", $nuevafecha);
        } else {
            $nuevafecha = date("Y-m-30", $nuevafecha);
        }
        $sql = "select count(id) cantidad from  gca_obligacion where fecha_calculo_mora='$nuevafecha' ";
        $datos = parametrosActions::executeConsultasConsul($sql);
        $sql = "update registro_liquidaciones set cantidad=" . $datos[0]['cantidad'] . " where fecha='$nuevafecha'";
        parametrosActions::executeConsultasInsert($sql);
        $this->registro_calculo_intereses = $this->registro_calculo_intereses();
        $this->setTemplate('calculoIntereses');
    }

    public function registro_calculo_intereses() {
        $sql = "SELECT b.login, a.fecha, a.tasa, a.cantidad FROM registro_liquidaciones a,employee b where a.id_usuario = b.id and a.id = (select max(id) from registro_liquidaciones)";
        return $registro_calculo_intereses = parametrosActions::executeConsultasConsul($sql);
    }

    public function Ejecutar_proceso() {
        ini_set('memory_limit', '-1');
        $id_user = $this->getUser()->getAttribute('usuario');
        $sql_consulta = "SELECT tasa_mora FROM gca_configuracion_sistema";
        $resultado = parametrosActions::executeConsultasConsul($sql_consulta);
        if ($resultado[0]['tasa_mora'] > 0) {

            $tasa = $resultado[0]["tasa_mora"];
            $fecha = date('Y-m-j');
            $nuevafecha = strtotime('-1 month', strtotime($fecha));
            if ($mes == 3) {
                $nuevafecha = date("Y-m-28", $nuevafecha);
            } else {
                $nuevafecha = date("Y-m-30", $nuevafecha);
            }

            $sql_guardar = "INSERT INTO registro_liquidaciones(id_usuario,fecha,tasa,cantidad) values (" . $id_user . ",'" . $nuevafecha . "'," . $resultado[0]["tasa_mora"] . ",0)";
            parametrosActions::executeConsultasInsert($sql_guardar);

            $sql = "select id,obligacion,saldo_mora,saldo_capital, interes_mora,fecha_calculo_mora from gca_obligacion where  	bloqueada=0 and fecha_calculo_mora < '$nuevafecha' ";
            $obligaciones = parametrosActions::executeConsultasConsul($sql);

            foreach ($obligaciones as $value) {
                $diferencia = strtotime($nuevafecha) - strtotime($value['fecha_calculo_mora']);
                $tiempo = floor($diferencia / 86400);
                $interes_mora_ant = $value['interes_mora'];
                $capital = $value['saldo_mora'];
                $tasa2 = ($tasa / 30) * $tiempo;
                $interes_mora = floor($capital * ($tasa2 / 100));
                $interes_mora_ant = $interes_mora_ant + $interes_mora;
                $sql = "update gca_obligacion set saldo_mora=saldo_mora+$interes_mora,interes_mora=$interes_mora_ant,fecha_calculo_mora='$nuevafecha'  where id=" . $value['id'];
                parametrosActions::executeConsultasInsert($sql);
                $sql = "insert into gca_obligacion_movimiento (obligacion,saldo_mora,saldo_capital,interes_mora,fecha_corte,detalle)"
                        . "values ('" . $value['obligacion'] . "','" . $value['saldo_mora'] . "','" . $value['saldo_capital'] . "','" . $interes_mora_ant . "','" . $nuevafecha . "','LIQUIDACION') ";
                parametrosActions::executeConsultasInsert($sql);
            }
        }
    }

    public function executeDelete(sfWebRequest $request) {
        $request->checkCSRFProtection();

        $this->forward404Unless($defaults = Doctrine::getTable('Defaults')->find($request->getParameter('id')), sprintf('Object defaults does not exist (%s).', $request->getParameter('id')));
        $defaults->delete();

        $this->redirect('parametros/index');
    }

    protected function processForm(sfWebRequest $request, sfForm $form) {
        $form->bind($request->getParameter($form->getName()));
        if ($form->isValid()) {
            $defaults = $form->save();

            $this->redirect('parametros/edit?id=' . $defaults->getId());
        }
    }

    function executeConsultasInsert($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $doctrine->query($sql);
    }

    function executeConsultasConsul($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $res = $doctrine->query($sql)->fetchAll();
        return $res;
    }

    public function nombre_usuarios($permisos = NULL) {
        if (empty($permisos))
            $permisos = $this->getUser()->getAttribute('usuario');
        $sql2 = "select name from employee  where id=$permisos";
        $credenciales = parametrosActions::executeConsultasConsul($sql2);
        $name = $credenciales[0]['name'];
        return $name;
    }

    function listaCausal() {
        $sql = "select hh.*,em.name modificado_por "
                . "from gca_obligacion_causales hh "
                . "join employee em on em.id=hh.modificado_por where hh.estado_general=0 and hh.id<>6";
        return $cartera = parametrosActions::executeConsultasConsul($sql);
    }

    public function executePdf2($html) {
        echo "Hola Mundo ";
        $config = sfTCPDFPluginConfigHandler::loadConfig();
        exit();
    }

    public function executePdf($html2 = null) {
//        die();
//        echo "*EEEEE";
//        die();
//        require_once '../../parametros/tcpdf/tcpdf.php';  
        require_once dirname(__FILE__) . '/../tcpdf/tcpdf.php';

//        require_once('tcpdf_include.php');
// create new PDF document
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);


// set default header data
$pdf->SetHeaderData('LOG02.jpg', PDF_HEADER_LOGO_WIDTH,'                                   ESTADO DE CUENTA', '');

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('dejavusans', '', 10);

// add a page
$pdf->AddPage();

// writeHTML($html, $ln=true, $fill=false, $reseth=false, $cell=false, $align='')
// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)


$pdf->writeHTML($html2, true, false, true, false, '');

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('Documento.pdf', 'D');
    }

}
