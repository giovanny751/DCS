<?php

/**
 * frontInformeGestion actions.
 *
 * @package    prejuridico
 * @subpackage frontInformeGestion
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class frontInformeGestionActions extends sfActions
{
  public function executeIndex(sfWebRequest $request)
  {
    $this->gca_obligacion_list = Doctrine::getTable('GcaObligacion')
      ->createQuery('a')
      ->execute();
  }

  public function executeShow(sfWebRequest $request)
  {
    $this->gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id'));
    $this->forward404Unless($this->gca_obligacion);
  }

  public function executeNew(sfWebRequest $request)
  {
    $this->form = new GcaObligacionForm();
  }

  public function executeCreate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod('post'));

    $this->form = new GcaObligacionForm();

    $this->processForm($request, $this->form);

    $this->setTemplate('new');
  }

  public function executeEdit(sfWebRequest $request)
  {
    $this->forward404Unless($gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id')), sprintf('Object gca_obligacion does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaObligacionForm($gca_obligacion);
  }

  public function executeUpdate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod('post') || $request->isMethod('put'));
    $this->forward404Unless($gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id')), sprintf('Object gca_obligacion does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaObligacionForm($gca_obligacion);

    $this->processForm($request, $this->form);

    $this->setTemplate('edit');
  }

  public function executeDelete(sfWebRequest $request)
  {
    $request->checkCSRFProtection();

    $this->forward404Unless($gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id')), sprintf('Object gca_obligacion does not exist (%s).', $request->getParameter('id')));
    $gca_obligacion->delete();

    $this->redirect('frontInformeGestion/index');
  }

  public function executeImprimirInforme(sfWebRequest $request){
    $this->carteras = Doctrine::getTable('GcaCartera')
      ->createQuery('a')
      ->execute();
    $this->carteras=$this->getCarterasUsuario();
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $doctrine->query("ALTER SEQUENCE seq_imprimir_consecutivo RESTART WITH 1");
  }
  
  public function executeGetReporteByCartera(sfWebRequest $request){
    $this->reportes = Doctrine::getTable('GcaReportes')->findByIdCartera($request->getParameter('id_cartera'));
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $doctrine->query("ALTER SEQUENCE seq_imprimir_consecutivo RESTART WITH 1");
    $arr_reportes = array();
    $arr_reportes["registros"] = array();
    $i=3;
	 $arr_reportes["registros"][0]["nombre_archivo"] = 'gestion_general';
      $arr_reportes["registros"][0]["nombre"] = 'Gestion Diaria General';
	$arr_reportes["registros"][1]["nombre_archivo"] = 'inactividad_general';
      $arr_reportes["registros"][1]["nombre"] = 'Inactividad General';
	$arr_reportes["registros"][2]["nombre_archivo"] = 'reporte_llamadas';
      $arr_reportes["registros"][2]["nombre"] = 'Reporte de Gestion Telefonica';
    foreach($this->reportes as $reporte){
      $arr_reportes["registros"][$i]["nombre_archivo"] = $reporte->getNombreArchivo();
      $arr_reportes["registros"][$i]["nombre"] = $reporte->getNombre();
      $i++;
    }
    $arr_reportes["cant"] = $i;
    $this->json_reportes = json_encode($arr_reportes);
  }


  protected function processForm(sfWebRequest $request, sfForm $form)
  {
    $form->bind($request->getParameter($form->getName()));
    if ($form->isValid())
    {
      $gca_obligacion = $form->save();

      $this->redirect('frontInformeGestion/edit?id='.$gca_obligacion->getId());
    }
  }
  
  public function getCarterasUsuario(){
	$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
	$idEmpleado = $this->getUser()->getAttribute("usuario");
    $res=$doctrine->query("SELECT c.id,c.nombre FROM gca_cartera c INNER JOIN gca_funcionarios f ON c.id =ANY(string_to_array(f.carteras,',')) WHERE f.id=$idEmpleado ORDER BY c.nombre")->fetchAll();
	$carteras =array();
	$i=0;
	foreach($res as $cartera){
		$carteras[]=array("id"=>$cartera["id"],"nombre"=>$cartera["nombre"]);
	}
	//$carteras = explode(",",$res);
	return $carteras;
  }
  
  public function executeGetFuncionariosCartera(sfWebRequest $request){  
	$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
	$id_cartera=$request->getParameter("id_cartera");
	$sql="	SELECT DISTINCT f.id,f.nombre FROM gca_funcionarios f
			INNER JOIN gca_gestion g ON g.id_funcionario=f.id
			WHERE $id_cartera=ANY(string_to_array(carteras,',')) 
			AND f.nombre NOT LIKE '%Gerente%'
			ORDER BY nombre";
	$rows=$doctrine->query($sql)->fetchAll();	
	$arr_funcionarios = array();
    $arr_funcionarios["registros"] = array();
    $arr_funcionarios["registros"][0] = array();
    $arr_funcionarios["registros"][0]["id"] = 0;
      $arr_funcionarios["registros"][0]["nombre"] = "Todos los funcionarios";
    $i=1;
	
    foreach($rows as $funcionario){
      $arr_funcionarios["registros"][$i]["id"] = $funcionario["id"];
      $arr_funcionarios["registros"][$i]["nombre"] = $funcionario["nombre"];
      $i++;
    }
    $arr_funcionarios["cant"] = $i;
    echo json_encode($arr_funcionarios);exit;
  }
  
  
    public function executeGetAccionCartera(sfWebRequest $request){  
	$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
	$id_cartera=$request->getParameter("id_cartera");
	$sql="select * from gca_codigos_equivalentes where id_cartera=$id_cartera and id_padre is null order by descripcion";
	$rows=$doctrine->query($sql)->fetchAll();
	
	$arr_funcionarios = array();
    $arr_funcionarios["registros"] = array();
    $arr_funcionarios["registros"][0] = array();
    //$arr_funcionarios["registros"][0]["id"] = 0;
      //$arr_funcionarios["registros"][0]["nombre"] = "Todos los funcionarios";
    $i=0;
	
    foreach($rows as $funcionario){
      $arr_funcionarios["registros"][$i]["id"] = $funcionario["id"];
      $arr_funcionarios["registros"][$i]["nombre"] = $funcionario["descripcion"];
      $i++;
    }	
    $arr_funcionarios["cant"] = $i;
    echo json_encode($arr_funcionarios);exit;
  }

     public function executeGetEfectoAccion(sfWebRequest $request){  
	$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
	$id_cartera=$request->getParameter("id_cartera");
	$id_accion=$request->getParameter("id_accion");
	$sql="select * from gca_codigos_equivalentes where id_cartera=$id_cartera and id_padre=$id_accion order by descripcion";
	$rows=$doctrine->query($sql)->fetchAll();
	$arr_funcionarios = array();
    $arr_funcionarios["registros"] = array();
    $arr_funcionarios["registros"][0] = array();
    $i=0;
    foreach($rows as $funcionario){
      $arr_funcionarios["registros"][$i]["id"] = $funcionario["id"];
      $arr_funcionarios["registros"][$i]["nombre"] = $funcionario["descripcion"];
      $i++;
    }	
    $arr_funcionarios["cant"] = $i;
    echo json_encode($arr_funcionarios);exit;
  }
  public function executeCierremensual() {
        $this->setTemplate('cierremensual');   
    }
  public function executeInactivacion_consolidada() {
        $this->setTemplate('inactivacion_consolidada');   
    }
  public function executeInactivaciondeudorescartera() {
        $this->setTemplate('inactivaciondeudorescartera');   
    }
  public function executeInactivaciondeudoresconsolidada() {
        $this->setTemplate('inactivaciondeudoresconsolidada');   
    }
  public function executeInactivaciondeudoresdetallada() {
        $this->setTemplate('inactivaciondeudoresdetallada');   
    }
  public function executeCierremensualgca() {
        $this->setTemplate('cierremensualgca');      
    }
    public function executeInventarioalcorte() {
        $this->setTemplate('inventarioalcorte');   
    }
    public function executeConsultas() {
        $this->setTemplate('consultas');   
    }
    function cartera_lista() {
        $sql3 = "select id,nombre from gca_cartera order by nombre ";
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql3);
        return $cartera;
    }
    function sucursal_lista() {
        $sql3 = "select sucursal from gca_obligacion group by sucursal order by sucursal ";
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql3);
        return $cartera;
    }
    function asesor_lista() {
        $sql3 = " select employee.id,employee.name "
                . " from gca_datos_funcionarios "
                . " join employee on  employee.id=gca_datos_funcionarios.id_empleado"
                . " where gca_datos_funcionarios.credenciales like '%asesor%' ";
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql3);
        return $cartera;
    }
    function executeConsultasInsert($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $doctrine->query($sql);
    }

    function executeConsultasConsul($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $res = $doctrine->query($sql)->fetchAll();
        return $res;
    }
 
 }
