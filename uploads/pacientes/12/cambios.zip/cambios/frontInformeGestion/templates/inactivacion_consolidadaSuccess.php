<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<form id="form133" action="" method="">
    <table style="margin: 0 auto;width: 80%" border="0">
        <tr>
            <td width="80px">Estado</td>
            <td>
                <input type="hidden" name="action" id="action" value="inactivacion_consolidada">
                <select id="causal" name="causal">
                    <option></option>
                    <option>Cancelar</option>
                    <option>Inactivar</option>
                    <option>Activar</option>
                </select>
            </td>
            <td width="80px">
                <label>Fecha Inicial</label>
            </td>
            <td>
                <input type="text" id="fecha_ini" name="fecha_ini" class="fecha"/>
            </td>
        </tr>
        <tr>
            <td>Causales</td>
            <td>
                <select id="cusales" name="cusales">

                </select>
            </td>
            <td>
                <label>Fecha Final</label>
            </td>
            <td>
                <input type="text" id="fecha_fin" name="fecha_fin" class="fecha">
            </td>
        </tr>
    </table>
</form>
<div id="botones">
    <P ALIGN=center>
        <button id="limpiar">Limpiar</button>
        <button id="buscar">Generar</button>
    </P>
</div>

<table border="0" style="margin: 0 auto;width: 80%" id="cartera_obligacion" >
    <thead>
    <th>Estado</th>
    <th>Sucursal</th>
    <th>No (Activaciones, Inactivaciones o Canceladas)</th>
    <th>Saldo Total</th>
    <th>Saldo Capital</th>
    <th>Saldo Mora</th>
</thead>
<tbody id="resul_tabla">
    <tr><td colspan="6">Sin Datos</td></tr>
</tbody>
</table>
<script>
    $('.fecha').datepicker();
    $('#buscar').click(function() {
        var url = 'consultas';
        $.post(url, $('#form133').serialize())
                .done(function(msg) {
                    $('#resul_tabla *').remove();
                    $('#resul_tabla').html(msg);
                })
                .fail(function(msg) {
                    alert('Error de conexion por favor intentar mas tarde')
                })
    })
</script>
<style>
    .table_modal td{
        margin: 19px;
        padding: 10px;
    }
    table thead{
        color:#fff;
        background: rgb(39, 126, 180);
    }
    input{
        width: 50%;
    }
    select{
        width: 50%;
    }
    #resul_tabla tr:nth-child(even) { background: #ddd }
    #resul_tabla tr:nth-child(odd) { background: #fff}  
</style>