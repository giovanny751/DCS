<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<form id="form133" action="" method="">
    <table style="margin: 0 auto;width: 80%" border="0">
        <tr>
            <td width="80px">Estado</td>
            <td>
                <input type="hidden" name="action" id="action" value="inactivacion_detalle">
                <select id="estado" name="estado">
                    <option></option>
                    <option value="Canc">Cancelar</option>
                    <option value="Inact">Inactivar</option>
                    <option value="Act">Activar</option>
                </select>
            </td>
            <td width="80px">
                <label>Fecha Inicial</label>
            </td>
            <td>
                <input type="text" id="fecha_ini" name="fecha_ini" class="fecha"/>
            </td>
        </tr>
        <tr>
            <td>Causales</td>
            <td>
                <select id="cusales" name="cusales">
                    
                </select>
            </td>
            <td>
                <label>Fecha Final</label>
            </td>
            <td>
                <input type="text" id="fecha_fin" name="fecha_fin" class="fecha">
            </td>
        </tr>
        <tr>
            <td>Cartera</td>
            <td>
                <select  name="cartera[]" id="cartera" style="width: 50%" tabindex="1" multiple>    
                    <?php
                    $cartera = frontInformeGestionActions::cartera_lista();
                    foreach ($cartera as $car):
                        ?>
                        <option value="<?php echo $car['id'] ?>" <?php if ($datos[0]['cartera'] == $car['id']) echo "selected"; ?>><?php echo $car['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
</form>
<div id="botones">
    <P ALIGN=center>
        <button id="limpiar">Limpiar</button>
        <button id="buscar">Generar</button>
    </P>
</div>

<table border="0" style="margin: 0 auto;width: 80%" id="cartera_obligacion" >
    <thead>
    <th>Cartera</th>
    <th>Sucursal</th>
    <th>Cedula</th>
    <th>Nombre</th>
    <th>Saldo Total</th>
    <th>Saldo Capital</th>
    <th>Intereses mora</th>
    <th>Estado</th>
</thead>
<tbody id="resul_tabla">
    <tr><td colspan="8">Sin Datos</td></tr>
</tbody>
</table>
<script>
    $('.fecha').datepicker({
            dateFormat: "yy-mm-dd"
        });
    $('#buscar').click(function() {
        var url = 'consultas';
        $.post(url, $('#form133').serialize())
                .done(function(msg) {
                    $('#resul_tabla *').remove();
                    $('#resul_tabla').html(msg);
                })
                .fail(function(msg) {
                    alert('Error de conexion por favor intentar mas tarde')
                })
    });
    $('#estado').change(function(){
        var url = 'consultas';
        var action = 'buscar_causal';
        $.post(url, {estado:$('#estado').val(),action:action})
                .done(function(msg){
                    $('#cusales').html(msg);
                })
                .fail(function(){
                    
                })
    })
</script>
<style>
    .table_modal td{
        margin: 19px;
        padding: 10px;
    }
    table thead{
        color:#fff;
        background: rgb(39, 126, 180);
    }
    input{
        width: 50%;
    }
    select{
        width: 50%;
    }
    #resul_tabla tr:nth-child(even) { background: #ddd }
    #resul_tabla tr:nth-child(odd) { background: #fff}  
</style>