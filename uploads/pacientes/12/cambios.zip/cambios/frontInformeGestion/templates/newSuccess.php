<h1>New FrontInformeGestion</h1>

<?php include_partial('form', array('form' => $form)) ?>
