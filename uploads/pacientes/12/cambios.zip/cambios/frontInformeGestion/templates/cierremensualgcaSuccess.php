<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.css">
<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.js"></script>
<div style="width: 80%;margin: 0 auto;">
    <p><br></p>
    <form action="consultas" method="post" id="form1" target="_black">
        <div><input type="hidden" id="action" value="buscar_mensualgca" name="action"></div>
        <table width="100%" border="0">
            <tr>
                <td width="10%">
                    <b>Sucursales</b>
                </td>
                <td >
                    <table width="100%">
                        <tr>
                            <td width="40%">    
                                <select  name="sucursal" id="sucursal" style="width: 100%" tabindex="1" multiple>
                                    <?php
                                    $cartera = frontInformeGestionActions::sucursal_lista();
                                    foreach ($cartera as $car):
                                        ?>
                                        <option value="<?php echo $car['sucursal'] ?>"><?php echo $car['sucursal'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <td width="20%">
                        <center>
                            <button id="sucursal_pasar">»</button>
                            <button id="sucursal_quitar">«</button><br>
                            <button id="sucursal_pasartodos">Todo »</button>
                            <button id="sucursal_quitartodos">« Todo </button>   
                        </center>
                </td>
                <td width="40%">    
                    <select  name="sucursal2[]" id="sucursal2" style="width: 100%" tabindex="1" multiple>
                    </select>
                </td>
            </tr>
        </table>
        </td>
        </tr> 
        <tr>
            <td><b>Carteras</b></td>
            <td> 
                <table width="100%">
                    <tr>
                        <td  width="40%">
                            <select  name="cartera" id="cartera" style="width: 100%" tabindex="1" multiple>    
                                <?php
                                $cartera = frontInformeGestionActions::cartera_lista();
                                foreach ($cartera as $car):
                                    ?>
                                    <option value="<?php echo $car['id'] ?>" <?php if ($datos[0]['cartera'] == $car['id']) echo "selected"; ?>><?php echo $car['nombre'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td width="20%">
                    <center>
                        <button id="cartera_pasar">»</button>
                        <button id="cartera_quitar">«</button><br>
                        <button id="cartera_pasartodos">Todo »</button>
                        <button id="cartera_quitartodos">« Todo </button>   
                    </center>
            </td>
            <td width="40%">    
                <select  name="cartera2[]" id="cartera2" style="width: 100%" tabindex="1" multiple>    
                </select>
            </td>
        </tr>

        </table>
        </td>
        <tr>
            <td><b>Mes</b></td>
            <td>
                <input type="text" class="fecha" id="mes" name="mes" value="<?php echo date('Y-m'); ?>">
            </td>
        </tr>
        </tr>
        </table>
    </form>
    <table width="70%" style="margin: 0 auto" border="0">
        <tr>
            <td width="14%">&nbsp;</td>
            <td>
        <center>
            <div id="bu1">
                <button type="button" class="limpiarcampos" id="limpiarcampos">Limpiar</button>
                <button type="button" class="buscar" id="buscar">Buscar</button> 
                <button type="button" class="excel" id="excel">Excel</button>
            </div>
            <div id="bu2">Cargando...</div>
        </center>
        </td>
        </tr>
    </table>
    <p>
    <hr>
    <p>
    <div id="tabla"></div> 
</div>
<?php $color = array('#B9FF73', '#73B9FF', '#DC73FF', '#FF7373', '#B9FF73', '#73B9FF', '#DC73FF', '#FF7373'); ?>
<style>
    .table {
        overflow: hidden;
        border: 1px solid #d3d3d3;
        background: #fefefe;
        width: 70%;
        margin: 5% auto 0;
        border-radius:5px;
        box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
    }
    .table th, .table td {padding:18px 28px 18px; text-align:center; }
    .table th {padding-top:22px; text-shadow: 1px 1px 1px #fff; background:#e8eaeb;}
    .table td {border-top:1px solid #e0e0e0; border-right:1px solid #e0e0e0;}
    .table tr.odd-row td {background:#f6f6f6;}
    .table td.first, .table th.first {text-align:left}
    .table td.last {border-right:none;}

    .table td {
        background: -moz-linear-gradient(100% 25% 90deg, #fefefe, #f9f9f9);
        background: -webkit-gradient(linear, 0% 0%, 0% 25%, from(#f9f9f9), to(#fefefe));
    }
    .table tr.odd-row td {
        background: -moz-linear-gradient(100% 25% 90deg, #f6f6f6, #f1f1f1);
        background: -webkit-gradient(linear, 0% 0%, 0% 25%, from(#f1f1f1), to(#f6f6f6));
    }
    .table th {
        background: -moz-linear-gradient(100% 20% 90deg, #e8eaeb, #ededed);
        background: -webkit-gradient(linear, 0% 0%, 0% 20%, from(#ededed), to(#e8eaeb));
    }
    .table tr:first-child th.first {
        -moz-border-radius-topleft:5px;
        -webkit-border-top-left-radius:5px; /* Saf3-4 */
    }
    .table tr:first-child th.last {
        -moz-border-radius-topright:5px;
        -webkit-border-top-right-radius:5px; /* Saf3-4 */
    }
    .table tr:last-child td.first {
        -moz-border-radius-bottomleft:5px;
        -webkit-border-bottom-left-radius:5px; /* Saf3-4 */
    }
    .table tr:last-child td.last {
        -moz-border-radius-bottomright:5px;
        -webkit-border-bottom-right-radius:5px; /* Saf3-4 */
    }
</style>

<script>
    $(document).ready(function() {
        $('.fecha').datepicker({
            dateFormat: "yy-mm"
        });
        $('#mitable').DataTable();
    });
    $('#excel').click(function() {
        $('#action').val('excel_mensualgca');
        $('#form1').submit();
    });
    $('.limpiarcampos').click(function() {

        $('#sucursal2 option').each(function() {
            $(this).remove().appendTo('#sucursal');
        });
        $('#cartera2 option').each(function() {
            $(this).remove().appendTo('#cartera');
        });
        $('#asesor2 option').each(function() {
            $(this).remove().appendTo('#asesor');
        });
    });
    $('#buscar').click(function() {
        $('#action').val('buscar_mensualgca');
        $('#bu1').hide();
        $('#bu2').show();
        var url = 'consultas'
        $.post(url, $('#form1').serialize())
                .done(function(msg) {
                    $('#tabla').html(msg)
                    $('#bu2').hide();
                    $('#bu1').show();
                })
                .fail(function(msg) {
                    $('#bu2').hide();
                    $('#bu1').show();
                    alert('Error al Consultar')
                })
    })
    $('#bu2').hide();

    $('#sucursal_pasar').click(function() {
        return !$('#sucursal option:selected').remove().appendTo('#sucursal2');
    });
    $('#sucursal_quitar').click(function() {
        return !$('#sucursal2 option:selected').remove().appendTo('#sucursal');
    });
    $('#sucursal_pasartodos').click(function() {
        $('#sucursal option').each(function() {
            $(this).remove().appendTo('#sucursal2');
        });
        return false;
    });
    $('#sucursal_quitartodos').click(function() {
        $('#sucursal2 option').each(function() {
            $(this).remove().appendTo('#sucursal');
        });
        return false;
    });
//----------------------------------------------------------------------------
    $('#asesor_pasar').click(function() {
        return !$('#asesor option:selected').remove().appendTo('#asesor2');
    });
    $('#asesor_quitar').click(function() {
        return !$('#asesor2 option:selected').remove().appendTo('#asesor');
    });
    $('#asesor_pasartodos').click(function() {
        $('#asesor option').each(function() {
            $(this).remove().appendTo('#asesor2');
        });
        return false;
    });
    $('#asesor_quitartodos').click(function() {
        $('#asesor2 option').each(function() {
            $(this).remove().appendTo('#asesor');
        });
        return false;
    });
//----------------------------------------------------------------------------
    $('#cartera_pasar').click(function() {
        return !$('#cartera option:selected').remove().appendTo('#cartera2');
    });
    $('#cartera_quitar').click(function() {
        return !$('#cartera2 option:selected').remove().appendTo('#cartera');
    });
    $('#cartera_pasartodos').click(function() {
        $('#cartera option').each(function() {
            $(this).remove().appendTo('#cartera2');
        });
        return false;
    });
    $('#cartera_quitartodos').click(function() {
        $('#cartera2 option').each(function() {
            $(this).remove().appendTo('#cartera');
        });
        return false;
    });

</script>
<style>
    button {
        text-align: center;
        width: 80px;
    }
</style>