<table>
  <tbody>
    <tr>
      <th>Id:</th>
      <td><?php echo $gca_obligacion->getid() ?></td>
    </tr>
    <tr>
      <th>Sucursal:</th>
      <td><?php echo $gca_obligacion->getsucursal() ?></td>
    </tr>
    <tr>
      <th>Referencia:</th>
      <td><?php echo $gca_obligacion->getreferencia() ?></td>
    </tr>
    <tr>
      <th>Expedicion:</th>
      <td><?php echo $gca_obligacion->getexpedicion() ?></td>
    </tr>
    <tr>
      <th>Fecha envio:</th>
      <td><?php echo $gca_obligacion->getfecha_envio() ?></td>
    </tr>
    <tr>
      <th>Edad mora:</th>
      <td><?php echo $gca_obligacion->getedad_mora() ?></td>
    </tr>
    <tr>
      <th>Nombres:</th>
      <td><?php echo $gca_obligacion->getnombres() ?></td>
    </tr>
    <tr>
      <th>Apellidos:</th>
      <td><?php echo $gca_obligacion->getapellidos() ?></td>
    </tr>
    <tr>
      <th>Obligacion:</th>
      <td><?php echo $gca_obligacion->getobligacion() ?></td>
    </tr>
    <tr>
      <th>Producto:</th>
      <td><?php echo $gca_obligacion->getproducto() ?></td>
    </tr>
    <tr>
      <th>Capital:</th>
      <td><?php echo $gca_obligacion->getcapital() ?></td>
    </tr>
    <tr>
      <th>Saldo mora:</th>
      <td><?php echo $gca_obligacion->getsaldo_mora() ?></td>
    </tr>
    <tr>
      <th>Fecha liquidacion:</th>
      <td><?php echo $gca_obligacion->getfecha_liquidacion() ?></td>
    </tr>
    <tr>
      <th>Empresa:</th>
      <td><?php echo $gca_obligacion->getempresa() ?></td>
    </tr>
    <tr>
      <th>Profesion:</th>
      <td><?php echo $gca_obligacion->getprofesion() ?></td>
    </tr>
    <tr>
      <th>Ingreso:</th>
      <td><?php echo $gca_obligacion->getingreso() ?></td>
    </tr>
    <tr>
      <th>Fecha ultimo reporte:</th>
      <td><?php echo $gca_obligacion->getfecha_ultimo_reporte() ?></td>
    </tr>
    <tr>
      <th>Fecha retoma:</th>
      <td><?php echo $gca_obligacion->getfecha_retoma() ?></td>
    </tr>
    <tr>
      <th>Devuelto:</th>
      <td><?php echo $gca_obligacion->getdevuelto() ?></td>
    </tr>
    <tr>
      <th>Fecha devolucion:</th>
      <td><?php echo $gca_obligacion->getfecha_devolucion() ?></td>
    </tr>
    <tr>
      <th>Pago verificado:</th>
      <td><?php echo $gca_obligacion->getpago_verificado() ?></td>
    </tr>
    <tr>
      <th>Fecha pago verificado:</th>
      <td><?php echo $gca_obligacion->getfecha_pago_verificado() ?></td>
    </tr>
    <tr>
      <th>Estado:</th>
      <td><?php echo $gca_obligacion->getestado() ?></td>
    </tr>
    <tr>
      <th>Id localizacion:</th>
      <td><?php echo $gca_obligacion->getid_localizacion() ?></td>
    </tr>
    <tr>
      <th>Id cartera:</th>
      <td><?php echo $gca_obligacion->getid_cartera() ?></td>
    </tr>
    <tr>
      <th>Id funcionario:</th>
      <td><?php echo $gca_obligacion->getid_funcionario() ?></td>
    </tr>
    <tr>
      <th>Numero expediente:</th>
      <td><?php echo $gca_obligacion->getnumero_expediente() ?></td>
    </tr>
    <tr>
      <th>Id funcionario sugerido:</th>
      <td><?php echo $gca_obligacion->getid_funcionario_sugerido() ?></td>
    </tr>
    <tr>
      <th>Cedula:</th>
      <td><?php echo $gca_obligacion->getcedula() ?></td>
    </tr>
    <tr>
      <th>Contacto:</th>
      <td><?php echo $gca_obligacion->getcontacto() ?></td>
    </tr>
  </tbody>
</table>

<hr />

<a href="<?php echo url_for('frontInformeGestion/edit?id='.$gca_obligacion->getId()) ?>">Edit</a>
&nbsp;
<a href="<?php echo url_for('frontInformeGestion/index') ?>">List</a>
