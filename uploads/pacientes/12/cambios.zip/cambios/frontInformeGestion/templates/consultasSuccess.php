<?php
switch ($_POST['action']) {
    case 'excel_mensual':
        ob_flush();
        header('Content-type: application/vnd.ms-excel;charset=utf-8');
        header("Content-Disposition: attachment; filename=documento.xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        $table = 1;
    case 'buscar_mensual':
        if (empty($table))
            $table = 0;
        $where = " where 1=1 ";
        if (count($_POST['cartera2']) > 0) {
            $a = "";
            foreach ($_POST['cartera2'] as $s)
                $a.=$s . ",";
            $a = substr($a, 0, -1);
            $where.=" and gca_cartera.id in (" . $a . ")";
        }
        if (count($_POST['sucursal2']) > 0) {
            $a = "";
            foreach ($_POST['sucursal2'] as $s)
                $a.="'" . $s . "',";
            $a = substr($a, 0, -1);
            $where.=" and gca_obligacion.sucursal in (" . $a . ")";
        }
        if (count($_POST['mes']) > 0) {
            $where.=" and gca_pagos.fecha>'" . $_POST['mes'] . "-01 00:00:00' and gca_pagos.fecha<'" . $_POST['mes'] . "-30 23:59:59' ";
        } else {
            $where.=" and gca_pagos.fecha>'" . date('Y-m') . "-01 00:00:00' and gca_pagos.fecha<'" . date('Y-m-d') . " 23:59:59' ";
        }
        if (count($_POST['asesor2']) > 0) {
            $a = "";
            foreach ($_POST['asesor2'] as $s)
                $a.="'" . $s . "',";
            $a = substr($a, 0, -1);
            $where = " join gca_datos_funcionarios on gca_cartera.id=gca_datos_funcionarios.id_cartera $where and gca_datos_funcionarios.id in (" . $a . ")";
        }


        $sql = "select nombre cartera,sucursal,count(id) clientes,sum(saldo_capital) capital,sum(saldo_mora) saldo_mora
                from (
                select gca_cartera.nombre,gca_obligacion.sucursal,gca_obligacion.id,
                gca_obligacion.saldo_mora,gca_obligacion.saldo_capital
                from gca_obligacion
                join gca_obligaciones_pagos on gca_obligaciones_pagos.obligacion=gca_obligacion.obligacion
                join gca_cartera on gca_cartera.id=gca_obligacion.id_cartera 
                join gca_pagos on gca_pagos.id=gca_obligaciones_pagos.id_pago
                 $where) tabla1
                group by nombre,sucursal";
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
        foreach ($cartera as $value) {
            $titulo1[$value['sucursal']] = $value['saldo_mora'];
        }
        foreach ($cartera as $value) {
            $titulo2[$value['cartera']][$value['sucursal']] = $value['clientes'] . " :: " . $value['capital'] . " :: " . $value['saldo_mora'];
        }
//        $color=array('style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"');
        ?>

        <table border="<?php echo $table; ?>" width="100%" style="text-align: center" class="table">

            <tr>
                <td rowspan="2"><b>CARTERA</b></td>
                <?php
                $i = 0;
                foreach ($titulo1 as $key => $value) {
                    ?><td colspan="3" <?php echo $color[$i] ?> ><b><?php echo $encabesado[] = $key; ?></b></td><?php
                    $i++;
                }
                ?>
                <td colspan="3"><b>Total General</b></td>
            </tr>
            <tr>
                <?php
                $i = 0;
                foreach ($titulo1 as $key => $value) {
                    ?>
                    <th <?php echo $color[$i] ?>>Clientes</th> 
                    <th <?php echo $color[$i] ?>>Capital</th>
                    <th <?php echo $color[$i] ?>>Saldo Mora</th>
                    <?php
                    $i++;
                }
                ?>
                <th>Clientes</th>
                <th>Capital</th>
                <th>Saldo Mora</th>
            </tr>

            <?php
            foreach ($titulo2 as $key => $value) {
                ?><tr><td><?php echo $key; ?></td><?php
                    $i = 0;
                    $j = 0;
                    $k = 0;
                    $cliente = 0;
                    $capital = 0;
                    $saldo = 0;
                    $hh = 0;
                    foreach ($value as $key2 => $value2) {
                        for ($i = $j; $i < count($encabesado); $i++) {
                            if ($encabesado[$i] == $key2) {
                                $j = $i + 1;
                                $i = count($encabesado);
                                $value2 = explode(' :: ', $value2);
                                $cliente += $value2[0];
                                $capital += $value2[1];
                                $saldo += $value2[2];
                                ?><td <?php echo $color[$hh] ?>><?php echo number_format($value2[0]); ?></td><td <?php echo $color[$hh] ?>><?php echo number_format($value2[1]); ?></td><td <?php echo $color[$hh] ?>><?php echo number_format($value2[2]); ?></td><?php
                                if (!empty($rr[$key2])) {
                                    $cliente_total[$key2] = $value2[0];
                                    $capital_total[$key2] = $value2[1];
                                    $saldo_total[$key2] = $value2[2];
                                } else {
                                    $cliente_total[$key2] += $value2[0];
                                    $capital_total[$key2] += $value2[1];
                                    $saldo_total[$key2] += $value2[2];
                                }
                            } else {
                                ?><td <?php echo $color[$hh] ?>>&nbsp;</td><td <?php echo $color[$hh] ?>>&nbsp;</td><td <?php echo $color[$hh] ?>>&nbsp;</td><?php
                                    }
                                    $k++;
                                    $hh++;
                                }
                            }

                            for ($h = $k; $h < count($encabesado); $h++) {
                                ?><td <?php echo $color[$h] ?>>&nbsp;</td><td <?php echo $color[$h] ?>>&nbsp;</td><td <?php echo $color[$h] ?>>&nbsp;</td><?php
                        }
                        ?><td><?php echo number_format($cliente); ?></td><td><?php echo number_format($capital); ?></td><td><?php echo number_format($saldo); ?></td><?php
                    echo "</tr>";
                }
                echo "<tr><td>TOTAL</td>";
                $cliente_t = 0;
                $capital_t = 0;
                $saldo_t = 0;
                $cliente = 0;
                for ($i = 0; $i < count($saldo_total); $i++) {
                    echo "<td>" . number_format($cliente_total[$encabesado[$i]]) . "</td><td>" . number_format($capital_total[$encabesado[$i]]) . "</td><td>" . number_format($saldo_total[$encabesado[$i]]) . "</td>";
                    $cliente_t+=$cliente_total[$encabesado[$i]];
                    $capital_t+=$capital_total[$encabesado[$i]];
                    $saldo_t+=$saldo_total[$encabesado[$i]];
                }
                ?><td><?php echo number_format($cliente_t); ?></td><td><?php echo number_format($capital_t); ?></td><td><?php echo number_format($saldo_t); ?></td><?php
                echo "</tr>";
                ?>
        </table>
        <p><br></p>
        <?php
        die();
    case 'excel_mensualgca':
        ob_flush();
        header('Content-type: application/vnd.ms-excel;charset=utf-8');
        header("Content-Disposition: attachment; filename=documento.xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        $table = 1;
    case 'buscar_mensualgca':
        if (empty($table))
            $table = 0;
        $where = " where 1=1 ";
        if (count($_POST['cartera2']) > 0) {
            $a = "";
            foreach ($_POST['cartera2'] as $s)
                $a.=$s . ",";
            $a = substr($a, 0, -1);
            $where.=" and gca_cartera.id in (" . $a . ")";
        }
        if (count($_POST['sucursal2']) > 0) {
            $a = "";
            foreach ($_POST['sucursal2'] as $s)
                $a.="'" . $s . "',";
            $a = substr($a, 0, -1);
            $where.=" and gca_obligacion.sucursal in (" . $a . ")";
        }
        if (count($_POST['mes']) > 0) {
            $where.=" and gca_pagos.fecha>'" . $_POST['mes'] . "-01 00:00:00' and gca_pagos.fecha<'" . $_POST['mes'] . "-30 23:59:59' ";
        } else {
            $where.=" and gca_pagos.fecha>'" . date('Y-m') . "-01 00:00:00' and gca_pagos.fecha<'" . date('Y-m-d') . " 23:59:59' ";
        }
        if (count($_POST['asesor2']) > 0) {
            $a = "";
            foreach ($_POST['asesor2'] as $s)
                $a.="'" . $s . "',";
            $a = substr($a, 0, -1);
            $where = " join gca_datos_funcionarios on gca_cartera.id=gca_datos_funcionarios.id_cartera $where and gca_datos_funcionarios.id in (" . $a . ")";
        }


        $sql = "
                select gca_cartera.nombre cartera,gca_obligacion.sucursal, sum(gca_pagos.entidad) entidad, sum(gca_pagos.cpm) paz_salvos, 
                sum(gca_pagos.abogados) abogados, sum(gca_pagos.honorarios) honorarios, sum(gca_pagos.otros) otros, 
                sum(gca_pagos.iva) iva 
                from gca_obligacion
                join gca_cartera on gca_cartera.id=gca_obligacion.id_cartera 
                join gca_obligaciones_pagos on gca_obligaciones_pagos.obligacion=gca_obligacion.obligacion
                join gca_pagos on gca_pagos.id=gca_obligaciones_pagos.id_pago
                 $where 
                group by gca_cartera.nombre,gca_obligacion.sucursal";
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
        foreach ($cartera as $value) {
            $titulo1[$value['sucursal']] = $value['saldo_mora'];
        }
        foreach ($cartera as $value) {
            $titulo2[$value['cartera']][$value['sucursal']] = $value['entidad'] . " :: " . $value['paz_salvos'] . " :: " . $value['abogados'] . " :: " . $value['honorarios'] . " :: " . $value['otros'] . " :: " . $value['iva'];
        }
//        $color=array('style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"');
        ?>

        <table border="<?php echo $table; ?>" width="100%" style="text-align: center" class="table">

            <tr>
                <td rowspan="2"><b>CARTERA</b></td>
                <?php
                $i = 0;
                foreach ($titulo1 as $key => $value) {
                    ?><td colspan="6" <?php echo $color[$i] ?> ><b><?php echo $encabesado[] = $key; ?></b></td><?php
                    $i++;
                }
                ?>
                <td colspan="6"><b>Total General</b></td>
            </tr>
            <tr>
                <?php
                $i = 0;
                foreach ($titulo1 as $key => $value) {
                    ?>
                    <th <?php echo $color[$i] ?>>Entidad</th>
                    <th <?php echo $color[$i] ?>>Paz y salvos</th>
                    <th <?php echo $color[$i] ?>>Abogados</th>
                    <th <?php echo $color[$i] ?>>Honorarios</th>
                    <th <?php echo $color[$i] ?>>Otros</th>
                    <th <?php echo $color[$i] ?>>Iva</th>
                    <?php
                    $i++;
                }
                ?>
                <th <?php echo $color[$i] ?>>Entidad</th>
                <th <?php echo $color[$i] ?>>Paz y salvos</th>
                <th <?php echo $color[$i] ?>>Abogados</th>
                <th <?php echo $color[$i] ?>>Honorarios</th>
                <th <?php echo $color[$i] ?>>Otros</th>
                <th <?php echo $color[$i] ?>>Iva</th>
            </tr>

            <?php
            foreach ($titulo2 as $key => $value) {
                ?><tr><td><?php echo $key; ?></td><?php
                    $i = 0;
                    $j = 0;
                    $k = 0;
                    $entidad = 0;
                    $paz_salvos = 0;
                    $abogados = 0;
                    $honorarios = 0;
                    $otros = 0;
                    $iva = 0;
                    $hh = 0;
                    foreach ($value as $key2 => $value2) {
                        for ($i = $j; $i < count($encabesado); $i++) {
                            if ($encabesado[$i] == $key2) {
                                $j = $i + 1;
                                $i = count($encabesado);
                                $value2 = explode(' :: ', $value2);
                                $entidad += $value2[0];
                                $paz_salvos += $value2[1];
                                $abogados += $value2[2];
                                $honorarios += $value2[3];
                                $otros += $value2[4];
                                $iva += $value2[5];
                                ?>
                                <td <?php echo $color[$hh] ?>><?php echo number_format($value2[0]); ?></td>
                                <td <?php echo $color[$hh] ?>><?php echo number_format($value2[1]); ?></td>
                                <td <?php echo $color[$hh] ?>><?php echo number_format($value2[2]); ?></td>
                                <td <?php echo $color[$hh] ?>><?php echo number_format($value2[3]); ?></td>
                                <td <?php echo $color[$hh] ?>><?php echo number_format($value2[4]); ?></td>
                                <td <?php echo $color[$hh] ?>><?php echo number_format($value2[5]); ?></td>
                                <?php
                                if (!empty($rr[$key2])) {
                                    $entidad_total[$key2] = $value2[0];
                                    $paz_salvos_total[$key2] = $value2[1];
                                    $abogados_total[$key2] = $value2[2];
                                    $honorarios_total[$key2] = $value2[3];
                                    $otros_total[$key2] = $value2[4];
                                    $iva_total[$key2] = $value2[5];
                                } else {
                                    $entidad_total[$key2] += $value2[0];
                                    $paz_salvos_total[$key2] += $value2[1];
                                    $abogados_total[$key2] += $value2[2];
                                    $honorarios_total[$key2] += $value2[3];
                                    $otros_total[$key2] += $value2[4];
                                    $iva_total[$key2] += $value2[5];
                                }
                            } else {
                                ?><td <?php echo $color[$hh] ?>>&nbsp;</td>
                                <td <?php echo $color[$hh] ?>>&nbsp;</td>
                                <td <?php echo $color[$hh] ?>>&nbsp;</td>
                                <td <?php echo $color[$hh] ?>>&nbsp;</td>
                                <td <?php echo $color[$hh] ?>>&nbsp;</td>
                                <td <?php echo $color[$hh] ?>>&nbsp;</td>
                                <?php
                            }
                            $k++;
                            $hh++;
                        }
                    }

                    for ($h = $k; $h < count($encabesado); $h++) {
                        ?>
                        <td <?php echo $color[$h] ?>>&nbsp;</td>
                        <td <?php echo $color[$h] ?>>&nbsp;</td>
                        <td <?php echo $color[$h] ?>>&nbsp;</td>
                        <td <?php echo $color[$h] ?>>&nbsp;</td>
                        <td <?php echo $color[$h] ?>>&nbsp;</td>
                        <td <?php echo $color[$h] ?>>&nbsp;</td>
                        <?php
                    }
                    ?>
                    <td><?php echo number_format($entidad); ?></td>
                    <td><?php echo number_format($paz_salvos); ?></td>
                    <td><?php echo number_format($abogados); ?></td>
                    <td><?php echo number_format($honorarios); ?></td>
                    <td><?php echo number_format($otros); ?></td>
                    <td><?php echo number_format($iva); ?></td>
                    <?php
                    echo "</tr>";
                }
                echo "<tr><td>TOTAL</td>";
                $entidad_t = 0;
                $paz_salvos_t = 0;
                $abogados_t = 0;
                $honorarios_t = 0;
                $otros_t = 0;
                $iva_t = 0;
                for ($i = 0; $i < count($entidad_total); $i++) {
                    echo
                    "<td>" . number_format($entidad_total[$encabesado[$i]]) . "</td>"
                    . "<td>" . number_format($paz_salvos_total[$encabesado[$i]]) . "</td>"
                    . "<td>" . number_format($abogados_total[$encabesado[$i]]) . "</td>"
                    . "<td>" . number_format($honorarios_total[$encabesado[$i]]) . "</td>"   
                    . "<td>" . number_format($otros_total[$encabesado[$i]]) . "</td>"
                    . "<td>" . number_format($iva_total[$encabesado[$i]]) . "</td>";
                    $entidad_t+=$entidad_total[$encabesado[$i]];
                    $paz_salvos_t+=$paz_salvos_total[$encabesado[$i]];
                    $abogados_t+=$abogados_total[$encabesado[$i]];
                    $honorarios_t+=$honorarios_total[$encabesado[$i]];
                    $otros_t+=$otros_total[$encabesado[$i]];
                    $iva_t+=$iva_total[$encabesado[$i]];
                }
                ?>
                <td><?php echo number_format($entidad_t); ?></td>
                <td><?php echo number_format($paz_salvos_t); ?></td>
                <td><?php echo number_format($abogados_t); ?></td>
                <td><?php echo number_format($honorarios_t); ?></td>
                <td><?php echo number_format($otros_t); ?></td>
                <td><?php echo number_format($iva_t); ?></td>
                <?php
                echo "</tr>";
                ?>
        </table>
        <p><br></p>
        <?php
        die();
        break;
    case 'excel_cierre':
        ob_flush();
        header('Content-type: application/vnd.ms-excel;charset=utf-8');
        header("Content-Disposition: attachment; filename=documento.xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        $table = 1;
    case 'buscar_cierre':
        if (empty($table))
            $table = 0;
        $where = " where 1=1 ";
        if (count($_POST['cartera2']) > 0) {
            $a = "";
            foreach ($_POST['cartera2'] as $s)
                $a.=$s . ",";
            $a = substr($a, 0, -1);
            $where.=" and gca_cartera.id in (" . $a . ")";
        }
        if (count($_POST['sucursal2']) > 0) {
            $a = "";
            foreach ($_POST['sucursal2'] as $s)
                $a.="'" . $s . "',";
            $a = substr($a, 0, -1);
            $where.=" and gca_obligacion.sucursal in (" . $a . ")";
        }
        if (count($_POST['mes']) > 0) {
            $d = $_POST['mes'];
            $d = explode('-', $d);
            $diasMes = UltimoDia($d[0], $d[1]);
            $where.=" and gca_pagos.fecha>'" . $_POST['mes'] . "-01 00:00:00' and gca_pagos.fecha<'" . $_POST['mes'] . "-$diasMes 23:59:59' ";
        } else {
            $where.=" and gca_pagos.fecha>'" . date('Y-m') . "-01 00:00:00' and gca_pagos.fecha<'" . date('Y-m-d') . " 23:59:59' ";
        }
        if (count($_POST['asesor2']) > 0) {
            $a = "";
            foreach ($_POST['asesor2'] as $s)
                $a.="'" . $s . "',";
            $a = substr($a, 0, -1);
            $where = " join gca_datos_funcionarios on gca_cartera.id=gca_datos_funcionarios.id_cartera $where and gca_datos_funcionarios.id in (" . $a . ")";
        }


        $sql = "select nombre cartera,sucursal,count(id) clientes,sum(saldo_capital) capital,sum(saldo_mora) saldo_mora,sum(entidad) entidad
                from (
                select gca_cartera.nombre,gca_obligacion.sucursal,gca_obligacion.id,
                gca_obligacion.saldo_mora,gca_obligacion.saldo_capital,gca_pagos.entidad
                from gca_obligacion
                join gca_cartera on gca_cartera.id=gca_obligacion.id_cartera 
                join gca_obligaciones_pagos on gca_obligaciones_pagos.obligacion=gca_obligacion.obligacion
                join gca_pagos on gca_pagos.id=gca_obligaciones_pagos.id_pago
                 $where) tabla1
                group by nombre,sucursal";
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
        foreach ($cartera as $value) {
            $titulo1[$value['sucursal']] = $value['saldo_mora'];
        }
        foreach ($cartera as $value) {
            $titulo2[$value['cartera']][$value['sucursal']] = $value['entidad'];
        }
//        $color=array('style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"','style="background:#B9FF73"','style="background:#73B9FF"','style="background:#DC73FF"','style="background:#FF7373"');
        ?>

        <table border="<?php echo $table; ?>" width="100%" style="text-align: center" class="table">

            <tr>
                <td rowspan="1"><b>CARTERA</b></td>
                <?php
                $i = 0;
                foreach ($titulo1 as $key => $value) {
                    ?><td colspan="1" <?php echo $color[$i] ?> ><b><?php echo $encabesado[] = $key; ?></b></td><?php
                    $i++;
                }
                ?>
                <td colspan="1"><b>Total General</b></td>
            </tr>

            <?php
            foreach ($titulo2 as $key => $value) {
                ?><tr><td><?php echo $key; ?></td><?php
                    $i = 0;
                    $j = 0;
                    $k = 0;
                    $cliente = 0;
                    $capital = 0;
                    $saldo = 0;
                    $hh = 0;
                    foreach ($value as $key2 => $value2) {
                        for ($i = $j; $i < count($encabesado); $i++) {
                            if ($encabesado[$i] == $key2) {
                                $j = $i + 1;
                                $i = count($encabesado);
                                $value2 = explode(' :: ', $value2);
                                $cliente += $value2[0];
                                $capital += $value2[1];
                                $saldo += $value2[2];
                                ?><td <?php echo $color[$hh] ?>><?php echo number_format($value2[0]); ?></td><?php
                                if (!empty($rr[$key2])) {
                                    $cliente_total[$key2] = $value2[0];
                                    $capital_total[$key2] = $value2[1];
                                    $saldo_total[$key2] = $value2[2];
                                } else {
                                    $cliente_total[$key2] += $value2[0];
                                    $capital_total[$key2] += $value2[1];
                                    $saldo_total[$key2] += $value2[2];
                                }
                            } else {
                                ?><td <?php echo $color[$hh] ?>>&nbsp;</td><?php
                            }
                            $k++;
                            $hh++;
                        }
                    }

                    for ($h = $k; $h < count($encabesado); $h++) {
                        ?><td <?php echo $color[$h] ?>>&nbsp;</td><?php
                        }
                        ?><td><?php echo number_format($cliente); ?></td><?php
                    echo "</tr>";
                }
                echo "<tr><td>TOTAL</td>";
                $cliente_t = 0;
                $capital_t = 0;
                $saldo_t = 0;
                $cliente = 0;
                for ($i = 0; $i < count($saldo_total); $i++) {
                    echo "<td>" . number_format($cliente_total[$encabesado[$i]]) . "</td>";
                    $cliente_t+=$cliente_total[$encabesado[$i]];
                    $capital_t+=$capital_total[$encabesado[$i]];
                    $saldo_t+=$saldo_total[$encabesado[$i]];
                }
                ?><td><?php echo number_format($cliente_t); ?></td><?php
                echo "</tr>";
                ?>
        </table>
        <p><br></p>
        <?php
        die();
        break;
    case 'inactivacion_consolidada':
        $where=" where 1=1 ";
        if($_POST['estado']!=""){
            $where.=" and con.estado_causal like '%".$_POST['estado']."%'";
//            $where.=" and ss.estado='".$_POST['estado']."'";
        }
        if($_POST['fecha_ini']!=""){
            $where.=" and con.fecha_actualizacion_causal > '".$_POST['fecha_ini']."'";
        }
        if($_POST['fecha_fin']!=""){
            $where.=" and con.fecha_actualizacion_causal < '".$_POST['fecha_fin']."'";
        }
        if($_POST['cusales']!=""){
            $where.=" and con.id_causal='".$_POST['cusales']."'";
        }
        if (count($_POST['cartera']) > 0) {
            $a = "";
            foreach ($_POST['cartera'] as $s)
                $a.=$s . ",";
            $a = substr($a, 0, -1);
            $where.=" and gca_cartera.id in (" . $a . ")";
        }
        
        
        $sql="select  con.estado_causal estado,con.sucursal,count(con.sucursal) cantidad
            ,sum(saldo_mora) saldo_total, sum(con.saldo_capital) capital_total, sum(con.interes_mora) saldo_mora
from gca_obligacion con
left join gca_obligacion_causales ss on ss.id=con.estado 
join gca_cartera on gca_cartera.id=con.id_cartera $where 
group by con.estado_causal,con.sucursal";
//        die();
        
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
        $html='';
        foreach ($cartera as $value) {
        $html.='<tr>'
                . '<td>'.$value['estado'].'</td>'
                . '<td>'.$value['sucursal'].'</td>'
                . '<td>'.number_format($value['cantidad']).'</td>'
                . '<td>'.number_format($value['saldo_total']).'</td>'
                . '<td>'.number_format($value['capital_total']).'</td>'
                . '<td>'.number_format($value['saldo_mora']).'</td>'
                . '</tr>';      
        $sum1+=$value['cantidad'];
        $sum2+=$value['saldo_total'];
        $sum3+=$value['capital_total'];
        $sum4+=$value['saldo_mora'];
        }
        $html.='<tr>'
                . '<td colspan="2">TOTAL</td>'
                . '<td>'.number_format($sum1).'</td>'
                . '<td>'.number_format($sum2).'</td>'
                . '<td>'.number_format($sum3).'</td>'
                . '<td>'.number_format($sum4).'</td>'
                . '</tr>';    
        echo $html;
        break;
    case 'inactivacion_consolidada_cartera':
        $where=" where 1=1 ";
        if($_POST['estado']!=""){
            $where.=" and con.estado_causal like '%".$_POST['estado']."%'";
//            $where.=" and ss.estado='".$_POST['estado']."'";
        }
        if($_POST['fecha_ini']!=""){
            $where.=" and con.fecha_actualizacion_causal > '".$_POST['fecha_ini']."'";
        }
        if($_POST['fecha_fin']!=""){
            $where.=" and con.fecha_actualizacion_causal < '".$_POST['fecha_fin']."'";
        }
        if($_POST['cusales']!=""){
            $where.=" and con.id_causal='".$_POST['cusales']."'";
        }
        if (count($_POST['cartera']) > 0) {
            $a = "";
            foreach ($_POST['cartera'] as $s)
                $a.=$s . ",";
            $a = substr($a, 0, -1);
            $where.=" and gca_cartera.id in (" . $a . ")";
        }
        
        
         $sql="select  con.estado_causal estado,con.sucursal,gca_cartera.nombre cartera,
            count(con.sucursal) cantidad
            ,sum(saldo_mora) saldo_total, sum(con.saldo_capital) capital_total, sum(con.interes_mora) saldo_mora
from gca_obligacion con
left join gca_obligacion_causales ss on ss.id=con.estado 
join gca_cartera on gca_cartera.id=con.id_cartera $where 
group by con.estado_causal,con.sucursal,gca_cartera.nombre";
//        die();
        
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
        $html='';
        foreach ($cartera as $value) {
        $html.='<tr>'
                . '<td>'.$value['estado'].'</td>'
                . '<td>'.$value['sucursal'].'</td>'
                . '<td>'.$value['cartera'].'</td>'
                . '<td>'.number_format($value['cantidad']).'</td>'
                . '<td>'.number_format($value['saldo_total']).'</td>'
                . '<td>'.number_format($value['capital_total']).'</td>'
                . '<td>'.number_format($value['saldo_mora']).'</td>'
                . '</tr>';      
        $sum1+=$value['cantidad'];
        $sum2+=$value['saldo_total'];
        $sum3+=$value['capital_total'];
        $sum4+=$value['saldo_mora'];
        }
        $html.='<tr>'
                . '<td colspan="3">TOTAL</td>'
                . '<td>'.number_format($sum1).'</td>'
                . '<td>'.number_format($sum2).'</td>'
                . '<td>'.number_format($sum3).'</td>'
                . '<td>'.number_format($sum4).'</td>'
                . '</tr>';    
        echo $html;
        break;
    case 'inactivacion_detalle':
        $where=" where 1=1 ";
        if($_POST['estado']!=""){
            $where.=" and con.estado_causal like '%".$_POST['estado']."%'";
//            $where.=" and ss.estado='".$_POST['estado']."'";
        }
        if($_POST['fecha_ini']!=""){
            $where.=" and con.fecha_actualizacion_causal > '".$_POST['fecha_ini']."'";
        }
        if($_POST['fecha_fin']!=""){
            $where.=" and con.fecha_actualizacion_causal < '".$_POST['fecha_fin']."'";
        }
        if($_POST['cusales']!=""){
            $where.=" and con.id_causal='".$_POST['cusales']."'";
        }
        if (count($_POST['cartera']) > 0) {
            $a = "";
            foreach ($_POST['cartera'] as $s)
                $a.=$s . ",";
            $a = substr($a, 0, -1);
            $where.=" and gca_cartera.id in (" . $a . ")";
        }
        
        $sql="select  gca_cartera.nombre cartera,con.sucursal,con.cedula,con.nombres,con.estado_causal estado,
            sum(saldo_mora) saldo_total, sum(con.saldo_capital) capital_total, sum(interes_mora) saldo_mora
from gca_obligacion con
left join gca_obligacion_causales ss on ss.id=con.estado 
join gca_cartera on gca_cartera.id=con.id_cartera  $where 
group by gca_cartera.nombre,con.sucursal,con.cedula,con.nombres,con.estado_causal";
//        die();
        $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
        $html='';
        $sum1=0;
        $sum2=0;
        $sum3=0;
        $sum4=0;
        foreach ($cartera as $value) {
        $html.='<tr>'
                . '<td>'.$value['cartera'].'</td>'
                . '<td>'.$value['sucursal'].'</td>'
                . '<td>'.$value['cedula'].'</td>'
                . '<td>'.$value['nombres'].'</td>'
                . '<td>'.number_format($value['saldo_total']).'</td>'
                . '<td>'.number_format($value['capital_total']).'</td>'
                . '<td>'.number_format($value['saldo_mora']).'</td>'
                . '<td>'.$value['estado'].'</td>'
                . '</tr>';    
        
        $sum2+=$value['saldo_total'];
        $sum3+=$value['capital_total'];
        $sum4+=$value['saldo_mora'];
        }
        $html.='<tr>'
                . '<td colspan="4">TOTAL</td>'
                . '<td>'.number_format($sum2).'</td>'  
                . '<td>'.number_format($sum3).'</td>'
                . '<td>'.number_format($sum4).'</td>'
                . '<td>&nbsp;</td>'
                . '</tr>';    
        echo $html;
        break;
        case 'buscar_causal':
            echo $sql="select * from gca_obligacion_causales where estado like '%".$_POST['estado']."%'";
            $cartera = frontInformeGestionActions::executeConsultasConsul($sql);
            echo "<option value=''></option>";
            foreach ($cartera as $value) {
                echo "<option value='".$value['id']."'>".$value['causal']."</option>";
            }
        break;
}

function UltimoDia($anho, $mes) {
    if (((fmod($anho, 4) == 0) and ( fmod($anho, 100) != 0)) or ( fmod($anho, 400) == 0)) {
        $dias_febrero = 29;
    } else {
        $dias_febrero = 28;
    }
    switch ($mes) {
        case 01: return 31;
            break;
        case 02: return $dias_febrero;
            break;
        case 03: return 31;
            break;
        case 04: return 30;
            break;
        case 05: return 31;
            break;
        case 06: return 30;
            break;
        case 07: return 31;
            break;
        case 08: return 31;
            break;
        case 09: return 30;
            break;
        case 10: return 31;
            break;
        case 11: return 30;
            break;
        case 12: return 31;
            break;
    }
        
}
?>
