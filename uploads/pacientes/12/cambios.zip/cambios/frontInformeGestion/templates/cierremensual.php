<p><br></p> 
<form method="post" id="f1">
    <input type="hidden" name="cierre" id="cierre" value="cierre">
<table>  
    <tr> 
        <td>Sucursal</td>  
        <td>
            <select id="sucursal" name="sucursal">
                
            </select>
        </td>
        <td>Cartera</td>
        <td>
            <select id="cartera" name="cartera"></select>
        </td>
        <td>Mes</td>
        <td>
            <input type="date" name="mes" id="mes">
        </td>
        <td>
            <button type="button" id="buscar">Buscar</button>
        </td>
    </tr>
</table>
</form>    
<hr>
<table>
    <thead>
        <th></th>
    </thead>
    <tbody>
        <tr>
            <td></td>
        </tr>
    </tbody>
</table>
<script>
    $('#buscar').click(function(){
        
        var url = "consultas";
        
        $.post(url,$('#f1').serialize())
                .done(function(msg){
            
                })
                .fail(function(msg){
            
                })        
    });
</script>    