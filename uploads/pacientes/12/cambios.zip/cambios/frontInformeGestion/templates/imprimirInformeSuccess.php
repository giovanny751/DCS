<?php use_helper('Red') ?>
<script type="text/javascript">
  function enviarFormulario(){
    $.getJSON("getReporteByCartera/id_cartera/0",function(data){
      document.form1.submit();
      return true;
    })
    return false;
  }
</script>

<?php 
$dir_reportes=redireccion_reportes();
?>

<form name="form1" action="<?php echo $dir_reportes?>" method="post" onsubmit="enviarFormulario();return false;">
<table>
  <tbody>
    <tr>
      <td><!--<input type="hidden" name="reporte" id="reporte" value="gestion_devolucion" />--></td>
    </tr>
    <tr>
      <th>Cartera: </th>  
      <td>
        <select name="cartera" id="cartera" onchange="traerDatos();traerDatos2();traerAccion()">
	  <option value=''>Seleccione....</option>
        <?php foreach($carteras as $cartera):?>
        <option value="<?php echo $cartera["id"]?>"><?php echo $cartera["nombre"]?></option>
        <?php endforeach;?>
        </select>
      </td>
    </tr>

    <tr>
      <th>Accion: </th>  
      <td>
        <select name="acciones" id="acciones" onchange="traerEfecto();">
	  <option value=''>Seleccione....</option>
        <?php foreach($acciones as $accion):?>
        <option value="<?php echo $accion["id"]?>"><?php echo $accion["nombre"]?></option>
        <?php endforeach;?>
        </select>
      </td>
	</tr>

    <tr>
      <th>Efecto: </th>
      <td>
        <select name="efectos" id="efectos" >
	  <option value=''>Seleccione....</option>
        <?php foreach($efectos as $efecto):?>
        <option value="<?php echo $efecto["id"]?>"><?php echo $efecto["nombre"]?></option>
        <?php endforeach;?>
        </select>
      </td>
  
    </tr>


	<tr>
      <th>Funcionario: </th>
      <td>
        <select name="funcionario" id="funcionario">
	</select>
      </td>
    </tr>
    <tr>
      <th>Informe: </th>
      <td>
        <select name="reporte" id="reporte">
	</select>
      </td>
    </tr>
	<tr>
		<th>Desde:</th>
		<td>
        <input type="text" name="fechadesde__String" id="fechadesde_String" value="<?php echo date("Y-m-d",time()-86400)." 16:00"?>" />
      </td>
	</tr>
	<tr>
		<th>Hasta:</th>
		<td>
        <input type="text" name="fechahasta__String" id="fechahasta_String" value="<?php echo date("Y-m-d")." 16:00"?>" />
      </td>
	</tr>
    <tr>
    
     
      <td><input type="submit" name="imprmir" value="Imprimir" class="enlace" /></td>
      
    </tr>
  </tbody>
</table>
</form>
<script> 

 function traerDatos(){        
    cartera = document.getElementById("cartera");
	var reportes = document.getElementById("reporte");
	reportes.options.length = 0;	
	if (cartera.value != ''){
				// .getJSON forma de consulta con acceso a base de datos
				$.getJSON("getReporteByCartera/id_cartera/"+cartera.value,
				function(data){				  
				  $.each(data.registros, function(i,item){
					reportes.options[i]=new Option(item.nombre, item.nombre_archivo);
				  });
				});
	}
 }
 
  function traerDatos2(){        
    cartera = document.getElementById("cartera");
	var funcionarios = document.getElementById("funcionario");
	funcionarios.options.length = 0;	
	if (cartera.value != ''){
				
				$.getJSON("getFuncionariosCartera/id_cartera/"+cartera.value,
				function(data){				  
				  $.each(data.registros, function(i,item){
					funcionarios.options[i]=new Option(item.nombre, item.id);
				  });
				});
	}
 }

 function traerAccion()
 {  
 cartera = document.getElementById("cartera");
 if (cartera.value != ''){			
				$.getJSON("getAccionCartera/id_cartera/"+cartera.value,
				function(data){				  
				  $.each(data.registros, function(i,item){
					acciones.options[i]=new Option(item.nombre, item.id);
				  });
				});
	}
 }
 
 
function traerEfecto()
 { 
 cartera = document.getElementById("cartera");
 accion = document.getElementById("acciones");
 if (accion.value != ''){			
				$.getJSON("getEfectoAccion/id_accion/"+accion.value+"/id_cartera/"+cartera.value,
				function(data){				  
				  $.each(data.registros, function(i,item){
					efectos.options[i]=new Option(item.nombre, item.id);
				  });
				});
	}
 
 }
 
</script>

<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d %H:%M");
    }

    Calendar.setup({
        inputField     :    "fechadesde_String",
        ifFormat       :    "%Y-%m-%d %H:%M",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	Calendar.setup({
        inputField     :    "fechahasta_String",
        ifFormat       :    "%Y-%m-%d %H:%M",
        showsTime      :    true,
        timeFormat     :    "24"
    });
</script>
