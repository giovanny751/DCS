<?php

/**
 * ExtensionFuncionario actions.
 *
 * @package    prejuridico
 * @subpackage ExtensionFuncionario
 * @author     Gerson Barbosa
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
use Symfony\Component\HttpFoundation\Response;

class CondonacionesActions extends sfActions {

    public function executeIndex() {
        $this->credenciales = $this->permisos();
        $this->setTemplate('index');
    }

    public function permisos() {
        $id_usuario = $this->getUser()->isAuthenticated();
        $sql = "select credenciales from gca_datos_funcionarios where credenciales=" . $id_usuario;
        $credenciales = CondonacionesActions::executeConsultasConsul($sql);
        return $credenciales[0]['credenciales'];
    }

    public function executeConsultasolicitud() {
        $this->anular();
        $sql = "select id,nombre from gca_cartera";
        $this->cartera = CondonacionesActions::executeConsultasConsul($sql);
        $sql2 = "select est_id,est_estado from gca_estados";
        $this->estado = CondonacionesActions::executeConsultasConsul($sql2);
        $this->setTemplate('consultasolicitud');
    }

    function anular() {
        
        if (isset($_POST['number2'])) {
            $sql = "update gca_solicitud_condonacion set estado=7 where id=" . $_POST['number2'];
            CondonacionesActions::executeConsultasInsert($sql);
            $sql = " select obligacion from gca_detalle_solicitud where id_solicitud_condonacion=" . $_POST['number2'];
            $datos = CondonacionesActions::executeConsultasConsul($sql);
            foreach ($datos as $value) {
                $sql = "update gca_obligacion set bloqueada=0 where obligacion='" . $value['obligacion'] . "'";
                CondonacionesActions::executeConsultasInsert($sql);
            }
            echo "<script>location.href='consultasolicitud'</script>";
//        die();
        }
    }

    public function permisos_usuarios() {
        $permisos = $this->getUser()->getAttribute('usuario');
        $sql2 = "select credenciales from gca_datos_funcionarios where id_empleado=$permisos";
        $credenciales = CondonacionesActions::executeConsultasConsul($sql2);
        $credenciales = $credenciales[0]['credenciales'];
        return $credenciales;
    }

    public function nombre_usuarios($permisos = NULL) {
        if (empty($permisos))
            $permisos = $this->getUser()->getAttribute('usuario');
        $sql2 = "select name from employee  where id=$permisos";
        $credenciales = CondonacionesActions::executeConsultasConsul($sql2);
        $name = $credenciales[0]['name'];
        return $name;
    }

    public function executeNuevasolicitud() {
        $credenciales = $this->permisos_usuarios();
        $sql2 = "select tasa_interes from gca_configuracion_sistema";
        $iva = CondonacionesActions::executeConsultasConsul($sql2);
        $this->iva = $iva[0]['tasa_interes'];

        $this->id_cartera = $this->getUser()->getAttribute("id_cartera");
        $this->editar = 1;
        $this->versolicitud = "";
        $sql = "select * from gca_estados where est_id in (1,2) order by est_id";
        $this->estados = CondonacionesActions::executeConsultasConsul($sql);
        if (!empty($_GET['number'])) {
            $_POST['number'] = $_GET['number'];
            $_POST['versolicitud'] = $_GET['versolicitud'];
        }

        if (!empty($_POST['number'])) {
            $this->numero = $_POST['number'];
            $this->versolicitud = $_POST['versolicitud'];
            $sqldatos = "select 
            gca_cartera.id cartera
           ,gca_solicitud_condonacion.numero
           ,gca_solicitud_condonacion.total_acuerdo
           ,gca_deudor.nombres
           ,gca_cartera.nombre
           ,gca_solicitud_condonacion.f_creacion
           ,gca_solicitud_condonacion.f_aprobacion
           ,gca_solicitud_condonacion.honorarios
           ,gca_solicitud_condonacion.condonacion_capital
           ,gca_solicitud_condonacion.cancelar_capital
           ,gca_solicitud_condonacion.condonacion_intereses
           ,gca_solicitud_condonacion.decision_comite
           ,gca_solicitud_condonacion.aprobado_director
           ,gca_solicitud_condonacion.aprobado_juridica
           ,gca_estados.est_estado estado
           ,gca_solicitud_condonacion.antecedentes
           ,gca_solicitud_condonacion.propuesta_cliente
           ,gca_solicitud_condonacion.investigacion_cleinte
           ,gca_solicitud_condonacion.investigacion_bienes
           ,gca_solicitud_condonacion.tipo_garantia
           ,gca_solicitud_condonacion.reporte_visita
           ,gca_solicitud_condonacion.concepto_operador
           ,gca_solicitud_condonacion.estado_proceso
           ,gca_solicitud_condonacion.aprobado_director 	
           ,gca_solicitud_condonacion.aprobado_juridica 		
           ,gca_solicitud_condonacion.decision_comite 	
           ,gca_solicitud_condonacion.concepto_juridico
           ,gca_solicitud_condonacion.medidas_cautelares
           ,gca_solicitud_condonacion.observaciones_comite
           ,gca_solicitud_condonacion.creado_por
           ,gca_solicitud_condonacion.abogado
           ,gca_solicitud_condonacion.porcen_interes
           ,gca_estados.est_id idestado
           ,gca_solicitud_condonacion.cedula"
                    . " from gca_solicitud_condonacion"
                    . " join gca_deudor on gca_deudor.cedula = gca_solicitud_condonacion.cedula"
                    . " join gca_cartera on gca_cartera.id = gca_solicitud_condonacion.id_cartera "
                    . " join gca_estados on gca_estados.est_id = gca_solicitud_condonacion.estado "
                    . " where  gca_solicitud_condonacion.numero = '" . $_POST['number'] . "' ";
            $this->datos = CondonacionesActions::executeConsultasConsul($sqldatos);
            $this->nombre = $this->nombre_usuarios($this->datos[0]['creado_por']);
            $this->editar = 2;
            $sqlacuerdo = "select * from gca_acuerdo_condonacion where con_id = " . $_POST['number'];
            $this->acuerdo = CondonacionesActions::executeConsultasConsul($sqlacuerdo);

            $sqlacuerdo = "select * from gca_detalle_solicitud where id_solicitud_condonacion = " . $_POST['number'];
            $datos = CondonacionesActions::executeConsultasConsul($sqlacuerdo);
            $html = "";
            $i = 0;
            $saldo_capital = 0;
            $capital = 0;
            $interes = 0;
            $condonacion_capital = 0;
            $total_condonacion = 0;
            $saldo_credito = 0;
            $honorarios = 0;
            $pago_total = 0;
            $condonacion_intereses = 0;
            foreach ($datos as $acciones) {
                $html.='<tr>'
                        . '<td>' . $acciones['obligacion'] . '<div><input type="text" class="num0' . $i . '" name="num_obligacion[]" value="' . $acciones['obligacion'] . '" style="display:none"></div></td>'// no obligacion 
                        . '<td>' . number_format($acciones['saldo_total']) . '<div><input type="text" class="num1' . $i . '" name="num_saldo_total[]"  value="' . $acciones['saldo_total'] . '" style="display:none"></div></td>'// saldo total
                        . '<td>' . number_format($acciones['capital']) . '<div><input type="text" class="num2' . $i . '" name="num_capital[]" value="' . $acciones['capital'] . '" style="display:none"></div></td>'  // capital
                        . '<td>' . number_format($acciones['total_intereses']) . '<div><input type="text" class="num4' . $i . '" name="num_total_interes[]" value="' . ($acciones['total_intereses'] ) . '" style="display:none"></div></td>'//total interes
                        . '<td><div class="condonacion_capital' . $i . '">' . number_format($acciones['condonacion_capital']) . '</div> <div><input type="text" class="num3' . $i . '" name="num_condonacion_capital[]" value="' . $acciones['condonacion_capital'] . '" style="display:none"></div></td>'// condonacion capital
                        . '<td><div class="condonacion_intereses' . $i . '">' . number_format($acciones['condonacion_intereses']) . '</div><div><input type="text" class="num4_5' . $i . '" name="condonacion_intereses[]" value="' . ($acciones['condonacion_intereses'] ) . '" style="display:none"></div></td>'//condonacion_intereses 
                        . '<td><div class="total_condonacion' . $i . '">' . number_format($acciones['total_condonacion']) . '</div> <div><input type="text" class="num5' . $i . '" name="num_total_condonacion[]" value="' . $acciones['total_condonacion'] . '" style="display:none"></div></td>' // total condonacion
                        . '<td><div class="saldo_a_pagar' . $i . '">' . number_format($acciones['saldo_credito']) . '</div> <div><input type="text" class="num6' . $i . '" name="num_saldo_a_pagar[]" value="' . $acciones['saldo_credito'] . '" style="display:none"></div></td>' // saldo a pagar a su credito
                        . '<td><div class="honorario_iva' . $i . '">' . number_format($acciones['honorarios']) . '</div> <div><input type="text" class="num7' . $i . '" name="num_honorario_iva[]" value="' . $acciones['honorarios'] . '" style="display:none"></div></td>' // honorarios + iva
                        . '<td><div class="total_a_pagar' . $i . '">' . number_format($acciones['pago_total']) . '</div> <div><input type="text" class="num8' . $i . '" name="num_total_a_pagar[]" value="' . $acciones['pago_total'] . '" style="display:none"></div></td>'// total a pagar
                        . '</tr>';
                $saldo_capital+=$acciones['saldo_total'];
                $capital+=$acciones['capital'];
                $interes+=$acciones['total_intereses'];
                $condonacion_capital+=$acciones['condonacion_capital'];
                $total_condonacion+=$acciones['total_condonacion'];
                $saldo_credito+=$acciones['saldo_credito'];
                $honorarios+=$acciones['honorarios'];
                $pago_total+=$acciones['pago_total'];
                $condonacion_intereses+=$acciones['condonacion_intereses'];
                $i++;
            }
            $html = $html . "<tr>
                    <td><b>TOTAL</b></td>
                    <td><b><div class='suma_1'>" . number_format($saldo_capital) . "</div></b></td>
                    <td><b><div class='suma_2'>" . number_format($capital) . "</div></b></td>
                    <td><b><div class='suma_4'>" . number_format($interes) . "</div></b></td>
                    <td><b><div class='suma_3'>" . number_format($condonacion_capital) . "</div></b></td>
                    <td><b><div class='suma_4_5'>" . number_format($condonacion_intereses) . "</div></b></td>
                    <td><b><div class='suma_5'>" . number_format($total_condonacion) . "</div></b></td>
                    <td><b><div class='suma_6'>" . number_format($saldo_credito) . "</div></b></td>
                    <td><b><div class='suma_7'>" . number_format($honorarios) . "</div></b></td>
                    <td><b><input type='hidden' class='totales_generales' value='" . str_replace(',', '', number_format($pago_total)) . "'><div class='suma_8'>" . number_format($pago_total) . "</div></b></td>
                </tr>" . '<div><input type="hidden" class="cantidad" value="' . $i . '"></div>';
            $this->html = base64_encode($html);
            $this->idestado = $this->datos[0]['idestado'];
            if ($this->datos[0]['idestado'] == 1) {
                $this->datos[0]['idestado'] = $this->datos[0]['idestado'] . ',2';
            }

            $sql = "select * from gca_estados where est_id in (" . $this->datos[0]['idestado'] . ") order by est_id";
            $this->estados = CondonacionesActions::executeConsultasConsul($sql);
        } else {
            $permiso = strpos($credenciales, 'crear_solicitud');
            $this->nombre = $this->nombre_usuarios();
            if ($permiso > -1) {
                $this->idestado = 1;
            } else {
                $this->idestado = 0;
            }
        }
        $this->credenciales = $credenciales;
        $sql2 = "select * from gca_decision";
        $this->decision = CondonacionesActions::executeConsultasConsul($sql2);
        $this->setTemplate('nuevasolicitud');
    }

    public function executeBusquedaCondonacion() {
        $this->cargo = $this->permisos_usuarios();
        $this->id_usuario = $this->getUser()->getAttribute('usuario');
        $this->setTemplate('busquedaCondonacion');
    }

    public function executeListaCondonacion() {
        $this->setTemplate('listaCondonacion');
    }

    public function executeSolicitudcondonacion() {
        $this->setTemplate('solicitudcondonacion');
    }

    public function executeInhabilidar() {
        $sql2 = "select * from gca_configuracion_sistema";
        $this->dias = CondonacionesActions::executeConsultasConsul($sql2);
        $this->setTemplate('inhabilidar');
    }

    public function executeConsultar() {
        $this->id_usuario = $this->getUser()->isAuthenticated();
        $this->setTemplate('consultar');
    }

    function executeConsultasInsert($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $doctrine->query($sql);
    }

    function executeConsultasConsul($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $res = $doctrine->query($sql)->fetchAll();
        return $res;
    }

    function listaCondonacion() {
        $sql = "select * from gca_condonaciones where estado=0 ";
        $datos = CondonacionesActions::executeConsultasConsul($sql);
        return $datos;
    }

    function cartera_lista($id = null) {
        if ($id != null)
            $where = " where id=$id";
        else
            $where = "";
        $sql3 = "select id,nombre from gca_cartera $where order by nombre ";
        $cartera = CondonacionesActions::executeConsultasConsul($sql3);
        return $cartera;
    }

    public function permiso_usuarios_general() {
        if ($this->getUser()->hasCredential('crear_condonacion') == 1) {
            $dato = 1;
        } else {
            $dato = 0;
        }
        return $dato;
    }

}
