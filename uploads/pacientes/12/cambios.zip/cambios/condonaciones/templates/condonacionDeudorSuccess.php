<table width="100%">
    <tr>
        <td>Cartera</td>
        <td><input type="text" name="" id=""></td>
        <td>Solicitud No</td>
        <td><input type="text" name="" id=""></td>
    </tr>
    <tr>
        <td>Cedula Titular</td>
        <td><input type="text" name="cedula" id="cedula"></td>
        <td>Estado</td>
        <td><input type="text" name="estado" id="estado"></td>
        <td>Direccion Comite</td>
        <td><input type="text" name="" id=""></td>
    </tr>
    <tr>
        <td>% de condonación a capital</td>
        <td><input type="text" name="condonacion_capital" id="condonacion_capital"></td>
        <td>Fecha creación</td>
        <td><input type="text" name="f_creacion" id="f_creacion"></td>
        <td>Aprobado por director</td>
        <td><input type="text" name="aprobado_director" id="aprobado_director"></td>
    </tr>
    <tr>
        <td>% a cancelar capital</td>
        <td><input type="text" name="" id=""></td>
        <td>Fecha aprobación</td>
        <td><input type="text" name="f_aprobacion" id=""></td>
        <td>Aprobado por juridica</td>
        <td><input type="text" name="aprobado_juridica" id="aprobado_juridica"></td>
    </tr>
    <tr>
        <td>% de condonacion intereses</td>
        <td><input type="text" name="condonacion_intereses" id="condonacion_intereses"></td>
        <td>Creada por</td>
        <td><input type="text" name="creado_por" id=""></td>
    </tr>
    <tr>
        <td>% de honorario</td>
        <td><input type="text" name="honorarios" id="honorarios"></td>
        <td>Abogados</td>
        <td><input type="text" name="abogado" id="abogado"></td>
    </tr>
</table>