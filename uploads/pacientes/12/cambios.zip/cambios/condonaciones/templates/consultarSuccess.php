<?php



if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case "insert_condonacion":
            $sql = "select max(id) id from gca_condonaciones";
            $id = CondonacionesActions::executeConsultasConsul($sql);
            $id = $id[0]['id'] + 1;
            //insertamos las variables que vienen por post
            $condonacion = $_POST['condonacion'];
            $pinicial = $_POST['pinicial'];
            $pfinal = $_POST['pfinal'];
            $phonorarios = $_POST['phonorarios'];

            $sql = "insert into gca_condonaciones (id,condonacion,inicial,final,honorarios,creado_por,f_creacion) "
                    . "values('$id','$condonacion','$pinicial','$pfinal','$phonorarios','$id_usuario','".  date('Y-m-d')."')";
            CondonacionesActions::executeConsultasInsert($sql);
            break;
        case "actualizar_condonacion":
            $condonacion = $_POST['condonacion'];
            $pinicial = $_POST['pinicial'];
            $pfinal = $_POST['pfinal'];
            $phonorarios = $_POST['phonorarios'];
            $id = $_POST['id'];
            $sql = "update gca_condonaciones set"
                    . " condonacion='$condonacion',inicial='$pinicial',final='$pfinal',honorarios='$phonorarios',modificado_por='$id_usuario',f_modificacion='".date('Y-m-d')."' where id='$id'";
            CondonacionesActions::executeConsultasInsert($sql);
            break;
        case "eliminar_condonacion":
            $id = $_POST['id'];
            $sql = "update gca_condonaciones set estado=1 where id='$id'";
            CondonacionesActions::executeConsultasInsert($sql);
            break;
        case "guardar_abogado":
            $id = $_POST['id'];
            $nombre = $_POST['nombre'];
            $cedula = $_POST['cedula'];
//            if(isset($_POST['externo']))$externo = ", abogado_externo='true'";
//            else $externo = ", abogado_externo='false'";
            $externo = ", abogado_externo='true'";
            $sql = "update gca_deudor set nombre_abogado='$nombre' $externo where  cedula = '$cedula'";
            
//            echo $sql;
            CondonacionesActions::executeConsultasInsert($sql);
            break;
        case "consulta_condonacion":
            $sql = "select * from gca_condonaciones where estado=0";
            CondonacionesActions::executeConsultasConsul($sql);
            break;
        case "buscar_condonacion":
            $condonacion = $_POST['condonacion'];
            $sql = "select id,condonacion,inicial,final,honorarios from gca_condonaciones "
                    . "where estado=0 and condonacion='$condonacion'";
            $cantidad = CondonacionesActions::executeConsultasConsul($sql);
            if (isset($cantidad[0]['condonacion'])) {
                $envio = '1 :: ' . $cantidad[0]['condonacion'] . ' :: ' . $cantidad[0]['inicial'] . ' :: ' . $cantidad[0]['final'] . ' :: ' . $cantidad[0]['honorarios'] . ' :: ' . $cantidad[0]['id'];
            } else {
                $envio = '0 :: ';
            }
            echo $envio;
            break;
        case 'buscar_cartera':
            $sql="select * from gca_condonaciones con"
                . " left join gca_obligacion_causales ss on ss.id=con.estado ";
            $cantidad = CondonacionesActions::executeConsultasConsul($sql);
            break;
    }
}
?>