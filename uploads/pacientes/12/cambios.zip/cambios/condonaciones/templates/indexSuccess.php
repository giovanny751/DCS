<?php echo $credenciales ?>
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<center><h1>Nueva Condonación</h1></center>
<table style="padding: 30px;" align="" >
    <tr>
        <td><b>CONDONACIÓN</b></td>
        <td>
            <input type="text" name="condonacion" id="condonacion" class="limpiar">
            <div id="condonacion_text"></div>
        </td>
    </tr>
    <tr>
        <td><b>%INICIAL</b></td>
        <td><input type="text" name="pinicial" id="pinicial" class="limpiar num"></td>
    </tr>
    <tr>
        <td><b>%FINAL</b></td>
        <td><input type="text" name="pfinal" id="pfinal" class="limpiar num"></td>
    </tr>
    <tr>
        <td><b>%HONORARIOS</b></td>
        <td>
            <input type="text" name="phonorarios" id="phonorarios" class="limpiar num">
            <div style="display:none "><input type="text" name="id_condonacion" id="id_condonacion" class="limpiar"></div>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table>
                <tr>
                    <td>
                        <button type="button" class="cancelarcondonacion" id="">Cancelar</button>
                    </td>
                    <td>
                        <div id="boton_guardar"><button type="button" class="guardarcondonacion" >Guardar</button></div>
                        <div id="boton_editar" style="display: none"><button type="button" class="">Editar</button></div>
                    </td>
                    <td>
                        <button type="button" class="limpiarcampos">Borrar</button>
                        <a href="listaCondonacion"><button type="Lista" >Lista</button></a>
                    </td>
                </tr>
            </table>
        </td>
            <!--<td><button type="button" class="buscarcondonacion" >Buscar</button></td>-->
    </tr>
</table>

<script>
    $('.limpiarcampos').click(function () {
        var url = "consultar";
        var id_condonacion = $('#id_condonacion').val();
        if (id_condonacion != '') {
            guardar(2)
        } else {
            $('.limpiar').val('');
            $('#boton_guardar').show();
            $('#boton_editar').hide();
        }
    });
    $('.buscarcondonacion').click(function () {

        var url = "consultar";

        $.post(url, {action: "insert_condonacion"})
                .done(function (msg) {

                })
                .fail(function (msg) {

                });
    });
    $('.guardarcondonacion').click(function () {
        guardar(1)
    });
    $('.cancelarcondonacion').click(function () {
        history.back(1);
    });

    function numeric() {
        var phonorarios = $('#phonorarios').val();
        var pfinal = $('#pfinal').val();
        var pinicial = $('#pinicial').val();
        var condonacion = $('#condonacion').val();
        var ve = true;
        if (phonorarios == "" || pfinal == "" || pinicial == "" || condonacion == "") {
            alert('Todos los campos son obligatorio');
            ve = false;
        }else if(pinicial>pfinal && pfinal!=100){
            alert('El %INICIAL debe ser menor al %FINAL');
            $('#pfinal').val('');
            ve = false;
        }else if (isNaN(phonorarios)) {
            alert('Honorarios valor incorrecto');
            $('#phonorarios').val('');
            ve = false;
        } else if (isNaN(pfinal)) {
            alert('%Final valor incorrecto');
            $('#pfinal').val('');
            ve = false;
        } else if (isNaN(pinicial)) {
            alert('%Inicial valor incorrecto');
            $('#pinicial').val('');
            ve = false;
        } else if (condonacion == "") {
            alert('Condonacion valor incorrecto');
            $('#pinicial').val('');
            ve = false;
        }
        return ve;
    }
    $('#condonacion').change(function () {
        consultar();
    });
    $('#boton_editar').click(function () {
        guardar(1)
    });
    function guardar(num) {
        var action = "";
        var id_condonacion = $('#id_condonacion').val();
        if (id_condonacion == "") {
            action = "insert_condonacion";
        } else {
            if (num == 2) {
                action = "eliminar_condonacion";
                var r = confirm('Confirma que desea eliminar la condonacion');
                if (r == false)
                    return false;
            } else {
                action = "actualizar_condonacion";
            }
        }
        var re = numeric();
        if (re === false)
            return re;
        var url = "consultar";
        var phonorarios = $('#phonorarios').val();
        var pfinal = $('#pfinal').val();
        var pinicial = $('#pinicial').val();
        var condonacion = $('#condonacion').val();

        if (pfinal > 101) {
            alert('El valor %final supera el 100%');
            return false
        }
        if (pinicial > 101) {
            alert('El valor %inicial supera el 100%');
            return false
        }
        if (phonorarios > 101) {
            alert('El valor %honorarios supera el 100%');
            return false
        }

        $.post(url, {action: action, id: id_condonacion, phonorarios: phonorarios, pfinal: pfinal, pinicial: pinicial, condonacion: condonacion})
                .done(function (msg) {
                    $('.limpiar').val('');
                    alert('Proceso Exitoso.');
                    $('#boton_guardar').show();
                    $('#boton_editar').hide();
                })
                .fail(function (msg) {
                    alert('Error al guardar');
                });
    }
    function consultar() {
        var ve = true;
        $('#boton_guardar').hide();
        $('#boton_editar').hide();
        var url = "consultar";
        var condonacion = $('#condonacion').val();
        $.post(url, {action: "buscar_condonacion", condonacion: condonacion})
                .done(function (msg) {
                    msg = msg.split(' :: ');
                    if (msg[0] == 1) {
                        $('#condonacion').val(msg[1]);
                        $('#pinicial').val(msg[2]);
                        $('#pfinal').val(msg[3]);
                        $('#phonorarios').val(msg[4]);
                        $('#id_condonacion').val(msg[5]);
                        //                        alert('Nombre de condonacion ya existe');
                        //                        $('#condonacion').val('')
                        $('#boton_guardar').hide();
                        $('#boton_editar').show();
                    } else {
                        id = "";
                        $('#boton_guardar').show();
                    }
                })
                .fail(function (msg) {
                    alert('Error al consultar');
                    $('#boton_guardar').show();
                });
    }
    $('body').delegate('.num', 'keypress', function(tecla) {
        var caja=$(this).val();
        if (tecla.charCode > 0 && tecla.charCode < 46 || tecla.charCode > 57 || tecla.charCode==47)
            return false;
        });
<?php if (isset($_GET['condo'])) { ?>
        $('#condonacion').val('<?php echo $_GET['condo'] ?>');
        $('#condonacion_text').text('<?php echo $_GET['condo'] ?>');
        $('#condonacion').hide();
        consultar();
<?php } ?>
</script>