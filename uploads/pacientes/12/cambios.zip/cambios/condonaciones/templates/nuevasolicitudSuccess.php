
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>


<?php
if (isset($_POST['versolicitud']) || $idestado == 0) {
    $todo_disabled = "disabled";
} else {
    $desasesor = strpos($credenciales, 'crear_solicitud');
    $desdirector = strpos($credenciales, 'aprueba_director');
    $desjuridica = strpos($credenciales, 'aprueba_juridica');
    $descomite = strpos($credenciales, 'aprueba_comite');
    if ($desasesor > -1 && ($idestado == 1 || $idestado == 2))
        $desasesor = "disabled";
    else
        $desasesor = "";

    if ($desdirector > -1 && $idestado == 2)
        $desdirector = "disabled";
    else
        $desdirector = "";
    if ($desjuridica > -1 && $idestado == 3)
        $desjuridica = "disabled";
    else
        $desjuridica = "";
    if ($descomite > -1 && ($idestado == 5 || $idestado == 3)) {
        $descomite = "disabled";
    } else
        $descomite = "";
}
?>

<style>
    table{
        width: 100%;
    }/*
    */    .textAreainfo{
        width: 100%;
        height: 120px;
    }
    .titulo{
        background-image: url('../js/resources/images/default/panel/top-bottom');
        color: #15428b;
        border: 1px solid #99bbe8;
    }
    .datosobligatorio{
        border: 1px solid red;
    }
</style> 
<div style="width: 95%;margin: 0 auto">
    <form method="post" id="creacion">
        <div style="display: none">
            <input type="hidden" name="action" id='action' value="guardar_solicitud">
            <input type="hidden" name="number" id='number' value="<?php echo $numero ?>">
        </div>
        <table style="width: 100%">
            <tr>
                <td>Cartera</td>
                <td style="width: 15%"> 
                    <select <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> name="cartera" id="cartera" style="width: 100%" tabindex="1" class="vacio desabilitar">
                        <?php
                        $cartera = CondonacionesActions::cartera_lista($id_cartera);
//                    
                        foreach ($cartera as $car):
                            if ($id_cartera == $car['id']) {
                                $sele = "selected='selected'";
                            } else {
                                $sele = "";
                            }
                            ?>
                            <option value="<?php echo $car['id'] ?>" <?php if ($datos[0]['cartera'] == $car['id']) echo "selected"; ?>><?php echo $car['nombre'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>

                <td>Nro Solicitud</td>
                <td>
                    <?php echo ($datos[0]['numero'] == "") ? "--" : $datos[0]['numero']; ?>
                </td>  
                <td>Estado</td>
                <td>
                    <select name='estado' class="desabilitar" <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?>>
                        <?php foreach ($estados as $estado): ?>

                            <option <?php if ($datos[0]['idestado'] == $estado['est_id']) echo "selected" ?> value="<?php echo $estado['est_id']; ?>"><?php echo $estado['est_estado']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>  
            </tr>
            <tr>
                <td>Cédula Titular</td>
                <td><input  style="border: 1px solid red;" <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> type="text" name="cc" id="cc" value="<?php if (!empty($datos[0]['cedula'])) echo $datos[0]['cedula'] ?>" tabindex="2" class="vacio obligatorio desabilitar"></td>
                <td colspan="2"><input type="text" readonly="readonly" name="nombre" value="<?php echo $datos[0]['nombres']; ?>" id="nombre" style="width: 80%" ></td>
                <td>Director</td>
                <td>
                    <select class="desabilitarcomite"  id='opdirector' tabindex="10" name="director" <?php echo $descomite . $desasesor . $desjuridica . $todo_disabled ?> <?php echo $descomite; ?>>
                    <!--<select class="desabilitarcomite"  id='opdirector' tabindex="10" name="director" <?php echo $descomite . $desasesor . $desjuridica ?> <?php echo $descomite; ?>>-->
                        <option value=''></option>
                        <?php foreach ($decision as $decisiones): ?>
                            <?php
//                        if($datos[0]['aprobado_director']==3) $datos[0]['aprobado_director'] = 3;
                            if (($datos[0]['aprobado_director'] == 3 && $decisiones['dec_id'] == 1 ) ||
                                    ($datos[0]['aprobado_director'] == 2 && $decisiones['dec_id'] == 2)
                            ) {
                                $select = "selected='selected'";
                            } else {
                                $select = "";
                            }
                            ?>
                            <option value="<?php echo $decisiones['dec_id'] ?>" <?php echo $select; ?>><?php echo $decisiones['dec_decision'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td>
                    <button type="button"  class='guardaraprobacion desabilitarcomite' at='aprobado_director'  <?php echo $desasesor . $desjuridica . $descomite . $todo_disabled; ?>>Guardar</button>
                </td>    
            </tr> 
            <tr>
                <td><br>%condonacion capital</td>
                <td><br><input  style="border: 1px solid red;" <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> type="text" name="pcondonacioncapital" id="pcondonacioncapital" value="<?php if (!empty($datos[0]['condonacion_capital']))
                            echo $datos[0]['condonacion_capital'];
                        else
                            echo '0'
                            ?>" tabindex="3" class="vacio obligatorio desabilitar" ></td>
                <td>Fecha Creación</td>
                <td><input <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> type="text" name="fechacreacion" style="text-align: center" value="<?php
                    if (!empty($datos[0]['f_creacion'])) {
                        echo $datos[0]['f_creacion'];
                    } else {
                        echo date('Y-m-d');
                    }
                    ?>"></td>
                <td>Juridica</td>
                <td>
                    <select class="desabilitar" id='opjuridica' tabindex="11"  <?php echo $desasesor . " " . $desdirector . $todo_disabled . " " . $descomite; ?>>
                        <option value=''></option>
                        <?php foreach ($decision as $decisiones): ?>
                            <?php
                            if ($datos[0]['aprobado_juridica'] == 5 && $decisiones['dec_id'] == 1) {
                                $select = "selected='selected'";
                            } else {
                                $select = "";
                            }
                            ?>
                            <option value="<?php echo $decisiones['dec_id'] ?>"  <?php echo $select; ?> ><?php echo $decisiones['dec_decision'] ?></option>
<?php endforeach; ?>
                    </select>
                </td>
                <td>
                    <button type="button"  class='guardaraprobacion desabilitarcomite' at='aprobado_juridica'  <?php echo $desasesor . $desdirector . $todo_disabled . $descomite; ?>>Guardar</button>
                </td>    
            </tr>
            <tr>

                <td>Valor Negociado</td>
                <td><input <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> style="border: 1px solid red;" type="text" name="valornegociado" id="valornegociado" value="0"></td>
                <td>Fecha Aprobación</td>
                <td><input readonly="readonly" value="<?php if (!empty($datos[0]['f_aprobacion'])) echo $datos[0]['f_aprobacion']; ?>" type="text" name="fechaaprobacion" tabindex="7" class="vacio desabilitar"></td>
                <td>Decisión Comite</td>
                <td>
                    <select id='opcomite' tabindex="9"  <?php echo $desasesor . $desdirector . $todo_disabled . $desjuridica ?>>
                        <option value=''></option>
<?php foreach ($decision as $decisiones): ?>
                            <option value="<?php echo $decisiones['dec_id'] ?>" <?php if ($datos[0]['decision_comite'] == 6 && $decisiones['dec_id'] == 1) echo "selected"; ?>  ><?php echo $decisiones['dec_decision'] ?></option>
<?php endforeach; ?>
                    </select>
                </td>
                <td>
                    <button type="button" class='guardaraprobacion' at='decision_comite' <?php echo $desasesor . " " . $desdirector . $todo_disabled . " " . $desjuridica ?> >Guardar</button>
                </td>
            </tr>
            <tr>
                <td>% Condonacion Intereses</td>
                <td><input <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> style="border: 1px solid red;" type="text" name="porcen_interes" id="porcen_interes" value="<?php if (!empty($datos[0]['porcen_interes']))
    echo $datos[0]['porcen_interes'];
else
    echo '0'
    ?>"></td>
                <td>Creada Por:</td>
                <td><input <?php echo $desjuridica . " " . $desdirector . $todo_disabled . " " . $descomite ?> type="text" name="creadapor"  readonly="readonly" class="desabilitar" value="<?php echo $nombre ?>"></td>
                <td></td> 
            </tr>
            <tr>
                <td>% Cancelar capital</td>
                <td><input <?php echo $desjuridica . " " . $desdirector . $todo_disabled . " " . $descomite ?> type="text" name="pcancelarcapital" readonly="readonly" id="pcancelarcapital" tabindex="4" class="vacio obligatorio desabilitar" value="<?php if (!empty($datos[0]['cancelar_capital'])) echo $datos[0]['cancelar_capital'] ?>"  ></td>
                <td>Abogado</td>
                <td><input value="<?php if (!empty($datos[0]['abogado'])) echo $datos[0]['abogado'] ?>" readonly="readonly" type="text" name="abogado" id="abogado" tabindex="8" class="vacio" ></td>
                <td></td>
            </tr>
            <tr>
                <td>% Cancelar Intereses</td>
                <td><input class="desabilitar" <?php echo $desjuridica . " " . $desdirector . $todo_disabled . " " . $descomite ?> type="text" name="pcondonacinint" id="pcondonacinint" readonly="readonly" tabindex="5" class="vacio obligatorio"  value="<?php if (!empty($datos[0]['condonacion_intereses'])) echo $datos[0]['condonacion_intereses'] ?>"></td>
            </tr>
            <tr>    
                <td>% Honorarios</td>
                <td><input <?php echo $desjuridica . " " . $desdirector . $todo_disabled . " " . $descomite ?> type="text" id="phonorarios" name="phonorarios" tabindex="6" class="vacio obligatorio desabilitar"  value="<?php if (!empty($datos[0]['honorarios'])) echo $datos[0]['honorarios'] ?>" readonly="readonly"></td>
            </tr>
        </table>
        <div>
            <button type="button" id='solicitud' style='cursor:pointer'>Solicitud</button>
            <button type="button" id='informacion'  style='cursor:pointer'>Más Información</button>
            <button type="button" id='juridico'  style='cursor:pointer'>Jurídico</button>
        </div>
        <div id='visualizacionsolicitud'>
            <div class='titulo'>
                <center><b>DETALLE SOLICITUD </b></center>
            </div>
            <table style="width: 100%" >
                <thead>
                <th>No Obligación</th>
                <th>Saldo Total</th>
                <th>Capital</th>
                <th>Intereses mora</th>
                <th>Condonación capital</th>
                <th>Condonación Intereses</th>
                <th>Total condonación</th>
                <th>Saldo a pagar al credito</th>
                <th>Honorarios + IVA</th>
                <th>Total pagar</th>
                </thead>
                <tbody class="detallesolicitud" align='right'>
<?php if (!isset($html)) { ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
    <?php
} else {
    echo base64_decode($html);
}
?>
                </tbody>
            </table>
            <div class='titulo'>
                <center><b>ACUERDO DE PAGO</b></center>
            </div>
            <table style="width: 100%">
                <thead>
                <th style="text-align: center">No de Cuotas</th>
                <th style="text-align: center">Fecha</th>
                <th style="text-align: center">Forma de pago</th>
                <th style="text-align: center">Valor de la Cuota</th>
                <th style="text-align: center">Agregar/Eliminar</th>
                </thead>
                <tbody id="acuerdo">
<?php
if (!empty($acuerdo)) {
    foreach ($acuerdo as $datosacuerdo):
        ?>
                            <tr class="numeroacuerdo">
                                <td align='center' class="numerofila"><input class="desabilitar" <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> style="text-align: center" type="text" name="cuotas[]" value="<?php echo $datosacuerdo['acu_num_cuota'] ?>"></td>
                                <td align='center'><input <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> type='text' name='fechapago[]' class="vacio obligatorio desabilitar fecha"  value="<?php echo $datosacuerdo['fechapago'] ?>"  placeholder='0'></td>
                                <td align='center'><textarea  <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> name='acuerdo[]' style="width: 100%" name="fecha[]"  class="vacio obligatorio desabilitar"><?php echo $datosacuerdo['acu_fecha_pago'] ?></textarea></td>
                                <td align='center'>$<input <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> type='text' name='valor[]' class="valor vacio obligatorio desabilitar"  value="<?php echo number_format($datosacuerdo['acu_valor_cuota'], '0', '.', ',') ?>"  placeholder='0'></td>
                                <td align="center">
                                    <button <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> type="button" class="agregar vacio desabilitar" style="background-color: green;color:white;font-weight: bold;font-size: 20px;">+</button>
                                    <button type="button" class="eliminar desabilitar" style="background-color: red;color:white;font-weight: bold;font-size: 20px;" <?php echo$desdirector . $todo_disabled . $desjuridica . $descomite ?>>-</button></td>
                            </tr>
        <?php
    endforeach;
} else {
    ?>
                        <tr class="numeroacuerdo">
                            <td align='center' class="numerofila"><input <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> style="text-align: center" type="text" name="cuotas[]" value="1"></td>
                            <td align='center'><input <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?>  type="text" name="fechapago[]" id="fechapago0" class="vacio obligatorio fechapago  fecha"></td>
                            <td align='center'><textarea <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> name='acuerdo[]' style="width: 100%" name="fecha[]" class="vacio obligatorio"></textarea></td>
                            <td align='center'>$<input <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> type='text' name='valor[]' class="valor vacio obligatorio"  placeholder='0'></td>
                            <td align="center">
                                <button <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?> type="button" class="agregar vacio desabilitar" style="background-color: green;color:white;font-weight: bold;font-size: 20px;">+</button>
                                <button type="button" class="eliminar desabilitar" style="background-color: red;color:white;font-weight: bold;font-size: 20px;" <?php echo $desdirector . $todo_disabled . $desjuridica . $descomite ?>>-</button></td>
                        </tr>  
<?php } ?>

                </tbody>
                <tfood>
                    <tr>
                        <td></td>
                        <td></td>
                        <td align='right'><b>Total</b></td>
                        <td align='center'>
                            <input <?php echo $descomite . $desjuridica . $desdirector . $todo_disabled ?> readonly="readonly" type="text" name="total" id="total" class="vacio desabilitar" value="<?php echo number_format($datos[0]['total_acuerdo'], 0, '.', ','); ?>" ></td>
                        <td></td>
                    </tr>
                </tfood>
            </table>
            <hr>
            <div align="right">
                <?php if (empty($_GET['number'])) { ?>
                    <button type="button" id="redi_listados"><a href="consultasolicitud">Listado</a></button>
                <?php }if ($editar == 1) { ?>

                    <button type="button" class="limpiar" <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?>>Limpiar</button>
                    <button type="button" class="guardar" <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?>>Guardar</button>
<?php } else if ($editar == 2) { ?>
                    <button type="button" class="actualizar" <?php echo $descomite . " " . $desjuridica . " " . $desdirector . $todo_disabled ?>>Actualizar</button>
<?php } ?>

            </div>
        </div>
    </form>    
    <div id='visualizacioninformacion'>
        <form method="post" id='forminformacion'>
            <input type='hidden' value='actualizar_informacion' name='action'>
            <input type='hidden' name='cedula' id='datocedula'>
            <table>
                <tr>
                    <td class='titulo'><b><center>2.ANTECEDENTES</center></b></td>
                </tr>
                <tr>
                    <td>
                        <textarea name="antecedentes" id="" class='textAreainfo desabilitar desabilitarcomite' <?php echo $descomite . " " . $desjuridica . " " . $todo_disabled ?>><?php echo $datos[0]['antecedentes']; ?></textarea>
                    </td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>3.PROPUESTA CLIENTE</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="propuestacliente" id="" class='textAreainfo desabilitar desabilitarcomite' <?php echo $descomite . " " . $desjuridica . " " . $todo_disabled ?>><?php echo $datos[0]['propuesta_cliente']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>4.INVESTIGACIÓN DE BIENES</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="investigacionbienes" id="" class='textAreainfo desabilitar desabilitarcomite'  <?php echo $descomite . " " . $desjuridica . " " . $todo_disabled ?>><?php echo $datos[0]['investigacion_bienes']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>5.TIPO DE GARANTÍA</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="tipogarantia" id="" class='textAreainfo desabilitar desabilitarcomite'  <?php echo $descomite . " " . $desjuridica . " " . $todo_disabled ?>><?php echo $datos[0]['tipo_garantia']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>6.REPORTE DE VISITA</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="reportevisita" id="" class='textAreainfo desabilitar desabilitarcomite'  <?php echo $descomite . " " . $desjuridica . " " . $todo_disabled ?>><?php echo $datos[0]['reporte_visita']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>7.CONCEPTO DEL OPERADOR</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="conceptooperador" id="" class='textAreainfo desabilitar desabilitarcomite' <?php echo $descomite . " " . $desjuridica . " " . $todo_disabled ?>><?php echo $datos[0]['concepto_operador']; ?></textarea></td>
                </tr>
            </table>
        </form>    
        <hr>
<?php if ($cargo != 1) { ?>
            <div align="right">
                <button type="button" class="guardarinformación" >Guardar</button>
            </div>
<?php } ?>
    </div>    
    <div id='visualizacionjuridico'>
        <form method="post" id='formjuridico'>
            <input type='hidden' value='actualizar_juridica' name='action'>
            <!--<input type='hidden'  name='cedula' id='ccedula'>-->
            <input type='hidden' name='cedula' id='datocedula2'>
            <table>
                <tr>
                    <td class='titulo'><b><center>8. ESTADO PROCESO</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="estadoproceso" id=""  class='textAreainfo desabilitar' <?php echo $descomite . " " . $desasesor . " " . $desdirector . $todo_disabled ?>><?php echo $datos[0]['estado_proceso']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>9. CONCEPTO JURIDICO</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="conptojuridico" id="" class='textAreainfo desabilitar' <?php echo $descomite . " " . $desasesor . " " . $desdirector . $todo_disabled ?>><?php echo $datos[0]['concepto_juridico']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>10. MEDIDAS CAUTELARES</center></b></td>
                </tr>
                <tr>
                    <td><textarea name="medidascautelares" id="" class='textAreainfo desabilitar' <?php echo $descomite . " " . $desasesor . " " . $desdirector . $todo_disabled ?>><?php echo $datos[0]['medidas_cautelares']; ?></textarea></td>
                </tr>
                <tr>
                    <td class='titulo'><b><center>11. OBSERVACIONES COMITE</center></b></td>
                </tr>
                <tr>
                    <td><textarea  name="observacioncomite" id="" class='textAreainfo desabilitar' <?php echo $desjuridica . " " . $desasesor . " " . $desdirector . $todo_disabled ?>><?php echo $datos[0]['observaciones_comite']; ?> </textarea></td>
                </tr>
            </table>
        </form>
        <hr>
        <div id="cantidad"></div>
<?php if ($cargo != 1) { ?>
            <div align="right">
                <button type="button" class="guardarjuridico" >Guardar</button>
            </div>
<?php } ?>
    </div>    

    <div id="formrepetidos">
        <form method="post" action="nuevasolicitud" id="solicitudcreada">

        </form>
    </div>  
</div>
<style>
    a{text-decoration:none;color: #000}
</style>
<script>

<?php if ($grado == "asesor" && ($datos[0]['idestado'] >= 2 && $datos[0]['idestado'] <= 6)) { ?>
        $('.desabilitar').attr('disabled', true);
        $('.actualizar').remove();
<?php } ?>
<?php if ($grado == "director" && ($datos[0]['aprobado_director'] == 3 || $datos[0]['aprobado_director'] == 2)) { ?>
        $('.desabilitarcomite').attr('disabled', true);
        $('.actualizar,.guardarinformación').remove();

<?php } ?>


    $(document).ready(function() {
        $('.fecha').datepicker({
            dateFormat: "yy-mm-dd"
        });
    });
    $("body").delegate("input[type=text].fecha", "focusin", function() {
        $(this).datepicker({
            dateFormat: "yy-mm-dd"
        });
    });
    $('#porcen_interes').change(function() {
        if ($('#porcen_interes').val() != '')
            buscar_horarios();

    })
//    function mirar_itereses() {
//        intereses = $('.suma_4').html();
//        intereses_condo = $('.suma_4_5').html();
//        if (intereses != intereses_condo) {
//            var cantidad = $('.cantidad').val();
//            var total = 0;
//            for (var r = 0; r < cantidad; r++) {
//                intereses = $('.num4' + r).val();
//                intereses_conso = $('.num4_5' + r).val();
//                resul = intereses - intereses_conso;
//                datos = $('.num8' + r).val();
//                resul = intereses-(datos - resul);
//                
//                $('.num8' + r).val(Math.round(resul));
//                $('.total_a_pagar' + r).html(CurrencyFormatted(resul));
//                total += Math.round(resul);
//            }
//            $('.suma_8').html(CurrencyFormatted(total));
//            $('.totales_generales').val((total));
//        }
//    }
    $('.guardaraprobacion').click(function() {
        var cedula = $('#cc').val()
        var campo = $(this).attr('at');
        var action = 'aprobacion';
        var url = "busquedaCondonacion";
        if (campo == 'aprobado_director')
            var valor = $('#opdirector').val();
        if (campo == 'aprobado_juridica')
            var valor = $('#opjuridica').val();
        if (campo == 'decision_comite')
            var valor = $('#opcomite').val();
        $.post(url, {campo: campo, valor: valor, action: action, cedula: cedula})
                .done(function(msg) {

                    alert('Guardado Correctamente');
                    location.href = 'consultasolicitud';
                })
                .fail(function(msg) {

                });
    });
    $('.guardarjuridico').click(function() {

        var url = "busquedaCondonacion";
        $('#datocedula2').val($('#cc').val());
        $.post(url, $('#formjuridico').serialize())
                .done(function(msg) {
                    alert("Guardado Correctamente");
                })
                .fail(function(msg) {

                });
    });
    $('.guardarinformación').click(function() {

//        console.log($('#cc').val());

        $('#datocedula').val($('#cc').val());
        var url = "busquedaCondonacion";
        $.post(url, $('#forminformacion').serialize())
                .done(function(msg) {

                })
                .fail(function(msg) {

                });
    });
    $('#visualizacioninformacion').hide();
    $('#visualizacionjuridico').hide();
    $('#solicitud').click(function() {

        $('#visualizacionsolicitud').show();
        $('#visualizacioninformacion').hide();
        $('#visualizacionjuridico').hide();
    });
    $('#informacion').click(function() {

        $('#visualizacionsolicitud').hide();
        $('#visualizacioninformacion').show();
        $('#visualizacionjuridico').hide();
    });
    $('#juridico').click(function() {
        $('#visualizacionsolicitud').hide();
        $('#visualizacioninformacion').hide();
        $('#visualizacionjuridico').show();
    });
    $('.guardar').click(function() {
        var totales_generales = $('.totales_generales').val();
        var total = $('#total').val();
        if (total.length > 3)
            total = total.replace(/,/g, '');

        if (totales_generales != total) {
            alert('Los valores del acuerdo de pago, no son correctos');
            return false;
        }
        var url = "busquedaCondonacion";
        var i = 0;
        $('.obligatorio').each(function(indice, campo) {
            if ($(this).val() == "") {
                $(this).addClass('datosobligatorio');
                i++;
            } else {
                $(this).removeClass('datosobligatorio');
            }
        });
        if (i == 0) {
            $.post(url, $('#creacion').serialize())
                    .done(function(msg) {
                        alert('la información se ha guardado con exito \nNúmero de condonacion: ' + msg);
                        location.href = 'consultasolicitud';
                    })
                    .fail(function() {

                    });
        }
    });
    $('.actualizar').click(function() {
        var totales_generales = $('.totales_generales').val();
        var total = $('#total').val();
        if (total.length > 3)
            total = total.replace(/,/g, '');
        $('#total').val(total);
//        console.log(totales_generales + " ** " + total);
        if (totales_generales != total) {
            alert('Los valores del acuerdo de pago, no son correctos');
            return false;
        }
        var url = "busquedaCondonacion";
        $('#action').val('actualizar_condonacion');
        var i = 0;
        $('.obligatorio').each(function(indice, campo) {
            if ($(this).val() == "") {
                $(this).addClass('datosobligatorio');
                i++;
            } else {
                $(this).removeClass('datosobligatorio');
            }
        });
        if (i == 0) {
            $.post(url, $('#creacion').serialize())
                    .done(function() {
                        alert('Solicitud actualizada con exito');
                        location.href = 'consultasolicitud';
                    })
                    .fail(function() {
                        alert('Error al Guardar')
                    });
        }
    });
    $('.limpiar').click(function() {

        Ext.Msg.confirm('Hey!', 'Esta seguro de limpiar la Solicitud?', function(btn, text) {

            if (btn == 'yes') {
                $('.vacio').val('');
                $('#nombre').val('')
                $('.detallesolicitud').html('');
                $('.eliminarfilas').remove();
            }
        });

    });
    $('body').delegate('.valor', 'keypress', function(tecla) {
        if (tecla.charCode > 0 && tecla.charCode < 48 || tecla.charCode > 57)
            return false;
    });
    $('body').delegate('.valor', 'keypress', function(tecla) {
        if (tecla.charCode > 0 && tecla.charCode < 48 || tecla.charCode > 57)
            return false;
    });
    $('#cc').keypress(function(tecla) {
        if (tecla.charCode == 32)
            return false;
    });
    $('body').delegate('.valor', 'keyup', function() {
        
        sumaacuerdo();
    });
    $('#valornegociado').change(function() {
        if ($('#valornegociado').val() == '' || $('#valornegociado').val() == 0)
            return false

        var action = "buscar_honorarios";
        var url = "busquedaCondonacion";
        $('#porcen_interes').val(100)
        $('#pcondonacinint').val(0)
        var resul = parseFloat($('.capital_total').val()) - parseFloat($('#valornegociado').val());
        if (resul < 0)
            resul = resul * (-1)
        var pcondonacioncapital = (parseFloat(resul) * 100) / parseFloat($('.capital_total').val())
        var pcondonacioncapital = (parseFloat(resul) * 100) / parseFloat($('.capital_total').val())
        if (pcondonacioncapital > 99) {
            alert('El porcentaje supera el 99%');
            return false;
        }
        $.post(url, {action: action, pcondonacioncapital: pcondonacioncapital})
                .done(function(msg) {
                    var datos = jQuery.parseJSON(msg);

                    honorarios = parseInt(datos['honorarios']) / 100;
                    hono = datos['honorarios'] / 100;
                    interes=$('.suma_4').html();
                    interes=interes.replace(",", "");
                    interes=interes.replace(",", "");
                    interes=interes.replace(",", "");
                    interes=interes.replace(",", "");
//                    interes=0;
//                    console.log(interes); 
                    valornegociado = parseFloat($('#valornegociado').val()) / (1 + (parseFloat(hono) + (parseFloat(hono) * parseFloat(<?php echo $iva; ?>))));
                    console.log(valornegociado);
//                    interes = parseFloat(interes) / (1 + (parseFloat(hono) + (parseFloat(hono) * parseFloat(<?php echo $iva; ?>))));
//                    valornegociado=interes+interes;
//                    var resul = parseFloat(valornegociado) / parseFloat($('.capital_total').val());
//alert("("+parseFloat(valornegociado)+"*100)/"+parseFloat($('.capital_total').val()));
                    var resul = (parseFloat(valornegociado) *100)/ parseFloat($('.capital_total').val());

//                    resul = parseFloat(100) * parseFloat(resul)
                    resul = 100 - resul
                    console.log()
                    $('#pcondonacioncapital').val(resul)
                    buscar_horarios(resul);
                })
    })
    $('#pcondonacioncapital').change(function() {
        if ($('#pcondonacioncapital').val() != ''){
            $('#valornegociado').val(0)
            $('#porcen_interes').val(100)
            buscar_horarios();
            
        }
    })
    function buscar_horarios() {
        var action = "buscar_honorarios";
        var url = "busquedaCondonacion";
        var suma_1 = 0;
        var suma_2 = 0;
        var suma_3 = 0;
        var suma_4 = 0;
        var suma_5 = 0;
        var suma_6 = 0;
        var suma_7 = 0;
        var suma_8 = 0;


        var valor_porcentaje = $('#porcen_interes').val();
        valor_porcentaje = $('#porcen_interes').val();
        var cantidad = $('.cantidad').val();
        var total = 0;
        for (var r = 0; r < cantidad; r++) {
            intereses = $('.num4' + r).val();
            intereses_porcentaje = (valor_porcentaje * intereses) / 100
            intereses_porcentaje = intereses_porcentaje
            $('.num4_5' + r).val(Math.round(intereses_porcentaje));
            $('.condonacion_intereses' + r).html(CurrencyFormatted(intereses_porcentaje));
            total += intereses_porcentaje;
        }
        $('.suma_4_5').html(CurrencyFormatted(total));
        $('#pcondonacinint').val(100 - valor_porcentaje)


        var pcondonacioncapital = $('#pcondonacioncapital').val();
        $.post(url, {action: action, pcondonacioncapital: pcondonacioncapital})
                .done(function(msg) {
                    var datos = jQuery.parseJSON(msg);
                    $('#phonorarios').val(datos['honorarios']);
                    porcen_interes = $('#porcen_interes').val();
                    $('#pcondonacinint').val(100 - porcen_interes);
                    var pcancelarcapital = 100 - pcondonacioncapital;
                    $('#pcancelarcapital').val(pcancelarcapital);
                    var cantidad = $('.cantidad').val();
                    for (var r = 0; r < cantidad; r++) {
                        resul = (parseFloat(pcondonacioncapital) * parseFloat($('.num2' + r).val())) / parseFloat(100);
                        $('.num3' + r).val(Math.round(resul));
                        suma_3 = suma_3 + resul;


                        intereses_mora = $('.num4' + r).val();


                        condonacion_intereses = $('.num4_5' + r).val();
//                        console.log(condonacion_intereses);

                        $('.condonacion_capital' + r).html(CurrencyFormatted(Math.round(resul)));
                        total_condonacion = (parseFloat(resul) + parseFloat(condonacion_intereses))//+parseFloat(condonacion_intereses);

                        $('.num5' + r).val(Math.round(total_condonacion));
                        suma_5 = suma_5 + total_condonacion;
                        $('.total_condonacion' + r).html(CurrencyFormatted(Math.round(total_condonacion)));


                        saldo_a_pagar_al_credito = parseFloat($('.num1' + r).val()) - parseFloat(total_condonacion);
                        
//                        Saldo a pagar al crédito= (Capital  "%cancelar capital") + (Interes_mora  "%Cancelar intereses");

if($('#pcondonacinint').val()==0){
    mul=0;
}else{
    mul=((($('#pcondonacinint').val())/100))
}
                        saldo_a_pagar_al_credito=((parseFloat($('.num2' + r).val()))*($('#pcancelarcapital').val()/100))+((parseFloat($('.num4' + r).val()))*mul)
                        
                        $('.num6' + r).val(Math.round(saldo_a_pagar_al_credito));
                        $('.saldo_a_pagar' + r).html(CurrencyFormatted(Math.round(saldo_a_pagar_al_credito)));
                        suma_6 = suma_6 + saldo_a_pagar_al_credito;
//                        resul = (parseFloat($('#phonorarios').val()) * parseFloat($('.num2' + r).val())) / parseFloat(100);
                        honorario_iva = ((parseFloat($('#phonorarios').val()) * parseFloat(saldo_a_pagar_al_credito)) / parseFloat(100)) + (((parseFloat($('#phonorarios').val()) * parseFloat(saldo_a_pagar_al_credito)) / parseFloat(100)) *<?php echo $iva; ?>);
                        $('.num7' + r).val(Math.round(honorario_iva));
                        $('.honorario_iva' + r).html(CurrencyFormatted(Math.round(honorario_iva)));
                        suma_7 = suma_7 + honorario_iva;

                        total_a_pagar = parseFloat($('.num6' + r).val()) + parseFloat($('.num7' + r).val())
                        $('.total_a_pagar' + r).html(CurrencyFormatted(Math.round(total_a_pagar)));
                        $('.num8' + r).val(Math.round(total_a_pagar));
                        suma_8 = suma_8 + total_a_pagar;
                    }

                    $('.suma_3').html(CurrencyFormatted(Math.round(suma_3)));
                    $('.suma_5').html(CurrencyFormatted(Math.round(suma_5)));
                    $('.suma_6').html(CurrencyFormatted(Math.round(suma_6)));
                    $('.suma_7').html(CurrencyFormatted(Math.round(suma_7)));
                    $('.suma_8').html(CurrencyFormatted(Math.round(suma_8)));
                    $('.totales_generales').val(Math.round(suma_8));

                    var porcen_interes = $('#porcen_interes').val();
                    $('#pcondonacinint').val(100 - porcen_interes)
//                        mirar_itereses();


                })
                .fail(function(msg) {
                });
    }
    function cambio_miles(number) {

        var result = '';
        while (number.length > 3) {
            result = '.' + number.substr(number.length - 3) + result;
            number = number.substring(0, number.length - 3);
        }
        result = number + result;
        return result;
    }
    $('#cc').change(function() {
        buscar_carteras();
    });
    $('#cartera').change(function() {
        buscar_carteras();
    });
    function buscar_carteras() {
        var cartera = $('#cartera').val();
        var cc = $('#cc').val();
//        $('#pcondonacioncapital').attr('disabled','disabled');
        if (cartera == '' || cc == '')
            return false;
        $('#pcondonacioncapital').val(0);
        $('#pcancelarcapital').val('');
        $('#pcondonacinint').val('');
        $('#phonorarios').val('');
        var url = "busquedaCondonacion";
        var cedula = cc.replace(" ", "");
        var action = "busqueda_cedula"
        $.post(url, {cedula: cedula, action: action, cartera: cartera})
                .done(function(msg) {
                    var datos = jQuery.parseJSON(msg);

                    if (datos.numero == 2) {
                        if (datos['idsolicitud'] == null) {
                            return false;
                        }
//                Ext.Msg.confirm('Hey!', 'ya fue creada Solicitud # '+datos['idsolicitud'], function(btn, text) {
                        alert('la solicitud #' + datos['idsolicitud'] + ' esta en proceso');
//                    if (btn == 'yes') {
                        $('#solicitudcreada').append('<input type="text" value="' + datos['idsolicitud'] + '" name="number"><input type="text" value="' + datos['idsolicitud'] + '" name="versolicitud">');

                        $('#solicitudcreada').submit();

//                    }
//                });
//                return;
                    }

                    if (datos['numero'] == 1)
                    {
                        $('#nombre').val(datos[1]);
                        $('#abogado').val(datos['contacto']);
                        $('#cantidad').html(datos['cantidad']);
                        $('.detallesolicitud').html(datos['html']);
                        $(".detallesolicitud tr:odd").css("background-color", "#ccc"); // filas impares
                        $(".detallesolicitud tr:even").css("background-color", "#fff"); // filas pares
                    } else {

                    }
                })
                .fail(function(msg) {
                });
    }

    $('body').delegate('.agregar', 'click', function() {

        var numero = $('.numeroacuerdo').length;
        var filano = numero + 1;
        var fila = "<tr  class='numeroacuerdo eliminarfilas'>";
        fila += "<td align='center' class='numerofila'><input style='text-align: center' type='text' name='cuotas[]' value='" + filano + "'></td>";
        fila += '<td align="center"><input type="text" name="fechapago[]" id="fechapago' + numero + '" class="vacio obligatorio fechapago  fecha"></td>';
        fila += "<td align='center'><textarea name='acuerdo[]' style='width:100%' class='obligatorio'></textarea></td>";
        fila += "<td align='center'>$<input type='text' name='valor[]' class='valor vacio obligatorio' placeholder='0'></td>";
        fila += '<td align="center"><button type="button" class="agregar" style="background-color: green;color:white;font-weight: bold;font-size: 20px;">+</button><button type="button" class="eliminar" style="background-color: red;color:white;font-weight: bold;font-size: 20px;">-</button></td>';
        fila += "</tr>";
        $('#acuerdo').append(fila);
        numeracion();
    });
    $('body').delegate('.eliminar', 'click', function() {

        var numero = $('.numeroacuerdo').length;
        if (numero > 1) {
            var confirmacion = confirm('Esta seguro de eliminarla');
            if (confirmacion == true) {
                $(this).parents('tr').remove();
                numeracion();
                sumaacuerdo();
            }
        }
    });
    function numeracion() {
        var i = 1;
        $('.numerofila').children('.numerofila *').remove()
        $('.numeroacuerdo').each(function(indice, campo) {
            $(this).children('.numerofila').append('<input style="text-align: center" type="text"  name="cuotas[]" value="' + i + '">');
            i++;
        });
    }
    function sumaacuerdo() {

        var total = 0;
        $('.valor').each(function(key, val) {

            if ($(this).val() == "")
                var valores = 0;
            else
                valores = $(this).val()
            if (valores.length > 3)
                valores = valores.replace(/,/g, '')
            total = parseFloat(valores) + parseFloat(total);
        });
        $('#total').val(CurrencyFormatted(total));
    }


    $(".detallesolicitud tr:odd").css("background-color", "#ccc"); // filas impares
    $(".detallesolicitud tr:even").css("background-color", "#fff"); // filas pares
    function CurrencyFormatted(num) {
        num = num.toString().replace(/\$|\,/g, '');
        if (isNaN(num))
            num = "0";
        sign = (num == (num = Math.abs(num)));
        num = Math.floor(num * 100 + 0.50000000001);
        cents = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10)
            cents = "0" + cents;
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
            num = num.substring(0, num.length - (4 * i + 3)) + ',' +
                    num.substring(num.length - (4 * i + 3));
        return (((sign) ? '' : '-') + num);
    }
    $('#redi_listados').click(function() {
        location.href = "consultasolicitud";
    })
    $('body').delegate('.valor', 'keyup', function() {
        dato = $(this).val();
        dato = CurrencyFormatted(dato);
        $(this).val(dato);
    })
</script>    