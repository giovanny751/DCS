<?php

if (isset($_POST['action'])) {
    $action = $_POST['action'];
} else if (isset($_GET['action'])) {
    $action = $_GET['action'];
}

switch ($action) {
    case 'actualizar_condonacion':
        if (!empty($_POST['number']))
            $number = $_POST['number'];
        else
            $number = "";
        if (!empty($_POST['cartera']))
            $cartera = $_POST['cartera'];
        else
            $cartera = "";
        if (!empty($_POST['cc']))
            $cc = $_POST['cc'];
        else
            $cc = "";
        if (!empty($_POST['pcondonacioncapital']))
            $pcondonacioncapital = $_POST['pcondonacioncapital'];
        else
            $pcondonacioncapital = "0";
        if (!empty($_POST['fechacreacion']))
            $fechacreacion = $_POST['fechacreacion'];
        else
            $fechacreacion = "";
        if (!empty($_POST['pcancelarcapital']))
            $pcancelarcapital = $_POST['pcancelarcapital'];
        else
            $pcancelarcapital = "";
        if (!empty($_POST['fechaaprobacion']))
            $fechaaprobacion = $_POST['fechaaprobacion'];
        else
            $fechaaprobacion = "";
        if (!empty($_POST['pcondonacinint']))
            $pcondonacinint = $_POST['pcondonacinint'];
        else
            $pcondonacinint = "0";
        if (!empty($_POST['phonorarios']))
            $phonorarios = $_POST['phonorarios'];
        else
            $phonorarios = "";
        if (!empty($_POST['total']))
            $total = $_POST['total'];
        else
            $total = "0";
        if (!empty($_POST['valornegociado']))
            $valornegociado = $_POST['valornegociado'];
        else
            $valornegociado = "";
        if (!empty($_POST['abogado']))
            $abogado = $_POST['abogado'];
        else
            $abogado = "";
        if (!empty($_POST['estado']))
            $estado = $_POST['estado'];
        else
            $estado = "";
        $usuario = $id_usuario;

        $sql = "update gca_solicitud_condonacion
            set
                f_modificacion = '" . date('Y-m-d') . "',
                modificado_por = '$usuario',
                condonacion_capital = '$pcondonacioncapital',
                cancelar_capital = '$pcancelarcapital',
                honorarios = '$phonorarios',
                estado = '$estado',
                total_acuerdo = '$total',
                abogado = '$abogado',
                condonacion_intereses = '$pcondonacinint',
                porcen_interes = '" . $_POST['porcen_interes'] . "'
                where numero = $number
                ";
        CondonacionesActions::executeConsultasInsert($sql);
//        die();
        $acuerdo = $_POST['acuerdo'];
        $valor = $_POST['valor'];
        $cuotas = $_POST['cuotas'];
        $contador = count($cuotas);
        $fechapago = $_POST['fechapago'];
        $delete = "delete from gca_acuerdo_condonacion where con_id = $number";

        CondonacionesActions::executeConsultasInsert($delete);
        $id = $number;
        for ($i = 0; $i < $contador; $i++) {
            $valor[$i] = str_replace(',', '', $valor[$i]);
            $query = "
                insert into gca_acuerdo_condonacion
                (acu_num_cuota,acu_fecha_pago,acu_valor_cuota,usu_idcreador,acu_fecha_cre,con_id,fechapago)
                values
                ('$cuotas[$i]','$acuerdo[$i]','$valor[$i]','$usuario','" . date('Y-m-d') . "','$id','$fechapago[$i]')
            ";
            CondonacionesActions::executeConsultasInsert($query);
        }
        $contador = count($_POST['num_capital']);
        $query = 'delete from gca_detalle_solicitud where id_solicitud_condonacion=' . $id;
        CondonacionesActions::executeConsultasInsert($query);

        $saldo = 0;
        for ($i = 0; $i < $contador; $i++) {
            $query = "insert into gca_detalle_solicitud
                (id_solicitud_condonacion,obligacion,saldo_total,capital,condonacion_capital,
                total_intereses,total_condonacion,total_condonacion_pago,
                saldo_credito,honorarios,pago_total,pago_total_pagos,condonacion_intereses)
                values
                (
                '" . $id . "',
                '" . $_POST['num_obligacion'][$i] . "',
                '" . $_POST['num_saldo_total'][$i] . "',
                '" . $_POST['num_capital'][$i] . "',
                '" . $_POST['num_condonacion_capital'][$i] . "',
                '" . $_POST['num_total_interes'][$i] . "',
                '" . $_POST['num_total_condonacion'][$i] . "',
                '" . $_POST['num_saldo_a_pagar'][$i] . "',
                '" . $_POST['num_saldo_a_pagar'][$i] . "',
                '" . $_POST['num_honorario_iva'][$i] . "',
                '" . $_POST['num_total_a_pagar'][$i] . "',
                '" . $_POST['num_total_a_pagar'][$i] . "',
                '" . $_POST['condonacion_intereses'][$i] . "'
                    ) ";
            $saldo+=$_POST['num_total_condonacion'][$i];
            CondonacionesActions::executeConsultasInsert($query);
            $sql = "update gca_obligacion set bloqueada=1 where obligacion='" . $_POST['num_obligacion'][$i] . "'";
            CondonacionesActions::executeConsultasInsert($sql);
            estados($estado, $_POST['num_obligacion'][$i]);
        }
        CondonacionesActions::executeConsultasInsert($sql);
        $sql = "update gca_solicitud_condonacion set total_a_pago_pagos=" . $saldo . ",total_a_pago=" . $saldo . " where numero=$number";
        CondonacionesActions::executeConsultasInsert($sql);
        break;
    case 'guardar_solicitud':

        if (!empty($_POST['cartera']))
            $cartera = $_POST['cartera'];
        else
            $cartera = "";
        if (!empty($_POST['cc']))
            $cc = $_POST['cc'];
        else
            $cc = "";
        if (!empty($_POST['pcondonacioncapital']))
            $pcondonacioncapital = $_POST['pcondonacioncapital'];
        else
            $pcondonacioncapital = "0";
        if (!empty($_POST['fechacreacion']))
            $fechacreacion = $_POST['fechacreacion'];
        else
            $fechacreacion = "";
        if (!empty($_POST['pcancelarcapital']))
            $pcancelarcapital = $_POST['pcancelarcapital'];
        else
            $pcancelarcapital = "";
        if (!empty($_POST['pcondonacinint']))
            $pcondonacinint = $_POST['pcondonacinint'];
        else
            $pcondonacinint = "";
        if (!empty($_POST['phonorarios']))
            $phonorarios = $_POST['phonorarios'];
        else
            $phonorarios = "";
        if (!empty($_POST['abogado']))
            $abogado = $_POST['abogado'];
        else
            $abogado = "";
        if (!empty($_POST['estado']))
            $estado = $_POST['estado'];
        else
            $estado = "";
        if (!empty($_POST['total']))
            $total = $_POST['total'];
        else
            $total = "";
        $usuario = $id_usuario;

        $id = "select max(id) id from gca_solicitud_condonacion";
        $id = CondonacionesActions::executeConsultasConsul($id);
        $id = $id[0]['id'] + 1;
        $total = str_replace(',', '', $total);
        $sql = "insert into  gca_solicitud_condonacion
                        (id,numero,id_cartera,cedula,f_creacion,creado_por,f_modificacion,modificado_por,condonacion_capital,cancelar_capital,
                        honorarios,estado,total_acuerdo,total_acuerdo_pagos,abogado,porcen_interes)
                values($id,$id,$cartera,'$cc','$fechacreacion','$usuario','" . date('Y-m-d') . "','$usuario','$pcondonacioncapital', 
                    '$pcancelarcapital','$phonorarios','$estado',$total,$total,'$abogado','" . $_POST['porcen_interes'] . "')";

        CondonacionesActions::executeConsultasInsert($sql);



        $acuerdo = $_POST['acuerdo'];
        $valor = $_POST['valor'];
        $fechapago = $_POST['fechapago'];
        $cuotas = $_POST['cuotas'];
        $contador = count($cuotas);
        for ($i = 0; $i < $contador; $i++) {
            $valor[$i] = str_replace(',', '', $valor[$i]);
            $query = "insert into gca_acuerdo_condonacion
                (acu_num_cuota,acu_fecha_pago,acu_valor_cuota,usu_idcreador,acu_fecha_cre,con_id,fechapago)
                values
                ('$cuotas[$i]','$acuerdo[$i]','$valor[$i]','$usuario','" . date('Y-m-d') . "','$id','$fechapago[$i]')
            ";


            CondonacionesActions::executeConsultasInsert($query);
        }
//        echo $query;die;


        $contador = count($_POST['num_capital']);
        $saldo = 0;
        for ($i = 0; $i < $contador; $i++) {
            $query = "insert into gca_detalle_solicitud
                (id_solicitud_condonacion,obligacion,saldo_total,capital,condonacion_capital,
                total_intereses,total_condonacion,total_condonacion_pago,
                saldo_credito,honorarios,pago_total,pago_total_pagos,condonacion_intereses)
                values
                (
                '" . $id . "',
                '" . $_POST['num_obligacion'][$i] . "',
                '" . $_POST['num_saldo_total'][$i] . "',
                '" . $_POST['num_capital'][$i] . "',
                '" . $_POST['num_condonacion_capital'][$i] . "',
                '" . $_POST['num_total_interes'][$i] . "',
                '" . $_POST['num_total_condonacion'][$i] . "',
                '" . $_POST['num_saldo_a_pagar'][$i] . "',
                '" . $_POST['num_saldo_a_pagar'][$i] . "',
                '" . $_POST['num_honorario_iva'][$i] . "',
                '" . $_POST['num_total_a_pagar'][$i] . "',
                '" . $_POST['num_total_a_pagar'][$i] . "',
                    '" . $_POST['condonacion_intereses'][$i] . "'
                    )
            ";
            $saldo+=$_POST['num_total_condonacion'][$i];
            CondonacionesActions::executeConsultasInsert($query);
            $sql = "update gca_obligacion set bloqueada=1 where obligacion='" . $_POST['num_obligacion'][$i] . "'";
            CondonacionesActions::executeConsultasInsert($sql);
            estados($estado, $_POST['num_obligacion'][$i]);
        }
        $sql = "update gca_solicitud_condonacion set total_a_pago_pagos=" . $saldo . ",total_a_pago=" . $saldo . " where id=$id";
        CondonacionesActions::executeConsultasInsert($sql);



        echo $id;
        break;
    case 'actualizar_informacion':
//      Mas Informacion
        $conceptooperador = $_POST['conceptooperador'];
        $reportevisita = $_POST['reportevisita'];
        $tipogarantia = $_POST['tipogarantia'];
        $investigacionbienes = $_POST['investigacionbienes'];
        $propuestacliente = $_POST['propuestacliente'];
        $antecedentes = $_POST['antecedentes'];
        $cedula = $_POST['cedula'];

        $sql = "update gca_solicitud_condonacion 
            set 
            antecedentes = '$antecedentes',
            propuesta_cliente = '$antecedentes',
            investigacion_bienes =  '$investigacionbienes',
            tipo_garantia = '$tipogarantia',
            reporte_visita = '$reportevisita',
            concepto_operador = '$conceptooperador'
            where cedula = '" . $cedula . "'";

        CondonacionesActions::executeConsultasInsert($sql);

        break;
    case 'actualizar_juridica':
//       Juridico

        $observacioncomite = $_POST['observacioncomite'];
        $medidascautelares = $_POST['medidascautelares'];
        $conptojuridico = $_POST['conptojuridico'];
        $estadoproceso = $_POST['estadoproceso'];
        $cedula = $_POST['cedula'];

        $sql = "update gca_solicitud_condonacion 
            set 
            estado_proceso = '$estadoproceso',
            concepto_juridico = '$conptojuridico',
            medidas_cautelares = '$medidascautelares',
            observaciones_comite = '$observacioncomite'
            where cedula = '" . $cedula . "'";

//        echo $sql;die;

        CondonacionesActions::executeConsultasInsert($sql);

        break;
    case 'busqueda_cedula':
        $consultaexistencia = "select * from gca_solicitud_condonacion "
                . "where estado <> 4 and estado <> 6 and estado <> 7 "
                . " and  id_cartera = '" . $_POST['cartera'] . "' and cedula = '" . $_POST['cedula'] . "'";

        $existencia = CondonacionesActions::executeConsultasConsul($consultaexistencia);

        $contadordatos = count($existencia);

        if ($contadordatos == 0) {
            $sql = "select gca_deudor.*,gca_obligacion.obligacion obligacion,gca_obligacion.saldo_capital capital,gca_obligacion.saldo_mora saldo_capital,"
                    . "gca_obligacion.contacto,gca_obligacion.interes_mora,gca_obligacion.fecha_calculo_mora  "
                    . "from gca_deudor "
                    . "join gca_obligacion on gca_obligacion.cedula=gca_deudor.cedula "
                    . "where gca_deudor.cedula='" . $_POST['cedula'] . "' and gca_obligacion.id_cartera='" . $_POST['cartera'] . "' "
                    . " and gca_obligacion.obligacion  not in ("
                    . "select gca_detalle_solicitud.obligacion from gca_detalle_solicitud join  gca_solicitud_condonacion on gca_solicitud_condonacion.id=gca_detalle_solicitud.id_solicitud_condonacion and gca_solicitud_condonacion.estado<>4 and gca_solicitud_condonacion.estado<>6 and gca_solicitud_condonacion.estado<>7)";
            $datos = CondonacionesActions::executeConsultasConsul($sql);
            if (count($datos) == 0) {
                $consultaexistencia = "select * from gca_solicitud_condonacion where estado<>4   and  id_cartera = '" . $_POST['cartera'] . "' and cedula = '" . $_POST['cedula'] . "'";
                $existencia = CondonacionesActions::executeConsultasConsul($consultaexistencia);
                $datos[0]['idsolicitud'] = $existencia[0]['id'];
                $datos[0]['numero'] = 2;
                echo json_encode($datos[0]);
                die();
            }




            // liquidacion de las obligaciones
            $sql_consulta = "SELECT tasa_mora FROM gca_configuracion_sistema";
            $resultado = CondonacionesActions::executeConsultasConsul($sql_consulta);
            if ($resultado[0]['tasa_mora'] > 0) {

                $tasa = $resultado[0]["tasa_mora"];

                $sql = "select id,obligacion,saldo_mora,saldo_capital, interes_mora,fecha_calculo_mora from gca_obligacion where  cedula='" . $_POST['cedula'] . "' and bloqueada=0 ";
                $obligaciones = CondonacionesActions::executeConsultasConsul($sql);
                foreach ($obligaciones as $value) {
                    $diferencia = strtotime(date('Y-m-j')) - strtotime($value['fecha_calculo_mora']);
                    if ($diferencia != 0) {
                        $tiempo = floor($diferencia / 86400);
                        $interes_mora_ant = $value['interes_mora'];
                        $saldo_mora_ant = $value['saldo_mora'];
                        $capital = $value['saldo_mora'];
                        $tasa2 = ($tasa / 30) * $tiempo;
                        $interes_mora = floor($capital * ($tasa2 / 100));
                        $interes_mora_ant = $interes_mora_ant + $interes_mora;
                        $saldo_mora_ant = $saldo_mora_ant + $interes_mora;
                        $sql = "update gca_obligacion set saldo_mora=$saldo_mora_ant,interes_mora=$interes_mora_ant,fecha_calculo_mora='" . date('Y-m-j') . "'  where id=" . $value['id'];
                        CondonacionesActions::executeConsultasInsert($sql);
                        $sql = "insert into gca_obligacion_movimiento (obligacion,saldo_mora,saldo_capital,interes_mora,fecha_corte,detalle)"
                                . "values ('" . $value['obligacion'] . "','" . $value['saldo_mora'] . "','" . $value['saldo_capital'] . "','" . $interes_mora_ant . "','" . date('Y-m-j') . "','LIQUIDACION') ";
                        CondonacionesActions::executeConsultasInsert($sql);
                    }
                }
            }



            //interes mora
            $sql_consulta = "SELECT tasa_mora FROM gca_configuracion_sistema";
            $resultado = CondonacionesActions::executeConsultasConsul($sql_consulta);



            $html = "";
            $i = 0;
            $saldo_capital2 = 0;
            $capital2 = 0;
            $interes2 = 0;
            foreach ($datos as $acciones) {
                if ($resultado[0]['tasa_mora'] > 0) {
                    $tasa = $resultado[0]['tasa_mora'];
                    $diferencia = strtotime(date('Y-m-d')) - strtotime($acciones['fecha_calculo_mora']);
                    $tiempo = floor($diferencia / 86400);
                    $capital = $acciones['saldo_capital'];
                    $tasa2 = ($tasa / 30) * $tiempo;
                    $interes_mora = floor($capital * ($tasa2 / 100));
                    $acciones['saldo_capital'] = $acciones['saldo_capital'] + $interes_mora;
                    $interes_mora = $interes_mora + $acciones['interes_mora'];
                }



                $html.='<tr>'
                        . '<td>' . $acciones['obligacion'] . '<div><input type="text" class="num0' . $i . '" name="num_obligacion[]" value="' . $acciones['obligacion'] . '" style="display:none"></div></td>'// no obligacion 
                        . '<td>' . number_format($acciones['saldo_capital']) . '<div><input type="text" class="num1' . $i . '" name="num_saldo_total[]"  value="' . $acciones['saldo_capital'] . '" style="display:none"></div></td>'// saldo total
                        . '<td>' . number_format($acciones['capital']) . '<div><input type="text" class="num2' . $i . '" name="num_capital[]" value="' . $acciones['capital'] . '" style="display:none"></div></td>'  // capital
                        . '<td>' . number_format($interes_mora) . '<div><input type="text" class="num4' . $i . '" name="num_total_interes[]" value="' . $interes_mora . '" style="display:none"></div></td>'//total interes
                        . '<td><div class="condonacion_capital' . $i . '"></div> <div><input type="text" class="num3' . $i . '" name="num_condonacion_capital[]" value="" style="display:none"></div></td>'// condonacion capital
                        . '<td><div class="condonacion_intereses' . $i . '">0</div><div><input type="text" class="num4_5' . $i . '" name="condonacion_intereses[]" value="0" style="display:none"></div></td>'//condonacion intereses
                        . '<td><div class="total_condonacion' . $i . '"></div> <div><input type="text" class="num5' . $i . '" name="num_total_condonacion[]" value="" style="display:none"></div></td>' // total condonacion
                        . '<td><div class="saldo_a_pagar' . $i . '"></div> <div><input type="text" class="num6' . $i . '" name="num_saldo_a_pagar[]" value="" style="display:none"></div></td>' // saldo a pagar a su credito
                        . '<td><div class="honorario_iva' . $i . '"></div> <div><input type="text" class="num7' . $i . '" name="num_honorario_iva[]" value="" style="display:none"></div></td>' // honorarios + iva
                        . '<td><div class="total_a_pagar' . $i . '"></div> <div><input type="text" class="num8' . $i . '" name="num_total_a_pagar[]" value="" style="display:none"></div></td>'// total a pagar
                        . '</tr>';
                $saldo_capital2+=$acciones['saldo_capital'];
                $capital2+=$acciones['capital'];
                $interes2+=$interes_mora;
                $i++;
            }
            $datos[0]['html'] = $html . "<tr>
                <td><b>TOTAL</b></td>
                    <td><b><div class='suma_1'>" . number_format($saldo_capital2) . "</div></b></td>
                    <td><b><div class='suma_2'>" . number_format($capital2) . "<input type='hidden' class='capital_total' value='" . $capital2 . "' ></div></b></td>
                    <td><b><div class='suma_4'>" . number_format($interes2) . "</div></b></td>
                        <td><b><div class='suma_3'></div></b></td>
                        <td><b><div class='suma_4_5'>0</div></b></td>
                    <td><b><div class='suma_5'></div></b></td>
                    <td><b><div class='suma_6'></div></b></td>
                    <td><b><div class='suma_7'></div></b></td>
                    <td><b><input type='hidden' class='totales_generales' value=''><div class='suma_8'></div></b></td>
                </tr>";
            $datos[0]['cantidad'] = '<div><input type="hidden" class="cantidad" value="' . $i . '"></div>';
            $datos[0]['numero'] = 1;
            echo json_encode($datos[0]);
        } else {
            $datos[0]['idsolicitud'] = $existencia[0]['id'];
            $datos[0]['numero'] = 2;
//            var_dump($datos[0]);die;
            echo json_encode($datos[0]);
        }
        break;
    case 'aprobacion':
        $valor = $_POST['valor'];
        $campo = $_POST['campo'];
        $cedula = $_POST['cedula'];
        $texto = "";

        if ($campo = $_POST['campo'] == 'decision_comite' && $valor == 1) {
            $valor = 6;
        } else if ($campo = $_POST['campo'] == 'decision_comite' && $valor == 2) {
            $valor = 4;
        }
        if ($campo = $_POST['campo'] == 'aprobado_director' && $valor == 1) {
            $valor = 3;
        } else if ($campo = $_POST['campo'] == 'aprobado_director' && $valor == 2) {
            $valor = 4;
        }
        if ($campo = $_POST['campo'] == 'aprobado_juridica' && $valor == 1) {
            $valor = 5;
        } else if ($campo = $_POST['campo'] == 'aprobado_juridica' && $valor == 2) {
            $valor = 4;
        }

        if ($_POST['campo'] == 'decision_comite') {
            $texto = ",f_aprobacion = '" . date('Y-m-d') . "'";
        }
        $campo = $_POST['campo'];
        $sql = "update  gca_solicitud_condonacion set $campo = '$valor',estado='$valor' $texto  where cedula = '" . $cedula . "'";

        CondonacionesActions::executeConsultasInsert($sql);
//        echo json_encode($datos[0]);
        break;
    case 'busqueda_general':
        $where = "where 1=1 ";
        if ($_POST['cartera'] != '') {
            $where.=" and id_cartera='" . $_POST['cartera'] . "'";
        }
        if ($_POST['cedula'] != '') {
            $where.=" and gca_solicitud_condonacion.cedula like '%" . $_POST['cedula'] . "%'";
        }
//if($_POST['creada']!=''){
//    " and like '".$_POST['creada']."'";
//}
        if ($_POST['estado'] != '') {
            $where.=" and gca_solicitud_condonacion.estado='" . $_POST['estado'] . "'";
        }
        if ($_POST['f_final'] != '' && $_POST['f_inicial'] != '') {
            $where.=" and f_creacion between ('" . $_POST['f_inicial'] . "') and ('" . $_POST['f_final'] . "')";
        } else {
            if ($_POST['f_final'] != '') {
                $where.=" and f_creacion >'" . $_POST['f_final'] . "'";
            }
            if ($_POST['f_inicial'] != '') {
                $where.=" and f_creacion <'" . $_POST['f_inicial'] . "'";
            }
        }
        if ($_POST['solicitud'] != '') {
            $where.=" and numero='" . $_POST['solicitud'] . "'";
        }
        $SQL = "select '$cargo' grado,gca_solicitud_condonacion.abogado,gca_deudor.cedula,total_acuerdo,gca_solicitud_condonacion.f_aprobacion,gca_cartera.nombre cartera,gca_solicitud_condonacion.numero,gca_deudor.nombres,gca_cartera.nombre,gca_solicitud_condonacion.f_creacion,"
                . "gca_solicitud_condonacion.f_aprobacion,gca_solicitud_condonacion.aprobado_director,"
                . "gca_solicitud_condonacion.aprobado_juridica,gca_solicitud_condonacion.decision_comite,gca_estados.est_estado estado,gca_estados.est_id"
                . " from gca_solicitud_condonacion"
                . " join gca_deudor on gca_deudor.cedula = gca_solicitud_condonacion.cedula"
                . " join gca_cartera on gca_cartera.id = gca_solicitud_condonacion.id_cartera "
                . " join gca_estados on gca_estados.est_id = gca_solicitud_condonacion.estado " . $where . " order by gca_solicitud_condonacion.id desc ";
        $datos = CondonacionesActions::executeConsultasConsul($SQL);
        if (count($datos) > 0)
            echo json_encode($datos);
        else
            echo 0;
        break;
    case 'contarInhabilitadas':
        $fecha = date('Y-m-d');
        $dias = $_POST['dias'];
        $nuevafecha = strtotime('-' . $_POST['dias'] . ' day', strtotime($fecha));
        $nuevafecha = date('Y-m-j', $nuevafecha);
        $sql = "select count(*) cantidad
            from gca_pagos
            
            where gca_pagos.fecha <  '$nuevafecha 23:59:59'  
             and gca_pagos.estado=0";
        $datos = CondonacionesActions::executeConsultasConsul($sql);
        echo $datos[0]['cantidad'];
        break;
    case 'buscar_honorarios':
        $sql = "select * from gca_condonaciones where estado=0 and inicial<='" . $_POST['pcondonacioncapital'] . "' and final >='" . $_POST['pcondonacioncapital'] . "'";
        $datos = CondonacionesActions::executeConsultasConsul($sql);
        echo json_encode($datos[0]);
        break;
    case 'inactivar_pagos':
        if (!isset($_POST['dias'])) {
            $sql = "select * from gca_configuracion_sistema";
            $datos = CondonacionesActions::executeConsultasConsul($sql);
            $_POST['dias'] = $datos[0]['dias_sin_aprobar_pago'];
        }

        $fecha = date('Y-m-d');
        $nuevafecha = strtotime('-' . $_POST['dias'] . ' day', strtotime($fecha));
        $nuevafecha = date('Y-m-d', $nuevafecha);
//        $sql = "update gca_solicitud_condonacion set estado=4 where f_creacion<'" . $nuevafecha . "' and f_aprobacion is null and estado=2";
        $sql = " delete from gca_forma_pago where id_gca_pagos in (select gca_pagos.id
            from gca_pagos
           
            where gca_pagos.fecha <  '$nuevafecha 23:59:59'  
             and gca_pagos.estado=0)";
        CondonacionesActions::executeConsultasInsert($sql);
        $sql = "delete from gca_pagos  where id in (select gca_pagos.id
            from gca_pagos
            
            where gca_pagos.fecha <  '$nuevafecha 23:59:59'  
            and gca_pagos.estado=0)";
        CondonacionesActions::executeConsultasInsert($sql);
        $sql = "update gca_configuracion_sistema set dias_sin_aprobar_pago='" . $_POST['dias'] . "'";
        CondonacionesActions::executeConsultasInsert($sql);
        break;
    case 'Guardar_dias':
        $sql = "update gca_configuracion_sistema set dias_sin_aprobar_pago='" . $_POST['dias'] . "'";
        CondonacionesActions::executeConsultasInsert($sql);
        break;
}

function estados($num, $obligacion) {
    if ($num == 4) {
        $sql = "update gca_obligacion set  bloqueada=0 where obligacion='" . $obligacion . "'";
        CondonacionesActions::executeConsultasInsert($sql);
    }
}

?>