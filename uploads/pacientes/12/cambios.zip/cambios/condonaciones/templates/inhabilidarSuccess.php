<script type="text/javascript" charset="utf8" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<table style="margin: 50px auto;border: 2px solid #CCC; padding: 20px">
    <tr>
        <td><b>Dias sin ser aprobado</b></td>
        <td><input type="text" name="dias" id="dias" value="<?php echo $dias[0]['dias_sin_aprobar_pago']; ?>"></td>
        <td><b>pagos</b></td>
    </tr>
    <tr>
        <td colspan="3" align='right'>
            <button id="ejecutar">Ejecutar</button>
            <button id="guardar">Guardar</button>
        </td>
    </tr>
</table>
<script>
    $('body').delegate('#dias', 'keypress', function(tecla) {
        if (tecla.charCode > 0 && tecla.charCode < 48 || tecla.charCode > 57)
            return false;
    });
    $('#guardar').click(function() {
        action = "Guardar_dias";
        var dias = $('#dias').val();
        var url = "busquedaCondonacion";
        if (dias > 0) {
            $.post(url, {action: action, dias: dias})
                    .done(function(msg) {
                        alert('Los cambios fueron realizados con exito');
                    }).fail(function() {
                alert('Error en consulta')
            });
        } else {
            alert('Dias tiene que ser mayor a 0.')
        }
    })
    $('#ejecutar').click(function() {
        var dias = $('#dias').val();
        if (dias > 0) {
            var url = "busquedaCondonacion";
            var action = "contarInhabilitadas";
            $.post(url, {action: action, dias: dias})
                    .done(function(msg) {
                        if (msg > 0) {
                            var r = confirm('Desea eliminar ' + msg + " pagos del sistema ")
                            if (r == true) {
                                action = "inactivar_pagos";
                                $.post(url, {action: action, dias: dias})
                                        .done(function(msg) {
                                            alert('Los cambios fueron realizados con exito');
                                        }).fail(function() {
                                    alert('Error en consulta')
                                })
                            }
                        } else {
                            alert('No se encontraron registros');
                        }
                    }).fail(function() {
                alert('Error al consultar')
            });
        } else {
            alert('Dias tiene que ser mayor a 0.')
        }
    });
</script>