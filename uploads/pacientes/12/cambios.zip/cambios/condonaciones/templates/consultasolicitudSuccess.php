<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.css">
<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.js"></script>
<div style="width: 80%;margin: 0 auto;">
    <form method="post" id="solicitudes">
        <div style="display: none">
            <input type="hidden" name="action" id="action" value="busqueda_general">
        </div>
        <table style="width: 100%; margin-top: 30px" border="0">
            <tr>
                <td style="width: 15%"><label for="solicitud">Solicitud No</label></td>
                <td style="width: 35%"><input type="text" id="solicitud" name="solicitud" class="limpiar"></td>
                <td style="width: 15%"><label for="f_inicial">Fecha Inicial</label></td>
                <td style="width: 35%"><input type="text" id="f_inicial" name="f_inicial" class="limpiar fecha"></td>
            </tr>
            <tr>
                <td><label for="cedula">Cedula</label></td>
                <td><input type="text" id="cedula" name="cedula" class="limpiar"></td>
                <td><label for="f_final">Fecha Final</label></td>
                <td><input type="text" id="f_final" name="f_final" class="limpiar fecha"></td>
            </tr>
            <tr>
                <td><label for="cartera">Cartera</label></td>
                <td>
                    <select class="limpiar" id="cartera" name="cartera">
                        <option value=""></option>
                        <?php foreach ($cartera as $value) { ?>
                            <option value="<?php echo $value['id']; ?>"><?php echo $value['nombre']; ?></option>
                        <?php } ?>
                    </select>
                </td>
                <td><label for="estado">Estado</label></td>
                <td>
                    <select class="limpiar" id="estado" name="estado">
                        <option value="">Todos...</option> 
                        <?php foreach ($estado as $value) { ?>
                            <option value="<?php echo $value['est_id']; ?>"><?php echo $value['est_estado']; ?></option>
                        <?php } ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="creada">Creada por:</label></td>
                <td><input type="text" id="creada" name="creada" class="limpiar"></td>
<!--                <td><label for="d_director">Aprobado por Director</label></td>
                <td><input type="checkbox" id="d_director" name="d_director"></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><label for="p_juridico">Aprobado por Juridico</label></td>
                <td><input type="checkbox" id="p_juridico" name="p_juridico"></td>-->
            </tr>
        </table>
    </form>
    <table width="100%">
        <tr>
            <td><center><button type="button" class="limpiarcampos" id="limpiarcampos">Limpiar</button>&nbsp;&nbsp;
            <button type="button" class="buscar" id="buscar">Buscar</button></center></td>
        </tr>
    </table>
    <p><br></p>

    <table style="width: 100%" id="mitable">
        <thead id="cabecera" style="background-color: #4c86ac;color: white;">
        <th>Solicitud No</th>
        <th>Cedula</th>
        <th>Titular</th>
        <th>Fecha Creación</th>
        <th>Cartera</th>
        <th>Estado</th>
        <th>Saldo a pagar al crédito</th>
        <th>Fecha Aprobación</th>
        <th>Aprobado por Director</th>
        <th>Aprobado por Juridico</th>
        <th>Aprobado por Comite</th>
        <th>Opciones</th>
        </thead>
        <tbody id="cuerpo">
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>
    <div align="right" style="margin-top: 60px">
        <a href="nuevasolicitud"><button type="button">Nueva Solicitud</button></a>
    </div>
</div>
<form method="post" id="editar" action="nuevasolicitud"> 
    <input type="hidden" name="number" id="number">
    <input type="hidden" name="versolicitud" id="versolicitud">
</form>
<form method="post" id="anular" action="consultasolicitud"> 
    <input type="hidden" name="number2" id="number2">
    <input type="hidden" name="versolicitud2" id="versolicitud2">
</form>
<style>
    .data{
        text-align: center;
    }
</style>
<script>

    $('#cabecera thead th').addClass('data');

    $(document).ready(function() {
        $('.fecha').datepicker({
            dateFormat: "yy-mm-dd"
        });
        $('#mitable').dataTable({
            "order": [[0, "desc"]]
        });
    });
    $('.limpiarcampos').click(function() {
        Ext.Msg.confirm('Hey!', 'Limpiar Filtros?', function(btn, text) {
            $('.limpiar').val('');
        });
    });

    $('body').delegate('.editar', 'click', function() {

        $('#number').val($(this).attr('number'));
        $('#versolicitud').attr('name', 'versolicitud2');
        $('#editar').submit();
    });
    $('body').delegate('.anular', 'click', function() {
        var r = confirm('Confirma que desea anular esta condonación')
        if (r == false)
            return false;
        $('#number2').val($(this).attr('number'));
        $('#versolicitud2').attr('name', 'versolicitud2');
        $('#anular').submit();
    });

    $('body').delegate('.ver', 'click', function() {

        $('#number').val($(this).attr('number'));
        $('#versolicitud').attr('name', 'versolicitud');
        $('#versolicitud').val($(this).attr('number'));

        $('#editar').submit();

    });

    $('.buscar').click(function() {
        var url = "busquedaCondonacion";
        $('#cuerpo').html('');
        $.post(url, $('#solicitudes').serialize())
                .done(function(msg) {

                    var datos = jQuery.parseJSON(msg);
                    $('#mitable').DataTable().rows().remove();
                    if (msg != 0) {
                        $.each(datos, function(key, val) {
                            var ver = "<button type='button'  number='" + val.numero + "' class='ver'>ver</button>";



                            var gg = val.grado;
                            console.log(gg);
                            var anular = "";
                            if (gg.indexOf('crear_solicitud') > -1 && val.est_id == 1) {
                                var opcion = "<button type='button' class='editar' number='" + val.numero + "'>Editar</button>";
                            } else if (gg.indexOf('aprueba_director') > -1 && val.est_id == 2) {
                                var opcion = "<button type='button' class='editar' number='" + val.numero + "'>Editar</button>";
                            } else if (((gg.indexOf('aprueba_comite') > -1 && val.abogado == '') || gg.indexOf('aprueba_juridica') > -1) && val.est_id == 3) {
                                var opcion = "<button type='button' class='editar' number='" + val.numero + "'>Editar</button>";
                            } else if (gg.indexOf('aprueba_comite') > -1 && val.est_id == 5) {
                                var opcion = "<button type='button' class='editar' number='" + val.numero + "'>Editar</button>";
                            } else {
                                var opcion = "";
                            }
                            if (gg.indexOf('anular_condonaciones') > -1 && val.est_id != 4 && val.est_id == 6) {
                                anular = "<button type='button' class='anular' number='" + val.numero + "'>Anular</button>";
                            }
                            $('#mitable').DataTable().row.add([
                                val.numero,
                                val.cedula,
                                val.nombres,
                                val.f_creacion,
                                val.cartera,
                                val.estado,
                                CurrencyFormatted(val.total_acuerdo),
                                val.f_aprobacion,
                                (val.aprobado_director ? (val.aprobado_director == 4 ? 'NO' : 'SI') : 'NO'),
                                (val.aprobado_juridica ? (val.aprobado_juridica == 4 ? 'NO' : 'SI') : 'NO'),
                                (val.decision_comite ? (val.decision_comite == 4 ? 'NO' : 'SI') : 'NO'),
                                opcion + ver + anular
                            ]).draw();


                            $('#cabecera thead th').addClass('data');
                        });
                    } else {
                        $('#cuerpo').html('<tr><th colspan="10"><center>Datos No Encontrados</center></th></tr>')
                    }
                })
                .fail(function(msg) {
                });
    });

    function CurrencyFormatted(num) {
        num = num.toString().replace(/\$|\,/g, '');
        if (isNaN(num))
            num = "0";
        sign = (num == (num = Math.abs(num)));
        num = Math.floor(num * 100 + 0.50000000001);
        cents = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10)
            cents = "0" + cents;
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
            num = num.substring(0, num.length - (4 * i + 3)) + ',' +
                    num.substring(num.length - (4 * i + 3));
        return (((sign) ? '' : '-') + num);
    }
</script>    