<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.css">
<!-- jQuery -->
<script type="text/javascript" charset="utf8" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.js"></script>
<?php
$datos = CondonacionesActions::listaCondonacion();
?>
<p style="margin-top: 30px;"></p>
<center>
<div style="width: 90%">
    <table id="mitable"  >
        <thead style="background-color: #4c86ac;color: white;">
        <th>Id</th>
        <th>Condonación</th>
        <th>% Inicial</th>
        <th>% Final</th>
        <th>% Honorarios</th>
        <th>Activo</th>
        </thead>
        <tbody id="lista">
            <?php
            foreach ($datos as $infor) {
                ?>
                <tr id="col<?php echo $infor['id'] ?>">
                    <td><?php echo $infor['id'] ?></td>
                    <td><?php echo $infor['condonacion'] ?></td>
                    <td><?php echo $infor['inicial'] ?></td>
                    <td><?php echo $infor['final'] ?></td>
                    <td><?php echo $infor['honorarios'] ?></td>
                    <td>
                        <div><a href="index?condo=<?php echo $infor['condonacion'] ?>" class="edit_cons" ahy="<?php echo $infor['id'] ?>">Editar</a></div>
                        <div><a href="javascript:" class="borrar_cons" ahy="<?php echo $infor['id'] ?>">Borrar</a></div>
                    </td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
    </div>
<div style="margin-top: 20px; width: 90%" align="right">
    <a href="index"><button type="button" id="nueva" style="width: 80px;height: 41px">Nueva</button></a>
</div>
    </center>
<style>
    .centrado{
        text-align: center;
    }
</style>
<script>
    
    
    
    $(document).ready(function () {
        $('#mitable').DataTable();
        
        $('#lista tr td').addClass('centrado');
        
    });
    $('.borrar_cons').click(function () {
        url = "consultar";
        var action = "eliminar_condonacion";
        var id = $(this).attr('ahy');
        var r = confirm('Confirma que desea eliminar la condonacion');
        if (r == false)
            return false;
        $.post(url, {action: action, id: id})
                .done(function (msg) {
                    alert('Los datos fueron eliminados correctamente');
                    $('#col' + id).hide()
                }).fail(function () {
            alert('Error en la solicitud por favor intentar mas tarde')
            $('#col' + id).show()
        });
    });
</script>