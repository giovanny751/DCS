<?php

/**
 * main actions.
 *
 * @package    caf
 * @subpackage main
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12479 2008-10-31 10:54:40Z fabien $
 */
class mainActions extends sfActions
{
 /**
  * Executes index action
  *
  * @param sfRequest $request A request object
  */
public function executeCodigos(sfWebRequest $request)
{

}
  public function executeIndex(sfWebRequest $request)
  {
 
    //$this->forward('default', 'module');
	$this->fecha= Doctrine::getTable('GcaDatosFuncionarios')->getFechaCambio($this->getUser()->getAttribute('usuario'));
  }
  public function executeMain(sfWebRequest $request){
	
  }
  /*Liliana:jur*/
  public function executeProcesos(sfWebRequest $request){
		
  }
  
  /*Liliana : searching*/
   public function executeSearching(sfWebRequest $request){
		
  }
   public function executeGestionUsuario(sfWebRequest $request){
		
  }
  
  public function executeHeader(sfWebRequest $request){
  
   if($this->getUser()->isAuthenticated()){
	 $this->credenciales = $this->getUser()->listCredentials();	 
	 
   }
 
  }
  public function executeLateral(sfWebRequest $request){
	$this->mostrarDeudores=false;
	$this->mostrarProcesos=false;
	if($this->getUser()->isAuthenticated()){
		if($this->getUser()->hasCredential('jur') || $this->getUser()->hasCredential('auditor')){
			$this->mostrarProcesos=true;
		}
		if($this->getUser()->hasCredential('asesor')){
			$this->mostrarDeudores=true;
		}
		if(!$this->getUser()->hasCredential('jur') && !$this->getUser()->hasCredential('asesor')){
		   $this->mostrarDeudores=true;
		}
	}	
  }
  public function executePrincipal(sfWebRequest $request){
	$this->codensa_id_reclamo = sfConfig::get('app_codensa_id_reclamo');
	$this->codensa_id_honorarios = sfConfig::get('app_codensa_id_honorarios');
	$this->codensa_id_cuotas = sfConfig::get('app_codensa_id_cuotas');
	$this->codensa_id_al_dia = sfConfig::get('app_codensa_id_al_dia');
	$this->codensa_id_documentos = sfConfig::get('app_codensa_id_documentos');
	$this->codensa_id_esperas = sfConfig::get('app_codensa_id_esperas');
	$documentos = sfConfig::get('app_codensa_documentos');
	$documentos = explode(",",$documentos);
	$codensa_documentos = "[";
	for($i=0;$i<count($documentos);$i=$i+2){
		if($i>0) $codensa_documentos.=",";
		$codensa_documentos.="{codigo:'".$documentos[$i]."',descripcion:'".$documentos[$i+1]."'}";
	}
	$codensa_documentos .= "]";
	$esperas = sfConfig::get('app_codensa_esperas');
	$esperas = explode(",",$esperas);
	$codensa_esperas  = "[";
	for($i=0;$i<count($esperas);$i=$i+2){
		if($i>0) $codensa_esperas.=",";
		$codensa_esperas.="{codigo:'".$esperas[$i]."',descripcion:'".$esperas[$i+1]."'}";
	}
	$codensa_esperas .= "]";
	$this->codensa_documentos = $codensa_documentos;
	$this->codensa_esperas = $codensa_esperas;
  }
  
  public function executeNomina(sfWebRequest $request){
	
  }
  
  public function executeGrilla(sfWebRequest $request){
    
  }
  
  public function executeIndicadoresGestion(sfWebRequest $request){
    
  }
  
  public function executeFiltros(sfWebRequest $request){
    
  }
 public function executeEjCambioClave(sfWebRequest $request){
	$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();   
	 $id_user = $this->getUser()->getAttribute('usuario');
	$ant_clave =$request->getParameter('clave_ant');
	$new_clave =$request->getParameter('clave_new');
	$conf_clave =$request->getParameter('clave_conf');
if(strlen($new_clave)<6)
	{echo 3;exit;}
if(is_numeric($new_clave))
	{echo 4;exit;}
	if($new_clave!=$conf_clave)
	{echo 2;exit;}
	//echo $ant_clave." ".$new_clave;exit;
$q = Doctrine_Query::create()
		->from('GcaDatosFuncionarios f')
		->where('f.id_empleado = ?', $id_user)
		->andWhere('f.clave = ?', pg_escape_string($ant_clave))
		->execute(); 
	//$sql = "select id_empleado from gca_datos_funcionarios where id_empleado = ".$id_user." and clave='".pg_escape_string($ant_clave)."'";
	 
	$id_otrouser = $q[0]['id_empleado'];
	//var_dump($q[0]);exit;
	//echo $id_otrouser;
	if($id_user==$id_otrouser && $ant_clave!=$new_clave)
	{
		$q[0]->setClave($new_clave);
		$q[0]->setFechaCambioClave(date("Y-m-d"));
		$q[0]->save();
		/*$q = Doctrine_Query::create()
		->update('GcaDatosFuncionarios')
		->set("clave='?'",$new_clave)
		->set('fecha_cambio_clave=?', 'current_date')
		->where('id_empleado=?',$id_user)->execute();*/
		echo 0;exit;
	}
	else{
		echo 1;exit;
	}
  }
  public function executeCambioClave(sfWebRequest $request){
   	
  }
  public function executeInfoCarteraBCSC(sfWebRequest $request){
	$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
	$id_user = $this->getUser()->getAttribute('usuario');
	$sql = "select id_cartera from gca_funcionarios where id = ".$id_user; 
	$id_cartera = $doctrine->query($sql)->fetchColumn();
	$query="SELECT COUNT(*) as cant FROM (SELECT DISTINCT tipo_registro FROM gca_info_tablas_ics) as temp";
	$cantidadRegistros= $doctrine->query($query)->fetchAll(); 
	$cantidadRegistros=(int)$cantidadRegistros[0]["cant"];
	$id_cartera_bcsc = sfConfig::get('app_id_cartera_bcsc');
	
	
	$query="SELECT group_concat(id) as carteras FROM gca_cartera WHERE ics=1";
	$carteras_ics=$doctrine->query($query)->fetchAll();
	$carteras_ics=explode(",",$carteras_ics[0]["carteras"]);
	if(!in_array($id_cartera,$carteras_ics)){
		$this->mostrarBCSC = false;
	}else{
		$this->mostrarBCSC = true;
	}
	//$this->mostrarBCSC=true;
	$query="SELECT * FROM gca_info_tablas_ics ORDER BY seq";
	$this->campos= $doctrine->query($query)->fetchAll(); 
	$this->tipoRegistros=$cantidadRegistros;
	$tipo_registro=$request->getParameter("tipoRegistro");
	
	if($tipo_registro){
	 $cedula = $doctrine->query("select tipo_documento||cedula from gca_obligacion where id = ".$request->getParameter('id'))->fetchColumn();
	 $query_info_adicional ="select * from gca_info_adicional where id_cartera = $id_cartera and col_2 = '$tipo_registro' and col_3 LIKE '%$cedula'";
	 $this->rs = $doctrine->query($query_info_adicional)->fetchAll();
	 $query1="SELECT * FROM gca_info_tablas_ics WHERE tipo_registro = 1 ORDER BY seq";
	 $this->values_info_adicional = $doctrine->query($query1)->fetchAll();
	 
	 $arr_values = array();
	 $arr_values['registros'] = array();
	 $i=0;
	 foreach($this->rs as $values){
	  $j = 3;
	  foreach($this->values_info_adicional as $value){
	    $arr_values['registros'][$i][$value['columna']] = $values['col_'.$j];
	    $j++;
	  }
	  $i++;
	  
	  
	 }
	 $arr_values['cant'] = $i;
	 $this->json_info_adicional = json_encode($arr_values);
	 echo $this->json_info_adicional; exit;
	}
	/*
	
	*/
	
  }
  
  public function executeInfoAdicional(sfWebRequest $request){
   
   exit;
   
   
   
   
   $params= $request->getGetparameters();
   $sqlObligacion = "select obligacion, id_cartera from gca_obligacion";
   
   
   $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
   
   $this->rsObligacion = $doctrine->query($sqlObligacion)->fetchAll(); 
   $this->gca_obligacion_list = array(); 
   //$this->id = $params['id']
   /*
   
   
   $sqlInfoAdicional = "select * from gca_info_adicional where obligacion = '".$rsObligacion['obligacion']."' and id_cartera = ".$rsObligacion['id_cartera'];
   $rsInfoAdional = $doctrine->query($sqlInfoAdicional)->fetchAll();
   
   $sqlColsInfoAdicional = "select columnas from gca_cols_info_adicional where id = ".$rsInfoAdicional[0]['id_gca_cols_info_adicional'];
   $rsColsInfoAdicional = $doctrine->query($sqlColsInfoAdicional)->fetchColumn();
   
   
   $colsInfoAdicional = explode(",",$rsColsInfoAdicional);
   $this->arr_colsInfoAdicional = str_replace("_", " ",$colsInfoAdicional);
   $cuenta = count($this->arr_colsInfoAdicional);
   
   
   $arr_info_adicional = array();
   $arr_info_adicional['registros'] = array();
   $i = 0;
   foreach($this->$rsInfoAdicional as $info_adicional){
    
      for($j = 0; $j<$cuenta; $j++){
	$arr_info_adicional['registros'][$i][$this->arr_colsInfoAdicional[$j]] = $info_adicional[$j+2];
      }
      
    
   }
   
   $arr_info_adicional['cant'] = $i;
   
   $this->json_infoAdicional = json_encode($arr_info_adicional);
   
   
   
   */
   
  }
public function executeDetalleLocalizacion(sfWebRequest $request)
{
$documento=$request->getParameter('id');
$this->documento=$request->getParameter('id');
if($documento!='')
	{
	$this->documento=$documento;
	}

}
public function executeJsonDatosUsuario(sfWebRequest $request)
{
$records= $request->getGetParameter('records');
//echo var_dump($request);exit;
$this->contenido=$contenido='{}';
if(isset($records))
	{$hecho=false;
		$registros=json_decode($records,TRUE);
		foreach($registros as $registro)
		{
		//var_dump($registro);exit;
		if(isset($registro['newRecordId']))//significa nuevo registro.
		{
			$usuario=new GcaFuncionariosSearching();
			//$usuario->setId($registro['idusuario']);
			$usuario->setNombre(strtoupper($registro['nombre']));
			$usuario->setUsuario($registro['usuario']);
			$usuario->setContrasena($registro['clave']);
			$usuario->setIdCliente($registro['cliente']);
			$usuario->save();
		}
		else{
			if(isset($registro['idusuario']))
			{
			$datosTabla=Doctrine::getTable('GcaFuncionariosSearching')->createQuery()->where('id=?',$registro['idusuario']);
				$datosTabla->update();				
				if(isset($registro['nombre']))
				{$datosTabla->set('nombre','?',strtoupper($registro['nombre']));}
				if(isset($registro['usuario']))
				{$datosTabla->set('Usuario','?',$registro['usuario']);}
				if(isset($registro['clave']))
				{$datosTabla->set('Contrasena','?',$registro['clave']);}
				if(isset($registro['cliente']))
				{$datosTabla->set('Id_Cliente','?',$registro['cliente']);}
			//echo $datosTabla->getSqlQuery();exit;
			$datosTabla->execute();
		
			}
		}
		
		}
		$this->contenido=$contenido='{ success: true}';
	
	}
else
{
$limite=$request->getParameter('limit');
$inicio=$request->getParameter('start');
$filtro=$request->getParameter('filtro');
if($filtro!='')
{
$sqlObligacion = "select * from gca_funcionarios_searching where nombre like '%".$filtro."%' limit ".$limite." offset ".$inicio;
 }
else
{
$sqlObligacion = "select * from gca_funcionarios_searching limit ".$limite." offset ".$inicio;
}  
   
   $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
   
   $cart = $doctrine->query($sqlObligacion)->fetchAll(); 
		$total=$doctrine->query("select count(*) from gca_funcionarios_searching")->fetchColumn();
		$contenido='';
		$contenido.='{ "total":"'.$total.'",
							 "registros":[';
			$i=0;
			foreach($cart as $c){
				if($i!=0) $contenido.=",";
				$contenido.='{
								"idusuario":"'.$c['id'].'",
								"nombre":"'.$c['nombre'].'",
								"usuario":"'.$c['usuario'].'",
								"clave":"'.$c['contrasena'].'",
								"cliente":"'.$c['id_cliente'].'",
								}';
				$i++;

			}
			$contenido.=']}';

		 	
			$this->contenido = $contenido;
 } 
}

/*NUEVO*/
public function executeVisitasCodensa(sfWebRequest $request){
	exit;
}
/*NUEVO*/ 
}
