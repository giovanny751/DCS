

var SolicitudesAsigHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'tab-solicitudes-asignadas',
		title: 'Solicitudes',
		region:'center',
		closable: true,
		layout:'fit', 
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-solicitudes', url: 'schSolicitud/solicitudes' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var SchReportesHandler = function (button,event){
	var nuevoTab = new Ext.Panel({
		id: 'tab-reportes-sch',
		title: 'Generar Reportes',
		region:'center',
		closable: true,
		layout:'fit', 
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-sch-reportes', url: 'schRegSolicitud/reportes' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}

var fm = Ext.form;

/* -----------------COMBO ESTADOS------------------------*/
var datosEstadosSch = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
				url : 'schRegSolicitud/getEstadosJson',
				method: 'GET',
		})

});	

var datosCarteraSch = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
				url : 'schSolicitud/getCarterasJson',
				method: 'GET',
		})

});	

var datosEstadosEps = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
				url : 'schRegSolicitud/getEstadosEpsJson',
				method: 'GET',
		})

});	

var datosRegimenEps = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
				url : 'schRegSolicitud/getRegimenEpsJson',
				method: 'GET',
		})

});	

var datosTipoEps = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
				url : 'schRegSolicitud/getTipoEpsJson',
				method: 'GET',
		})

});	

var datosAsesoresSch = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
				url : 'schAsesoresAsig/getAsesoresAsigJson',
				method: 'GET',
		})

});	


Ext.localizarRegistro = function(sel){
	var idLocalizados = "";
	var direccionesLocalizados="";
	var telefonosLocalizados="";
	var ciudadesLocalizados="";
	var cedulasLocalizados="";
	if(sel=="yes"){
		var grillaBDSearch = Ext.getCmp('reporte-bbdd-searching');
		var storeBDSearch = grillaBDSearch.getStore();
		//alert(storeBDSearch.getCount());
		var j=0;
		for(i=0;i<storeBDSearch.getCount();i++){
			var regSearchingBBDD = storeBDSearch.getAt(i);			
			var registroChecked = document.getElementById("localizado_"+regSearchingBBDD.get("id")).checked;
			if(registroChecked){
				if(j>0){
					idLocalizados+=";"
					direccionesLocalizados+=".::.";
					telefonosLocalizados+=".::.";
					ciudadesLocalizados+=".::.";
					cedulasLocalizados+=".::.";
				}
				idLocalizados+=""+regSearchingBBDD.get("validacion")
				direccionesLocalizados+=""+regSearchingBBDD.get("direccion");
				telefonosLocalizados+=""+regSearchingBBDD.get("telefono");
				ciudadesLocalizados+=""+regSearchingBBDD.get("ciudad");
				cedulasLocalizados+=""+regSearchingBBDD.get("cedula");
				j++;
			}
		}
		var paramBBDDSearch = {params: {tipo:"validar", localizados:idLocalizados,ciudades:ciudadesLocalizados,direcciones:direccionesLocalizados,telefonos:telefonosLocalizados,cedulas:cedulasLocalizados}};
		storeBDSearch.load(paramBBDDSearch);
	}
	
}



var gestionSeachHandler = function(button,event) {
	
	//var registro;
	var parametros = {params: {inicio:0, limite:20}};
    // Create a standard HttpProxy instance.
    var datosStore = new Ext.data.JsonStore({
            root: 'registros',
            totalProperty: 'cant',
            idProperty: 'id',
            autoSave: false,
            writer:new Ext.data.JsonWriter(),
            fields: [
                    {name: 'id'},    
                    {name: 'nombre'},	
                    {name: 'cedula'},		   	   
                    {name: 'estado'},	
                    {name: 'fecha_estado'},		   	   
                    {name: 'telefono'},
                    {name: 'direccion'},
                    {name: 'ciudad_sin_editar'},
                    {name: 'quien_confirma'},
                    {name: 'parentesco'},
                    {name: 'cod_ass'},
                    {name: 'id_asesor'},
                    {name: 'asesor'},					
                    {name: 'id_cartera'},					
                    {name: 'nomb_cc'},					
                    {name: 'eps_estado'},					
                    {name: 'eps_entidad'},					
                    {name: 'eps_regimen'},					
                    {name: 'eps_tipo'},					
                    {name: 'eps_fecha'},					
            ],
            proxy: new Ext.data.HttpProxy({
                    url: 'schRegSolicitud/getJson',
                    method: 'GET',
            }),
            paramNames:{
                start: 'inicio',
                limit: 'limite'                
            }
			
    });
    datosStore.load(parametros);
	
	var comboEst = new fm.ComboBox({
										store:datosEstadosSch,
									   lazyRender: true,
										typeAhead: true,
										allowBlank:false,
										resizable:true,
										triggerAction: 'all',
										displayField:'nombre',
										valueField: 'id',
										mode: 'local',                                    
									});
								
	var comboEstEps = new fm.ComboBox({
									store:datosEstadosEps,
								   lazyRender: true,
									typeAhead: true,
									allowBlank:true,
									resizable:true,
									triggerAction: 'all',
									displayField:'nombre',
									valueField: 'id',
									mode: 'local',                                    
								});

	var comboRegEps = new fm.ComboBox({
									store:datosRegimenEps,
								   lazyRender: true,
									typeAhead: true,
									allowBlank:true,
									resizable:true,
									triggerAction: 'all',
									displayField:'nombre',
									valueField: 'id',
									mode: 'local',                                    
								});
					
	var comboTipoEps = new fm.ComboBox({
							store:datosTipoEps,
						   lazyRender: true,
							typeAhead: true,
							allowBlank:true,
							resizable:true,
							triggerAction: 'all',
							displayField:'nombre',
							valueField: 'id',
							mode: 'local',                                    
						});		
	
	var esp_nuevo = false; 
	var obligacionGrid = new Ext.grid.EditorGridPanel({
		id: 'obligacion-sch-grid',
		store: datosStore,
		flex:10,
		clicksToEdit: 1,
		listeners: {
					afteredit: function(celda) {
						celda.dirty=false;
						//alert(celda.field); 
						if(celda.field == 'eps_estado' | celda.field == 'eps_regimen' | celda.field == 'eps_tipo' | celda.field == 'eps_entidad'){
							esp_nuevo = true; 
						}
						this.store.add(celda); 
					},
				},				
		columns: [
				{id:'id', header:'Id', hidden:true, width: 20, sortable:true, dataIndex: 'id'},    
				{header: 'Nombre', width: 150, sortable:true, dataIndex: 'nombre'},
				{header: 'Cedula', width: 70, sortable:true, dataIndex: 'cedula'},
				{header: 'Estado', width: 75, dataIndex: 'estado', fixed: true ,  editor: comboEst, renderer: function(value) {
                                            var r = datosEstadosSch.getById(value);                            
                                            return r ? r.data.nombre : '';
										  }
				},
				{header: 'Fecha Estado', width: 75, sortable:true, dataIndex: 'fecha_estado'},
				{header: 'Telefono', width: 75, sortable:true, dataIndex: 'telefono', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Direccion', width: 100, sortable:true, dataIndex: 'direccion', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Ciudad', width: 70, sortable:true, dataIndex: 'ciudad_sin_editar', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Quien Confirma', width: 100, sortable:true, dataIndex: 'quien_confirma', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Parentesco', width: 70, sortable:true, dataIndex: 'parentesco', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Estado EPS', width: 75, dataIndex: 'eps_estado', fixed: true , editor: comboEstEps, renderer: function(value) {
                                            var r = datosEstadosEps.getById(value);                            
                                            return r ? r.data.nombre : '';
										  }
				},
				{header: 'Entidad EPS', width: 100, sortable:true, dataIndex: 'eps_entidad', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Detalle EPS', width: 100, sortable:true, dataIndex: 'eps_detalle', editor: new fm.TextField({
																									grow:true,
																								   allowBlank: true
																							   })
				},
				{header: 'Regimen EPS', width: 75, dataIndex: 'eps_regimen', fixed: true , editor: comboRegEps, renderer: function(value) {
                                            var r = datosRegimenEps.getById(value);                            
                                            return r ? r.data.nombre : '';
										  }
				},
				{header: 'Tipo Afiliacion', width: 75, dataIndex: 'eps_tipo', fixed: true , editor: comboTipoEps, renderer: function(value) {
                                            var r = datosTipoEps.getById(value);                            
                                            return r ? r.data.nombre : '';
										  }
				},
				{header: 'Fecha EPS', width: 75, sortable:true, dataIndex: 'eps_fecha'},
				{header: 'Cod Asesor', width: 75, sortable:true, dataIndex: 'cod_ass'},
				{header: 'Asesor', hidden:true, width: 100, sortable:true, dataIndex: 'asesor'},
		],
		bbar: new Ext.PagingToolbar({
						pageSize: 20,
						store: datosStore,
						displayInfo: true,
						displayMsg: 'Mostrando registros {0} - {1} de {2}',
						emptyMsg: "No hay registros para mostrar",

		}),	
		tbar:[
			new Ext.form.ComboBox({
                store:datosCarteraSch,
                id:'comboCarteraSch',
				typeAhead: true,
				editable:false,
				triggerAction: 'all',
				emptyText:'Buscar por Cartera...',
				displayField:'nombre',
				valueField: 'id',
				title: 'Cartera',
				mode: 'local',
				listeners: {
								select: function(combo,rec,row) {
								   parametros.params.id_cartera=rec.id;								   
								},
							},
            }),
			new Ext.form.ComboBox({
                store:datosAsesoresSch,
				margins: {top:0, right:50, bottom:0, left:0},
                id:'comboAsesorSch',
				typeAhead: true,
				editable:false,
				triggerAction: 'all',
				emptyText:'Buscar por Asesor...',
				displayField:'nombre',
				valueField: 'id',
				title: 'Asesor',
				mode: 'local',				
				listeners: {
								select: function(combo,rec,row) {
								   parametros.params.id_asesor=rec.id;								   
								},
							},
            }),
			new Ext.form.ComboBox({
                store:datosEstadosSch,
                id:'comboEstadosSch',
				typeAhead: true,
				editable:false,
				triggerAction: 'all',
				emptyText:'Buscar por Estado...',
				displayField:'nombre',
				valueField: 'id',
				title: 'Estado',
				mode: 'local',
				listeners: {
								select: function(combo,rec,row) {
								   parametros.params.estado=rec.id;								   
								},
							},
            }),
			{
				xtype:'textfield',
				emptyText:'Buscar por Nombre o Cedula',
				name:'busqueda_name_ced',
				width: 150,
				id: 'id-busqueda_name_ced'
			},
			new Ext.Button({
							text: 'Buscar',
							margins : {top:0, right:100, bottom:0, left:0},
							handler: function(){
								var parametro_busq = Ext.getCmp('id-busqueda_name_ced').getValue();
								if(parametro_busq != ''){
									parametros.params.nomb_cc=parametro_busq;				
								}
								datosStore.load(parametros);
                                datosStore.reload();
								
								Ext.getCmp("id-busqueda_name_ced").setValue('');
								Ext.getCmp("comboCarteraSch").setValue(null);
								Ext.getCmp("comboAsesorSch").setValue(null);
								Ext.getCmp("comboEstadosSch").setValue(null);
								
								parametros.params.estado=null;
								parametros.params.id_asesor=null;
								parametros.params.id_cartera=null;			
								parametros.params.nomb_cc=null;								
								},
							anchor: '100%'
			}),
			{
			   text: '<span style="color:blue";>Guardar</span>',
			   margins : {top:0, right:0, bottom:0, left:75},
			   handler : function(){

			   var datosStore2=Ext.getCmp('obligacion-sch-grid');

			var modificados = obligacionGrid.getStore().getModifiedRecords();
		if(!Ext.isEmpty(modificados)){
			var recordenviar = [];
			Ext.each(modificados, function(record) { 
				recordenviar.push(Ext.apply({id:record.id},record.data));
			});

			
			obligacionGrid.stopEditing();
			
			recordenviar = Ext.encode(recordenviar); 
			
			Ext.Ajax.request({ 		
				url : 'schRegSolicitud/getJson',
				params :{xaction:'update', registros : recordenviar,start: 0 , limit: 20},
				scope:this,
				method: 'GET',
				success : function(response) {
					
					obligacionGrid.getStore().commitChanges(); 
					
					var info = Ext.decode(response.responseText); 
					Ext.each(info.data,function(obj){
						var record = obligacionGrid.getStore().getById(obj.oldId); 
						
						record.set('id',obj.id);
						delete record.data.newRecordId; 
					},this);
				Ext.MessageBox.alert('Atencion','Cambios Guardados Correctamente');
				},
				failure:  function(response) {
					
					Ext.MessageBox.alert('Error','Ocurrio un error al realizar la operaci�n.');
				}
			});
		}
			   obligacionGrid.getStore().reload();
				}
			
			},
			{
			   text: '<span style="color:blue";>Ver reporte de base de datos</span>',
			   margins : {top:0, right:0, bottom:0, left:75},
			   handler : function(){
					var panelReporteBBDD=Ext.getCmp('reporte-bbdd-searching');
					if(panelReporteBBDD){
						panelPrincipal.remove(panelReporteBBDD);
					}
					var columnasReporteBBDD=[
						{header: 'Nombre', width: 150, sortable:true, dataIndex: 'nombre'},
						{header: 'Cedula', width: 70, sortable:true, dataIndex: 'cedula'},
						{header: 'Direcci\xF3n', width: 150, sortable:true, dataIndex: 'direccion'},
						{header: 'Telefono', width: 70, sortable:true, dataIndex: 'telefono'},
						{header: 'Ciudad', width: 100, sortable:true, dataIndex: 'ciudad'},						
						{header: 'Origen', width: 70, sortable:true, dataIndex: 'origen'},					
						{header: 'Localizado', width: 70, sortable:true, dataIndex: 'id', renderer: function(evt){
							return '<input type="checkbox" id="localizado_'+evt+'" />';
						}},
					];
					
					var datosReporteBBDD= new Ext.data.JsonStore({
						root: 'registros',
						totalProperty: 'cant',
						idProperty: 'id',

						autoSave: false,
						writer:new Ext.data.JsonWriter(),
						fields: [
								{name: 'id'},    
								{name: 'nombre'},	
								{name: 'cedula'},		   	      	   
								{name: 'telefono'},
								{name: 'direccion'},
								{name: 'ciudad'},
								{name: 'origen'},
								{name: 'validacion'},								
						],
						proxy: new Ext.data.HttpProxy({
								url: 'bbddSearching/buscarEnBases',
								method: 'GET',
						}),
						paramNames:{
							start: 'inicio',
							limit: 'limite'                
						}
					});
					datosReporteBBDD.load({});
					panelReporteBBDD = new Ext.grid.EditorGridPanel({
						id:'reporte-bbdd-searching',
						closable: 'true',
						flex: 10,
						title: 'Busqueda en Bases de Datos',
						clicksToEdit: 1,
						columns: columnasReporteBBDD,
						store: datosReporteBBDD,
						tbar:[
							{
								text:'Guardar como localizados',
								handler: function(){
									Ext.Msg.show({
									   title:'Registro localizado',
									   msg: 'Realmente desea marcar los registros seleccionados como localizado?',
									   buttons: Ext.Msg.YESNO,
									   fn: Ext.localizarRegistro,
									   animEl: 'elId',	   
									   icon: Ext.MessageBox.QUESTION
									});
								}
							},
							{
								text: 'Cerrar',
								handler: function(){
									var panelGBD = Ext.getCmp("reporte-bbdd-searching");
									var panelGestionSearching = Ext.getCmp("panel-gestionSch");
									panelGestionSearching.remove(panelGBD);
									panelPrincipal.doLayout();
								}
							}
						]
					});
					var panelGestionSearching = Ext.getCmp("panel-gestionSch");
					panelGestionSearching.add(panelReporteBBDD).show();
					panelPrincipal.doLayout();
				}
			
			},
			

		],
			
		
	});
	
    var gridGestion = new Ext.Panel({
        id: 'panel-gestionSch',
        title: 'Gestion Searching',
        region: 'center',
        closable: true,
        layout:{
            type:'vbox',
            align:'stretch'
        },
        items: [
                obligacionGrid            
                ]
    });
	 panelPrincipal.add(gridGestion).show();
}