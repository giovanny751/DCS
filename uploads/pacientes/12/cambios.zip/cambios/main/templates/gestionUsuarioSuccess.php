var datosCarteraSch = new Ext.data.JsonStore({
		autoLoad: true,
		root: 'registros',
		fields: [
			{name: 'id'},
			{name: 'nombre'},
		],
		totalProperty: 'total',
		proxy: new Ext.data.HttpProxy({
				url : 'schSolicitud/getCarterasJson',
				method: 'GET',
		})

});	



var gestionUsuarioHandler = function(){  

var storeUsuarios = new Ext.data.JsonStore({
			url: 'main/JsonDatosUsuario',
			root: 'registros',
			id:'store_usuarios',
			fields: ['idusuario','nombre','usuario','clave','cliente'],
			method: 'GET',
		});
		//load the data
		storeUsuarios.load({params:{start: 0, limit: 20}});
		
		//creates the texfield to edit the data
		var texto = new Ext.form.TextField();
		var pass = new Ext.form.TextField({inputType: 'password'} );
		
		
var comboCartera= new Ext.form.ComboBox({
                store:datosCarteraSch,
                id:'comboCarteraSch',
				typeAhead: true,
				editable:false,
				triggerAction: 'all',
				displayField:'nombre',
				valueField: 'id',
				title: 'Cartera',
				mode: 'local',
				width: 150,
				listeners: {
								select: function(combo,rec,row) {
								   parametros.params.id_cartera=rec.id;								   
								},
							},
            });

		var usuariosGrid = new Ext.grid.EditorGridPanel({
		id: 'obligacion-sch-grid',
		store: storeUsuarios,
		flex:10,
		clicksToEdit: 1,
						
		columns: [
				{id:'id', header:'Id', width: 20, sortable:true, dataIndex: 'idusuario',editor: new fm.TextField   ({																								grow:true,																							   allowBlank: true})},    				
				{header: 'Nombre', width: 200, sortable:true, dataIndex: 'nombre', editor: new fm.TextField   ({																								grow:true,																							   allowBlank: true})},
				{header: 'Usuario', width: 70, sortable:true, dataIndex: 'usuario', editor: new fm.TextField({
																									grow:true,																								   allowBlank:    true})},
				{header: 'Clave', width: 70, sortable:true, dataIndex: 'clave', editor: new fm.TextField({
																													grow:true,
																								   allowBlank: true,
inputType: 'password' })},
				{header: 'Cliente', width: 150, dataIndex: 'cliente', fixed: true ,  editor: comboCartera, renderer: function(value) {
                                            var r = datosCarteraSch.getById(value);                            
                                            return r ? r.data.nombre : '';
										  }
				},
				],
		bbar: new Ext.PagingToolbar({
			pageSize: 20,
			store: storeUsuarios,			
			displayInfo: true,
			displayMsg: 'Mostrando registros {0} - {1} de {2}',
			emptyMsg: "No hay registros para mostrar"
                        
                      
	}),
	 tbar:{  
         defaults:{scope:this},  
         items:[ 
		{
				xtype:'textfield',
				emptyText:'Buscar por Nombre',
				name:'busqueda_name_ced',
				width: 150,
				id: 'id-busqueda_name_ced'
			},
			new Ext.Button({
							text: 'Buscar',
							margins : {top:0, right:100, bottom:0, left:0},
							handler: function(){
								var parametro_busq = Ext.getCmp('id-busqueda_name_ced').getValue();
								if(parametro_busq != ''){
									parametros.params.filtro=parametro_busq;				
								}
								storeUsuarios.load({params:{start: 0, limit: 20,filtro: parametro_busq}});
								
								Ext.getCmp("id-busqueda_name_ced").setValue('');
								
								},
							anchor: '100%'
			}), 
             {text:'Guardar Cambios',handler:function(){
		
		var modificados = usuariosGrid.getStore().getModifiedRecords();
		if(!Ext.isEmpty(modificados)){
			var recordenviar = [];
			Ext.each(modificados, function(record) { 
				recordenviar.push(Ext.apply({id:record.id},record.data));
			});

			usuariosGrid.el.mask('Guardando...', 'x-mask-loading'); 
			usuariosGrid.stopEditing();
			
			recordenviar = Ext.encode(recordenviar); 
			
			Ext.Ajax.request({ 		
				url : 'main/JsonDatosUsuario',
				params :{records : recordenviar,start: 0 , limit: 20},
				scope:this,
				method: 'GET',
				success : function(response) {
					usuariosGrid.el.unmask();
					usuariosGrid.getStore().commitChanges(); 
					
					var info = Ext.decode(response.responseText); 
					Ext.each(info.data,function(obj){
						var record = usuariosGrid.getStore().getById(obj.oldId); 
						
						record.set('id',obj.id);
						delete record.data.newRecordId; 
					},this);
				Ext.MessageBox.alert('Atencion','Cambios Guardados Correctamente');
				},
				failure:  function(response) {
					usuariosGrid.el.unmask(); 
					Ext.MessageBox.alert('Error','Ocurrio un error al realizar la operación.');
				}
			});
		}
	}},
	  
	{text:'Cancelar Cambios',handler:function(){
	
		usuariosGrid.getStore().rejectChanges();
	}},
	{text:'Añadir Usuario',handler:function(){

		var position = usuariosGrid.getStore().getCount();
		var id = Ext.id();
		var defaultData = {	
			newRecordId: id
		};
		var Person = usuariosGrid.getStore().recordType; 
		var person = new Person(defaultData,id); 
		usuariosGrid.stopEditing();
		usuariosGrid.getStore().insert(position, person); 
		usuariosGrid.startEditing(position, 1); 
	}},
         ]  
     },  

});
		//creates a window to hold the grid
		
	
	
	

var gridGestionUsuario = new Ext.Panel({
        id: 'panel-gestionUSch',
        title: 'Gestion Usuario',
        region: 'center',
        closable: true,
        layout:{
            type:'vbox',
            align:'stretch'
        },
        items: [
                usuariosGrid            
                ]
    });
	 panelPrincipal.add(gridGestionUsuario).show();
}
