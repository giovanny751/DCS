
var registro;
var parametros = {params:{inicio:0, limite:15}};
var datosProcsStore = new Ext.data.JsonStore({
	root: 'registros',
	totalProperty: 'cant',
	idProperty: 'id',
	fields: [
	   	{name: 'id', type: 'int'},
		{name: 'tipo_proceso'},
		{name: 'abogado'},		   
		{name: 'id_abogado'},		   
		{name: 'asesor'},	
		{name: 'id_asesor'},		   	   
		{name: 'cliente'},	
		{name: 'id_cliente'},		   	   
		{name: 'demandado'},
		{name: 'id_demandado'},
		{name: 'descripcion'},
		{name: 'fecha_inicio'},
		{name: 'estado'},
		{name: 'juzgado'},
		{name: 'no_radicado'},
		{name: 'demd_nom_cc'},
	],
	proxy: new Ext.data.HttpProxy({
		url: 'frontProceso/mostrarJSON',
		method: 'GET',
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	}
});
datosProcsStore.load(parametros);


var buscarProcesosHandle = function(button,event) {
	
	var fldAbogado=Ext.getCmp("fld_id_abog");	
	if(fldAbogado.getValue()!=""){
		parametros.params.abogado=fldAbogado.getValue();
	}else{
		parametros.params.abogado=null
	}
	
	var fldCliente=Ext.getCmp("fld_id_client");	
	if(fldCliente.getValue()!=""){
		parametros.params.cliente=fldCliente.getValue();
	}else{
		parametros.params.cliente=null
	}
	
	var fldJuzgado=Ext.getCmp("fld_juzgado");	
	if(fldJuzgado.getValue()!=""){
		parametros.params.juzgado=fldJuzgado.getValue();
	}else{
		parametros.params.juzgado=null
	}
	var fldDemandado=Ext.getCmp("fld_demandado");	
	if(fldDemandado.getValue()!=""){
		parametros.params.demd_nom_cc=fldDemandado.getValue();
	}else{
		parametros.params.demd_nom_cc=null
	}
	datosProcsStore.load(parametros);
	datosProcsStore.reload();
	
	
	Ext.getCmp("fld_demandado").setValue('');
	Ext.getCmp("fld_id_abog").setValue('');	
	Ext.getCmp("fld_id_client").setValue('');										
	Ext.getCmp("fld_juzgado").setValue('');	
	
	parametrosrm.params.inicio = 0;
	parametrosrm.params.limite = 15;
	
	parametros.params.demd_nom_cc=null;
	parametros.params.juzgado=null;
	parametros.params.cliente=null;
	parametros.params.abogado=null;
}

var formularioProcesos = new Ext.form.FormPanel({
	title: 'Bucar Procesos',
	id:'formulario-procesos',
	height: 185,
	frame: true,
	layout: 'column',
	items:[{
		columnWidth: 0.99,
		xtype: 'fieldset',
		defaultType: 'textfield',
		border: false,
		autoHeight: true,
		bodyStyle: Ext.isIE ? 'padding:0 0 5px 15px;' : 'padding:10px 15px;',
		style: {
			"margin-left": "10px", // when you add custom margin in IE 6...
			"margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
		},
		items:[{
			fieldLabel: '<b>Abogado</b>',
			name: 'abogado',
			width: 100,
			id: 'fld_id_abog'
		},
		{
			fieldLabel: '<b>Cliente</b>',
			name: 'cliente',
			width: 100,
			id: 'fld_id_client'
		},
		{
			fieldLabel: '<b>Juzgado</b>',
			name: 'juzgado',
			width: 100,
			id: 'fld_juzgado'
		},
		{
			fieldLabel: '<b>Demandado</b>',
			name: 'demandado',
			width: 100,
			id: 'fld_demandado'
		},
		new Ext.Button({
			text: 'Buscar',
			style: {
			"margin-bottom": "5px",
			},
			handler: buscarProcesosHandle
		})
		]
	}
	]
});

var procesoSelect=0;
var primerIngreso=true;

var procesosGrid = new Ext.grid.GridPanel({	
	id: 'grid-procesos',
	store: datosProcsStore,	
	flex: 15,
	columns: [						  
		{id:'id', header: "Id", hidden:true, width: 50, sortable: true, dataIndex: 'id'},
		{header: "No Radicado", width: 68, sortable: true, dataIndex: 'no_radicado' },
		{header: "Abogado", width: 120, sortable: true, dataIndex: 'abogado'},
		{header: "Asesor", width: 100, sortable: true, dataIndex: 'asesor'},
		{header: "Cliente", width: 120, sortable: true, dataIndex: 'cliente'},	
		{header: "Demandado", width: 120, sortable: true, dataIndex: 'demandado'},		
		{header: "Fecha Inicio", width: 65, sortable: true, dataIndex: 'fecha_inicio'},
		{header: "Descripcion", width: 90, sortable: true, dataIndex: 'descripcion'},
		{header: "Fecha Cierre", width: 70, sortable: true, dataIndex: 'fecha_cierre'},
		{header: "Estado", width: 70, sortable: true, dataIndex: 'estado' },
		{header: "Juzgado", width: 70, sortable: true, dataIndex: 'juzgado' },
	],
	/*
	listeners: {
                    render: function(g) {
                        g.getSelectionModel().selectRow(0);
                    },
                    delay: 15 // Allow rows to be rendered.
                },
	*/
	sm: new Ext.grid.RowSelectionModel({
                    singleSelect: true,
					firstActive: true,
                    listeners: {
								rowselect: function(sm, row, rec) {
									this.deselectRow(row);
									//rec.data.fecha_programada_inicio=rec.data.fecha_programada;
									//rec.data.fecha_programada_fin=rec.data.fecha_programada;
									if(primerIngreso){
										primerIngreso=false;
									}else{
										Ext.getCmp("formulario-procesos").getForm().loadRecord(rec);
									}
									procesoSelect=rec.data.id;
									
									var treeEx = new Ext.tree.TreePanel({
										useArrows: true,
										autoScroll: true,
										animate: true,
										id: 'arbol-procesos',
										region: 'west',
										enableDD: true,
										IdProceso: procesoSelect,
										collapseMode :'mini',
										containerScroll: true,
										border: false,
										split: true,
										width: 200,		
										// auto create TreeLoader
										dataUrl: 'frontEtapas/jsonTree?id_procs='+procesoSelect,
										listeners: {
											render: function (g){
												g.expandAll();
											},
											beforecollapsenode : function(nodo,profundidad,animado) {
												nodo.loaded=false;
											},
											click: function(n) {
												n.ownerTree.IdNodo = n.id ; 
												if(n.id == 'src'){
													panelProcesosTabs.remove('item_tarea_proceso');
													panelProcesosTabs.remove('item_auditoria_proceso');
													panelProcesosTabs.doLayout();	
												}else{
													panelProcesosTabs.remove('item_tarea_proceso');
													panelProcesosTabs.remove('item_auditoria_proceso');
													
													var tareaProcesoItem = new Ext.ux.IFrameComponent({
														url: 'frontEtapas/edit?id='+n.id,
														id: 'item_tarea_proceso',
														layout: 'column',
														height: '50%', 													
													});
													var auditoriaProcesoItem = new Ext.ux.IFrameComponent({
														url: 'frontAuditorias/new?id_etapa='+n.id, 
														id: 'item_auditoria_proceso',
														layout: 'column',
														height: '15%', 
													});

													panelProcesosTabs.add(tareaProcesoItem).show();
													panelProcesosTabs.add(auditoriaProcesoItem).show();
													panelProcesosTabs.doLayout();		
												}
											}
								
										},
										root: {
											nodeType: 'async',
											text: 'Proceso',
											draggable: false,
											id: 'src'
											}            
									});
										
									var panelVacioPro = new Ext.Panel({
										id: 'panel-central-procs',
										region: 'center'
									});
									
									var panelProcesosTabs = new Ext.Panel({
										region: 'center',	
										split: true,
										id: 'tab-panel-procs',
										frame: true,
										layout:{
											type:'vbox',
											align: 'stretch'
										},
										item: [
											panelVacioPro
										]
									});
									panelProcesosTabs.doLayout();
									
									panelProcesosTabs.remove('panel-central-procs');
									
									var infoProcesoItem = new Ext.ux.IFrameComponent({
										url: 'frontProceso/show?id='+procesoSelect, 
										id: 'item_info_proceso',
										layout: 'column',
										height: '30%', 
									});			
									panelProcesosTabs.add(infoProcesoItem).show();
									panelProcesosTabs.doLayout();	
									
									registro=rec;
									panelPrincipal.remove('panel-admin-pcs');
									var nuevoTab = new Ext.Panel({									
									id: 'panel-admin-pcs',
									title: 'Administracion de Procesos',
									closable: true,
									layout:'border',	
									items: [
											treeEx,
											panelProcesosTabs
											]
									});
									panelPrincipal.add(nuevoTab).show();
									panelPrincipal.doLayout();
								}
                    }
        }),
	bbar: new Ext.PagingToolbar({
			pageSize: 15,
			store: datosProcsStore,
			displayInfo: true,
			displayMsg: 'Mostrando registros {0} - {1} de {2}',
			emptyMsg: "No hay registros para mostrar",
			listeners: {
				change: function(g) {
						if(!primerIngreso){				
							Ext.getCmp("fld_id_abog").setValue('');	
							Ext.getCmp("fld_id_client").setValue('');										
							Ext.getCmp("fld_juzgado").setValue('');	
							Ext.getCmp("fld_demandado").setValue('');																
						}
									
				},
				beforechange: function(tb,parametros2){
						
						  parametros2.abogado=parametros.params.abogado;
						  parametros2.cliente=parametros.params.cliente;
						  parametros2.juzgado=parametros.params.juzgado;
						  parametros2.demd_nom_cc=parametros.params.demd_nom_cc;

							  parametros.params=parametros2;
							  datosProcsStore.load(parametros);
							  datosProcsStore.reload();
							  //return false;
				},
            }			
	}),
});
	
var Tree = Ext.tree;
var tree = new Tree.TreePanel({
        useArrows: true,
        autoScroll: true,
        animate: true,
        enableDD: true,
        containerScroll: true,
        border: false,
		split: true,
		collapsible: true,
		collapseMode :'mini',
		width: 200,
		region: 'west',
        // auto create TreeLoader
        dataUrl: 'http://192.168.0.58/~edwin/prototipo/extjs/examples/tree/get-nodes.php',
		listeners: {
                    render: function(g) {
                        g.getRootNode().expand();
                    },
               
        },
		
        root: {
            nodeType: 'async',
            text: 'Ext JS',
            draggable: false,
            id: 'src'
        }
		
});


var from=0;
var accion = 0;

/*Proceso Plantilla Codensa*/
var TreePlt2 = Ext.tree; 
var treeplt2 = new TreePlt2.TreePanel({
		useArrows: true,
        autoScroll: true,
        animate: true,
		region: 'west',
        enableDD: true,
		collapseMode :'mini',
        containerScroll: true,
        border: false,
		split: true,
		NodoCopy: from,
		accionEnviar: accion,
		width: 320,
        // auto create TreeLoader
        dataUrl: 'frontEtapasProceso/jsonTreeCod',
		listeners: {
					render: function (g){
						g.expandAll();
					},
                    beforecollapsenode : function(nodo,profundidad,animado) {
                        nodo.loaded=false;
                    },
					click: function(n) {
						if(n.attributes.id == 'src'){
							var modulo = '../frontTipoProceso/subProcesoPlant?id_tipo=2&id=';
						}else{
							var modulo = 'frontEtapasProceso/edit?id=';
						}
						//Ext.Msg.alert('Navigation Tree Click', 'You clicked: "'+modulo+ n.attributes.id + '"');
						panelProcesosPlantCodTabs.remove('panel-central-pp-cod');
						
						var frameProcesos = new Ext.ux.IFrameComponent({
										url: modulo+n.attributes.id, 
										id: 'panel-central-pp-cod',
										width: '100%',
										height: '95%',
										region: 'center'
						});
						panelProcesosPlantCodTabs.add(frameProcesos);
						panelProcesosPlantCodTabs.doLayout();
					},
					contextmenu: function(node, e) {
	
						node.select();
						var c = node.getOwnerTree().contextMenu;
						c.contextNode = node;
						c.showAt(e.getXY());
					}
			
        },
		contextMenu: new Ext.menu.Menu({
			items: [
				{
					id: 'copy-node',
					text: 'Copiar Etapa',
					icon: '../js/resources/images/default/tree/copy.gif'
				},
				{
					id: 'cut-node',
					text: 'Cortar Etapa',
					icon: '../js/resources/images/default/tree/Cut.gif'
				},
				{
					id: 'paste-node',
					text: 'Pegar Etapa',
					icon: '../js/resources/images/default/tree/paste.gif'
				},
				{
					id: 'delete-node',
					text: 'Eliminar Etapa',
					icon: '../js/resources/images/default/tree/remove.png'
				}
			],
			listeners: {
				itemclick: function(item) {
					switch (item.id) {
						case 'delete-node':
							var n = item.parentMenu.contextNode;
								n.ownerTree.accionEnviar = 'delete';
								padre = n.parentNode;
								var conn = new Ext.data.Connection();
								conn.request({
									url: 'frontEtapasProceso/editarTree',
									params: {
										accion: n.ownerTree.accionEnviar,
										id_to: n.id
									},
									success: function(respuesta){
										if(respuesta.responseText==3){
											padre.collapse();
											padre.collapse(); 
											alert('Nodos Eliminados');
										}
										//collapse collapse	
									},
									failure: function(respuesta){
										alert("No se puedo Eliminar el nodo, intente nuevamente");
									}
								});
							break;
							
						case 'copy-node':
							var n = item.parentMenu.contextNode;
								n.ownerTree.NodoCopy = n;
								n.ownerTree.accionEnviar = 'copy';
							break;
							
						case 'paste-node':
							var n = item.parentMenu.contextNode;
							
							var conn = new Ext.data.Connection();
							conn.request({
								url: 'frontEtapasProceso/editarTree',
								params: {
									accion: n.ownerTree.accionEnviar,
									id_from: n.ownerTree.NodoCopy.id,
									id_to: n.id
								},
								success: function(respuesta){
									if(respuesta.responseText==1){
										// cut/paste
										
										 n.ownerTree.NodoCopy.parentNode.collapse();
										 n.parentNode.collapse(); 
										 n.parentNode.expand(true); 

									}else if (respuesta.responseText==2){
										// copy/paste
										n.parentNode.loaded=false;
										n.parentNode.collapse(); 
										n.parentNode.expand(true); 
									}
								},
								failure: function(respuesta){
									alert("No se realizo la accion, intente nuevamente");
								}
							});
							break;
							
						case 'cut-node':
							var n = item.parentMenu.contextNode;
							n.ownerTree.NodoCopy = n;
							n.ownerTree.accionEnviar = 'cut';
					}
				}
			}
		}),
        root: {
            nodeType: 'async',
            text: 'Plantilla Gestion Codensa',
            draggable: false,
            id: 'src'
        }

});

/*Proceso Plantilla*/
var TreePltl = Ext.tree; 
var treepltl = new TreePltl.TreePanel({
		useArrows: true,
        autoScroll: true,
        animate: true,
		region: 'west',
        enableDD: true,
		collapseMode :'mini',
        containerScroll: true,
        border: false,
		split: true,
		NodoCopy: from,
		accionEnviar: accion,
		width: 320,
        // auto create TreeLoader
        dataUrl: 'frontEtapasProceso/jsonTree',
		listeners: {
					render: function (g){
						g.expandAll();
					},
                    beforecollapsenode : function(nodo,profundidad,animado) {
                        nodo.loaded=false;
                    },
					click: function(n) {
						if(n.attributes.id == 'src'){
							var modulo = '../frontTipoProceso/subProcesoPlant?id=';
						}else{
							var modulo = 'frontEtapasProceso/edit?id=';
						}
						//Ext.Msg.alert('Navigation Tree Click', 'You clicked: "'+modulo+ n.attributes.id + '"');
						panelProcesosPlantTabs.remove('panel-central-pp');
						
						var frameProcesos = new Ext.ux.IFrameComponent({
										url: modulo+n.attributes.id, 
										id: 'panel-central-pp',
										width: '100%',
										height: '95%',
										region: 'center'
						});
						panelProcesosPlantTabs.add(frameProcesos);
						panelProcesosPlantTabs.doLayout();
					},
					contextmenu: function(node, e) {
	
						node.select();
						var c = node.getOwnerTree().contextMenu;
						c.contextNode = node;
						c.showAt(e.getXY());
					}
			
        },
		contextMenu: new Ext.menu.Menu({
			items: [
				{
					id: 'copy-node',
					text: 'Copiar Etapa',
					icon: '../js/resources/images/default/tree/copy.gif'
				},
				{
					id: 'cut-node',
					text: 'Cortar Etapa',
					icon: '../js/resources/images/default/tree/Cut.gif'
				},
				{
					id: 'paste-node',
					text: 'Pegar Etapa',
					icon: '../js/resources/images/default/tree/paste.gif'
				},
				{
					id: 'delete-node',
					text: 'Eliminar Etapa',
					icon: '../js/resources/images/default/tree/remove.png'
				}
			],
			listeners: {
				itemclick: function(item) {
					switch (item.id) {
						case 'delete-node':
							var n = item.parentMenu.contextNode;
								n.ownerTree.accionEnviar = 'delete';
								padre = n.parentNode;
								var conn = new Ext.data.Connection();
								conn.request({
									url: 'frontEtapasProceso/editarTree',
									params: {
										accion: n.ownerTree.accionEnviar,
										id_to: n.id
									},
									success: function(respuesta){
										if(respuesta.responseText==3){
											padre.collapse();
											padre.collapse(); 
											alert('Nodos Eliminados');
										}
										//collapse collapse	
									},
									failure: function(respuesta){
										alert("No se puedo Eliminar el nodo, intente nuevamente");
									}
								});
							break;
							
						case 'copy-node':
							var n = item.parentMenu.contextNode;
								n.ownerTree.NodoCopy = n;
								n.ownerTree.accionEnviar = 'copy';
							break;
							
						case 'paste-node':
							var n = item.parentMenu.contextNode;
							
							var conn = new Ext.data.Connection();
							conn.request({
								url: 'frontEtapasProceso/editarTree',
								params: {
									accion: n.ownerTree.accionEnviar,
									id_from: n.ownerTree.NodoCopy.id,
									id_to: n.id
								},
								success: function(respuesta){
									if(respuesta.responseText==1){
										// cut/paste
										
										 n.ownerTree.NodoCopy.parentNode.collapse();
										 n.parentNode.collapse(); 
										 n.parentNode.expand(true); 

									}else if (respuesta.responseText==2){
										// copy/paste
										n.parentNode.loaded=false;
										n.parentNode.collapse(); 
										n.parentNode.expand(true); 
									}
								},
								failure: function(respuesta){
									alert("No se realizo la accion, intente nuevamente");
								}
							});
							break;
							
						case 'cut-node':
							var n = item.parentMenu.contextNode;
							n.ownerTree.NodoCopy = n;
							n.ownerTree.accionEnviar = 'cut';
					}
				}
			}
		}),
        root: {
            nodeType: 'async',
            text: 'Plantilla Gestion Abogados',
            draggable: false,
            id: 'src'
        }

});


var panelVacio = new Ext.Panel({
	id: 'panel-central-pp',
	region: 'center'
});
var panelProcesosPlantTabs = new Ext.Panel({
	region: 'center',	
	split: true,
	collapseMode :'mini',
	width: 250,
	id: 'tab-panel-procesos',
	enableTabScroll : true,
	activeTab:0,
	frame: true,
	item: [
		panelVacio
	]
});
var panelProcesoPlant = new Ext.Panel({
	title: 'Proceso Plantilla',
	layout:'border',
	items:[
		treepltl,
		panelProcesosPlantTabs
	]
});

var panelVacioCod = new Ext.Panel({
	id: 'panel-central-pp-cod',
	region: 'center'
});
var panelProcesosPlantCodTabs = new Ext.Panel({
	region: 'center',	
	split: true,
	collapseMode :'mini',
	width: 250,
	id: 'tab-panel-procesos-cod',
	enableTabScroll : true,
	activeTab:0,
	frame: true,
	item: [
		panelVacioCod
	]
});
var panelProcesoPlantCodensa = new Ext.Panel({
	title: 'Proceso Plantilla',
	layout:'border',
	items:[
		treeplt2,
		panelProcesosPlantCodTabs
	]
});

/*
var win = new Ext.Window({
	title: 'Editar Proceso',
	id:'win-edit-procs',
	closable:true,
	width:600,
	height:350,
	//border:false,
	plain:true,
	layout: 'border',

	items: [
		new Ext.Panel({region:'center'})
	]
});
*/