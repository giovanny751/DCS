<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

    <head>
        <?php include_http_metas() ?>
        <?php include_metas() ?>
        <?php //include_title() ?>
        <title>Grupo Consultor Andino</title>
        <link rel="shortcut icon" href="/favicon.ico" />
        <link rel="stylesheet" type="text/css" href="../js/resources/css/ext-all.css" />
        <link rel="stylesheet" type="text/css" href="../css/loading.css" />
        <link rel="stylesheet" type="text/css" href="../css/tab-scroller-menu.css" />
        <link rel="stylesheet" type="text/css" href="../css/fileupload.css" />
        <link rel="stylesheet" type="text/css" href="../js/resources/css/lookandfeel.css" />


        <style type="text/css">
            #header{
                background-color:rgb(39,126,180);
                height: 30px;
                color: white;
                font-family:Arial, Helvetica, sans-serif;
                font-weight: bolder;
                font-size:18px;
                width:100%;
                text-shadow: #CCCCCC;
                text-shadow:inherit;
            }
            #header .text{
                float:left;
                margin-left:4px;
                margin-top: 4px;
                display:block;
            }
            #header .logo{
                float:left;
                display:block;
                margin-left:20px;
            }

            #footer{
                background-color:#616161;
                height:20px;
                font-size:12px;
                color: white;
                font-family:Arial, Helvetica, sans-serif;
                text-align: left;
                padding:5px;
                font-weight:bolder
            }

        </style>

    </head>
    <body>
        <div id="loading-mask" style=""></div>
        <div id="loading">
            <div class="loading-indicator">
                <img src="../js/resources/images/default/gif_cargando.gif" width="84" height="16" style="margin-right:8px;" align="absmiddle"/>
                Cargando...
            </div>
        </div>
        <script type="text/javascript" src="../js/adapter/ext/ext-base.js"></script>
        <script type="text/javascript" src="../js/ext-all.js"></script>
        <script type="text/javascript">
            Ext.chart.Chart.CHART_URL = "http://200.25.26.6/portal/web/images/charts.swf"
        </script>
        <script type="text/javascript" src="../js/src/locale/ext-lang-es.js"></script>
        <script type="text/javascript" src="../js/adapter/ext/MultiSelect.js"></script>
        <script type="text/javascript" src="../js/ux/RowExpander.js" ></script>
        <script type="text/javascript" src="../js/VTypes.js" ></script>
        <script type="text/javascript" src="../js/ux/StatusBar.js" ></script>
        <script type="text/javascript" src="../js/ux/Spotlight.js" ></script>
        <script type="text/javascript" src="../js/ux/FileUploadField.js" ></script>
        <script type="text/javascript">
            Ext.BLANK_IMAGE_URL = '../js/resources/images/default/s.gif';
        </script>
        <script type="text/javascript" src="../js/historico.js"></script>
        <script type="text/javascript" src="../js/archivos.js"></script>
        <script type="text/javascript" src="../js/promesaPago.js"></script>
        <script type="text/javascript" src="../js/cargar_archivos.js"></script>
        <script type="text/javascript" src="../js/pagos.js"></script>
        <!--<script type="text/javascript" src="../js/infoAdicional.js"></script>-->
        <script type="text/javascript" src="../index.php/main/infoAdicional"></script>

        <script type="text/javascript" src="../js/direcciones.js"></script>    
        <script type="text/javascript" src="../js/formPromesa.js"></script>
        <script type="text/javascript" src="../js/formNuevaLocalizacion.js"></script>    
        <script type="text/javascript" src="../js/productos.js"></script>
        <script type="text/javascript" src="../js/condonacion.js"></script>  
        <script type="text/javascript" src="../js/codensa.js"></script>
        <script type="text/javascript" src="../js/visitas.js"></script>
        <script type="text/javascript" src="../js/serialize.js"></script>
        <script type="text/javascript" src="../js/llamadas.js"></script>	
        <script type="text/javascript" src="../js/formulario_gestion.js"></script> 
        <script type="text/javascript" src="../index.php/bancoCuenta/bancoCuenta"></script> 
        <script type="text/javascript" src="../index.php/vendorCartera/vendorCartera"></script>    

        <script type="text/javascript" src="../index.php/main/grilla"></script>
        <script type="text/javascript" src="../index.php/main/nomina"></script>
        <script type="text/javascript" src="../index.php/main/codigos"></script>
        <script type="text/javascript" src="../index.php/main/cambioClave"></script>

        <!--Liliana:jur-->
        <script type="text/javascript" src="../index.php/main/procesos"></script>
        <script type="text/javascript" src="../index.php/main/searching"></script>
        <script type="text/javascript" src="../index.php/main/indicadoresGestion"></script>
        <script type="text/javascript" src="../index.php/main/filtros"></script>
        <script type="text/javascript" src="../index.php/main/header"></script>    
        <script type="text/javascript" src="../index.php/main/lateral"></script>
        <script type="text/javascript" src="../index.php/main/infoCarteraBCSC"></script>    
        <!--<script type="text/javascript" src="js/TabScrollerMenu.js"></script>-->
        <script type="text/javascript" src="../index.php/main/principal"></script>
        <script type="text/javascript" src="../js/codensa_gestion.js"></script>    
<!--    <script type="text/javascript" src="../lookandfeel2.js"></script>-->
        <script type="text/javascript" src="../index.php/main/main"></script>
        <script type="text/javascript" src="../js/jquery-1.10.2.js"></script>
        <script>
        var fecha =<?php echo $fecha ?>;
        if (fecha == null || fecha >= 30)
        {
            vCambiarClave.show();
        }
        function buscar_causal(estado) {
//        var estado=$('.causal_causal').val();
            estado = estado.value
            if(estado=="")
                return false;
            var url = 'deudorCartera/consulta';
            var action = 'buscar_causal';
            $.post(url, {estado: estado, action: action})
                    .done(function(msg) {
//                    msg=msg.split(' :: ');
                        $('.causal_causal *').remove()
                        $('.causal_causal').append(msg)
//                    $('.descri_causal').val(msg[1])
                    })
                    .fail(function() {
                        alert('Error de conexion favor intentar mas tarde')
                    })

        }
        function validar_causal(estado) {
//        var estado=$('.causal_causal').val();
            estado = estado.value
            var url = 'deudorCartera/consulta';
            var action = 'buscar_estado';
            $.post(url, {estado: estado, action: action})
                    .done(function(msg) {
//                    msg=msg.split(' :: ');
//                        $('.causal_causal').html(msg)
                    $('.descri_causal').val(msg)
                    })
                    .fail(function() {
                        alert('Error de conexion favor intentar mas tarde')
                    })

        }
        $('html').delegate('.enviar_causal','click',function(){
            var url = 'deudorCartera/consulta';
            var action = 'guardar_causal';
            $('.estado_causal').each(function(){
                estado_causal=$(this).val();
            })
            $('.causal_causal').each(function(){
                causal_causal=$(this).val();
            })
            $('.ig_perons').each(function(){
                ig_perons=$(this).val();
            })
            $('.descri_causal').each(function(){
                descri_causal=$(this).val();
            })
//            console.log(estado_causal);
//            var descri_causal=$('.descri_causal').val()
//            var causal_causal=$('.causal_causal').val()
//            var ig_perons=$('.ig_perons').html()
//            var estado_causal=$('.estado_causal').val()
            console.log(descri_causal+"**"+causal_causal+"**"+ig_perons+"**"+estado_causal);
            if(descri_causal=="" || ig_perons=="" || estado_causal==""){
                alert('Datos Incompletos');
                return false;
            }
                
            $.post(url,{action:action,ig_perons:ig_perons,estado_causal:estado_causal,descripcion_causal:descri_causal})
            .done(function(msg) {
                     alert('Datos Guardados con extito');
                    })
                    .fail(function() {
                        alert('Error de conexion favor intentar mas tarde')
                    })
        })
        </script>
    </body>
</html>
