/**
 * @author Carlos Andraus
 */
var semaforoView = function (valor){
	var mensaje = "";
	var imagen = "";
	switch(valor){
		case 3: 
			mensaje="rojo";
			imagen="sr.gif";
			break;
		case 2: 
			mensaje="amarillo";
			imagen="sa.gif";
			break;
		case 1: 
			mensaje="verde";
			imagen="sv.gif";
			break;
		case -1: 
		default :
			mensaje="azul";
			imagen="saz.gif";
	}
	return '<img src="../images/'+imagen+'" alt="'+mensaje+'" width="13" height="13"/>';
}
 
 

var busquedaStore = new Ext.data.JsonStore({
	id: 'id-busquedaStore',
        root: 'registros',
	totalProperty: 'cant',
	idProperty: 'id',
    fields: [
	   {name: 'id', type: 'int'},
       {name: 'nombres'},
       {name: 'cedula'},
       {name: 'saldo_mora'},
       {name: 'obligacion'},
       {name: 'numero_expediente'},
       {name: 'fecha_ultima_gestion'},
	   {name: 'semaforo'}
    ],
	//data:myData,
	//url:"data.php",
	proxy: new Ext.data.HttpProxy({
		url: 'deudorCartera/deudorJson',
		method: 'GET',
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	}
});

busquedaStore.load({params:{inicio:0, limite:30,tipo:'normal'}});


var detalleDeudorHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-subirCartera',
		title: 'Subir Cartera',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-subirCartera', url: 'plantilla/procesarCartera' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}






var deudorId=-1;
var deudorcedula= 0;
var panelGestion = new Ext.TabPanel({
	id:'panel-gestion',
        title: 'Gestión',
	flex:3,
	frame: true,
	activeTab:0,
	items:[
		historicoGrid, //Se carga en historico.js
		new Ext.Panel({
                        id:'panel-ingresarGestion',
			title: 'Ingresar Gestión',
			frame: true,
			layout: 'border',
			items:[
				formularioIngresarGestion
			]
		}),
                promesaPagoGrid,
                pagosGrid,
                direccionesGrid,    
				archivosGrid,
				visitasCodensaGrid
                //infoAdicionalGrid
	],
	listeners:{
		activate: function(p){
			p.doLayout();
		}
	}
});

var funcionInfoAdicional = function(){
    var dir='frontInfoAdicional/infoAdicional/id/' + deudorId
    return dir;
}



var funcionDeudor = function(){
    
    var dir='deudorCartera/infoPersonal/id/' + deudorId
    return dir;
}

/* var proponerHandler = function(button,event) {
	alert('hgh');
	
} */


var busquedaGrid = new Ext.grid.GridPanel({
	id: 'gridBusqueda',
	flex:6,	
	store: busquedaStore,
	title: 'Deudores',
	columns: [							  
		{header: "&nbsp;&nbsp;&nbsp;", width:20, sortable: false, dataIndex: 'semaforo', renderer:semaforoView},
		{header: "C&eacute;dula", width:65, sortable: true, dataIndex: 'cedula'},
		{id:'nombre', header: "Nombre", sortable: true, dataIndex: 'nombres'},
                {id:'id', header: "id", hidden:true, dataIndex: 'id'},
                {header: "Monto", hidden:true, sortable: true, width:50, renderer: 'usMoney', dataIndex:'saldo_mora'},
                {header: "&Uacute;ltima Gesti&oacute;n", hidden:true, width:80,  sortable: true, dataIndex: 'fecha_ultima_gestion'},
                {header: "Obligaci&oacute;n", hidden:true, width:80,  sortable: true, dataIndex: 'obligacion'},
                {header: "Expediente", hidden:true, width:80,  sortable: true, dataIndex: 'numero_expediente'},
                
	],
	stripeRows: true,
	bbar: new Ext.PagingToolbar({
			pageSize: 30,
			store: busquedaStore,
			displayInfo: true,
			displayMsg: 'Mostrando registros {0} - {1} de {2}',
			emptyMsg: "No hay registros para mostrar",
                        listeners :{
                            beforechange:function(tb, parametros2){
                                parametros.params=parametros2;
								var idBusqueda = Ext.getCmp('id-busqueda').getValue();
								if(idBusqueda!="") parametros.params.id = idBusqueda;
                                parametros.params.tipo=Ext.paginadorTipo;                                
                                busquedaStore.load(parametros);
                                
                            }
                        }
                      
	}),
	autoExpandColumn: 'nombre',
        	sm: new Ext.grid.RowSelectionModel({
                    singleSelect: true,
		    firstActive: true,
                    listeners: {
			rowselect: function(sm, row, rec) {
							Ext.Ajax.abort(historicoStore.proxy.activeRequest);
							Ext.Ajax.abort(promesaPagoStore.proxy.activeRequest);
							Ext.Ajax.abort(pagosStore.proxy.activeRequest);
							Ext.Ajax.abort(datosTipoContacto.proxy.activeRequest);
							Ext.Ajax.abort(datosResultados.proxy.activeRequest);
							Ext.Ajax.abort(archivosStore.proxy.activeRequest);
							Ext.Ajax.abort(direccionesStore.proxy.activeRequest);
							Ext.Ajax.abort(datosCiudad.proxy.activeRequest);
							Ext.Ajax.abort(datosAccion.proxy.activeRequest);
                            //alert(rec.data.id);
                            productosGestion = new Array();
			    //Ext.getCmp('combo-telefonos').setValue('');			
                            var campoProductos = document.getElementById('productos_ser_field');
							 var campoProductos = document.getElementById('productos_ser_field');
							 var cedulaDeudor = document.getElementById('td-ob-cedula');
							 if(cedulaDeudor!=null){
								cedulaDeudor.parentNode.removeChild(cedulaDeudor);;
								//document.body.removeChild(cedulaDeudor);
							 }
                            if(campoProductos!=null){
                                campoProductos.value="";
                            }
                            var infoPersonal= new Ext.form.FieldSet({
                                    title: 'Información Personal',
                                    margins: '5 5 5 5',
                                    frame: true,
                                    
                                    //url:'deudorCartera/deudorSelectionModel',
                                    /*autoLoad:{
                                            url: funcionDeudor
                                    },*/
                                    height: 180, 
                                    bbar: new Ext.ux.StatusBar({
                                    statusAlign: 'right',
                                    items: [
                                                    '<b>&Uacute;ltimo tel&eacute;fono: </b>--',
                                                    {
                                                            text: 'Ver m&aacute;s'
                                                    }, 
                                                    '-',
                                                    '<b>&Uacute;ltima direcci&oacute;n: </b>--',
                                                    {
                                                            text: 'Ver m&aacute;s'
                                                    }, '-',
													'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
													new Ext.Button({
													text:'<b>Enviar Searching</b>',
														region: 'center',
														handler:  function(button,event) {
															//alert(rec.data.id);
															Ext.MessageBox.confirm('confirmar','¿Seguro?', proponerHandler);

															function proponerHandler(btn){
																if(btn == 'yes'){
																	var enviarDeudor = new Ext.data.JsonStore({
																	root: 'registros',
																	 autoDestroy: true,
																	proxy: new Ext.data.HttpProxy({
																		url: 'schSolicitud/agregarReg',
																		method: 'GET',
																	}),
																	});

																	enviarDeudor.load({params:{id:rec.data.id}});  

																}
															};
														},
													}),'-',
													'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
													new Ext.Button({
														text:'<b>Subir Archivo</b>',
														handler: abrirCargarArchivos
													}),
													new Ext.Button({
                                                                                                                text:'<b>Carga Masiva de Archivos</b>',
                                                                                                                handler: abrirCargarArchivosMasivo
                                                                                                        }) 
                                            ]
                            
                                    })
                            });
                            
                            var infoObligacion= new Ext.form.FieldSet({
                                    title: 'Obligación',
                                    margins: '5 5 5 5',
                                    frame: true,
                                    autoLoad:{
                                            url: 'deudorCartera/infoObligacion/id/'+rec.data.id
                                    },
									id:'info-obligacion-deudor',
                                    height: 110
                            });


                            deudorId = rec.data.id;
							deudorcedula=rec.data.cedula;
			    console.log(rec.data);
                            
                            
                            
                            iFrame=new Ext.ux.IFrameComponent({ id: 'hola', url: 'frontInfoAdicional/infoAdicional/id/'+deudorId,region: 'center'});
							var productosSer=document.getElementById("productos_ser_field");
							if(productosSer)productosSer.value="";
							var productosSelPanel= Ext.getCmp('panel-seleccion-productos');
							if(productosSelPanel){
								panelGestion.remove(productosSelPanel);
							}
                            //Limpiando campos de formulariogestion.js
                            Ext.getCmp('fieldContacto').setValue(null);
							Ext.getCmp('fieldCedulaContacto').setValue(null);
                            Ext.getCmp('combo-ciudad').setValue(null);
                            Ext.getCmp('combo-telefonos').setValue(null);
                            Ext.getCmp('proxima_fecha').setValue(null);
                            Ext.getCmp('combo-accion').setValue(null);
                            Ext.getCmp('combo-efecto1').setValue(null);
                            //Ext.getCmp('combo-efecto1').setValue(null);                            
                            Ext.getCmp('combo-efecto2').setValue(null);
                            Ext.getCmp('combo-efecto3').setValue(null);
                            Ext.getCmp('visita_codensa_field').setValue(null);//NUEVO
                            Ext.getCmp('combo-direccion').setValue(null);
                            Ext.getCmp('combo-resultado-gestion').setValue(null);
                            //limpiando campos de formpromesa.js
                            Ext.getCmp('fieldFechaDePago').setValue(null);
                            Ext.getCmp('fieldAfinidadFE').setValue(null);
                            Ext.getCmp('fieldValorFE').setValue(null);
                            Ext.getCmp('fieldComentarioFE').setValue(null);
                            Ext.getCmp('combo-formaPagoFE').setValue(null);
                            Ext.getCmp('combo-estadoFE').setValue(null);
							Ext.getCmp('fld_id_llamada').setValue(null);
                            
                            //
                            
                           
                            var nuevoTab = new Ext.Panel({
                                id: 'panel-deudor',                                
                                title: 'Detalle Deudor',
                                frame:true,
                                region: 'center',
                                closable: false,
                                layout:{
                                    type:'vbox',
                                    align:'stretch'
                                },
                                align:'stretch',
                                items: [
                                        infoPersonal,
                                        infoObligacion,
                                        //new Ext.ux.IFrameComponent({ id: 'panel-deudor', url: 'deudorCartera/deudorSelectionModel/id/'+rec.data.id}),
                                        
                                        panelGestion,
                                        
                                        ]
                            });
                            
							if(Ext.getCmp('panel-infoA')!=null){
								panelGestion.remove('panel-infoA',true);
							}
                            var infoAdicional= new Ext.Panel({
                                    id: 'panel-infoA',
                                    title: 'Informaci&oacute;n Adicional',
                                    frame: true,
                                    layout: 'border',
                                    items:[new Ext.ux.IFrameComponent({ id: 'hola', url: 'frontInfoAdicional/infoAdicional?id='+deudorId,region: 'center'})]
                            });
							infoAdicional.doLayout();
                            panelGestion.add(infoAdicional).show();
                            Ext.getCmp('panel-gestion').setActiveTab(0);
                            panelPrincipal.add(nuevoTab).show();
                            Ext.getCmp('main-container').doLayout();
							infoPersonal.load({
								url: funcionDeudor,
								text: 'Cargando...',
								callback: function(){
									historicoStore.load({params:{inicio:0, limite:10, id:deudorId}});
								   if(mostrarInfoBCSC){
								   <?php
									   for($i=1;$i<=22;$i++){
											//echo "bcscStore_$i.load({params: {inicio:0, limite:10, id:deudorId, tipoRegistro:$i}});\n";
									
										}
								   ?>
									}
									
									promesaPagoStore.load({params: {inicio:0, limite:10, id:deudorId}});
									pagosStore.load({params: {inicio:0, limite:10, id:deudorId}});
									//direccionesStore.load({params: {inicio:0, limite:10, id:deudorId}});
									datosTipoContacto.load({params: {inicio:0, limite:10, id:deudorId}});
									datosResultados.load({params: {inicio:0, limite:10, id:deudorId}});
									archivosStore.load({params: {inicio:0, limite:10, id:deudorId}});
									direccionesStore.load({params: {inicio:0, limite:10, id:deudorId}});
									//alert(deudorId);
									datosCiudad.load({params: {inicio:0, limite:10, id:deudorId}});
									datosAccion.load({params: {inicio:0, limite:10, id:deudorId}});
								}
							});
                            selectAllProducts();
                        },                    
                    },                    
        }),
});


var metaStore = new Ext.data.JsonStore({
	root: 'metas',
    fields: [
	   {name: 'id',},
       {name: 'meta', type: 'int'},
       {name: 'comision', type: 'int'},
	   {name: 'fecha' }
    ],
	//data:myData,
	//url:"data.php",
	proxy: new Ext.data.HttpProxy({
		url: '../index.php/frontPagos/jsonMeta',
		method: 'GET',
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	},
	autoLoad: true
});


var metaDefinitivosStore = new Ext.data.JsonStore({
	root: 'metas',
    fields: [
	   {name: 'id',},
       {name: 'meta', type: 'int'},
       {name: 'comision', type: 'int'},
	   {name: 'fecha' }
    ],
	//data:myData,
	//url:"data.php",
	proxy: new Ext.data.HttpProxy({
		url: '../index.php/frontPagos/jsonMetaDefinitivos',
		method: 'GET',
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	},
	autoLoad: true
});


var metasChart = new Ext.Panel({
	title: 'Honorarios',
	flex:4,
	frame: true,
	layout: 'fit',
	items:{
		xtype: 'linechart',
		store: metaStore,
		xField: 'fecha',
		series: [{
                type:'line',
                displayName: 'Pagos',
                yField: 'comision',
                style: {
                    color: 0x15428B
                }
            },
            {
                type: 'line',
                displayName: 'Meta',
                yField: 'meta',
                style: {
                    color:0xFF0000
                }
            }
		]

	}
});

var metasDefinitivosChart = new Ext.Panel({
	title: 'Riesgos',
	frame: true,
	layout: 'fit',
	items:{
		xtype: 'linechart',
		store: metaDefinitivosStore,
		xField: 'fecha',
		series: [{
                type:'line',
                displayName: 'Pagos',
                yField: 'comision',
                style: {
                    color: 0x15428B
                }
            },
            {
                type: 'line',
                displayName: 'Meta',
                yField: 'meta',
                style: {
                    color:0xFF0000
                }
            }
		]

	}
});


var metasSummary = new Ext.Panel({
	title:'Summary',
	frame: true,
	id: 'metas-summary-panel',
	autoLoad : '../frontPagos/summaryMetas'
});
var metasTabPanel = new Ext.TabPanel({
	activeTab: 0,
	id: 'metas-tab-panel', 
	items: [
		metasChart,
		metasDefinitivosChart,
		metasSummary
	],
	flex:4
});


var actualizador;
var panelMensajeria = new Ext.Panel({
			id: 'panel-gestion-mensajeria',
			title: 'Mensajes',
			flex: 4,
			frame: true,
		//	autoLoad : '../frontMensajeria/showMensajes',
			html: '',
			autoScroll: true/*,
			doAutoLoad : function(){
		        var u = this.getUpdater();
		        actualizador=u;
		        if(this.renderer){
		            u.setRenderer(this.renderer);
		        }
		        u.showLoading=function(){
		        } 
		        u.update(Ext.isObject(this.autoLoad) ? this.autoLoad : {url: this.autoLoad});
		        u.showLoadIndicator = "Hola Mundo";
		        u.startAutoRefresh(60, "../frontMensajeria/showMensajes");
		        
		        
		      	//alert(u);
		    }*/		    		    					
});

var buscarDeudorHandlerButton = function(button,event){
		var idBusqueda = Ext.getCmp('id-busqueda').getValue();
		Ext.paginadorTipo = 'normal';
		busquedaStore.load({params:{inicio:0, limite:10, id:idBusqueda, tipo:'normal'}});	
}

var panelLateralPre = new Ext.Panel({
	split: true,
	width: 250,
	id: 'panel-lateral-prejur',
	title: 'Deudores',
	layout:{
		type:'vbox',
		align: 'stretch'
	},
	items:[
		{
			height: 79,
			title: 'B&uacute;squeda Deudor',
			frame: true,
			layout: 'column',
			items:[
				{
					columnWidth: .80,
					items:[
						{
							xtype:'textfield',
							name:'busqueda',
							width: 1800,
							anchor: '100%',
                                                        id: 'id-busqueda'
						},
                                                new Ext.Panel({
                                                        layout: 'column',
                                                        items:[
                                                            {
                                                                columnWidth: .50,
                                                                items:[
                                                                    new Ext.Button({
                                                                            text: 'Riesgo',
                                                                            handler: function(){
                                                                                Ext.paginadorTipo = 'inactividad';
                                                                                
                                                                                busquedaStore.load({params:{inicio:0, limite:10, tipo:'riesgo'}});
                                                                                //'id-busquedaStore'
                                                                                
                                                                                },
                                                                            anchor: '100%'
                                                                    })
                                                                ]
                                                            },
                                                            {
                                                                columnWidth: .50,
                                                                items:[
                                                                    new Ext.Button({
                                                                            text: 'Inactividad',
                                                                            handler: function(){
                                                                                Ext.paginadorTipo = 'inactividad';
                                                                                busquedaStore.load({params:{inicio:0, limite:10, tipo:'inactividad'}});
                                                                                //'id-busquedaStore'
                                                                                
                                                                                },
                                                                            anchor: '100%'
                                                                    })
                                                                ]
                                                            }
                                                        ]
                                                })
					]
				},
				{
					columnWidth: .20,
					items:[
						new Ext.Button({
							text: 'Buscar',
							handler: buscarDeudorHandlerButton,
							anchor: '100%'
						})
					]
				}
			]
		},		
		busquedaGrid,
		metasTabPanel,
		panelMensajeria
	],
	keys:[{key:[10,13],handler:buscarDeudorHandlerButton}],
});

//var mgr = new Ext.Updater("panel-gestion-mensajeria");
//mgr.startAutoRefresh(60, "http://myserver.com/index.php");
//mgr.on("update", myFcnNeedsToKnow);


//actualizadorMensajes.startAutoRefresh(1000);

/*
Liliana:jur
los items estan en procesos
*/
var panelLateralJur = new Ext.Panel({
	split: true,
	width: 250,
	title: 'Procesos',
	layout:{
		type:'vbox',
		align: 'stretch'
	},
	items:[
			formularioProcesos,
			procesosGrid
	]
});

var panelLateral = new Ext.TabPanel({
	region: 'east',	
	split: true,
	collapseMode :'mini',
	width: 250,
	id: 'tab-panelLateral',
	enableTabScroll : true,
	activeTab:0,
	frame: true,
	items:[
		<?php if($mostrarDeudores) echo "panelLateralPre,"; 
			if($mostrarProcesos) echo "panelLateralJur" ?>
		
	]
});
