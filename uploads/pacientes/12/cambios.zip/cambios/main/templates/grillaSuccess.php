/*var scrollerMenu = new Ext.ux.TabScrollerMenu({
	maxText  : 15,
	pageSize : 5
});*/

Ext.ux.IFrameComponent = Ext.extend(Ext.BoxComponent, {
     onRender : function(ct, position){
          this.el = ct.createChild({tag: 'iframe', id: 'iframe-'+ this.id, frameBorder: 0, src: this.url});
     }
});

var panelPrincipal2 = new Ext.TabPanel({
	region: 'center',	
	split: true,
	collapseMode :'mini',
	width: 250,
	id: 'tab-panel',
	enableTabScroll : true,
	activeTab:0,
	frame: true
});


////////PRUEBAS GRILLA ///////////////////





////////FIN PRUEBAS GRILLA ///////////////////














