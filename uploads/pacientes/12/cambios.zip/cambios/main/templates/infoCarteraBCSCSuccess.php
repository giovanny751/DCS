<?php

    if($mostrarBCSC){
?>        
        var mostrarInfoBCSC = true;





<?php

	for($i=1;$i<=$tipoRegistros;$i++){
?>
var bcscStore_<?php echo $i; ?> = new Ext.data.JsonStore({
	root: 'registros',
	id:'bcsc_store_<?php echo $i; ?>',
	idProperty: 'id',
	fields:[
		
<?php
		foreach($campos as $llave=>$valor){
			if($valor['tipo_registro']==$i && is_numeric($llave)){
?>
		{name: '<?php echo $valor['columna']; ?>'},
<?php
			}
		}
?>
	],
	proxy: new Ext.data.HttpProxy({
		url: '../index.php/main/infoCarteraBCSC',
		method: 'GET',
	})
});

<?php
	}
?>

<?php
for($i=1;$i<=$tipoRegistros;$i++){
?>
	var actualizarBCSC_<?php echo$i; ?>  = new Ext.Toolbar();
	actualizarBCSC_<?php echo$i; ?>.add(
	new Ext.Button({
		text:'Cargar Info',
		handler:function(){
	<?php echo "bcscStore_$i.load({params: {inicio:0, limite:10, id:deudorId, tipoRegistro:$i}});\n";?>
		}
	})
);
<?php 
}  
?>
<?php
      
	for($i=1;$i<=$tipoRegistros;$i++){
?>
var bcscColumns_<?php echo$i; ?> = [
		
<?php
		foreach($campos as $llave=>$valor){
                        
			if($valor['tipo_registro']==$i && is_numeric($llave)){
?>
		{dataIndex: '<?php echo $valor['columna']; ?>', header:'<?php echo $valor['nombre']; ?>'},
<?php
			}
		}
?>
	];
<?php
	}
?>


var infoBCSC ={
<?php
        $nombreColumnas=array();
        $nombreColumnas[0]=null;
        $nombreColumnas[1]='Informaci\xF3n Personal';
        $nombreColumnas[2]='Direcciones';
        $nombreColumnas[3]='Tel\xE9fono';
        $nombreColumnas[4]='Obligaciones en mora';
        $nombreColumnas[5]='Obligaciones no morosas';
        $nombreColumnas[6]='Pagos';
        $nombreColumnas[7]='Promesas';
        $nombreColumnas[8]='Gestiones';
        $nombreColumnas[9]='Cartas';
	$nombreColumnas[10]='Procesos Juridicos';
	$nombreColumnas[11]='Gestión Jurídica Realizada';
	$nombreColumnas[12]='Gastos en Proceso Jurídico';
	$nombreColumnas[13]='Gastos en Proceso Jurídico';
	$nombreColumnas[14]='Embargos';
	$nombreColumnas[15]='Acuerdos de Pago';
	$nombreColumnas[16]='Detallada De Acuerdos de Pago';
	$nombreColumnas[17]='De Visitas';
	$nombreColumnas[18]='Codeudores';
	$nombreColumnas[19]='Morosidad por Edades';
	$nombreColumnas[20]='Garantías';
	$nombreColumnas[21]='Marcas de Obligaciones';
	$nombreColumnas[22]='Marcas de Deudor';
	
                                                
	for($i=1;$i<=$tipoRegistros;$i++){
?>

	infoBCSC_<?php echo$i; ?> : new Ext.grid.GridPanel({
		title:'<?php echo $nombreColumnas[$i]?$nombreColumnas[$i]:"Registro_$i"; ?>',
		ds: bcscStore_<?php echo$i; ?>,
		columns: bcscColumns_<?php echo$i; ?>,
		bbar: actualizarBCSC_<?php echo$i; ?>
	}),
<?php
	}
?>
}

var panelInfoBCSC = new Ext.TabPanel({
	title: 'Informaci\xF3n ICS',
	enableTabScroll : true,
	activeTab:0,
	frame: true,
	items:[ 
<?php
	for($i=1;$i<=$tipoRegistros;$i++){
?>
		infoBCSC.infoBCSC_<?php echo$i; ?>,
<?php
}
?>
	]
});

panelGestion.add(panelInfoBCSC);

<?php
	}else{
?>
var mostrarInfoBCSC = false;	
<?
	}
?>
