<?php
	$credenciales=$sf_data->getRaw('credenciales');
?>
var head = new Ext.BoxComponent({
	height		: 33,
	autoEl		: {
		tag: 'div',
		html: '<div class="logo"><img src="../images/logo.png" height="30" alt="logo" /></div><div class="text">Grupo Consultor Andino</div><div id="div-nombre-cartera" style="float:right; margin-right: 15px;margin-top:5px; font-size:16px; font-weight:bolder"></div>'
	},
	id			: 'header'
});


var obtenerNombreCartera = function () {
	var connNC = new Ext.data.Connection();
	connNC.request({
		url: '../index.php/cartera/nombreCartera',
		method: 'POST',
		success: function(respuesta){
			var divNC = document.getElementById("div-nombre-cartera");
			divNC.innerHTML = respuesta.responseText;
		}
	});
}



var toolbar = new Ext.Toolbar();




var crearPlantillaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-plantilla',
		title: 'Crear Plantilla',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: 'cartera/subirCartera' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var visitasCodensaHandler = function(button,event) {
        var nuevoTab = new Ext.Panel({
                id: 'panel-visitasCodensa',
                title: 'Visitas Codensa',
                region:'center',
                closable: true,
        // layout to fit child component
                layout:'fit',
        // add iframe as the child component
                items: [ new Ext.ux.IFrameComponent({ id: 'panel-visitasCodensa', url: '/codensa' }) ]
        });

        panelPrincipal.add(nuevoTab).show();
}

var gestionMasivaExtHandler = function(button,event) {
        var nuevoTab = new Ext.Panel({
                id: 'panel-gestionMasivaExt',
                title: 'Gesti\xF3n Masiva',
                region:'center',
                closable: true,
        // layout to fit child component
                layout:'fit',
        // add iframe as the child component
                items: [ new Ext.ux.IFrameComponent({ id: 'panel-gestionMasivaExt', url: 'carga_masiva/procesarCartera' }) ]
        });

        panelPrincipal.add(nuevoTab).show();
}

var crearReporteHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-reporte',
		title: 'Crear Reporte',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reporte', url: 'frontInformeGestion/imprimirInforme' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var cierremensualHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-reporte',
		title: 'Cierre Mensual',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reporte', url: 'frontInformeGestion/cierremensual' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var cortemensualHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-reporte2',
		title: 'Inventario al corte mensual',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reporte2', url: 'frontInformeGestion/inventarioalcorte' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var cortemensual2Handler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'cortemensual2Handler',
		title: 'Informe Cierre mensual GCA',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'cortemensual2Handler', url: 'frontInformeGestion/cierremensualgca' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var inactivaciondeudoresdetalladaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'inactivaciondeudoresdetallada',
		title: 'Inactivación de deudores detallada',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'inactivaciondeudoresdetallada', url: 'frontInformeGestion/inactivaciondeudoresdetallada' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var inactivaciondeudoresconsolidadaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'inactivaciondeudoresconsolidada',
		title: 'Informe Inactivación de deudores consolidada',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'inactivaciondeudoresconsolidada', url: 'frontInformeGestion/inactivaciondeudoresconsolidada' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var inactivaciondeudorescarteraHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'inactivaciondeudorescartera',
		title: 'inactivación de deudores por cartera',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'inactivaciondeudorescartera', url: 'frontInformeGestion/inactivaciondeudorescartera' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var cierremensualgcaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'cierremensualgca',
		title: 'Informe Cierre mensual GCA',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'cierremensualgca', url: 'frontInformeGestion/cierremensualgca' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}



var busquedaHistoricoHandler = function(button,event) {
        var nuevoTab = new Ext.Panel({
                id: 'panel-busquedaHistorico',
                title: 'Buscar Gestiones Históricas',
                region:'center',
                closable: true,
        // layout to fit child component
                layout:'fit',
        // add iframe as the child component
                items: [ new Ext.ux.IFrameComponent({ id: 'panel-busquedaHistorico', url: 'busquedaHistorico' }) ]
        });
        panelPrincipal.add(nuevoTab).show();
}


var crearSucursalHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-crearSucursal',
		title: 'Crear Sucursal',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-crearSucursal', url: 'sucursal_gca' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var redistribuirpagoshistoricosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'redistribuirpagoshistoricosHandler',
		title: 'Redistribuir Pagos Históricos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'redistribuirpagoshistoricosHandler', url: 'parametros/redistribucionPagosHis' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var causalesHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'causalesHandler',
		title: 'Causales',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'causalesHandler', url: 'parametros/causales' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var listaCausalesHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'listaCausalesHandler',
		title: 'Causales',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'listaCausalesHandler', url: 'parametros/mostrar_causal' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var redistribuirpagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'redistribuirpagosHandler',
		title: 'lista de redistribución de pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'redistribuirpagosHandler', url: 'parametros/redistribucionPagos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var calculoInteresesHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'calculoInteresesHandler',
		title: 'Cálculo de Intereses',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'calculoInteresesHandler', url: 'parametros/calculoIntereses' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var estadoCuestaXclienteHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'estadoCuestaXclienteHandler',
		title: 'Estado de Cuenta por Cliente',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'estadoCuestaXclienteHandler', url: 'parametros/estadoCuestaXcliente' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var consultabasicaportafoliosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'consultabasicaportafolios',
		title: 'Crear Sucursal',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'consultabasicaportafolios', url: 'parametros/portafilio_basico' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}



var cargarCarteraICS = function(button,event) {
        var nuevoTab = new Ext.Panel({
                id: 'panel-carteraICS',
                title: 'Cargar Cartera ICS',
                region:'center',
                closable: true,
        // layout to fit child component
                layout:'fit',
        // add iframe as the child component
                items: [ new Ext.ux.IFrameComponent({ id: 'panel-carteraICS', url: '/ics' }) ]
        });

        panelPrincipal.add(nuevoTab).show();
}

var ingresarPagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'ingresarPagos',
		title: 'Ingresar Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'ingresarPagos', url: 'frontPagos/new' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var configuracionsistemaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'configuracionsistema',
		title: 'Ingresar Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'configuracionsistema ', url: 'condonaciones/inhabilidar' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var registrorecibosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-ingresarPagos',
		title: 'Registro Recibos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-ingresarPagos', url: 'frontPagos/registroRecibos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var listacondonacion = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'listacondonacion',
		title: 'Lista de condonaciones',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'listacondonacion', url: 'condonaciones/listaCondonacion' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var nuevacondonacion = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'nuevacondonacion',
		title: 'Administración Condonación',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'nuevacondonacion', url: 'condonaciones/nuevasolicitud' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var listainformes = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'listainformes',
		title: 'Administración Condonación',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'listainformes', url: 'condonaciones/listaCondonacion' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var buscarcondonacion = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'buscarcondonacion',
		title: 'Lista de Condonaciones',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'buscarcondonacion', url: 'condonaciones/Consultasolicitud' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var inabilitarcondonacion = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'inabilitarcondonacion',
		title: 'Lista de Condonaciones',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'inabilitarcondonacion', url: 'condonaciones/inhabilidar' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var verPagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-verPagos',
		title: 'Ver Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-verPagos', url: 'frontPagos/index' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}



var subirPagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-subirPagos',
		title: 'Subir Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-subirPagos', url: 'frontSubirPagos/subirPagos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
} 



var crearCarteraHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-crearCartera',
		title: 'Crear Cartera',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-crearCartera', url: 'NuevaCartera' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var GestionMasivaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-gestionMasiva',
		title: 'Gesti\xF3n Masiva',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-gestionMasiva', url: 'codigosEquivalentesFront/gestionMasiva' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var subirCarteraHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-subirCartera',
		title: 'Subir Cartera',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-subirCartera', url: 'plantilla/procesarCartera' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var subirCarteraBCSCHandler = function(button, event){
        var nuevoTab = new Ext.Panel({
                id:'panel-subirCarteraBCSC',
                title:'Subir Cartera BCSC',
                region:'center',
                closable:true,
                layout:'fit',
                items: [ new Ext.ux.IFrameComponent({id:'panel-subirCarteraBCSC', url:'carteraBCSC/subirCartera'})]
        });
        panelPrincipal.add(nuevoTab).show();
}

var plantillaActualizarHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-plantillaActualizar',
		title: 'Actualizar Registros',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantillaActualizar', url: 'cartera/plantillaDefinitivos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


/*Liliana: jur*/
var reporteCodensaJurHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-reportecodensa',
		title: 'Reporte Gestion Codensa',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reportecodensa', url: 'frontProceso/reporte' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var tipoProcJurHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-tipoProcs',
		title: 'Tipos de Procesos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-tipoProcs', url: 'frontTipoProceso' }) ]
	});
	panelPrincipal.add(nuevoTab).show();
}
var plantillaJurHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-plantillaJur',
		title: 'Proceso Plantilla',
		region:'center',
		closable: false,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: panelProcesoPlant
	});
	panelPrincipal.add(nuevoTab).show();
	panelLateralJur.show();
}

var plantillaCodJurHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-plantillaJurCod',
		title: 'Proceso Plantilla Codensa',
		region:'center',
		closable: false,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: panelProcesoPlantCodensa
	});
	panelPrincipal.add(nuevoTab).show();
	panelLateralJur.show();
}

var crearProcesojurHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-subirProcesojur',
		title: 'Crear Proceso',
		region:'center',
		closable: true,
		layout:'fit', 
		items: [ 
			new Ext.ux.IFrameComponent({ id: 'panel-subirProcesojur', url: 'frontProceso/new' }) 
		]
	});

	panelPrincipal.add(nuevoTab).show();
	panelLateralJur.show();
}

var notificacionesJurHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-notificacionJur',
		title: 'Notificaciones',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-notificacionJur', url: 'frontNotificaciones' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}



/*
var asignarCarteraHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-asignarCartera',
		title: 'Asignar Cartera',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-asignarCartera', url: 'asignarCartera' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
*/
///////////////////

var parametros = {params:{inicio:0, limite:20}};
var pagos = {params:{inicio:0, limite:20}};
var datosStore = new Ext.data.JsonStore({
	root: 'registros',
	totalProperty: 'cant',
	idProperty: 'id',
	fields: [
	   	{name: 'id', type: 'int'},
		{name: 'estado'},
		{name: 'tipo_tiquete'},		   
		{name: 'id_tipo_tiquete'},		   
		{name: 'area_negocio'},	
		{name: 'id_area_negocio'},		   	   
		{name: 'estacion'},	
		{name: 'id_estacion'},		   	   
		{name: 'fecha_cierre'},
		{name: 'fecha_programada'},
		{name: 'id_inventario'},
		{name: 'inventario'},
	],
	proxy: new Ext.data.HttpProxy({
		url: 'asignarCartera/json',
		method: 'GET'
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	}
});

datosStore.load(parametros);




var clienteHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-cliente',
		title: 'Cliente',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-cliente', url: 'cliente' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var grupoTrabajoHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-grupoTrabajo',
		title: 'Grupo de Trabajo',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-grupoTrabajo', url: 'grupo_trabajo' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var codigosGcaHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-codigosGca',
		title: 'Codigos Gca',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-codigosGca', url: 'codigos_gca' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var efHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-extensiones',
		title: 'Extensiones',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-extensiones', url: 'ExtensionFuncionario' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var codigosEquivalentesHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-codigosEquivalentes',
		title: 'Codigos Equivalentes',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-codigosEquivalentes', url: 'codigosEquivalentes' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var codigosEquivalentesNewHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-codigosEquivalentesNew',
		title: 'Codigos Equivalentes Nuevo',
		region:'center',
		closable: false,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		//items: [ new Ext.ux.IFrameComponent({ id: 'panel-codigosEquivalentes', url: 'codigosEquivalentes' }) ]
		items: panelCodigos
	});

	panelPrincipal.add(nuevoTab).show();
}

/*
var funcionarioHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-funcionario',
		title: 'Funcionario',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-funcionario', url: 'funcionarios' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
*/
/*Liliana:jur*/
var cargosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-cargos',
		title: 'Cargos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-cargos', url: 'cargos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var demandadoHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-demandado',
		title: 'Demandados',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-demandado', url: 'frontDemandado/new' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var obligacionHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-obligacion',
		title: 'Obligacion',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-obligacion', url: 'obligacion' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var historicoHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-historico',
		title: 'historico',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-historico', url: 'obligacionHistoricos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var enviarSchHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-solic_sch',
		title: 'Solicitudes para Consolidar',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'anel-solic_sch', url: 'schSolicitud' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var aprobarSchHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-aprob_sch',
		title: 'Solicitudes por aprobar',
		region:'center',
		closable: true,
		layout:'fit', 
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-solicitudes_sch', url: 'schSolicitud/lista' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

/*por katty*/
var pagosDefinitivosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-pagosDefinitivos',
		title: 'Registrar Pagos Preliminares',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-pagosDefinitivos', url: 'frontPagos/search' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var reembolsoHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-reembolso',
		title: 'Reembolso',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reembolso', url: 'frontPagos/searchReembolso' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var confirmarChequesHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-confirmarCheques',
		title: 'Confirmar Cheques',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-confirmarCheques', url: 'frontPagos/searchCheques' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var imprimirChequeReembHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-imprimirCheques',
		title: 'Imprimir Cheque',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-imprimirCheques', url: 'frontPagos/imprimirChequeReembolso' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var consultarPagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-consultarPagos',
		title: 'Consulta Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-consultarPagos', url: 'frontPagos/searchPagos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var consultarComisionesHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-consultarComisiones',
		title: 'Consultar Comisiones',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-consultarComisiones', url: 'frontPagosExternos/consultarComisiones' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var facturacionMasiva = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-facturacion',
		title: 'Facturación Masiva',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-facturar', url: 'frontPagos/facturacionMasiva' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var facturarHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-facturar',
		title: 'Descargar Factura',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-facturar', url: 'frontPagos/llamarERP' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var consignacionHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-consignacion',
		title: 'Consignación Diaria',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-consignacion', url: 'frontPagos/consignacionDiaria' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var libroClaveHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-libroClave',
		title: 'libro Clave',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-libroClave', url: 'frontPagos/libroClave' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var libroClave2Handler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-libroClave2',
		title: 'libro Clave2',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-libroClave2', url: 'frontPagos/libroClave2' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}



var facturarLibroClaveHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-facturarLibroClave',
		title: 'Facturar Libro Clave',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-facturarLibroClave', url: 'frontPagos/facturarLibroClave' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var facturarLibroClave2Handler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-facturarLibroClave2',
		title: 'Facturar Libro Clave2',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-facturarLibroClave2', url: 'frontPagos/facturarLibroClave2' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


//reporte cont de pagos tesoreria
var listadoFacturacionHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-listadoFacturacion',
		title: 'Reporte a Contadores',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-listadoFacturacion', url: 'frontPagos/reporteContadores' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var subirPagosExternosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-subirPagos',
		title: 'Subir Pagos Externos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-subirPagos', url: 'frontPagosExternos/subirPagos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var FacturarPagosExternosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-facturarPagos',
		title: 'Facturar Pagos Externos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-facturarPagos', url: 'frontPagosExternos/facturarPagos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


var ConsultarPagosExternosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-ConsultarPagos',
		title: 'Consultar Pagos Externos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-ConsultarPagos', url: 'frontPagosExternos/ConsultarPagos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var AprobarDiscriminacionPagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-discriminarPagos',
		title: 'Aplicación Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-discriminarPagos', url: 'distribuirPagos/listaPagosDistribuidos?opcion=distribuir' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var ConsultarAplicacionPagosHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-consultarAplicacionPagos',
		title: 'Consultar Aplicación Pagos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-consultarAplicacionPagos', url: 'distribuirPagos/listaPagosDistribuidos?opcion=consultar' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

//reporte contadores de distribuc
var reporteContadoresHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-reporteContadores',
		title: 'Reportes aplicación Pagos ',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reporteContadores', url: 'distribuirPagos/reportes' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

//consulta general para cualquier obligacion,,, la finalidad es consultar saldos iniciales
var consultarObligacionHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-consultarObligacion',
		title: 'Consultar SI Obligación ',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-consultarObligacion', url: 'distribuirPagos/listaPagosDistribuidos?opcion=saldosI'}) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


/*Fin Katty*/

var reporteJuridicoHandler  = function(button,event) {
	var rndId=+Math.random()
	var nuevoTab = new Ext.Panel({
		id: 'panel-reporteJuridico'+rndId,
		title: 'Reporte Jurídico ',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-reporteJuridico'+rndId, url: 'frontProceso/generarReporteGeneral'}) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var cargaMasivaJuridicoHandler  = function(button,event) {
        var rndId=+Math.random()
        var nuevoTab = new Ext.Panel({
                id: 'panel-cargaMasivaJuridico'+rndId,
                title: 'Carga Masiva ',
                region:'center',
                closable: true,
        // layout to fit child component
                layout:'fit',
        // add iframe as the child component
                items: [ new Ext.ux.IFrameComponent({ id: 'panel-cargaMasivaJuridico'+rndId, url: 'frontProceso/cargaMasiva'}) ]
        });

        panelPrincipal.add(nuevoTab).show();
} 

var asignarCarteraHandler = function(button,event) {
    var parametros = {params: {inicio:0, limite:20, id_cartera:0}};
    // Create a standard HttpProxy instance.
    var datosStore2 = new Ext.data.JsonStore({
            root: 'registros',
            totalProperty: 'cant',
            idProperty: 'id',
            
           // proxy: proxy,
            autoSave: false,
            writer:new Ext.data.JsonWriter(),
            fields: [
                    {name: 'id'},    
                    {name: 'edad_mora'},	
                    {name: 'nombres'},		   	   
                    {name: 'apellidos'},	
                    {name: 'obligacion'},		   	   
                    {name: 'saldo_mora',type: 'int'},
                    {name: 'id_cartera'},
                    {name: 'id_funcionario'},                    
            ],
            proxy: new Ext.data.HttpProxy({
                    url: 'asignarCartera/json',
                    method: 'GET',
            }),
            paramNames:{
                start: 'inicio',
                limit: 'limite'                
            }
            
    });
    datosStore2.load(parametros);
    

    var datosFuncionario = new Ext.data.Store({
            id: 'datos-funcionario',
            autoLoad: true,
            root: 'registros',
			storeId: 'datosFuncionarios',
            totalProperty:'cant',
            idProperty: 'id',
            fields: [{name: 'id'},{name: 'nombre'},],
            proxy: new Ext.data.HttpProxy({
                    url : 'asignarCartera/jsonFuncionarios?id_cartera=-1',
                    method: 'GET',
            }),
           reader: new Ext.data.JsonReader({
                root: 'registros',      

            },
            [{name: 'id', mapping:'id'}, {name: 'name' , mapping:'nombre'}]
            
            )
    
    });

    var datosColumnasInfoAdicional = new Ext.data.Store({
            id: 'datos-columnasInfoAdicional',
			storeId: 'datosColumnasInfoAdicional',
            //autoLoad: true,
            root: 'registros',
            totalProperty:'cant',
            idProperty: 'id',
            fields: [{name: 'id'},{name: 'nombre'},],
            proxy: new Ext.data.HttpProxy({
                    url : 'frontInfoAdicional/columnasInfoAdicional?id_cartera=-1',
                    method: 'GET',
            }),
            reader: new Ext.data.JsonReader({
                root: 'registros',      

            },
            [{name: 'id', mapping:'id'}, {name: 'name' , mapping:'nombre'}]
            
            )
             
    });    
    
    var datosCartera = new Ext.data.Store({
			id: 'datos-cartera',
			storeId: 'datosCartera',
            root: 'registros',
            totalProperty:'cant',
            idProperty: 'id',
            fields: [{name: 'id'},{name: 'nombre'},],
            proxy: new Ext.data.HttpProxy({
                    url : 'asignarCartera/cartera',
                    method: 'GET',
            }),
           reader: new Ext.data.JsonReader({
                root: 'registros',      

            },
            [{name: 'id', mapping:'id'}, {name: 'name' , mapping:'nombre'}]
            
            )
    
    });
	
    datosCartera.load();    
    //Ext.StoreMgr.register(datosFuncionario);
//	Ext.StoreMgr.register(datosColumnasInfoAdicional);
//	Ext.StoreMgr.register(datosCartera);
//fin seg pru store//




    

    var fm = Ext.form;

    var obligacionGrid = new Ext.grid.EditorGridPanel({
        id: 'obligacion-grid',
        store: datosStore2,
        flex:10,
        clicksToEdit: 1,
        listeners: {
                    afteredit: function(celda) {
                        celda.dirty=false;
                        //this.refresh();
                        this.store.add(celda); 
                    },
                },
        columns: [
                {id:'id', header:'Id', width: 75, sortable:true, dataIndex: 'id'},    
                {header: 'Edad Mora', width: 75, sortable:true, dataIndex: 'edad_mora'},
                {header: 'Nombres', width: 150, sortable:true, dataIndex: 'nombres'},
                {header: 'Apellidos', width: 75, sortable:true, dataIndex: 'apellidos'},
                {header: 'Obligaci&oacute;n', width: 75, sortable:true, dataIndex: 'obligacion'},
                {header: 'Monto', width: 75, sortable:true, dataIndex: 'saldo_mora'},
                {header: 'Cartera', width: 75, sortable:true, dataIndex: 'id_cartera'},
                {header: 'Asesor Sugerido', width: 100, sortable:true, dataIndex: 'id_funcionario',
                                editor: new fm.ComboBox({
                                    store:datosFuncionario,
                                    typeAhead: true,
                                    editable:false,
                                    triggerAction: 'all',
                                    emptyText:'Asesor...',
                                    displayField:'name',
                                    valueField: 'id',
                                    //transform: 'funcionario',
                                    //lazyRender: true,
                                    //selectOnFocus:true
                                    mode: 'remote',                                    
                                }),  
                },
        ],
        bbar: new Ext.PagingToolbar({
                        pageSize: 20,
                        store: datosStore2,
                        displayInfo: true,
                        displayMsg: 'Mostrando registros {0} - {1} de {2}',
                        emptyMsg: "No hay registros para mostrar",
                        listeners: {
                                    beforechange: function(tb,parametros2) {
                                        var cartera=Ext.getCmp('comboCartera').getValue();
                                        parametros2.id_cartera=cartera;
                                        parametros.params=parametros2;
                                        datosStore2.load(parametros);
                                        datosStore2.reload();
                                        return false;
                                    },
                                },
        }),
        
        tbar:[
            new Ext.form.ComboBox({
                store:datosCartera,
                id:'comboCartera',
                                    typeAhead: true,
                                    editable:false,
                                    triggerAction: 'all',
                                    emptyText:'Seleccione...',
                                    displayField:'name',
                                    valueField: 'id',
                                    //transform: 'funcionario',
                                    //lazyRender: true,
                                    //selectOnFocus:true
                                    mode: 'remote',
                                    listeners: {
                                        select: function(combo,rec,row) {
                                           parametros.params.id_cartera=rec.id;
                                           datosStore2.load(parametros);
                                           datosStore2.reload();
                                           datosFuncionario.load({url: 'asignarCartera/jsonFuncionarios',params:{id_cartera:rec.id}});
                                           datosColumnasInfoAdicional.load({url:'asignarCartera/columnasInfoAdicional', params:{id_cartera:rec.id}});
                                           
                                        },
                                    },
            }),
            {
                text: "&nbsp;&nbsp;&nbsp;&nbsp;Asesor Anterior",
                handler : function(){

                    var cartera=Ext.getCmp('comboCartera').getValue();
                    var datosStore2=Ext.getCmp('obligacion-grid');    
                    datosStore2.load({url: 'asignarCartera/respetarAsesor', params: {inicio:0, limite:20, id_cartera:cartera}});
                    
        


                }
                
            },
            {
                text: "&nbsp;&nbsp;&nbsp;&nbsp;Por montos",
                handler : function(){

                    var msForm = new Ext.form.FormPanel({
                        id: 'msform-msform',
                        title: 'Asignar Asesores por monto',
                        width: 700,
                        bodyStyle: 'padding:10px;',
                        //renderTo: 'multiselect',
                        items:[{
                            xtype: 'multiselect',
                            fieldLabel: 'Asesores<br />disponibles',
                            name: 'multiselect',
                            width: 250,
                            height: 170,
                            allowBlank:false,
                            store: datosFuncionario,
                            displayField:'name',
                            valueField: 'id',
                            tbar:[{
                                text: 'clear',
                                handler: function(){
                                        msForm.getForm().findField('multiselect').reset();
                                }
                            }],
                            ddReorder: false,
                        }],
                    });
                    var submit = msForm.addButton({
                        text: 'Asignar',
                        //disabled:true,
                        handler: function(){
                            var cartera=Ext.getCmp('comboCartera').getValue();
                            msForm.getForm().submit({url:'asignarCartera/seleccionarAsesores', params: {id_cartera:cartera}});
                        }
                    });      
                
                    win = new Ext.Window({
                        layout:'fit',
                        width:500,
                        height:300,
                        closeAction:'hide',
                        plain: true,        
                        items: [msForm],
                        

                    });
                    win.show(this);

                    var cartera=Ext.getCmp('comboCartera').getValue();
                    //var datosStore2 =Ext.getCmp('obligacion-grid');
                    //datosStore2.load({url: 'asignarCartera/asignarMontos', params: {inicio:0, limite:20, id_cartera:cartera}});
                    //datosStore2.load({url: 'asignarCartera/json', params: {inicio:0, limite:20, id_cartera:cartera}});
                    
                    datosStore2.reload();   
                }
            },
            {
                text: 'Confirmar asesores',
                handler: function(){                   
                    
                        //disabled:true,
                    var cartera=Ext.getCmp('comboCartera').getValue();
                    var datosStore2=Ext.getCmp('obligacion-grid');    
                    datosStore2.load({url: 'asignarCartera/confirmarAsesor', params: {inicio:0, limite:20, id_cartera:cartera}});
                    

                    
                }
            },





           /* {
              text: 'Otros',
              handler: function(){
                var arrayOtros = [['igual que', '='],
                                  ['mayor que', '>'],
                                  ['menor que', '<']
                                 ];
                
                var storeOtros = new Ext.data.ArrayStore({
                    autoDestroy: true,
                    storeId: 'store-otros',
                    fields: ['texto', 'valor'],
		    data: arrayOtros
                });
                
            



                    var comboCampos1 =new Ext.form.ComboBox({
                        id:'combo-campos1',
                        fieldLabel: '', 
                        //typeAhead: true,
                        width:100,
                        triggerAction: 'all',
                        lazyRender:true,
                        mode: 'local',
                        store: datosColumnasInfoAdicional,
                        hiddenName:'campos1',
                        valueField: 'id',
                        displayField: 'name',
                        name: 'name',
                        //tabIndex:6
                    });

                    var comboCampos2 =new Ext.form.ComboBox({
                        id:'combo-campos2',
                        fieldLabel: '', 
                        //typeAhead: true,
                        width:100,
                        triggerAction: 'all',
                        lazyRender:true,
                        mode: 'local',
                        store: datosColumnasInfoAdicional,
                        hiddenName:'campos2',
                        valueField: 'id',
                        displayField: 'name',
                        name: 'name',
                        //tabIndex:6
                    });
             
                    var comboOperador1 =new Ext.form.ComboBox({
                        id:'combo-operador-1',
                        fieldLabel: '', 
                        //typeAhead: true,
                        width:80,
                        triggerAction: 'all',
                        lazyRender:true,
                        mode: 'local',
                        store: storeOtros,
                        hiddenName:'operador1',
                        valueField: 'valor',
                        displayField: 'texto',
                        name: 'texto',
                        //tabIndex:6
                    });

                    var comboOperador2 =new Ext.form.ComboBox({
                        id:'combo-operador-2',
                        fieldLabel: '', 
                        //typeAhead: true,
                        width:80,
                        triggerAction: 'all',
                        lazyRender:true,
                        mode: 'local',
                        store: storeOtros,
                        hiddenName:'operador2',
                        valueField: 'valor',
                        displayField: 'texto',
                        name: 'texto',
                        //tabIndex:6
                    });
					
                    var comboAsesor =new Ext.form.ComboBox({
                        id:'combo-asesor',
                        fieldLabel: '<b>Asesor</b>', 
                        //typeAhead: true,
                        width:120,
                        triggerAction: 'all',
                        lazyRender:true,
                        mode: 'local',
                        store: datosFuncionario,
                        hiddenName:'id',
                        valueField: 'id',
                        displayField: 'name',
                        //tabIndex:6
                    });
              
                    var  formOtros = new Ext.form.FormPanel({
                        id: 'formOtros-formOtros',
                        title: 'Asignar Asesores por otros criterios',
                        width: 900,
                        bodyStyle: 'padding:10px;',
                        //renderTo: 'multiselect',
                        frame:true,
                        items:[
                            {
                                layout: 'column',
                                items: [
                                        {
                                            columnWidth: .36,
                                            //layout: 'form',
                                            items:[
                                                comboCampos1,
                                                comboCampos2,
                                                comboAsesor,
                                            ]
                                            
                                        },
                                    
                                    
                                        {
                                            columnWidth: .34,
                                            //layout: 'form',
                                            items:[                                                
                                                comboOperador1,
                                                comboOperador2,
                                                
                                            ]
                                        },
                                        {
                                            columnWidth: .30,
                                            //layout: 'form',
                                            items:[                                                
                                                    {
							xtype: 'textfield',
							//fieldLabel: '<b>Contacto</b>',
							id: 'fieldValue1',
							name :'value1',
							width : 80,
							tabIndex: 1
                                                    },
                                                    {
                                                            xtype: 'textfield',
                                                            //fieldLabel: '<b>Contacto</b>',
                                                            id: 'fieldValue2',
                                                            name :'value2',
                                                            width : 80,
                                                            tabIndex: 1
                                                    },
                                                ]
                                        }
                                    ]
                                },

                            ]
                        });
                    var submit = formOtros.addButton({
                        text: 'Asignar',
                        //disabled:true,
                        handler: function(){
                            var cartera=Ext.getCmp('comboCartera').getValue();
                            
                            formOtros.getForm().submit({url:'asignarCartera/asignarPorCriterios', params: {id_cartera:cartera}});
                            winA.hide();
                            
                        }
                    });      
                
                    winA = new Ext.Window({
                        layout:'fit',
                        width:500,
                        height:300,
                        closeAction:'hide',
                        plain: true,        
                        items: [formOtros],
                    });
                    winA.show(this);
                }
            }*/
			
			{
				text: 'Asignar por filtros',
				handler: ventanaFiltrosAsignacion
			},








            {
               text: '<span style="color:blue";>Guardar</span>',
               handler : function(){
               alert("Datos Actualizados");
               var datosStore2=Ext.getCmp('obligacion-grid');
               datosStore2.getStore().save();
               datosStore2.getStore().reload();
                }
                //obligacionGrid.stopEditing();
                //datosStore2.insert(0, p);
                //obligacionGrid.startEditing(0, 0);                
                
            },

            ]
    });
    


    var nuevoTab = new Ext.Panel({
        id: 'panel-asignarCartera',
        title: 'Asignar Cartera',
        region: 'center',
        closable: true,
        layout:{
            type:'vbox',
            align:'stretch'
        },
        items: [
                obligacionGrid,
                new Ext.Panel({                    
                    height:20,
                    frame: false
                }),                
                ]
    });





    
    panelPrincipal.add(nuevoTab).show();
}



var CarteraAsignadaHandler = function(button, event){
	var nuevoTab = new Ext.Panel({
		id: 'cartera-asignada',
		title: 'Cartera Asignada',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'cartera-asignada', url: 'carteraAsignada' }) ]
	});

	panelPrincipal.add(nuevoTab).show();        
}


/* Desarrollo Interfaz Contable Handlers*/

var vendorCarteraHandler = function(button, event){
    var nuevoTab = new Ext.Panel({
        id: 'panel-vendorCartera',
        title: 'Carteras por Inversionista',
        region: 'center',
        closable: true,
        layout:{
            type:'vbox',
            align:'stretch'
        },
        items: [
                PanelVendorGcaCartera(),
                new Ext.Panel({                    
                    height:20,
                    frame: false
                }),                
                ]
    });

    panelPrincipal.add(nuevoTab).show();

}

var bancoCuentaHandler = function(button, event){
    var nuevoTab = new Ext.Panel({
        id: 'panel-bancoCuenta',
        title: 'Bancos por Cuenta',
        region: 'center',
        closable: true,
        layout:{
            type:'vbox',
            align:'stretch'
        },
        items: [
                PanelGcaBancoCuenta(),
                new Ext.Panel({                    
                    height:20,
                    frame: false
                }),                
                ]
    });

    panelPrincipal.add(nuevoTab).show();

}

var crearBancoHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-crearBanco',
		title: 'Crear Banco',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-crearBanco', url: 'bancos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}


/*var DefaultsHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-Default',
		title: 'Preferencias',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-Default', url: 'defaults' }) ]
	});
        panelPrincipal.add(nuevoTab).show();
}*/

var parametrosCuentasHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-parametrosCuentas',
		title: 'Parametros Cuentas',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-parametrosCuentas', url: 'parametros' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var informeContableHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'panel-informeContable',
		title: 'Generar Reportes para World Office',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-informeContable', url: 'frontPagos/informesContables' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
        
/* Fin Desarrollo Interfaz Contable Handlers */


//---------prototipo------








//------Fin prototipo-------





var cerrarSesionHandler = function(button,event) {
        //var datosStore2=Ext.getCmp('obligacion-grid');
        //alert(datosStore2.getStore().save());
	//alert("Cerrando Sesión");
        //window.location="login/logout";

    
    Ext.MessageBox.confirm('confirmar','¿Seguro?', showResult);

    function showResult(btn){
        if(btn == 'yes'){
            window.location="login/logout";
        }
    };

/*   
    var win;       
    win = new Ext.Window({
        //applyTo:'hello-win',
        layout:'fit',
        width:200,
        height:110,
        closeAction:'hide',
        title:'Cerrar Sesión',
        //plain: true,
--
        items: new Ext.TabPanel({
            //applyTo: 'hello-tabs',
            autoTabs:true,
            activeTab:0,
            deferredRender:false,
            border:false
        }),
--
        buttons: [{
            text:'Aceptar',
            handler: function(){
                window.location="login/logout";
            }
        },{
            text: 'Cancelar',
            handler: function(){
                win.hide();
            }
        }]
    });

    win.show(this);
      */

}

var menuCartera = new Ext.menu.Menu({
    id: 'menuCartera',
    items: [
<?php if(in_array('director',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Crear Cartera',
            tooltip: 'Opciones Cartera',
            handler: crearCarteraHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('director',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Crear Plantilla',
            tooltip: 'Crear plantillas de cartera',
            handler: crearPlantillaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>        
<?php if(in_array('coordinador',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Subir Cartera',
            tooltip: 'Opciones de cartera',
            handler: subirCarteraHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Subir Cartera BCSC',
            tooltip: 'Opciones de cartera',
            handler: subirCarteraBCSCHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Subir Cartera ICS',
            tooltip: 'Carga de carteras de tipo ICS',
            handler: cargarCarteraICS,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Cargar Visitas Codensa',
            tooltip: 'Cargar Visitas Codensa',
            handler: visitasCodensaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
        new Ext.menu.Item({
            text: 'Gesti\xF3n Masiva Extendido',
            tooltip: 'Gesti\xF3n Masiva',
            handler: gestionMasivaExtHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>
        new Ext.menu.Item({
            text: 'Plantilla Actualizar Cartera',
            tooltip: 'Opciones de cartera',
            handler: plantillaActualizarHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>        
<?php if(in_array('coordinador',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Asignar Cartera',
            tooltip: 'Opciones de cartera',
            handler: asignarCarteraHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Cartera Asignada',
            tooltip: 'Opciones de cartera',
            handler: CarteraAsignadaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Gesti\xF3n Masiva',
            tooltip: 'Realizar gesti\xF3n masiva',
            handler: GestionMasivaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('coordinador',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Codigos Equivalentes',
            tooltip: 'Crear codigos Equivalentes',
            handler: codigosEquivalentesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>  
<?php if(in_array('coordinador',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Crear Codigos Equivalentes',
            tooltip: 'Arbol codigos Equivalentes',
            handler: codigosEquivalentesNewHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endif; ?>     
        
//inicio de submenus para Condonaciones

<?php if(in_array('coordinador',$credenciales)): ?>      
        new Ext.menu.Item({
                text: 'Informes',
                tooltip: 'Informes',
                icon: '../js/resources/images/default/tree/leaf.gif',
                menu: {        
                    items: [
               
                    <?php if(in_array('coordinador',$credenciales)): ?>
                            {
                                text: 'Informes',
                                tooltip: 'Crear Informe Gesti&oacute;n',
                                handler: crearReporteHandler,
                                icon: '../js/resources/images/default/tree/leaf.gif'
                            },
                    <?php endIf; ?>
                    <?php if(in_array('coordinador',$credenciales)): ?>
                    {
                        text: 'Cierre Mensual ',
                        tooltip: 'Crear Informe Gesti&oacute;n',
                        handler: cierremensualHandler,
                        icon: '../js/resources/images/default/tree/leaf.gif'
                    },
                    <?php endIf; ?>
                    <?php if(in_array('coordinador',$credenciales)): ?>
                    {
                        text: 'Cierre Mensual GCA',
                        tooltip: 'Informe Cierre mensual GCA',
                        handler: cierremensualgcaHandler,
                        icon: '../js/resources/images/default/tree/leaf.gif'
                    },
                    <?php endIf; ?>
                    <?php if(in_array('coordinador',$credenciales)): ?>
                    {
                        text: 'Inactivacion de Deudores Consolidada',
                        tooltip: 'Informe Inactivación de deudores consolidada',
                        handler: inactivaciondeudoresconsolidadaHandler,
                        icon: '../js/resources/images/default/tree/leaf.gif'
                    },
                    <?php endIf; ?>
                    <?php if(in_array('coordinador',$credenciales)): ?>
                    {
                        text: 'Inactivacion de Deudores Detallada',
                        tooltip: 'Inactivación de deudores detallada',
                        handler: inactivaciondeudoresdetalladaHandler,
                        icon: '../js/resources/images/default/tree/leaf.gif'
                    },
                    <?php endIf; ?>
                    <?php if(in_array('coordinador',$credenciales)): ?>
                    {
                        text: 'Inactivacion de Deudores por Cartera',
                        tooltip: 'inactivación de deudores por cartera',
                        handler: inactivaciondeudorescarteraHandler,
                        icon: '../js/resources/images/default/tree/leaf.gif'
                    },
                    <?php endIf; ?>
                    <?php if(in_array('coordinador',$credenciales)): ?>
                            {
                                text: 'Inventario al corte mensual',
                                tooltip: 'Listado Condonaciones',
                                handler: cortemensualHandler,
                                icon: '../js/resources/images/default/tree/leaf.gif'
                            }
                    <?php endIf; ?>
                    
                                                
                                                
                                                
			  ]//fin item
			}// fin etiqueta menu
        }),
<?php endIf; ?>        
        
        
<?php if(in_array('coordinador',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Indicadores',
            tooltip: 'Muestra los indicadores de gestion',
            handler: IndicadoresGestionHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>       

       
<?php if(in_array('tesorero',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Inversionista Cartera',
            tooltip: 'Crea participación de inversionas por cartera',
            handler: vendorCarteraHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>   
        
    ]
});

var menuObligacion = new Ext.menu.Menu({
    id: 'menuObligacion',
    items: [
        /*
        new Ext.menu.Item({
            text: 'Obligaci&oacute;n',
            tooltip: 'Ver obligaciones',
            handler: obligacionHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
        new Ext.menu.Item({
            text: 'Historico',
            tooltip: 'Ver Historicos de obligaciones',
            handler: historicoHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
     */        
<?php if(in_array('coordinador',$credenciales)): ?>        
	new Ext.menu.Item({
            text: 'Consolidar Solicitud',
            tooltip: 'Consolidar las solucitudes para enviar a Searching',
            handler: enviarSchHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
        new Ext.menu.Item({
            text: 'Históricos',
            tooltip: 'Permite consultar gestiones de obligaciones no vigentes',
            handler: busquedaHistoricoHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('director',$credenciales)): ?>        
	new Ext.menu.Item({
            text: 'Solicitudes Searching',
            tooltip: 'Aprobar Solicitudes Searching',
            handler: aprobarSchHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>       
		
    ]    
});

var menuParametros = new Ext.menu.Menu({
    id: 'menuParametros',
    items: [
<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Crear Sucursal',
            tooltip: 'Crear Sucursal',
            handler: crearSucursalHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Lista de Redistribución de pagos',
            tooltip: 'lista de redistribución de pagos',
            handler: redistribuirpagosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
        <?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Redistribuir pagos históricos',
            tooltip: 'Crear Sucursal',
            handler: redistribuirpagoshistoricosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Cálculo de Intereses',
            tooltip: 'Cálculo de Intereses',
            handler: calculoInteresesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Estado de Cuenta por Cliente',
            tooltip: 'Crear Sucursal',
            handler: estadoCuestaXclienteHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>

<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Causales',
            tooltip: 'Crear Causales',
            handler: causalesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Lista Causales',
            tooltip: 'Lista  Causales',
            handler: listaCausalesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>

<?php if(in_array('administrador',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Consulta Básica Portafolios',
            tooltip: 'Crear Sucursal',
            handler: consultabasicaportafoliosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>

<?php if(in_array('administrador',$credenciales)): ?>            
       new Ext.menu.Item({
            text: 'Extensiones',
            tooltip: 'Asigna extensiones de VoIP a los usuarios',
            handler: efHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
<?php if(in_array('administrador',$credenciales)): ?>            
       new Ext.menu.Item({
            text: 'Codigos Gca',
            tooltip: 'Crear codigos de gca',
            handler: codigosGcaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>
<?php if(in_array('administrador',$credenciales) || in_array('director_juridico',$credenciales)): ?>            
       new Ext.menu.Item({
            text: 'Clientes',
            tooltip: 'Opciones Cliente',
            handler:clienteHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('administrador',$credenciales)): ?>            
/*        new Ext.menu.Item({
                text: 'Funcionarios',
                tooltip: 'Opciones Funcionario',
                handler: funcionarioHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),*/
<?php endIf; ?>
<?php if(in_array('administrador',$credenciales) || in_array('nomina',$credenciales)): ?>            
        new Ext.menu.Item({
                text: 'Cargos',
                tooltip: 'Administracion Cargos',
                handler: cargosHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('nomina',$credenciales) || in_array('administrador',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Agregar Entidades',
			tooltip: 'Permite agregar o eliminar una entidad',
			handler: entidadesNominaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>
<?php if(in_array('asesor_juridico',$credenciales) || in_array('director_juridico',$credenciales)): ?>            
        new Ext.menu.Item({
                text: 'Demandados',
                tooltip: 'Opciones Demandados',
                handler: demandadoHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf;?>     


<?php 	/* Informes contables*/
if(in_array('administrador',$credenciales) || in_array('nomina',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Banco Cuenta',
            tooltip: 'Crea cuentas por banco',
            handler: bancoCuentaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
  
<?php endIf;?> 
 <?php if(in_array('administrador',$credenciales) || in_array('nomina',$credenciales)): ?>            
        new Ext.menu.Item({
            text: 'Crear Banco',
            tooltip: 'Nuevo Banco',
            handler: crearBancoHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
        <?php if(in_array('administrador',$credenciales) || in_array('nomina',$credenciales)): ?>            
        new Ext.menu.Item({
                text: 'Parametros Cuentas',
                tooltip: 'Configuración de Otros Parametros',
                handler: parametrosCuentasHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; 


/* Fin Informes contables*/
?>
<?php if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
        new Ext.menu.Item({
                text: 'Configuración Sistema',
                tooltip: 'Configuración Sistema',
                handler: configuracionsistemaHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

    
        new Ext.menu.Item({
                text: 'Cambiar Clave',
                tooltip: 'Cambiar Clave',
                handler: function(){
			vCambiarClave = Ext.getVCambiarClave();
			vCambiarClave.show();
		},
                icon: '../js/resources/images/default/tree/leaf.gif'
        })
 ]
});


/*Por Katty.. pagos....*/
var menuPagos = new Ext.menu.Menu({
    id: 'menuPagos',
    items: [

<?php if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
        new Ext.menu.Item({
                text: 'Ingresar Pagos',
                tooltip: 'Ingresar Pagos',
                handler: ingresarPagosHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
        new Ext.menu.Item({
                text: 'Registro Recibos de caja',
                tooltip: 'Registro Recibos de caja',
                handler: registrorecibosHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>




//inicio de submenus para Condonaciones


<?php if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
        new Ext.menu.Item({
                text: 'Condonaciones',
                tooltip: 'Condonaciones',
                icon: '../js/resources/images/default/tree/leaf.gif',
                menu: {        
                    items: [
               
               <?php if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
                            {
                                text: 'Nueva Solicitud',
                                tooltip: 'Configuración Condonaciones',
                                handler: nuevacondonacion,
                                icon: '../js/resources/images/default/tree/leaf.gif'
                            },
                    <?php endIf; 
                    
                    if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
                            {
                                text: 'Configuración Condonaciones',
                                tooltip: 'Configuración Condonaciones',
                                handler: listacondonacion,
                                icon: '../js/resources/images/default/tree/leaf.gif'
                            },
                    <?php endIf; 
                    
                    if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
                            {
                                text: 'Lista Solicitud de condonaciones',
                                tooltip: 'Listado Condonaciones',
                                handler: buscarcondonacion,
                                icon: '../js/resources/images/default/tree/leaf.gif'
                            }
				<?php endIf; ?>
			  ]//fin item
			}// fin etiqueta menu
        }),
<?php endIf; ?>

 //Fin de submenus Condonaciones Alexa


<?php if(in_array("asesor",$credenciales) or in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales)  ): ?>
        new Ext.menu.Item({
                text: 'Configuracion Sistema',
                tooltip: 'Configuracion  ', 
                handler: inabilitarcondonacion,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array('asesor',$credenciales) or in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Consultar Pagos',
            tooltip: 'Consultar Pagos',
            handler:  consultarPagosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?
 /*php if(in_array('tesorero', $credenciales)): ?>
        new Ext.menu.Item({
                text: 'Subir Pagos',
                tooltip: 'Subir Pagos',
                handler: subirPagosHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        }),      
<?php endIf; */
?> 


<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) or in_array("coordinador",$credenciales)  ): ?>        
      new Ext.menu.Item({
            text: 'Registrar Pagos',
            tooltip: 'Guarda un pago preliminar como definitivo',
            handler:  pagosDefinitivosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Confirmar Cheques/Fax-Cheque',
            tooltip: 'Confirma cheques y Fax Cheque',
            handler:  confirmarChequesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Reembolso',
            tooltip: 'Confirma cheques y Fax efectivo',
            handler:  reembolsoHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Imprimir Cheque Reembolso',
            tooltip: 'Imprime Cheque a la entidad con el valor del reembolso',
            handler:  imprimirChequeReembHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>




<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) or in_array("contabilidad",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Consignación Diaria',
            tooltip: 'Consignación Diaria',
            handler:  consignacionHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) or in_array("contabilidad",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Libro Clave',
            tooltip: 'Libro Clave',
            handler:  libroClaveHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array("tesorero",$credenciales)  or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Facturar Libro Clave',
            tooltip: '',
            handler:  facturarLibroClaveHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array("tesorero",$credenciales) or in_array("tesorero_sucursal",$credenciales) or in_array("contabilidad",$credenciales)): ?>        
      new Ext.menu.Item({
            text: 'Reporte a contadores',
            tooltip: '',
            handler:  listadoFacturacionHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Generar Facturación Masiva',
            tooltip: 'Facturacion Masiva',
            handler:  facturacionMasiva,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('coordinador',$credenciales) or in_array("tesorero",$credenciales)or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Subir Pagos externos',
            tooltip: 'Subir archivo de pagos',
            handler:  subirPagosExternosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) or in_array('coordinador',$credenciales)  ): ?>        
      new Ext.menu.Item({
            text: 'Consultar Pagos Externos',
            tooltip: 'Consultar Pagos Externos',
            handler:  ConsultarPagosExternosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array('tesorero_ya_no',$credenciales) or in_array("tesorero_sucursal_ya_no",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Consultar Comisiones',
            tooltip: 'Consultas',
            handler:  consultarComisionesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Facturar Pagos externos',
            tooltip: 'Factura pagos externos',
            handler:  FacturarPagosExternosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesorero',$credenciales) or in_array("tesorero_sucursal",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Descargar Factura ERP',
            tooltip: 'Facturar los pagos reembolsados al cliente',
            handler:  facturarHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>



<?php if(in_array("analista_portafolios",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Aplicar Pagos',
            tooltip: '',
            handler:  AprobarDiscriminacionPagosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array("analista_portafolios",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Consultar Aplicación Pagos',
            tooltip: '',
            handler:  ConsultarAplicacionPagosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array("analista_portafolios",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Reportes Aplicación Pagos',
            tooltip: '',
            handler:  reporteContadoresHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array("analista_portafolios",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Consultar SI Obligación',
            tooltip: '',
            handler:  consultarObligacionHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

<?php if(in_array('tesoreroPruebas',$credenciales)): ?>        
      new Ext.menu.Item({
            text: 'Libro Clave2',
            tooltip: 'Libro Clave2',
            handler:  libroClave2Handler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array("tesoreroPruebas",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Facturar Libro Clave2',
            tooltip: '',
            handler:  facturarLibroClave2Handler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>


<?php if(in_array("contabilidad",$credenciales)  or in_array("contabilidad",$credenciales) ): ?>        
      new Ext.menu.Item({
            text: 'Informes Contables',
            tooltip: '',
            handler:  informeContableHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>

/*fin pagos katty*/   
    ]
});


/*Liliana: jur*/
var menuJuridico = new Ext.menu.Menu({
    id: 'menuJuridico',
    items: [
<?php if(in_array('director_juridico',$credenciales)): ?>        
	new Ext.menu.Item({
            text: 'Tipos Procesos',
			tooltip: 'Administraci&ocute;n tipos de Procesos',
            handler: tipoProcJurHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('director_juridico',$credenciales)): ?>        
	new Ext.menu.Item({
            text: 'Proceso Plantilla',
			tooltip: 'Modificar el proceso plantilla',
            handler: plantillaJurHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('director_juridico',$credenciales)): ?>        
	new Ext.menu.Item({
            text: 'Proceso Plantilla Codensa',
			tooltip: 'Modificar el proceso plantilla',
            handler: plantillaCodJurHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('director_juridico',$credenciales)): ?>        
        new Ext.menu.Item({
            text: 'Crear Proceso',
            handler: crearProcesojurHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('director_juridico',$credenciales)): ?>        
       new Ext.menu.Item({
            text: 'Notificaciones',
            handler:notificacionesJurHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('abogado',$credenciales) OR in_array('director_juridico',$credenciales)): ?>
       new Ext.menu.Item({
            text: 'Carga Masiva',
            handler:cargaMasivaJuridicoHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('abogado',$credenciales) OR in_array('director_juridico',$credenciales)): ?>        
       new Ext.menu.Item({
            text: 'Reporte General',
            handler:reporteJuridicoHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        }),
<?php endIf; ?>
<?php if(in_array('abogado',$credenciales) OR in_array('director_juridico',$credenciales)): ?>        
       new Ext.menu.Item({
            text: 'Reporte Codensa',
            handler:reporteCodensaJurHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
        })
<?php endIf; ?>
    ]
});


var menuNomina = new Ext.menu.Menu({
	id:'menu-nomina',
	items: [
	new Ext.menu.Item({
			text: 'Mis comprobantes',
			tooltip: 'Ver los comprobantes de la ultima nomina o anteriores',
			handler: comprobantesNominaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Comprobantes Funcionarios',
			tooltip: 'Consulta de Comprobantes de Funcionarios',
			handler: comprobantesFuncNominaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Administrar Nominas',
			tooltip: 'Permite agregar o eliminar nominas',
			handler: administrarNominaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Agregar Funcionarios',
			tooltip: 'Permite agregar funcionarios',
			handler: agregarFuncionariosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>  
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Buscar Funcionarios',
			tooltip: 'Permite buscar funcionarios',
			handler: buscarFuncionariosHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>  
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Buscar Novedades',
			tooltip: 'Buscar novedad',
			handler: buscarNovedadesFuncHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?> 
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Cargar Novedades Funcionario',
			tooltip: 'Permite cargar masivamente novedades de funcionario',
			handler: subirNovedadesFuncHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?> 
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Agregar Grupos',
			tooltip: 'Permite agregar o eliminar grupos',
			handler: gruposNominaHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?> 
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Reporte Funcionarios',
			tooltip: 'Generar reporte excel de los funcionaros',
			handler: reporteFuncHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>                
<?php if(in_array('nomina',$credenciales)): ?>            
		new Ext.menu.Item({
			text: 'Reporte Nomina',
			tooltip: 'Generar reporte excel de la nomina',
			handler: reporteNomHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		})
<?php endIf;?>  
	]
});
 
var menuSearching = new Ext.menu.Menu({
	id:'menu-searching',
	items: [
<?php if(in_array('coordinador_searching',$credenciales)): ?>                        
		new Ext.menu.Item({
			text: 'Carteras Asignadas',
			tooltip: 'Muestra las carteras y permite asignarle asesores',
			handler: SolicitudesAsigHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
		new Ext.menu.Item({
			text: 'Reportes',
			tooltip: 'Genera reportes de la gestion',
			handler: SchReportesHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),
<?php endIf;?>
<?php if(in_array('asesor_searching',$credenciales)): ?>                        
		new Ext.menu.Item({
			text: 'Gestion',
			tooltip: 'Permite realizar la gestion',
			handler: gestionSeachHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		})
<?php endIf;?>                
	]
});





<?php if(in_array('coordinador',$credenciales)): ?>                            
toolbar.add(
	new Ext.Button({
		text: 'Cartera&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'Men&uacute; cartera',
		menu:menuCartera,
                icon: '../js/resources/images/default/tree/folder.gif'
	})
);
<?php endIf;?>
toolbar.add(
	new Ext.Button({
		text: 'Obligaciones&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'Men&uacute; obligaci&oacute;n',
		menu:menuObligacion,
                icon: '../js/resources/images/default/tree/folder.gif'
	})
);

toolbar.add(
	new Ext.Button({
		text: 'Parametros&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'Parametros',
		menu:menuParametros,
                icon: '../js/resources/images/default/tree/folder.gif'
	})
);

toolbar.add(
	new Ext.Button({
		text: 'Pagos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'Pagos',
		menu:menuPagos,
                icon: '../js/resources/images/default/tree/folder.gif'
	})
);

/*Liliana : jur*/
<?php if(in_array('jur',$credenciales)): ?>
toolbar.add(
	new Ext.Button({
		text: 'Juridico&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'Jur&iacute;dico',
		menu:menuJuridico,
                icon: '../js/resources/images/default/tree/folder.gif'
	})
);
<?php endIf;?>
/*Carlos : Nominas*/
<?php //if(in_array('nomina',$credenciales)): ?>
toolbar.add(
	new Ext.Button({
		text: 'N&oacute;mina&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'N&oacute;mina',
		menu:menuNomina,
        icon: '../js/resources/images/default/tree/folder.gif'
	})
);
<?php //endIf;?>
/*Liliana : searching*/
<?php if(in_array('asesor_searching',$credenciales)): ?>
toolbar.add(
	new Ext.Button({
		text: 'Searching&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
		tooltip: 'Searching',
		menu:menuSearching,
        icon: '../js/resources/images/default/tree/folder.gif'
	})
);
<?php endIf;?>


/*
toolbar.add(
        new Ext.menu.Item({
                text: 'Funcionario',
                tooltip: 'Opciones Funcionario',
                handler: funcionarioHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        })
);

toolbar.add(
        new Ext.menu.Item({
                text: 'Grupo de Trabajo',
                tooltip: 'Opciones de Grupo de Trabajo',
                handler: grupoTrabajoHandler,
                icon: '../js/resources/images/default/tree/leaf.gif'
        })
);
*/

var elearningHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'tab-elearning',
		title: 'E-Learning',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-elearning', url: 'http://190.144.46.221/elearning' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var intranetHandler = function(button,event) {
	var nuevoTab = new Ext.Panel({
		id: 'tab-intranet',
		title: 'Intranet',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-intranet', url: 'http://190.144.46.221/gca_intranet' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}



var menuVarios = new Ext.menu.Menu({
	id:'menu-varios',
	items: [
		new Ext.menu.Item({
			text: 'Intranet',
			tooltip: 'Informaci\xF3n Institucional de Grupo Consultor Andino',
			handler: intranetHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		}),  
		new Ext.menu.Item({
			text: 'E-Learning',
			tooltip: 'Capacitaci\xF3n e Instrucci\xF3n ',
			handler: elearningHandler,
            icon: '../js/resources/images/default/tree/leaf.gif'
		})
	]
});


toolbar.add(
	new Ext.Button({
		text: 'Institucional',
		tooltip: 'Informaci\xF3n Importante',
		menu: menuVarios,
		icon: '../js/resources/images/default/tree/folder.gif'
	})
);

toolbar.add(
	new Ext.Button({
		text: 'Cerrar',
		tooltip: 'Cierra la sesi&oacute;n',
		iconCls: 'salir',
		handler: cerrarSesionHandler
	})
);

var comboCarterasJSON = new Ext.data.JsonStore({
	root: 'registros',
	idProperty: 'id',
	fields: [
	   	{name: 'id', type: 'int'},
		{name: 'nombre'},
	],
	proxy: new Ext.data.HttpProxy({
		url: 'crearCartera/carterasFuncionariosJson',
		method: 'GET'
	})
});

comboCarterasJSON.load();
var cambiarCarteraFunction = function(combo,registro,indice){
	var jsonGuardarCarteraUsuario = new Ext.data.JsonStore({
		root: 'registros',
		idProperty: 'id',
		fields: [
			{name: 'id', type: 'int'},
			{name: 'nombre'},
		],
		proxy: new Ext.data.HttpProxy({
			url: 'crearCartera/guardarCarterasFuncionariosJson',
			method: 'GET'
		}),
		listeners: {
			'load' : function (st,rec,obj){
				if(rec.length>0){					
					if(rec[0].data.id==1){
						busquedaStore.load({params:{inicio:0, limite:30,tipo:'normal'}});
						Ext.MessageBox.alert("Cambio de Cartera","El cambio de cartera ha sido exitoso");
						obtenerNombreCartera();
					}					
				}
			}
		}
	});
	var parametros = {params: {id_cartera:registro.data.id,bbddMain:1}};
	jsonGuardarCarteraUsuario.load(parametros);
	//window.location.reload();
}
toolbar.add(
	new Ext.form.ComboBox({
		typeAhead: true,
		triggerAction: 'all',
		lazyRender:true,
		mode: 'local',
		minListWidth:'100%',
		minWidth:'100%',
		store: comboCarterasJSON,
		valueField: 'id',
		displayField: 'nombre',
		listeners: {
			'select': cambiarCarteraFunction
		}
	})
);


var panelSuperior = new Ext.Panel({
	layout		: {
		type	: 'vbox',
		align	:'stretch'
	},
	items: [
		head,toolbar
	],
	height:58,
	region: 'north'
});

var panelInferior = new Ext.BoxComponent({
	height		: 20,
	region		: 'south',
	autoEl		: {
		tag: 'div',
		html: '<div class="text" align="center">Copyright 2009 &copy; Grupo Consultor </div>'
	},
	id			: 'footer'
});
