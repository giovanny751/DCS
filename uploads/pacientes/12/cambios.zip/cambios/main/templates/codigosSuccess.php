var from=0;
var accion = 0;
var TreeCodigos = Ext.tree; 
var treeCodigos = new TreeCodigos.TreePanel({
		useArrows: true,
        autoScroll: true,
        animate: true,
		id: 'arbolito',
		region: 'west',
        enableDD: true,
		collapseMode :'mini',
        containerScroll: true,
        border: false,
		split: true,
		NodoCopy: from,
		accionEnviar: accion,
		width: 320,
        // auto create TreeLoader
        dataUrl: 'codigosEquivalentesNuevo/jsonTree',
		listeners: {
					render: function (g){
						//g.expandAll();
					},
                    beforecollapsenode : function(nodo,profundidad,animado) {
                        nodo.loaded=false;
                    },click: function(n) {
						var idnodo='';
						var datos=n.attributes.id.split('_');
						var opcion=datos[0];
						var enti=datos[1];
						var cod=datos[2];
						if(opcion=='e1')
							{
							idnodo=cod;
							var modulo = 'codigosEquivalentesNuevo/EditarCrear?id=';
							}
						else if(opcion=='e2')
							{
							idnodo=cod;
							var modulo = 'codigosEquivalentesNuevo/EditarCrear?id=';
							}
						else if(opcion=='e3')
							{
							idnodo=cod;
							var modulo = 'codigosEquivalentesNuevo/EditarCrear?id=';
							}
						else if(opcion=='ent')
							{
							idnodo=enti;
							var modulo = 'codigosEquivalentesNuevo/CrearHijo?id=';
							}

						else if(opcion=='acc')
							{
							idnodo=enti;
							var modulo = 'codigosEquivalentesNuevo/CrearHijo?id=';
							}
						else if(opcion=='res')
							{
							idnodo=enti;
							var modulo = 'codigosEquivalentesNuevo/CrearResultado?id=';
							}
						else{
						idnodo='';
						var modulo= '';						
						}
						panelEdicionCodigos.remove('panel-central-pp-cod');
						
						var frameProcesos = new Ext.ux.IFrameComponent({
										url: modulo+idnodo, 
										id: 'panel-central-pp-cod',
										width: '100%',
										height: '95%',
										region: 'center'
						});
						panelEdicionCodigos.add(frameProcesos);
						panelEdicionCodigos.doLayout();
					},
					
					contextmenu: function(node, e) {
	
						node.select();
						var c = node.getOwnerTree().contextMenu;
						c.contextNode = node;
						c.showAt(e.getXY());
					}
			
        },
		contextMenu: new Ext.menu.Menu({
			items: [
				{
					id: 'copy-node',
					text: 'Copiar Accion',
					icon: '../js/resources/images/default/tree/copy.gif'
				},
				{
					id: 'cut-node',
					text: 'Cortar Accion',
					icon: '../js/resources/images/default/tree/Cut.gif'
				},
				{
					id: 'paste-node',
					text: 'Pegar Accion',
					icon: '../js/resources/images/default/tree/paste.gif'
				},
				{
					id: 'delete-node',
					text: 'Eliminar Accion',
					icon: '../js/resources/images/default/tree/remove.png'
				}
			],
			listeners: {
				itemclick: function(item) {
					switch (item.id) {
						case 'delete-node':
							Ext.MessageBox.confirm('Precaucion','Esta a punto de eliminar el nodo o el grupo, Esta seguro?',function(btn,text){
	if(btn=='yes'){
var n = item.parentMenu.contextNode;
								n.ownerTree.accionEnviar = 'delete';
								padre = n.parentNode;
								var conn = new Ext.data.Connection();
								conn.request({
									url: 'codigosEquivalentesNuevo/editarAcciones',
									params: {
										accion: n.ownerTree.accionEnviar,
										id_to: n.id
										
									},
									success: function(respuesta){
										if(respuesta.responseText==3){
											padre.collapse();
											padre.collapse(); 
											alert('Nodos Eliminados');
										}
										//collapse collapse	
									},
									failure: function(respuesta){
										alert("No se puedo Eliminar el nodo, intente nuevamente");
									}
								});
	}
});

						
							break;
							
						case 'copy-node':
							var n = item.parentMenu.contextNode;
								n.ownerTree.NodoCopy = n;
								n.ownerTree.accionEnviar = 'copy';
							break;
							
						case 'paste-node':
							var n = item.parentMenu.contextNode;
							
							var conn = new Ext.data.Connection();
							conn.request({
								url: 'codigosEquivalentesNuevo/editarAcciones',
								params: {
									accion: n.ownerTree.accionEnviar,
									id_from: n.ownerTree.NodoCopy.id,
									id_to: n.id
								},
								success: function(respuesta){
									if(respuesta.responseText==1){
										// cut/paste
										
										 n.ownerTree.NodoCopy.parentNode.collapse();
										 n.parentNode.collapse(); 
										 n.parentNode.expand(true); 

									}else if (respuesta.responseText==2){
										// copy/paste
										n.parentNode.loaded=false;
										n.parentNode.collapse(); 
										n.parentNode.expand(true); 
									}
								},
								failure: function(respuesta){
									alert("No se realizo la accion, intente nuevamente");
								}
							});
							break;
							
						case 'cut-node':
							var n = item.parentMenu.contextNode;
							n.ownerTree.NodoCopy = n;
							n.ownerTree.accionEnviar = 'cut';
					}
				}
			}
		}),
		        root: {
            nodeType: 'async',
            text: 'Entidades',
            draggable: false,
            id: 'src'
        }

});
var panelVacio = new Ext.Panel({
	id: 'panel-central-pp',
	region: 'center'
});
var panelEdicionCodigos = new Ext.Panel({
	region: 'center',	
	split: true,
	collapseMode :'mini',
	width: 250,
	id: 'tab-panel-edcodigos',
	enableTabScroll : true,
	activeTab:0,
	frame: true,
	item: [
		panelVacio
	]
});
var panelCodigos = new Ext.Panel({
	title: 'Codigos Equivalentes',
	layout:'border',
	items:[
		treeCodigos,
		panelEdicionCodigos
	]
});

