



/*STORE*/

var indicadoresGestionStore = new Ext.data.JsonStore({
	root: 'datos',	
	idProperty: 'id',
    fields: [
	   {name: 'id', type: 'int'},
	   {name: 'jefe', type: 'int'},
	   {name: 'id_actual', type: 'int'},
       {name: 'nombre'},	   
	   {name: 'codigo_asesor'},	
       {name: 'asignado',type: 'int'},
       {name: 'llamadas_entrantes',type: 'int'},
	   {name: 'llamadas_salientes',type: 'int'},
       {name: 'porcentaje',type: 'int'},
	   {name: 'recaudado',type: 'int'},
       {name: 'valor_porcentaje'},
       {name: 'id_funcionario',type: 'int'}
    ],
	//data:myData,
	//url:"data.php",
	proxy: new Ext.data.HttpProxy({
		url: 'frontPagos/jsonIndicadores2',
		method: 'GET'
	})
	
	
});

var valorPorcentajeIndicadores=0;
var porcentajeIndicadores=0;
var asignadoIndicadores=0;
var recuperadoIndicadores=0;
var calledBackIndicadores = false; 
indicadoresGestionStore.valorPorcentajeIndicadores=0
/*
indicadoresGestionStore.load({
		callback: function(st,op,su){
			var asignado = 0;
			var recuperado = 0;
			var porcentaje = 0;
			var valor_porcentaje=0;
			if(su){
				for(var i=0;i < st.length;i++){
					var rec=st[i];
					asignado+=rec.get("asignado");
					recuperado+=rec.get("recaudado");
					porcentaje+=rec.get("porcentaje");
				}
			}
			
			if(asignado!=0){
				valor_porcentaje = Math.round((recuperado/asignado)*10000)/100;
			}
			indicadoresGestionStore.valorPorcentajeIndicadores=valor_porcentaje;
			indicadoresGestionStore.porcentajeIndicadores=porcentaje;
			indicadoresGestionStore.asignadoIndicadores=asignado;
			indicadoresGestionStore.recuperadoIndicadores=recuperado;
			//alert(asignado +" "+ recuperado+" "+porcentaje+" "+valor_porcentaje);
			calledBackIndicadores=true;
		} 
	});
	//while(!calledBackIndicadores){}
*/


/*TOTALES*/

function getValorPorcentajeIndicadores(valor){
	alert(valor);
	return valor;
}




/*PANEL PRINCIPAL*/
var idViejo=new Array();
var idActual=0;
var rendererIrAIndicador = function (elemento) {	
	idActual =indicadoresGestionStore.getAt(0).data.id_actual;	
	if(idActual!=elemento){		
		return "<input type=\"button\" value=\"Ver\" onclick=\"actualizarStoreIndicadores("+elemento+",1)\" />";
	}else{
		return "<input type=\"button\" value=\"Ver\" disabled />";
	}
}

var nivelIndicadores = 0;

function actualizarStoreIndicadores(elemento,nivel){
	if(nivel>0){
		idViejo.push(idActual);
	}else{
		idViejo.pop();
	}
	
	indicadoresGestionStore.load({
		params:{
			id:elemento
		},
		callback: function(st,op,su){
			//alert(elemento);
			var asignado = 0;
			var recuperado = 0;
			var porcentaje = 0;
			var valor_porcentaje=0;
			nivelIndicadores = nivelIndicadores + nivel;
			//ESTE BLOQUE VA COMENTADO
			/*
			if(su){
				for(var i=0;i < st.length;i++){
					var rec=st[i];
					asignado+=rec.get("asignado");
					recuperado+=rec.get("recaudado");
					porcentaje+=rec.get("porcentaje");
				}
			}
			*/
			// FIN DE BLOQUE
			
			asignado=indicadoresGestionStore.sum("asignado");
			recuperado=indicadoresGestionStore.sum("recaudado");
			porcentaje=indicadoresGestionStore.sum("porcentaje");
			
			if(asignado!=0){
				valor_porcentaje = Math.round((recuperado/asignado)*10000)/100;
			}
			indicadoresGestionStore.valorPorcentajeIndicadores=valor_porcentaje;
			indicadoresGestionStore.porcentajeIndicadores=porcentaje;
			indicadoresGestionStore.asignadoIndicadores=asignado;
			indicadoresGestionStore.recuperadoIndicadores=recuperado;
			var panelIndicadores = Ext.getCmp("panel-indicadores-gestion");
			panelIndicadores.remove('indicadores-gestion-field');
		//	panelIndicadores.remove(idGraficaIndicadores);
			var botonRegresar = "";
			if(nivelIndicadores>0){
				botonRegresar='<input type="button" value="Regresar" onclick="actualizarStoreIndicadores('+idViejo[idViejo.length-1]+',-1)" />';
			}else{
				botonRegresar='<input type="button" value="Regresar" disabled />';
			}
			var indicadoresGestionField= new Ext.form.FieldSet({
				margins: '5 5 5 5',
				frame: true,
				id:'indicadores-gestion-field',
				bbar: new Ext.ux.StatusBar({
			    	statusAlign: 'right',
			        items: [
						'<b>Capital Asignado </b>&nbsp;'+Ext.util.Format.usMoney(indicadoresGestionStore.asignadoIndicadores),			 
						'-',
						'<b>Promesas Realizadas </b>&nbsp;'+Ext.util.Format.usMoney(indicadoresGestionStore.recuperadoIndicadores),
						'-',
						'<b>Porcentaje </b>&nbsp;'+Ext.util.Format.usMoney(indicadoresGestionStore.porcentajeIndicadores),
						'-', 
						'<b>% Recuperaci&oacute;n </b>&nbsp;'+indicadoresGestionStore.valorPorcentajeIndicadores+"%",
						'-',
						botonRegresar,
					]
			
				})
			});
			panelIndicadores.add(indicadoresGestionField);
		//	panelIndicadores.add(graficaIndicadores);
			panelIndicadores.doLayout();
		}
	})

	}

var graficaIndicadores;
var idGraficaIndicadores;
var IndicadoresGestionHandler = function(button, event){
//	panelIndicadores.remove("gridIndicadoresGestion");
//	panelIndicadores.remove("indicadores-gestion-charts");
	/*GRILLA*/
	var indicadoresGestionGrid = new Ext.grid.GridPanel({
		id: 'gridIndicadoresGestion',
		store: indicadoresGestionStore,
		title: 'Indicadores de gesti&oacute;n',
		autoExpandColumn : 'nombre',
		columns: [										  
			{id:'id', header: "No. Asesor", sortable: true, dataIndex: 'id'},
			{header: "Nombre",id: 'nombre',  sortable: true, anchor: '100', dataIndex: 'nombre', align: 'right'},
			{header: "Capital Asignado", width: 140, sortable: true, dataIndex: 'asignado',align:'right',renderer: 'usMoney'},
			{header: "Valor Promesas", width: 160, sortable: true, dataIndex: 'recaudado',align:'right',renderer: 'usMoney'},
			{header: "Llamadas Salientes", width: 50, sortable: true, dataIndex: 'llamadas_salientes',align:'right'},
			{header: "Llamadas Entrantes", width: 50, sortable: true, dataIndex: 'llamadas_entrantes',align:'right'},			
			{header: "%", sortable: true, width: 20, dataIndex: 'valor_porcentaje',align:'right'},
			{header: " - ", sortable: true, width: 40, dataIndex: 'id',align:'right',renderer:rendererIrAIndicador}				
		],
		flex:4,
		frame:true
	
	});
		
	/*GRAFICA*/
	idGraficaIndicadores = 'indicadores-gestion-charts'+Math.random();
	var indicadoresGestionChart = new Ext.Panel({
		flex:4,
		iconCls:'chart',
		id: idGraficaIndicadores,
		items: {
			xtype: 'columnchart',
			store: indicadoresGestionStore,
			url:'../js/resources/charts.swf',
			xField: 'codigo_asesor',
			wmode: 'transparent',
			yAxis: new Ext.chart.NumericAxis({
	                displayName: 'Capital',
	                labelRenderer : Ext.util.Format.numberRenderer('0,0')
	        }),
	        listeners: {
	            itemclick:function(evtObj){
	                actualizarStoreIndicadores(evtObj.item.id,1);
	            }
	        },
	        series: [
	        	{
	                type: 'column',
	                displayName: 'Capital Asignado',
	                yField: 'asignado',
	                style: {
	                   // image:'bar.gif',
	                    mode: 'stretch',
	                    color:0x008888,
	                    width: 100,
	                    size:30,
	                    border:'5px'
	                }
	            },
	            {
	                type: 'column',
	                displayName: 'Promesas Realizadas',
	                yField: 'recaudado',
	                style: {
	                   // image:'bar.gif',
	                    mode: 'stretch',
	                    color:0x880088,
	                    width: 100,
	                    size:30,
	                    border:'5px'
	                }
	            },
	            {
	                type: 'column',
	                displayName: 'Porcentaje',
	                yField: 'porcentaje',
	                style: {
	                   // image:'bar.gif',
	                    mode: 'stretch',
	                    color:0x888800,
	                    width: 100,
	                    size:30,
	                    border:'5px'
	                }
	            }
	        ]		
		}
	});
	graficaIndicadores = indicadoresGestionChart;
	
	var indicadoresGestionField= new Ext.form.FieldSet({
				margins: '5 5 5 5',
				frame: true,
				id:'indicadores-gestion-field',
				bbar: new Ext.ux.StatusBar({
			    	statusAlign: 'right',
			        items: [
						'<b>Capital Asignado </b>&nbsp;'+Ext.util.Format.usMoney(indicadoresGestionStore.asignadoIndicadores),			 
						'-',
						'<b>Promesas Realizadas </b>&nbsp;'+Ext.util.Format.usMoney(indicadoresGestionStore.recuperadoIndicadores),
						'-',
						'<b>Porcentaje </b>&nbsp;'+Ext.util.Format.usMoney(indicadoresGestionStore.porcentajeIndicadores),
						'-', 
						'<b>% Recuperaci&oacute;n </b>&nbsp;'+indicadoresGestionStore.valorPorcentajeIndicadores+"%",
						'-',
					]
			
				})
		});
	
	
	panelPrincipal.remove("panel-indicadores-gestion");
	
	var panelIndicadores=new Ext.Panel({
		id:'panel-indicadores-gestion',
		title:'Indicadores Gestion',
		layout: {
	    	type:'vbox',
			padding:'5',
			align:'stretch'
		},
		closable: true,
		frame:true,
		defaults:{margins:'5 5 5 5'},
		items:[
			indicadoresGestionGrid,
			indicadoresGestionChart,
			indicadoresGestionField,
		]
	});

	//panelIndicadores.add(indicadoresGestionChart);
	panelPrincipal.add(panelIndicadores).show();     
	panelPrincipal.doLayout();
}
