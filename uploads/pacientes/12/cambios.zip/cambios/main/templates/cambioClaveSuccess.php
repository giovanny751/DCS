Ext.getVCambiarClave = function(){
	var cambiarclave=function(button,event){ 
		 Ext.Ajax.request({
			url : 'main/EjCambioClave' , 
			params : { clave_ant : Ext.getCmp('fldc_clave').getValue(), clave_new : Ext.getCmp('fldc_new_clave').getValue() , clave_conf : Ext.getCmp('fldc_conf_clave').getValue() },
			method: 'POST',
			success: function ( result, request ) { 
				if(result.responseText=='0'){
				Ext.MessageBox.alert('Success','Cambio de Clave Realizado Correctamente'); 
				Ext.getCmp('ventana-cambio').destroy();
				}
				if(result.responseText=='1')
				{
				Ext.MessageBox.alert('Failed','clave anterior no valida, por favor revisar.');
				}
				if(result.responseText=='2')
				{
				Ext.MessageBox.alert('Failed','claves no concuerdan, por favor revisar.');
				}
				if(result.responseText=='3')
				{
				Ext.MessageBox.alert('Failed','la clave debe tener minimo 6 caracteres, por favor revisar.');
				}
				if(result.responseText=='4')
				{
				Ext.MessageBox.alert('Failed','la clave debe tener nùmeros y letras, por favor revisar.');
				}
	

			},
			failure: function ( result, request) { 
				Ext.MessageBox.alert('Failed','Fall&oacute cambio de clave'); 
			} 
		});
		}

		var formularioCambio = new Ext.form.FormPanel({
			//title: 'Cambio de Clave',
			id:'form-cambio',
			height: 200,
			frame: true,
			layout: 'column',
			items:[{
				columnWidth: 0.99,
				xtype: 'fieldset',
				defaultType: 'textfield',
				border: false,
				autoHeight: true,
				bodyStyle: Ext.isIE ? 'padding:0 0 5px 15px;' : 'padding:10px 15px;',		
				style: {
					"margin-left": "1px", // when you add custom margin in IE 6...
					"margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
				},
				items:[{
					text: 'Recuerde cambiar periodicamente su clave.',
					xtype: 'label'
			
				},{
					fieldLabel: '<b>Contraseña Actual</b>',
					name: 'clave_ant',
					width: 100,
					inputType: 'password',
					allowBlank: false,
					id: 'fldc_clave'
			
				},{
					fieldLabel: '<b>Nueva Contraseña</b>',
					name: 'clave_new',
					width: 100,
					inputType: 'password',
 					allowBlank: false,
					id: 'fldc_new_clave'
			
				},{
					fieldLabel: '<b>Confirmar Nueva Contraseña</b>',
					name: 'conf_clave',
					width: 100,
					inputType: 'password',
					 allowBlank: false,
					id: 'fldc_conf_clave'
			
				},				
				new Ext.Panel({
					layout:'column',
					items:[
						{
							columnWidth:0.77,
							items:[
								new Ext.Button({					
									text: 'Cambiar Clave',
									style: {
									"margin-bottom": "5px"
									},
									handler: cambiarclave
								})
							]
						},
						{
							columnWidth:0.22,
							items:[
								new Ext.Button({
									text:'Limpiar',
									handler:function(){
								
										formularioCambio.getForm().reset();
									}
								})
							]
						}
					]
				})
				]
			}],
			keys:[{key:[10,13],handler:cambiarclave}]
		});
	return new Ext.Window({
		renderTo: document.body,
		width: 350,
		height: 230,
		id: 'ventana-cambio',
		title: 'Cambio de Clave',
		closable: false,	
		modal: true,
		closeAction: 'hide',
		resizable: false,
		minWidth: 500,
		minHeight: 350,
		maximized: false,
		constrain: true	,
		layout:{
			type:'vbox',
			align: 'stretch'
		},
		items:[
			formularioCambio
			]

	});
}


var vCambiarClave = Ext.getVCambiarClave();
