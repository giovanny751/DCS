/*var scrollerMenu = new Ext.ux.TabScrollerMenu({
	maxText  : 15,
	pageSize : 5
});*/

Ext.ux.IFrameComponent = Ext.extend(Ext.BoxComponent, {
     onRender : function(ct, position){
          this.el = ct.createChild({tag: 'iframe', id: 'iframe-'+ this.id, frameBorder: 0, src: this.url});
     }
});


/////////////////////////
/*
Crear un Ext.data.JsonStore
*/
////////////////////

/*
var registro;
var parametros = {params:{inicio:0, limite:20}};
var datosStore = new Ext.data.JsonStore({
	root: 'registros',
	totalProperty: 'cant',
	idProperty: 'id',
	fields: [
	   	{name: 'id', type: 'int'},
		{name: 'estado'},
		{name: 'tipo_tiquete'},		   
		{name: 'id_tipo_tiquete'},		   
		{name: 'area_negocio'},	
		{name: 'id_area_negocio'},		   	   
		{name: 'estacion'},	
		{name: 'id_estacion'},		   	   
		{name: 'fecha_cierre'},
		{name: 'fecha_programada'},
		{name: 'id_inventario'},
		{name: 'inventario'},
	],
	proxy: new Ext.data.HttpProxy({
		url: 'index.php/tiquetes/mostrarJSON',
		method: 'GET',
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	}
});

datosStore.load(parametros);

function estados(val){
	if(val == "0"){
		return '<span style="color:green;">Cerrado</span>';
	}else if(val=="1"){
		return '<span style="color:blue;">Abierto</span>';
	}else{
		return '<span style="color:red;">Abierto</span>';
	}
}

function abrirDetalle(val){
	var tab = new Ext.Panel({
		id: 'ver-ticket-'+val,
		title: 'Detalle Ticket #'+val,
		closable:true,
		// layout to fit child component
		layout:'fit', 
		// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'ver-ticket-'+val, url: 'index.php/tiquetes/detalle/id/'+val, }) ]
	});
		panelPrincipal.add(tab).show();
}

function abrirHistorial(val){
	var tab = new Ext.Panel({
		id: 'ver-historial-'+val,
		title: 'Historial Ticket #'+val,
		closable:true,
		// layout to fit child component
		layout:'fit', 
		// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'ver-historial-'+val, url: 'index.php/programaciones/historico/id/'+val, }) ]
	});
		panelPrincipal.add(tab).show();
}

var arregloImpresion = new Array();

function imprimirArreglo(){
	var tiquetes="";
	var i=0;
	for(tiquete in arregloImpresion){
		if(tiquete!='remove' && arregloImpresion[tiquete]!=""){
			if(i>0) tiquetes=tiquetes+",";
			tiquetes=tiquetes+arregloImpresion[tiquete];
			i=i+1;
		}
	}
	var tab = new Ext.Panel({
		id: 'imprimir',
		title: 'Imprimir',
		closable:true,
		// layout to fit child component
		layout:'fit', 
		// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'imprimir', url: 'index.php/tiquetes/imprimir/id/'+tiquetes, }) ]
	});
		panelPrincipal.add(tab).show();
}

function agregarImpresion(val,elem){
	var bandera=true;
	for (tiquete in arregloImpresion) {
	    if (tiquete != 'remove') {
		if(tiquete==val){
			arregloImpresion[tiquete]="";
			bandera=false;
		}
	    }
	}
	if(bandera){
		arregloImpresion[val]=val;	
	}
}

function verdetalle(val){
	return '<a title="Ver detalle de ticket" href="javascript:abrirDetalle('+val+')"><img alt="Ver detalle de ticket" src="images/leaf.gif" /></a>';
}

function verhistorial(val){
	return '<a title="Ver reprogramaciones" href="javascript:abrirHistorial('+val+')"><img alt="Ver reprogramaciones" src="images/calendar.gif" /></a>';
}

function imprimir(val){
	var checked="";
	for (tiquete in arregloImpresion) {
	    if (tiquete != 'remove') {
		if(tiquete==val){
			checked="checked";
		}
	    }
	}
	return '<input '+checked+' type="checkbox" value="'+val+'" name="imprimir" id="imprimir_"'+val+' onclick="agregarImpresion('+val+',this) " >';
}


var tiquetesGrid = new Ext.grid.GridPanel({
	id: 'grid-tiquetes',
	store: datosStore,	
	flex: 2,
	columns: [						  
		{id:'id', header: "Id", width: 50, sortable: true, dataIndex: 'id'},
		{header: "Tipo", width: 120, sortable: true, dataIndex: 'tipo_tiquete'},
		{header: "&Aacute;rea de negocio", width: 100, sortable: true, dataIndex: 'area_negocio'},
		{header: "Estaci&oacute;n", width: 120, sortable: true, dataIndex: 'estacion'},		
		{header: "Fecha Cierre", width: 90, sortable: true, dataIndex: 'fecha_cierre'},
		{header: "Fecha Programada", width: 120, sortable: true, dataIndex: 'fecha_programada'},
		{header: "Estado", width: 60, sortable: true, dataIndex: 'estado', renderer:estados },
		{header: "Inventario", width: 120, sortable: true, dataIndex: 'inventario' },
		{header: "", width: 30, sortable: true, dataIndex: 'id', renderer:verdetalle },
		{header: "", width: 30, sortable: true, dataIndex: 'id', renderer:verhistorial },
		{header: "Imprimir", width: 50, align:'center',sortable: true, dataIndex: 'id', renderer:imprimir },
	],
	listeners: {
                    render: function(g) {
                        g.getSelectionModel().selectRow(0);
                    },
                    delay: 10 // Allow rows to be rendered.
                },
	sm: new Ext.grid.RowSelectionModel({
                    singleSelect: true,
                    listeners: {
                        rowselect: function(sm, row, rec) {
			    rec.data.fecha_programada_inicio=rec.data.fecha_programada;
			    rec.data.fecha_programada_fin=rec.data.fecha_programada;
                            Ext.getCmp("formulario-tiquete").getForm().loadRecord(rec);
				//alert(rec.data.id);
			    registro=rec;
                        }
                    }
        }),
	bbar: new Ext.PagingToolbar({
			pageSize: 20,
			store: datosStore,
			displayInfo: true,
			displayMsg: 'Mostrando registros {0} - {1} de {2}',
			emptyMsg: "No hay registros para mostrar"							
	}),
});


*/

var panelPrincipal = new Ext.TabPanel({
	region: 'center',	
	split: true,
	collapseMode :'mini',
	width: 250,
	id: 'tab-panel',
	enableTabScroll : true,
	activeTab:0,
	frame: true,
        style: {
            "margin-left": "10px", // when you add custom margin in IE 6...
            "margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
        }
});

/*
var buscarHandler = function(button,event) {
	
	
	var fldEstado=Ext.getCmp("fld_estado");	
	
	if(fldEstado.getValue()!=""){
		parametros.params.estado=fldEstado.getValue();
	}else{
		parametros.params.estado=null
	}

	var fldEstacion=Ext.getCmp("fld_estacion");	

	if(fldEstacion.getValue()!=""){
		parametros.params.id_estacion=fldEstacion.getValue();
	}else{
		parametros.params.id_estacion=null
	}

	var fldId=Ext.getCmp("fld_id");	

	if(fldId.getValue()!=""){
		parametros.params.id=fldId.getValue();
	}else{
		parametros.params.id=null
	}

	var fldFechaInicio=Ext.getCmp("fld_fecha_programada_inicio");	
	//alert(fldFechaInicio.getValue()=="");

	if(fldFechaInicio.getValue()!=""){
		parametros.params.fecha_programada_inicio=fldFechaInicio.getValue().format('Y-m-d');
	}else{
		parametros.params.fecha_programada_inicio=null
	}

	var fldFechaFin=Ext.getCmp("fld_fecha_programada_fin");	
	if(fldFechaFin.getValue()!=""){
		parametros.params.fecha_programada_fin=fldFechaFin.getValue().format('Y-m-d');
	}else{
		parametros.params.fecha_programada_fin=null
	}

	datosStore.load(parametros);
	datosStore.reload();
 };
*/
 
/*
var editarHandler = function(button,event) {
	var fldId=Ext.getCmp("fld_id");	

	if(fldId.getValue()!=""){
		parametros.params.id=fldId.getValue();
		var tab = new Ext.Panel({
			id: 'editar-ticket-tab-'+fldId.getValue(),
			title: 'Editar Ticket #'+fldId.getValue(),
			closable:true,
			// layout to fit child component
			layout:'fit', 
			// add iframe as the child component
			items: [ new Ext.ux.IFrameComponent({ id: 'editar-ticket-tab-'+fldId.getValue(), url: 'index.php/tiquetes/tiquete/id/'+fldId.getValue(), }) ]
		});
		panelPrincipal.add(tab).show();
		
	}
}

var reportarHandler = function(button,event) {
	var fldId=Ext.getCmp("fld_id");	

	if(fldId.getValue()!=""){
		parametros.params.id=fldId.getValue();		
		var fldEstacion=Ext.getCmp("fld_estacion");
		var fldIdInventario=Ext.getCmp("fld_id_inventario");
		if(fldEstacion.getValue()!=""){
			var tab = new Ext.Panel({
				id: 'registrar-ticket-tab-'+fldId.getValue()+"-"+fldEstacion.getValue(),
				title: 'Registrar Visita',
				closable:true,
				// layout to fit child component
				layout:'fit', 
				// add iframe as the child component
				items: [ new Ext.ux.IFrameComponent({ id: 'registrar-ticket-tab-'+fldId.getValue()+"-"+fldEstacion.getValue(), url: 'index.php/visitastiquete/new/id_tiq/'+fldId.getValue()+'/id_est/'+fldEstacion.getValue()+'/id_inv/'+fldIdInventario.getValue(), }) ]
			});
			panelPrincipal.add(tab).show();
		}
	}
}*/
/*
var formulario = new Ext.form.FormPanel({
	title: 'Ticket',
	id:'formulario-tiquete',
	frame: true,
	height: '200px',
	labelAlign: 'left',
	bodyStyle:'padding:5px',
	layout: 'column',
	items:[{
		columnWidth: 0.33,
		xtype: 'fieldset',
            	labelWidth: 120,
		defaults: {width: 140, border:false},    // Default config options for child items
		defaultType: 'textfield',
		autoHeight: true,
		bodyStyle: Ext.isIE ? 'padding:0 0 5px 15px;' : 'padding:10px 15px;',
		border: false,
		style: {
			"margin-left": "10px", // when you add custom margin in IE 6...
			"margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
		},
		items:[{
			fieldLabel: '<b>Id</b>',
			name: 'id',
			width: 80,
			id: 'fld_id'
		},
		{
			fieldLabel: '<b>Estaci&oacute;n</b>',
			name: 'id_estacion',
			id: 'fld_estacion'
		},
		{
			fieldLabel: '<b>Estado</b>',
			name: 'estado',
			id: 'fld_estado'
		},
		new Ext.form.Hidden({
			name: 'id_inventario',
			id: 'fld_id_inventario',
		})
		]
	},
	{
		columnWidth: 0.33,
		xtype: 'fieldset',
            	labelWidth: 120,
		defaults: {width: 140, border:false},    // Default config options for child items
		defaultType: 'textfield',
		autoHeight: true,
		bodyStyle: Ext.isIE ? 'padding:0 0 5px 15px;' : 'padding:10px 15px;',
		border: false,
		style: {
			"margin-left": "10px", // when you add custom margin in IE 6...
			"margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
		},
		items:[{
			fieldLabel: '<b>Fecha Programada Inicio</b>',
			name: 'fecha_programada_inicio',
			xtype: 'datefield',
			format: 'Y-m-d',
			id: 'fld_fecha_programada_inicio'
		},
		{
			fieldLabel: '<b>Fecha Programada F&iacute;n</b>',
			name: 'fecha_programada_fin',
			xtype: 'datefield',
			format: 'Y-m-d',
			id: 'fld_fecha_programada_fin'
		},	
		]
	}
,
	{
		columnWidth: 0.17,
		xtype: 'fieldset',
            	labelWidth: 120,
		defaults: {width: 100, border:false},    // Default config options for child items
		defaultType: 'textfield',
		autoHeight: true,
		bodyStyle: Ext.isIE ? 'padding:15px 15px 5px 15px;' : 'padding:10px 15px;',
		border: false,
		style: {
			"margin-left": "10px", // when you add custom margin in IE 6...
			"margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
		},
		items:[new Ext.Button({
			text: 'Buscar',
			style: {
			"margin-bottom": "5px",
			},
			handler: buscarHandler
		}),
		new Ext.Button({
			text: 'Editar',
			style: {
			"margin-bottom": "5px",
			},
			handler: editarHandler,
		})
		]
	},
	{
		columnWidth: 0.17,
		xtype: 'fieldset',
            	labelWidth: 120,
		defaults: {width: 100, border:false},    // Default config options for child items
		defaultType: 'textfield',
		autoHeight: true,
		bodyStyle: Ext.isIE ? 'padding:15px 15px 5px 15px;' : 'padding:10px 15px;',
		border: false,
		style: {
			"margin-left": "10px", // when you add custom margin in IE 6...
			"margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
		},
		items:[
		new Ext.Button({
			text: 'Reportar Visita',
			style: {
			"margin-bottom": "5px",
			},
			handler: reportarHandler
		}),	
		new Ext.Button({
			text: 'Imprimir',
			style: {
			"margin-bottom": "5px",
			},
			handler: imprimirArreglo
		})
		]
	}
	]
});
*/
/*
formulario.addButton('Load', function(){
	formulario.getForm().load({url:'data.php', waitMsg:'Loading'});
});

*/
/*
var panelTiquetes = new Ext.Panel({
	title: 'Tickets',
	layout:{
		type:'vbox',
		align:'stretch'
	},
	items:[
		tiquetesGrid,
		formulario
	]
});
*/
/*
function crearTab(n){
	var tab = new Ext.Panel({
	id: n.attributes.id,
	title: n.attributes.text,
	closable:true,
	// layout to fit child component
	layout:'fit', 
	// add iframe as the child component
	items: [ new Ext.ux.IFrameComponent({ id: n.attributes.id, url: n.attributes.url, }) ]
	});
     	if(!n.attributes.local){
		panelPrincipal.add(tab).show();
	}else{
		panelPrincipal.add(panelTiquetes).show();
	}
}

*/



////////PRUEBAS GRILLA ///////////////////
/*!
 * Ext JS Library 3.0.0
 * Copyright(c) 2006-2009 Ext JS, LLC
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
/*
Ext.onReady(function(){
    Ext.QuickTips.init();

    function formatDate(value){
        return value ? value.dateFormat('M d, Y') : '';
    }
    // shorthand alias
    var fm = Ext.form;

    // custom column plugin example
    /*var checkColumn = new Ext.grid.CheckColumn({
       header: 'Indoor?',
       dataIndex: 'indoor',
       width: 55
    });

    // the column model has information about grid columns
    // dataIndex maps the column to the specific data field in
    // the data store (created below)
    var cm = new Ext.grid.ColumnModel([{
           id: 'common',
           header: 'Common Name',
           dataIndex: 'common',
           width: 220,
           // use shorthand alias defined above
           editor: new fm.TextField({
               allowBlank: false
           })
        },{
           header: 'Light',
           dataIndex: 'light',
           width: 130,
           editor: new fm.ComboBox({
               typeAhead: true,
               triggerAction: 'all',
               transform:'light',
               lazyRender: true,
               listClass: 'x-combo-list-small'
            })
        },{
           header: 'Price',
           dataIndex: 'price',
           width: 70,
           align: 'right',
           renderer: 'usMoney',
           editor: new fm.NumberField({
               allowBlank: false,
               allowNegative: false,
               maxValue: 100000
           })
        },{
           header: 'Available',
           dataIndex: 'availDate',
           width: 95,
           renderer: formatDate,
           editor: new fm.DateField({
                format: 'm/d/y',
                minValue: '01/01/06',
                disabledDays: [0, 6],
                disabledDaysText: 'Plants are not available on the weekends'
            })
        },
/*       example
    var checkColumn
    ]);

    // by default columns are sortable
    cm.defaultSortable = true;

    // create the Data Store
    var store = new Ext.data.Store({
        // load remote data using HTTP
        url: 'plants.xml',

        // specify a XmlReader (coincides with the XML format of the returned data)
        reader: new Ext.data.XmlReader(
            {
                // records will have a 'plant' tag
                record: 'plant'
            },
            // use an Array of field definition objects to implicitly create a Record constructor
            [
                // the 'name' below matches the tag name to read, except 'availDate'
                // which is mapped to the tag 'availability'
                {name: 'common', type: 'string'},
                {name: 'botanical', type: 'string'},
                {name: 'light'},
                {name: 'price', type: 'float'},             
                // dates can be automatically converted by specifying dateFormat
                {name: 'availDate', mapping: 'availability', type: 'date', dateFormat: 'm/d/Y'},
                {name: 'indoor', type: 'bool'}
            ]
        ),

        sortInfo: {field:'common', direction:'ASC'}
    });

    // create the editor grid
    var grid = new Ext.grid.EditorGridPanel({
        store: store,
        cm: cm,
        renderTo: 'editor-grid',
        width: 600,
        height: 300,
        autoExpandColumn: 'common',
        title: 'Edit Plants?',
        frame: true,
        plugins: checkColumn,
        clicksToEdit: 1,
        tbar: [{
            text: 'Add Plant',
            handler : function(){
                // access the Record constructor through the grid's store
                var Plant = grid.getStore().recordType;
                var p = new Plant({
                    common: 'New Plant 1',
                    light: 'Mostly Shade',
                    price: 0,
                    availDate: (new Date()).clearTime(),
                    indoor: false
                });
                grid.stopEditing();
                store.insert(0, p);
                grid.startEditing(0, 0);
            }
        }]
    });

    // trigger the data store load
    store.load();
});
*/
////////FIN PRUEBAS GRILLA ///////////////////

function guardar(valor, id){
	//alert(valor.checked);

var registro;
var parametros = {params:{inicio:0, limite:20}};
var guardarSalvado = new Ext.data.JsonStore({
	root: 'registros',
	totalProperty: 'cant',
	idProperty: 'id',
	fields: [
	],
	proxy: new Ext.data.HttpProxy({
		url: 'deudorCartera/guardarSalvado',
		method: 'GET'
	}),
	paramNames:{
		start: 'inicio',
		limit: 'limite'
	}
});

guardarSalvado.load({params:{inicio:0, limite:10, valor:valor.checked, id:id}});        
	
}

var id_codensa_reclamos = new Array(<?php echo $codensa_id_reclamo; ?>);
var id_codensa_honorarios = new Array(<?php echo $codensa_id_honorarios; ?>);
var id_codensa_cuotas = new Array(<?php echo $codensa_id_cuotas; ?>);
var id_codensa_al_dia = new Array(<?php echo $codensa_id_al_dia; ?>);
var id_codensa_documentos = new Array(<?php echo $codensa_id_documentos; ?>)
var id_codensa_esperas = new Array(<?php echo $codensa_id_esperas; ?>)
var codensa_documentos = <?php echo $sf_data->getRaw('codensa_documentos') ?>; 
var codensa_esperas = <?php echo $sf_data->getRaw('codensa_esperas') ?>; 
var codensa_gestion_documentos = { documento:new Array(), fecha_visita: '', motivo_visita:'', actualizado: false }
var codensa_gestion = {
	numero_reclamo : '',
	motivo: '',
	honorarios: '',
	cuota_inicial: '',
	fecha_pago: '',
	esperas: '',
	actualizado: false
};
