var gridForm = new Ext.FormPanel({
        id: 'company-form',
        frame: true,
        labelAlign: 'left',
        title: 'Company data',
        bodyStyle:'padding:5px',
        width: 750,
        layout: 'column',    // Specifies that the items will now be arranged in columns
        items: [{
            columnWidth: 0.60,
            layout: 'fit',
            items: {
                xtype: 'grid',
                ds: ds,
                cm: colModel,
                sm: new Ext.grid.RowSelectionModel({
                    singleSelect: true,
                    listeners: {
                        rowselect: function(sm, row, rec) {
                            Ext.getCmp("company-form").getForm().loadRecord(rec);
                        }
                    }
                }),
                autoExpandColumn: 'company',
                height: 350,
                title:'Company Data',
                border: true,
                listeners: {
                    render: function(g) {
                        g.getSelectionModel().selectRow(0);
                    },
                    delay: 10 // Allow rows to be rendered.
                }
            }
        },{
            columnWidth: 0.4,
            xtype: 'fieldset',
            labelWidth: 90,
            title:'Company details',
            defaults: {width: 140, border:false},    // Default config options for child items
            defaultType: 'textfield',
            autoHeight: true,
            bodyStyle: Ext.isIE ? 'padding:0 0 5px 15px;' : 'padding:10px 15px;',
            border: false,
            style: {
                "margin-left": "10px", // when you add custom margin in IE 6...
                "margin-right": Ext.isIE6 ? (Ext.isStrict ? "-10px" : "-13px") : "0"  // you have to adjust for it somewhere else
            },
            items: [{
                fieldLabel: 'Name',
                name: 'company'
            },{
                fieldLabel: 'Price',
                name: 'price'
            },{
                fieldLabel: '% Change',
                name: 'pctChange'
            },{
                xtype: 'datefield',
                fieldLabel: 'Last Updated',
                name: 'lastChange'
            }, {
                xtype: 'panel',
                layout: 'table',
                layoutConfig: {
                    columns: 4
                },
                anchor: '100%',
                defaults: {
                    border: false,
                    layout: 'form',
                    labelWidth: 15,
                    style: {
                        paddingRight: '10px'
                    }
                },

// A radio group: A setValue on any of the following 'radio' inputs using the numeric
// 'rating' field checks the radio instance which has the matching inputValue.
                items: [{
                    cellCls: 'x-form-item',
                    xtype: 'label',
                    text: 'Rating',
                       width: 98form
                }, {
                    items: {    
                        xtype: 'radio',
                        name: 'rating',
                        inputValue: '0',
                        fieldLabel: 'A'
                    }
                }, {
                    items: {
                        xtype: 'radio',
                        name: 'rating',
                        inputValue: '1',
                        fieldLabel: 'B'
                    }
                }, {
                    items: {
                        xtype: 'radio',
                        name: 'rating',
                        inputValue: '2',
                        fieldLabel: 'C'
                    }
                }]
            }]
        }],
    });
