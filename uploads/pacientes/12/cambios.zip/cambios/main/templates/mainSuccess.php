
Ext.onReady(function(){
	Ext.QuickTips.init();
	Ext.state.Manager.setProvider(new Ext.state.CookieProvider());
	
	new Ext.Viewport({
	  layout: 'border',
	  id: 'main-container',
	  renderTo: Ext.getBody(),
	  items: [
	  panelSuperior //Se incluye en el archivo lookandfeel.js
	  ,panelPrincipal //se incluye en el archivo principal.js
	  ,panelLateral //Se incluye en el archivo lateral.js
	  ,panelInferior //Se incluye en el archivo lookandfeel.js
	  ] 
	}).doLayout();
	setTimeout(function(){
        	Ext.get('loading').remove();
        	Ext.get('loading-mask').fadeOut({remove:true});
	}, 250);
	obtenerNombreCartera();
});



