var ventanaFiltrosAsignacion = function(){
	var cantFiltros=-1;
	var cartera=Ext.getCmp('comboCartera').getValue();
	var datosFuncionarioFiltros = Ext.StoreMgr.get("datos-funcionario");
	var datosColumnasInfoAdicionalFiltros = Ext.StoreMgr.get("datos-columnasInfoAdicional");
	
	Ext.eliminarDato= function (id){
			var gdFiltros=Ext.getCmp("gridpanel-filtros").getStore();
			var rcFiltros=gdFiltros.find("id",id);
			gdFiltros.removeAt(rcFiltros);
	}
	
	var arrayOtros = [
		['Igual que', '='],
		['Mayor que', '>'],
		['Menor que', '<']
	 ];
                
	var storeOtros = new Ext.data.ArrayStore({
		autoDestroy: true,
		storeId: 'store-otros',
		idProperty: 'texto',
		fields: ['texto', 'valor'],
		data: arrayOtros
	});

	
	
	var gridFiltros = new Ext.data.ArrayStore({
		fields: [
		   'id',
		   {name: 'valor', type: 'float'},			   
		   {name: 'comparacion', type: 'float'},
		   {name: 'comparacionTexto'},	
		   {name: 'campo'},
		   {name: 'campoTexto'},					   
		],
		id:'grid-filtros',					  
		storeId:'gridFiltros'
	});
	
	var nuevosCampos=function(){			
		return {
			width:390,
			bodyStyle: 'margin-right:5px;',
			autoHeight: true,
			frame:true,
			flex: 1,
			layout: 'column',					
			items: [{
				bodyStyle: 'margin-right:5px;margin-left:5px',
				columnWidth: 'auto',
				layout: 'form',
				items: new Ext.form.ComboBox({
						store: datosColumnasInfoAdicionalFiltros,
						hideLabel: true,
						valueField: 'id',
						displayField: 'name',
						typeAhead: true,
						name: 'campo',													
						width:110,
						mode: 'local',
						triggerAction: 'all',
						emptyText:'Campos...',
						selectOnFocus:true,
				})
			},{
				bodyStyle: 'margin-right:5px;',
				columnWidth: 'auto',
				layout: 'form',
				items: new Ext.form.ComboBox({
						store: storeOtros,
						hideLabel: true,
						displayField: 'texto',
						valueField: 'valor',
						typeAhead: true,
						mode: 'local',
						name: 'comparacion',
						width:110,													
						triggerAction: 'all',
						emptyText:'Comparacion...',
						selectOnFocus:true,
				})
			},{
				bodyStyle: 'margin-right:5px',
				columnWidth: 'auto',
				layout: 'form',
				items: [{
					xtype:'textfield',
					hideLabel: true,
					name: 'valor',
					anchor:'95%',
					width: 100,
				}]
			},{
				bodyStyle: 'margin-right:5px',
				columnWidth: 'auto',
				layout: 'form',
				bodyStyle: 'padding:4px',
				items:	[	
					{
						xtype: 'button',
						text: 'Agregar',
						width: 15,
						handler: function(){									
							var gdFiltros=Ext.getCmp("gridpanel-filtros").getStore();
							var fmFiltros=Ext.getCmp("formulario-filtros").getForm();
							var fieldComparacion=fmFiltros.findField("comparacion");
							var fieldValor=fmFiltros.findField("valor");
							var fieldCampo=fmFiltros.findField("campo");									
							cantFiltros++;
							var defaultData = {
								id: cantFiltros,
								valor: fieldValor.getValue(),
								comparacion: fieldComparacion.getValue(),
								comparacionTexto: fieldComparacion.lastSelectionText,
								campo: fieldCampo.getValue(),
								campoTexto:  fieldCampo.lastSelectionText,				
							};
							var r =  new gdFiltros.recordType(defaultData, cantFiltros); // create new record
							gdFiltros.insert(0, r); 
						}
					}
				]											
			}]
		}
	}
	
	var ventanaFiltros=new Ext.Window({
		width:600,
		title: 'Asignar obligaciones por filtro', 
		height:350,
		modal: true,
		items:[
				new Ext.form.FormPanel({
					url: 'prueba.php',
					id: 'formulario-filtros',
					labelAlign: 'top',
					layout:'column',
					frame:false,
					items: [
						{
							columnWidth: 0.67,
							autoHeight: true,
							title:'Filtros',
							id: 'panelFiltros', 
							layout: {
								type: 'column',
								align:'stretch'
							},
							items: [
									nuevosCampos() ,
							new Ext.grid.GridPanel({
								columns:[
									{header: 'Id',id:'id',width:20,dataIndex:'id'},
									{header: 'Campo',width:120,dataIndex:'campoTexto'},
									{header: 'Comparacion',width:110,dataIndex:'comparacionTexto'},											
									{header: 'Valor',width:110,dataIndex:'valor'},	
									{header: ' - ',id:'id',width:20,dataIndex:'id',sortable:false,renderer:function(val){
										return '<input type="button" value=" - " onclick="Ext.eliminarDato(\''+val+'\')" />';
									}},											
								],
								id:'gridpanel-filtros',
								store:gridFiltros,
								height:216,
							})
							]
						},
						{
							columnWidth: 0.33,
							height: 290,
							title:'Asesores',
							items:[
									{
										xtype: 'multiselect',
										name: 'asesores',
										frame: false,
										allowBlank:false,
										hiddenName:'id',
										valueField: 'id',
										displayField: 'name',
										hideLabel: true,
										autoHeight:true,
										width: 192,
										height:290,
										store:datosFuncionarioFiltros,
									}
							]
						}
					],
					bbar:{
						items:[
							 {
								text: 'Asignar',
								handler:function(btn,ev){
									var gdFiltros=Ext.getCmp("gridpanel-filtros").getStore();
									var fmFiltros=Ext.getCmp("formulario-filtros").getForm();
									cantDataGridFiltros=0
									var expDataGridFiltros= new Array();
									gdFiltros.data.each(function() {
										expDataGridFiltros[cantDataGridFiltros++] = this.data;
									});
									var filtrosAEnviar=Ext.encode(expDataGridFiltros); 
									var asesoresAEnviar=fmFiltros.findField("asesores").getValue();
									var connFiltros = new Ext.data.Connection();
									connFiltros.request({
										url: 'asignarCartera/asignarPorCriterios',
										method: 'POST',
										params: {"filtros": filtrosAEnviar, "asesores": asesoresAEnviar, "id_cartera": cartera},
										success: function(responseObject) {
											Ext.Msg.alert("Asignaci\xF3n de cartera por filtro",responseObject.responseText);
										},
										 failure: function() {
											 Ext.Msg.alert('Asignaci\xF3n de cartera por filtro', 'No se pudo realizar la asignaci\xF3n. Intente nuevamente.');
										 }
									});
								}
							 }
						]
					},
				})
		],
		
	});
   
   ventanaFiltros.show();

}