var comprobantesNominaHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-comprobantes-nominas',
		title: 'Mis comprobantes',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../index.php/comprobantes/MisComprobantes' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
var comprobantesFuncNominaHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-comprobantes-nominas',
		title: 'Mis comprobantes',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../index.php/comprobantes/MisComprobantesFunc' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var administrarNominaHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-administrar-nominas',
		title: 'Administrar Nominas',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var agregarFuncionariosHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-agregar-func-nominas',
		title: 'Agregar Funcionario',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/empleados/new' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var buscarNovedadesFuncHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-buscar-novedades',
		title: 'Buscar Novedades',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/novedades/buscar' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var subirNovedadesFuncHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-cargar-novedades',
		title: 'Subir Novedades Funcionario',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/novedades/subirNovedades' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var entidadesNominaHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-nomina-entidades',
		title: 'Agregar y editar entidades',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/entidades' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var gruposNominaHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-nomina-grupos',
		title: 'Agregar y editar grupos',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/grupos' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var reporteFuncHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-reporte-func',
		title: 'Parametros reporte',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/funcionarios/reporteFunc' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var reporteNomHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-reporte-nomina',
		title: 'Parametros reporte',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/nominas/reporteNom' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}

var buscarFuncionariosHandler = function (bt,ev){
	var nuevoTab = new Ext.Panel({
		id: 'tab-funcionarios-nominas',
		title: 'Buscar Funcionario',
		region:'center',
		closable: true,
	// layout to fit child component
		layout:'fit', 
	// add iframe as the child component
		items: [ new Ext.ux.IFrameComponent({ id: 'panel-plantilla', url: '../nomina.php/empleados/buscar' }) ]
	});

	panelPrincipal.add(nuevoTab).show();
}
