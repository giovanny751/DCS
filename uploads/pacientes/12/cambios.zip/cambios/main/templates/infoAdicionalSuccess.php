/*
<table class="lista">
  <thead>
    <tr>
      <th>Id</th>
      <th>Edad mora</th>
      <th>Nombres</th>
      <th>Obligacion</th>
      <th>Saldo mora</th>
      <th>Id cartera</th>
      <th>Id funcionario</th>
      <th>Opciones</th>
    </tr>
  </thead>
  <tbody>
    <?php 
	$lista = $gca_obligacion_list!=null?$gca_obligacion_list:array();
	foreach ($lista as $gca_obligacion): ?>
    <tr>
      <td><a href="<?php echo url_for('carteraAsignada/show?id='.$gca_obligacion->getId()) ?>"><?php echo $gca_obligacion->getId() ?></a></td>
      <td><?php echo $gca_obligacion->getEdadMora() ?></td>
      <td><?php echo $gca_obligacion->getNombres() ?></td>
      <td><?php echo $gca_obligacion->getObligacion() ?></td>
      <td><?php echo $gca_obligacion->getSaldoMora() ?></td>
      <td><?php echo $gca_obligacion->getIdCartera() ?></td>
      <td><?php echo $gca_obligacion->getIdFuncionario() ?></td>
      <td><a href="<?php echo url_for('carteraAsignada/reAsignar?id='.$gca_obligacion->getId()) ?>">Reasignar</a></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
*/
