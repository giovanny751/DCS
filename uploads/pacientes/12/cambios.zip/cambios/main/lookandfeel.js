/**
 * @author Carlos Andraus
 */

var head = new Ext.BoxComponent({
	height		: 30,
	autoEl		: {
		tag: 'div',
		html: '<div class="logo"><img src="logo.png" height="30" alt="logo" /></div><div class="text">Grupo Consultor Andino</div>'
	},
	id			: 'header'
});

var toolbar = new Ext.Toolbar();

toolbar.add(
	new Ext.Button({
		text: 'Cerrar',
		tooltip: 'Cierra la sesión',
		iconCls: 'salir'
	})
);

var panelSuperior = new Ext.Panel({
	layout		: {
		type	: 'vbox',
		align	:'stretch'
	},
	items: [
		head,
		toolbar
	],
	height:59,
	region: 'north'
});

var panelInferior = new Ext.BoxComponent({
	height		: 20,
	region		: 'south',
	autoEl		: {
		tag: 'div',
		html: '<div class="text">Copyright 2009 &copy; Grupo Consultor Andino</div>'
	},
	id			: 'footer'
});
