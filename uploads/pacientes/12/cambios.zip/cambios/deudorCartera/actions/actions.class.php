<?php

/**
 * deudorCartera actions.
 *
 * @package    prejuridico
 * @subpackage deudorCartera
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class deudorCarteraActions extends sfActions {

    public function executeIndex(sfWebRequest $request) {
        $this->gca_obligacion_list = Doctrine::getTable('GcaObligacion')
                ->createQuery('a')
                ->execute();
    }

    public function executeShow(sfWebRequest $request) {
        $this->gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id'));
        $this->forward404Unless($this->gca_obligacion);
    }

    public function executeNew(sfWebRequest $request) {
        $this->form = new GcaObligacionForm();
    }

    public function executeCreate(sfWebRequest $request) {
        $this->forward404Unless($request->isMethod('post'));

        $this->form = new GcaObligacionForm();

        $this->processForm($request, $this->form);

        $this->setTemplate('new');
    }

    public function executeEdit(sfWebRequest $request) {
        $this->forward404Unless($gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id')), sprintf('Object gca_obligacion does not exist (%s).', $request->getParameter('id')));
        $this->form = new GcaObligacionForm($gca_obligacion);
    }

    public function executeUpdate(sfWebRequest $request) {
        $this->forward404Unless($request->isMethod('post') || $request->isMethod('put'));
        $this->forward404Unless($gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id')), sprintf('Object gca_obligacion does not exist (%s).', $request->getParameter('id')));
        $this->form = new GcaObligacionForm($gca_obligacion);

        $this->processForm($request, $this->form);

        $this->setTemplate('edit');
    }

    public function executeDelete(sfWebRequest $request) {
        $request->checkCSRFProtection();

        $this->forward404Unless($gca_obligacion = Doctrine::getTable('GcaObligacion')->find($request->getParameter('id')), sprintf('Object gca_obligacion does not exist (%s).', $request->getParameter('id')));
        $gca_obligacion->delete();

        $this->redirect('deudorCartera/index');
    }

    public function executeDeudorJson(sfWebRequest $request) {
        $id_user = $this->getUser()->getAttribute('usuario');
        $idCartera = $this->getUser()->getAttribute('id_cartera');
        $idNumeroCartera = $idCartera;
        $idCartera = $idCartera ? 'cartera_' . $idCartera : 'default';

        $semaforoGestion = sfConfig::get('app_semaforosGestion_' . $idCartera);


        $params = $request->getGetParameters();

        if (isset($params['tipo']) && $params['tipo'] != 'inactividad') {
            if ($params['tipo'] == 'riesgo') {
                $where = "definitivo = true and nombres IS NOT NULL and id_funcionario = " . $id_user;
                $where .=" and id_cartera = " . $idNumeroCartera;
            } else {
                //$where = isset($params['id'])?$params['id']!= ''?is_numeric($params['id'])?" cedula like '".$params['id']."%'":" nombres like '%".strtoupper($params['id'])."%' ":'true':'true';
                if (isset($params['id'])) {
                    if ($params['id'] != '') {
                        if (is_numeric($params['id'])) {
                            $where = " (cedula like '" . $params['id'] . "%' OR obligacion LIKE '" . $params['id'] . "%')";
                        } else {
                            $where = " (nombres like '%" . strtoupper($params['id']) . "%' OR obligacion LIKE '%" . strtoupper($params['id']) . "%')  ";
                        }
                        if (isset($_GET["sidel"]) && $_GET["sidel"] == "12345") {
                            //var_dump($where);exit;
                        }
                    } else {
                        $where = "nombres IS NOT NULL and id_funcionario = " . $id_user;
                    }
                } else {
                    $where = "nombres IS NOT NULL and id_funcionario = " . $id_user;
                }
                $where .=" and id_cartera = " . $idNumeroCartera;
            }

            $this->gca_obligacion_list = Doctrine::getTable('GcaObligacion')
                    ->createQuery('a')
                    ->where($where)
                    ->orderBy('saldo_mora desc');
            if (isset($_GET["sidel"])) {
                echo $this->gca_obligacion_list->getSql();
                exit;
            }
            //->execute();

            $this->paginadorGcaObligacionList = new sfDoctrinePager('GcaObligacion', $request->getParameter("limite", 20));
            $this->paginadorGcaObligacionList->setQuery($this->gca_obligacion_list);
            $pagina = ceil(($request->getParameter("inicio") / $request->getParameter("limite", 20))) + 1;
            $this->paginadorGcaObligacionList->setPage($pagina);
            $this->paginadorGcaObligacionList->init();

            $arr_obligaciones = array();
            $arr_obligaciones["registros"] = array();
            $i = 0;
            foreach ($this->paginadorGcaObligacionList->getResults() as $obligacion) {
                $arr_obligaciones["registros"][$i]['nombres'] = $obligacion->getNombres();
                $arr_obligaciones["registros"][$i]['cedula'] = $obligacion->getCedula();
                $arr_obligaciones["registros"][$i]['id'] = $obligacion->getId();
                $arr_obligaciones["registros"][$i]['saldo_mora'] = $obligacion->getSaldoMora();
                $arr_obligaciones["registros"][$i]['obligacion'] = $obligacion->getObligacion();
                $arr_obligaciones["registros"][$i]['numero_expediente'] = $obligacion->getNumeroExpediente();

                $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
                $sql = "SELECT obtenerSemaforoObligacion(" . $this->getUser()->getAttribute('id_cartera') . ",'" . $obligacion->getObligacion() . "'," . $semaforoGestion["rojo"] . "," . $semaforoGestion["amarillo"] . ")";
                $semaforoArr = $doctrine->query($sql)->fetchAll();
                $arr_obligaciones["registros"][$i]['semaforo'] = $semaforoArr[0][0];


                //var_dump($arr_obligaciones["registros"][$i]['semaforo']);
                $i++;
            }
            $arr_obligaciones['cant'] = ($this->paginadorGcaObligacionList->getLastPage() + 1) * $request->getParameter("limite", 20);
            $this->json_obligacion = json_encode($arr_obligaciones);
        } else if (isset($params['tipo']) && $params['tipo'] == 'inactividad') {
            $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
            $limite = $request->getParameter("limite", 20);
            $offset = $request->getParameter("inicio", 0);
            $sql = "select count(*) as cantidad
                from gca_obligacion o
                where o.nombres IS NOT NULL AND o.id_cartera = $idNumeroCartera and o.id_funcionario = " . $id_user;
            $this->gca_obligacion_cantidad = $doctrine->query($sql)->fetchAll();
            $this->gca_obligacion_cantidad = $this->gca_obligacion_cantidad [0][0];
            $paginas = ceil($this->gca_obligacion_cantidad / $limite);
            $sql = "select o.*, g.fecha_inicio, obtenerSemaforoObligacion(" . $this->getUser()->getAttribute('id_cartera') . ",o.obligacion," . $semaforoGestion["rojo"] . "," . $semaforoGestion["amarillo"] . ") as semaforo
                from gca_obligacion o left join gca_gestion g on(o.obligacion = g.obligacion AND o.id_cartera=g.id_cartera)
                where o.nombres IS NOT NULL and o.id_funcionario = " . $id_user;
            $sql .= " order by COALESCE(g.fecha_inicio,'1970-01-01') asc  limit $limite OFFSET $offset";

            $sql = "SELECT * FROM (
				select o.id,o.cedula,o.nombres,o.saldo_mora,o.obligacion,o.numero_expediente,MAX(g.fecha_inicio) as fecha_inicio, 
				CASE 
				WHEN MAX(g.fecha_inicio) IS NULL THEN -1 
				WHEN MAX(g.fecha_inicio) + interval '" . $semaforoGestion["rojo"] . " day' <= current_timestamp THEN 3 
				ELSE
					CASE WHEN MAX(g.fecha_inicio) + interval '" . $semaforoGestion["amarillo"] . " day' <= current_timestamp THEN 2 
					ELSE 1
					END
				END as semaforo
				from gca_obligacion o 
				left join gca_gestion g 
				on(o.obligacion = g.obligacion AND o.id_cartera=g.id_cartera)
				where o.nombres IS NOT NULL 
				and o.id_funcionario = $id_user 
				AND o.id_cartera = $idNumeroCartera
				group by o.id,o.cedula,o.nombres,o.saldo_mora,o.obligacion,o.numero_expediente
				) as temp
				order by COALESCE(temp.fecha_inicio,'1970-01-01') ASC  
				limit $limite  OFFSET $offset ";
            //echo($sql." ".$request->getParameter("limite",20)." ".($this->gca_obligacion_cantidad));exit;
            $this->gca_obligacion_list = $doctrine->query($sql)->fetchAll();

            /* $this->paginadorGcaObligacionList = new sfDoctrinePager('GcaObligacion',$request->getParameter("limite",20));
              $this->paginadorGcaObligacionList->setQuery($doctrine->query($sql));
              $pagina=ceil(($request->getParameter("inicio")/$request->getParameter("limite",20)))+1;
              $this->paginadorGcaObligacionList->setPage($pagina);
              //$this->paginadorGcaObligacionList->init(); */

            $arr_obligaciones = array();
            $arr_obligaciones["registros"] = array();
            $i = 0;
            foreach ($this->gca_obligacion_list as $obligacion) {
                $arr_obligaciones["registros"][$i]['nombres'] = $obligacion['nombres'];
                $arr_obligaciones["registros"][$i]['cedula'] = $obligacion['cedula'];
                $arr_obligaciones["registros"][$i]['id'] = $obligacion['id'];
                $arr_obligaciones["registros"][$i]['saldo_mora'] = $obligacion['saldo_mora'];
                $arr_obligaciones["registros"][$i]['fecha_ultima_gestion'] = $obligacion['fecha_inicio'];
                $arr_obligaciones["registros"][$i]['semaforo'] = $obligacion['semaforo'];
                $i++;
            }
            //$arr_obligaciones['cant'] = $i;
            $arr_obligaciones['cant'] = ($paginas) * $request->getParameter("limite", 20);
            $this->json_obligacion = json_encode($arr_obligaciones);
        }
        echo $this->json_obligacion;
        exit;
    }

    public function traer_abogado($cedula) {
$doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $sql="select * from gca_deudor where cedula=".$cedula;
        $semaforoArr = $doctrine->query($sql)->fetchAll();
//        print_r($semaforoArr);
        return $semaforoArr;
    }

    public function executeInfoPersonal(sfWebRequest $request) {
 
        $this->deudor = Doctrine::getTable('GcaObligacion')->find(array($request->getParameter('id')));
    }

    public function executeInfoObligacion(sfWebRequest $request) {

        $this->deudor = Doctrine::getTable('GcaObligacion')->find(array($request->getParameter('id')));
    }

    public function executeGuardarSalvado(sfWebRequest $request) {
        $idDeudor = $request->getParameter('id');
        $valor = $request->getParameter('valor');

        $sql = "update gca_obligacion set salvado = " . $valor . ", fecha_salvado = now() where id = " . $idDeudor;
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $doctrine->query($sql);

        return sfView::NONE;
    }

    protected function processForm(sfWebRequest $request, sfForm $form) {
        $form->bind($request->getParameter($form->getName()));
        if ($form->isValid()) {
            $gca_obligacion = $form->save();

            $this->redirect('deudorCartera/edit?id=' . $gca_obligacion->getId());
        }
    }

    public function executeObtenerProductos(sfWebRequest $request) {
        $productos = array();
        $idCartera = $this->getUser()->getAttribute('id_cartera');
        $query = "SELECT g.id as id,producto as pr,saldo_mora as mt, saldo_capital as sc,obligacion as ob 
    FROM obligaciones.gca_obligacion_$idCartera g,
    (
    SELECT cedula, id_cartera
    FROM obligaciones.gca_obligacion_$idCartera
    WHERE id=" . $request->getParameter("id") . "
    AND id_cartera=$idCartera
    ) as temp
    WHERE g.cedula=temp.cedula
    AND g.id_cartera=temp.id_cartera
    AND g.id_cartera=$idCartera";
        if (isset($_GET["sgm"])) {
            var_dump($query);
        }
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $datos = $doctrine->query($query)->fetchAll();
        $productos["prods"] = array();
        foreach ($datos as $llave => $valor) {
            $productos["prods"][] = array("id" => $valor["id"], "ob" => $valor["ob"], "mt" => $valor["mt"], "pr" => $valor["pr"] == null ? "" : $valor["pr"], "sc" => $valor["sc"] == null ? 0 : $valor["sc"]);
            // var_dump($productos);
        }

        header('Content-type: application/json');
        echo json_encode($productos);
        exit;
    }

    function executeConsultasInsert($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $doctrine->query($sql);
    }

    function executeConsultasConsul($sql) {
        $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $res = $doctrine->query($sql)->fetchAll();
        return $res;
    }
    function traer_causal(){
        $sql="select estado from gca_obligacion_causales where estado_general=0 and estado <> 'Cancelar' group by estado ";
        return deudorCarteraActions::executeConsultasConsul($sql);
    }
    function traer_causal_cedula($cedula){
        $sql="select ss.* "
                . "from gca_obligacion_causales ss "
                . "join gca_deudor gg on gg.id_causal=ss.id where gg.cedula='".$cedula."'";
        return deudorCarteraActions::executeConsultasConsul($sql);
    }
    public function executeConsulta() {
        $this->id_usuario = $this->getUser()->getAttribute('usuario');
        $this->setTemplate('consulta');
    }

}
