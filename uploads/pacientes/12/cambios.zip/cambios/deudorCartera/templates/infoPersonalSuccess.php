<?php
//echo $sf_data->getRaw('json_obligacion');
?>
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<?php
echo $sf_data->getRaw('json_obligacion');
?>
<style>
    .fila1{
        width: 4%;
    }
    .fila2{
        width: 10%;
    }
    .file3{
        width: 6%;
    }
</style>

<?php // var_dump($deudor);  
@$abogado=deudorCarteraActions::traer_abogado($deudor->getCedula());
//        print_r($abogado);
?>

<table style="font-size: 10; width: 100%">
    <tr>
        <td>
            <form method="post" id="infoabogado" class="infoabogado" >
                <input type="hidden" value="guardar_abogado" name="action"  >
                <input type="hidden" value="<?php echo $id ?>" name="id"  >
                <input type="hidden" value="<?php echo $deudor->getCedula() ?>" name="cedula"  class="cedula_abogado">
                <input type="hidden" value="<?php echo $deudor->getCedula() ?>" name="cedula"  class="ig_perons">
                <table width="100%">
                    <tr>
                        <td class="fila1"><b>Nombres:</b></td>
                        <td class="fila2"><?php echo $deudor->getNombres() ?></td>
                        <td class="fila1"><b>C&eacute;dula:</b></td>
                        <td class="fila2 " id="td-ob-cedula" ><?php echo $deudor->getCedula() ?></td>
                        
                    </tr>
                    <?php 
                    $s=strpos($deudor->getContacto(),'GCA');
                    if($s>-1){
                        $che='';   
                    }else{
                        $che='checked="checked"';
                    }
                    ?>
                    <tr>
                        <td class="fila1"><b>Cartera:</b></td>
                        <td class="fila2"><?php echo $deudor->getProfesion() ?></td>
                        <td class="fila1"><b>Empresa</b></td>
                        <td class="fila2"><?php echo $deudor->getEmpresa() ?></td>
                    </tr>
                    <tr>
                        <td class="fila1"><b>Fecha Carga</b></td>
                        <td class="fila2"><?php echo $deudor->getFechaCarga() ?></td>
                        <td class="fila1"><b>Contacto:</b></td>
                        <td class="fila2"><?php echo $deudor->getContacto() ?></td>
<!--                        <td class="fila1"><b>Nombre Abogado</b></td>
                        <td class="fila2"><input type="text" name="nombre" class="nombre_abogado" value="<?php if (!empty($abogado[0]['nombre_abogado'])) echo $abogado[0]['nombre_abogado'] ?>"></td>-->
                        
                    </tr>
                    <tr>
                        <td class="fila1"><b>Ingresos</b></td>
                        <td class="fila2"><?php echo money_format('%=#9n', $deudor->getIngreso()) ?></td>
                        <td class="fila1"><b>Abogado Externo</b></td>
                        <td class="fila2"><input type="checkbox" disabled="disabled" <?php echo $che; ?>  name="externo" class="check_abogado"  value="true" <?php if (!empty($abogado[0]['abogado_externo'])) echo "checked" ?>></td>
                    </tr>
<!--                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>-->
                        <!--<td class="fila2"><button type="button" class="x-btn-text" id="guardar" onclick="guardar_abogado('<?php echo url_for('condonaciones/consultar') ?>')">Guardar</button></td>-->
                        <!--<td class="fila2"></td>-->
                    <!--</tr>-->
                </table>
            </form>    
        </td>
        <td>
            <table>
                <tr>
                    <td><b>Estado Obligación</b></td>
                    <td><pre>
                            <?php
                            $estado = deudorCarteraActions::traer_causal_cedula($deudor->getCedula());
//                            print_r($estado);
                            if (isset($estado[0]['estado'])) {
                                $estado2 = $estado[0]['estado'];
                                $causal = $estado[0]['causal'];
                                $causal2 = $estado[0]['causal'];
                                $descripcion = $estado[0]['descripcion'];
                            } else {
                                $estado2 = "";
                                $causal = "";
                                $causal2 = "seleccione...";
                                $descripcion = "";
                            }
                            $estado = deudorCarteraActions::traer_causal();
//                        print_r($estado);
                            ?></pre>
                        <select class="estado_causal" onchange="buscar_causal(this)" name="estado_causal">
                            <option value="">Selección...</option>
<?php
foreach ($estado as $value) {
    if($value['estado']==$estado2){
        $selec='selected="selected"';
    }else{
        $selec='';
    }
    ?><option <?php echo $selec; ?> value="<?php echo $value['estado']; ?>"><?php echo $value['estado']; ?></option><?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><b>Causal</b></td>
                    <td>
                        <select class="causal_causal" onchange="validar_causal(this)" name="causal_causal">
                            <option value="<?php echo $causal; ?>"><?php echo $causal2; ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><b>Descripción</b></td>
                    <td><input type="text" class="descri_causal" value="<?php echo $descripcion;?>" name="descri_causal" readonly="readonly" idcu="<?php echo $id ?>"></td>
                </tr>
                <tr>
                    <td colspan="2"><button class="enviar_causal">Guardar</button></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<script>


</script>

