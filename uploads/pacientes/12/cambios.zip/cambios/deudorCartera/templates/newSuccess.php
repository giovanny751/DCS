<h1>New DeudorCartera</h1>

<?php include_partial('form', array('form' => $form)) ?>
