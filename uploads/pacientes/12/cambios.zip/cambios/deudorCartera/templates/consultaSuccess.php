<?php

switch ($_POST['action']) {
    case 'buscar_causal':
        $sql = "select * from gca_obligacion_causales where estado_general=0 and estado='" . $_POST['estado'] . "'";
        $datos = deudorCarteraActions::executeConsultasConsul($sql);
        $html = '<option value="">Selección...</option>';
        foreach ($datos as $value) {
            $html.=''
                    . '<option value="' . $value['causal'] . '">' . $value['causal'] . '</option>';
        }echo $html;
        break;
    case 'buscar_estado':
        $sql = "select * from gca_obligacion_causales where estado_general=0 and causal='" . $_POST['estado'] . "'";
        $datos = deudorCarteraActions::executeConsultasConsul($sql);
        echo $datos[0]['descripcion'];
        break;
    case 'guardar_causal':

        $sql = "select * from gca_obligacion_causales where estado='" . $_POST['estado_causal'] . "' and descripcion='" . $_POST['descripcion_causal'] . "'";
        $datos = deudorCarteraActions::executeConsultasConsul($sql);
        if (count($datos) > 0) {
            $dd=$datos[0]['causal'];
            $sql = "update gca_obligacion set fecha_actualizacion_causal='".date('Y-m-d')."',id_causal='".$datos[0]['id']."',estado_causal='" . $_POST['estado_causal'] . "' where cedula='" . $_POST['ig_perons'] . "'";
            deudorCarteraActions::executeConsultasInsert($sql);
            $sql = "update gca_deudor set fecha_actualizacion='".date('Y-m-d')."', id_causal='" . $datos[0]['id'] . "' where cedula='" . $_POST['ig_perons'] . "'";
            deudorCarteraActions::executeConsultasInsert($sql);
            $sql="select * from gca_obligacion where cedula=".$_POST['ig_perons'];
            $datos = deudorCarteraActions::executeConsultasConsul($sql);
            foreach ($datos as $value) {
                $sql="insert into gca_cambios_estado_deudores (cedula,obligacion,estado,causal,fecha,usuario)"
                        . "values ("
                        . "'".$_POST['ig_perons']."',"
                        . "'".$value['obligacion']."',"
                        . "'".$_POST['estado_causal']."',"
                        . "'".$dd."',"
                        . "'".date('Y-m-d')."',"
                        . "'".$id_usuario."'"
                        . ")";
                deudorCarteraActions::executeConsultasInsert($sql);
            }
        }

        break;
}
?>