<?php
 //echo $sf_data->getRaw('json_obligacion');
?>


<form name="form1" method="post" action="" >
<table width="100%">

	<tr>
		<td><b>Fecha Env&iacute;o:</b></td>
		<td><?php echo $deudor->getFechaAsignacion();?></td>		
		<td><b>Estado:</b></td>
		<td><?php echo $deudor->getEstado(); ?></td>
		<td><b>Max. Mora:</b></td>
		<td><?php echo $deudor->getNumeroExpediente()?></td>
	</tr>
	<tr>
		<td width="10%"><b>Saldo Mora:</b></td>
		<?php //setlocale(LC_MONETARY, 'es_ES');?>
		<td width="10%"><?php echo number_format($deudor->getSaldoMora())?></td>
		<td width="10%"><b>Asesor:</b></td>
		<td width="30%"><?php echo Doctrine::getTable('GcaFuncionarios')->find(array($deudor->getIdFuncionario()))?></td>
		<td width="10%"><b>Edad mora:</b></td>
		<td width="10%"><?php echo $deudor->getEdadMora()?></td>
	</tr>
	<tr>
		<td width="10%"><b>Sucursal:</b></td>
		<td width="10%"><?php echo $deudor->getSucursal()?></td>
		<td width="10%"><b>Obligaci&oacute;n:</b> </td>
		<td width="30%"><?php echo $deudor->getObligacion()?></td>
		<td width="10%"><b>Salvado:</b></td>
		<?php if($deudor->getSalvado() == 'true')$salvado = 'checked';else $salvado='';?>
		<td><input type="checkbox" name="salvado" id="salvado" <?php echo $salvado?> onclick="guardar(this,<?php echo $deudor->getId()?>);"/></td>
	</tr>	
    <?php $saldos = Doctrine::getTable('GcaObligacion')->getSaldoMoraDeudor($deudor->getCedula(),$deudor->getIdCartera());
	?>
	<tr>
		<td width="10%"><b>Saldo Mora Total:</b></td>
		<td width="10%"><?php echo number_format($saldos[0])?></td>
		<td width="10%"><b>Saldo Capital Total:</b> </td>
		<td width="30%"><?php echo number_format($saldos[1])?></td>
		<td width="10%" colspan="2">&nbsp;</td>
	</tr>
</table>
	
</form>

