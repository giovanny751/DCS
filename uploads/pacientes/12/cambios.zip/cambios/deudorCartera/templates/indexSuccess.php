<h1>DeudorCartera List</h1>

<table>
  <thead>
    <tr>
      <th>Id</th>
      <th>Sucursal</th>
      <th>Referencia</th>
      <th>Expedicion</th>
      <th>Fecha envio</th>
      <th>Edad mora</th>
      <th>Nombres</th>
      <th>Apellidos</th>
      <th>Obligacion</th>
      <th>Producto</th>
      <th>Capital</th>
      <th>Saldo mora</th>
      <th>Fecha liquidacion</th>
      <th>Empresa</th>
      <th>Profesion</th>
      <th>Ingreso</th>
      <th>Fecha ultimo reporte</th>
      <th>Fecha retoma</th>
      <th>Devuelto</th>
      <th>Fecha devolucion</th>
      <th>Pago verificado</th>
      <th>Fecha pago verificado</th>
      <th>Estado</th>
      <th>Id localizacion</th>
      <th>Id cartera</th>
      <th>Id funcionario</th>
      <th>Numero expediente</th>
      <th>Id funcionario sugerido</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($gca_obligacion_list as $gca_obligacion): ?>
    <tr>
      <td><a href="<?php echo url_for('deudorCartera/show?id='.$gca_obligacion->getId()) ?>"><?php echo $gca_obligacion->getId() ?></a></td>
      <td><?php echo $gca_obligacion->getSucursal() ?></td>
      <td><?php echo $gca_obligacion->getReferencia() ?></td>
      <td><?php echo $gca_obligacion->getExpedicion() ?></td>
      <td><?php echo $gca_obligacion->getFechaEnvio() ?></td>
      <td><?php echo $gca_obligacion->getEdadMora() ?></td>
      <td><?php echo $gca_obligacion->getNombres() ?></td>
      <td><?php echo $gca_obligacion->getApellidos() ?></td>
      <td><?php echo $gca_obligacion->getObligacion() ?></td>
      <td><?php echo $gca_obligacion->getProducto() ?></td>
      <td><?php echo $gca_obligacion->getCapital() ?></td>
      <td><?php echo $gca_obligacion->getSaldoMora() ?></td>
      <td><?php echo $gca_obligacion->getFechaLiquidacion() ?></td>
      <td><?php echo $gca_obligacion->getEmpresa() ?></td>
      <td><?php echo $gca_obligacion->getProfesion() ?></td>
      <td><?php echo $gca_obligacion->getIngreso() ?></td>
      <td><?php echo $gca_obligacion->getFechaUltimoReporte() ?></td>
      <td><?php echo $gca_obligacion->getFechaRetoma() ?></td>
      <td><?php echo $gca_obligacion->getDevuelto() ?></td>
      <td><?php echo $gca_obligacion->getFechaDevolucion() ?></td>
      <td><?php echo $gca_obligacion->getPagoVerificado() ?></td>
      <td><?php echo $gca_obligacion->getFechaPagoVerificado() ?></td>
      <td><?php echo $gca_obligacion->getEstado() ?></td>
      <td><?php echo $gca_obligacion->getIdLocalizacion() ?></td>
      <td><?php echo $gca_obligacion->getIdCartera() ?></td>
      <td><?php echo $gca_obligacion->getIdFuncionario() ?></td>
      <td><?php echo $gca_obligacion->getNumeroExpediente() ?></td>
      <td><?php echo $gca_obligacion->getIdFuncionarioSugerido() ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

  <a href="<?php echo url_for('deudorCartera/new') ?>">New</a>
