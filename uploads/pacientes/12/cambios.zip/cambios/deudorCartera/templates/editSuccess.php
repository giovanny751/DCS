<h1>Edit DeudorCartera</h1>

<?php include_partial('form', array('form' => $form)) ?>
