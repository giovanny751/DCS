


<h1>Editar Pagos</h1>


<?php 
include_partial('pagos', array('form' => $form, 'honorarios' => $honorarios, 'iva' => $iva, 'formulario'=>'edit_tesorero', 'deudor'=>$deudor,'is_tesorero'=>$is_tesorero,'is_tesorero_sucursal'=>$is_tesorero_sucursal,'departamento'=>$departamento,'obligacionesPagos'=>$sf_data->getRaw('obligacionesPagos'),'is_coordinador'=>$is_coordinador , 'asesor'=>$asesor,'cartera_elejida'=> $cartera_elejida,'estado_elejido'=>$estado_elejido,'opcion'=>'','is_analista'=>$is_analista,'editarPagosReg'=>$editarPagosReg )) ?>


