

<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
</style>

<h1>Editar Pagos</h1>

<form  method="post" action="<?php echo url_for('frontPagos/update?id='.$form->getObject()->getId())?>">


<table class="nuevo">
    <tr>
      <th><?php echo ($form['expediente']->renderLabel()) ?> </th>
      <td><?php echo ($form['expediente']->render()) ?> </td>
    </tr>

    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?> </th>
      <td><?php echo ($form['por_concepto']->render()) ?> </td>    
    </tr>
    <tr>
      <th><?php echo ($form['id_cartera']->renderLabel())?></th>
      <td><?php echo ($form['id_cartera']->render())?></td>
    </tr>

</table>



<table border="0" align="left" ><tr><td>

<table class="nuevo" border="0" align="left">
    <tr class="listheading">
      <!--<th width="50px"><?php// echo ($form['Formas']['medio_pago']->renderLabel()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
     <!-- <th><?//php echo ($form['Formas']['producto']->renderLabel()) ?> </th>-->
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>
      <th width="150px"><?php echo ($form['Formas']['fecha']->renderLabel()) ?> </th>      
      <th><?php echo ($form['Formas']['entidad']->renderLabel()) ?> </th>
	  <th><?php echo ($form['Formas']['cpm']->renderLabel()) ?> </th> 
      <th><?php echo ($form['Formas']['abogados']->renderLabel()) ?> </th>      	  	  
	  <th><?php echo ($form['Formas']['honorarios']->renderLabel()) ?> </th>      	  
	  <th><?php echo ($form['Formas']['otros']->renderLabel()) ?> </th>     	  	 
      <th><?php echo ($form['Formas']['iva']->renderLabel()) ?> </th>      
      <th><?php echo ($form['Formas']['concepto_rechazo']->renderLabel()) ?> </th>	  
      
    </tr>
    <tr>
      <!--<th><?php //echo ($form['Formas']['medio_pago']->render()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->render()) ?> </th>
      <!--<th><?//php echo ($form['Formas']['producto']->render()) ?> </th>-->
     
      <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva.',1'?>);" size="10"  value="<? print number_format($form['Formas']['valor']->getValue())?>"/>
	  
      <input type="hidden" id="gca_pagos_Formas_valor" name="gca_pagos[Formas][valor]" /></th>

      <th><?php echo ($form['Formas']['fecha']->render()) ?> </th>	 	  
	  <?php 
	  echo ($form['Formas']['entidad']->render());
	  echo ($form['Formas']['honorarios']->render());
	  echo ($form['Formas']['cpm']->render());
	  echo ($form['Formas']['iva']->render());
	  echo ($form['Formas']['otros']->render());
	  echo ($form['Formas']['abogados']->render());
	  ?> 
	  
	  <th><input type="text" id="gca_pagos_Formas_entidadT" name="gca_pagos_Formas_entidadT"   onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1'?>)" size="10" value="<? print number_format($form['Formas']['entidad']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas_cpmT" name="gca_pagos_Formas_cpmT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>);"  value="<? print number_format($form['Formas']['cpm']->getValue())?>"/> 
         
      <th><input type="text" id="gca_pagos_Formas_abogadosT" name="gca_pagos_Formas_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>)" value="<? print number_format($form['Formas']['abogados']->getValue())?>" /> </th>
	 
	  <th><input type="text" id="gca_pagos_Formas_honorariosT" name="gca_pagos_Formas_honorariosT" size="10" readonly value="<? print number_format($form['Formas']['honorarios']->getValue())?>"/> </th> 

	  <th><input type="text" id="gca_pagos_Formas_otrosT" name="gca_pagos_Formas_otrosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>)" value="<? print number_format($form['Formas']['otros']->getValue())?>"/> </th> 
	  
	  <th><input type="text" id="gca_pagos_Formas_ivaT" name="gca_pagos_Formas_ivaT" size="10" readonly value="<? print number_format($form['Formas']['iva']->getValue())?>"/> 
	  <th><?php echo ($form['Formas']['concepto_rechazo']->render()) ?> </th>	       
	  <input type="hidden" id="gca_pagos_Formas_medio_pago" name="gca_pagos[Formas][medio_pago]" value="1"  />      
    
      </tr>    
    <tr>
    <!--  <th><?php //echo ($form['Formas2']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas2']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['num_cheque']->render()) ?> </th>
      
      <th><input type="text" id="gca_pagos_Formas2_valorT" name="gca_pagos_Formas2_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva.',2';?>);" size="10" value="<? print number_format($form['Formas2']['valor']->getValue())?>"/>
      <input type="hidden" id="gca_pagos_Formas2_valor" name="gca_pagos[Formas2][valor]"/></th>	
	
      <th><?php echo ($form['Formas2']['fecha']->render()) ?> </th>	
	  <th><input type="text" id="gca_pagos_Formas2_entidadT" name="gca_pagos_Formas2_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>)" size="10" value="<? print number_format($form['Formas2']['entidad']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas2_cpmT" name="gca_pagos_Formas2_cpmT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>);" value="<? print number_format($form['Formas2']['cpm']->getValue())?>"/>      
     
	  <th><input type="text" id="gca_pagos_Formas2_abogadosT" name="gca_pagos_Formas2_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>)"  value="<? print number_format($form['Formas2']['abogados']->getValue())?>"/> </th> 

	  <th><input type="text" id="gca_pagos_Formas2_honorariosT" name="gca_pagos_Formas2_honorariosT" size="10" readonly value="<? print number_format($form['Formas2']['honorarios']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas2_otrosT" name="gca_pagos_Formas2_otrosT" size="10"  onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>)" value="<? print number_format($form['Formas2']['otros']->getValue())?>"/> </th> 
	  
		  
	  <th><input type="text" id="gca_pagos_Formas2_ivaT" name="gca_pagos_Formas2_ivaT" size="10" readonly value="<? print number_format($form['Formas2']['iva']->getValue())?>" />
	 <th><?php echo ($form['Formas2']['concepto_rechazo']->render()) ?> </th>	  
	 <input type="hidden" id="gca_pagos_Formas2_medio_pago" name="gca_pagos[Formas2][medio_pago]" value="1"  />   
	  
	<?php 
	  echo ($form['Formas2']['entidad']->render());
	  echo ($form['Formas2']['iva']->render());
	  echo ($form['Formas2']['honorarios']->render());
	  echo ($form['Formas2']['cpm']->render());
	   echo ($form['Formas2']['otros']->render());
	  echo ($form['Formas2']['abogados']->render());
	  ?> 	  
    </tr>	
	
    <tr>
      <!--<th><?php//echo ($form['Formas3']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas3']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['num_cheque']->render()) ?> </th>      
      <th><input type="text" id="gca_pagos_Formas3_valorT" name="gca_pagos_Formas3_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva.',3';?>);" size="10" value="<? print number_format($form['Formas3']['valor']->getValue())?>"/>
      <input type="hidden" id="gca_pagos_Formas3_valor" name="gca_pagos[Formas3][valor]" /></th>

      <th><?php echo ($form['Formas3']['fecha']->render()) ?> </th>  

	  <th><input type="text" id="gca_pagos_Formas3_entidadT" name="gca_pagos_Formas3_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>);" size="10" value="<? print number_format($form['Formas3']['entidad']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas3_cpmT" name="gca_pagos_Formas3_cpmT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>);" value="<? print number_format($form['Formas3']['iva']->getValue())?>"/>           

	  <th><input type="text" id="gca_pagos_Formas3_abogadosT" name="gca_pagos_Formas3_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>)" value="<? print number_format($form['Formas3']['abogados']->getValue())?>"/> </th> 

	  <th><input type="text" id="gca_pagos_Formas3_honorariosT" name="gca_pagos_Formas3_honorariosT" size="10" readonly value="<? print number_format($form['Formas3']['honorarios']->getValue())?>"/>
	
	  <th><input type="text" id="gca_pagos_Formas3_otrosT" name="gca_pagos_Formas3_otrosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>)" value="<? print number_format($form['Formas3']['otros']->getValue())?>"/> </th> 
	  
		  
	  <th><input type="text" id="gca_pagos_Formas3_ivaT" name="gca_pagos_Formas3_ivaT" size="10" readonly value="<? print number_format($form['Formas3']['iva']->getValue())?>"/>
	  <th><?php echo ($form['Formas3']['concepto_rechazo']->render()) ?> </th>	  
	  <input type="hidden" id="gca_pagos_Formas3_medio_pago" name="gca_pagos[Formas3][medio_pago]" value="1"  /> 
		  
	  <?php 
	  echo ($form['Formas3']['entidad']->render());
	  echo ($form['Formas3']['iva']->render());
	  echo ($form['Formas3']['honorarios']->render());
	  echo ($form['Formas3']['cpm']->render());
	  echo ($form['Formas3']['otros']->render());
	  echo ($form['Formas3']['abogados']->render());
	  
	  ?> 	  
    </tr>
	<?php 
	//ocultos del formulario formaPago... por katty*** 
	/*echo ($form['Formas']['id']->render());
	echo ($form['Formas']['id_gca_pagos']->render());*/
        echo ($form['Formas']['estado']->render());	
        echo ($form['Formas2']['estado']->render());	
        echo ($form['Formas3']['estado']->render());			
     ?> 

</table>

<?php print "---".$form['fecha']->render();?>


<br>
<table  class="nuevo" border=0 align="right" width="250px">
  <tr>    
    <th class="listheading" width="120px">&nbsp;&nbsp;<?php echo ($form['entidad']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT" value="<? print number_format($form['entidad']->getValue())?>"
readonly  />
        <input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" />
	</th>    
	<th>&nbsp;</th>
   </tr>
  <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['cpm']->renderLabel())?>: </th>
	<th><input type="text" id="gca_pagos_cpmT" name="gca_pagos_cpmT"  onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"  value="<? print number_format($form['cpm']->getValue())?>" readonly/> </th>	
	<th>&nbsp;</th>
  </tr>
  <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['otros']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_otrosT" name="gca_pagos_otrosT"  onkeyup="calcular(<?php echo $honorarios.', '.$iva; ?>);" value="<? print number_format($form['otros']->getValue())?>"
 readonly/> 
	
	</th>
	<th>&nbsp;</th>
  </tr>    
   <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['abogados']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_abogadosT" name="gca_pagos_abogadosT" value="<? print number_format($form['abogados']->getValue())?>" readonly/> 
</th>
	<th>&nbsp;</th>
  </tr> 
  
  <tr>   
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['honorarios']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" value="<? print number_format($form['honorarios']->getValue())?>" readonly /> </th>
    <th><div id="porcentaje_honorarios"><?php echo ($honorarios*100).'%';?></div></th>
  </tr>
  <tr>   
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['iva']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_ivaT" name="gca_pagos_ivaT" value="<? print number_format($form['iva']->getValue())?>" readonly />  </th>
    <th><?php echo ($iva*100).'%'; ?></th>
  </tr>      
  <tr>
    
    <th class="listheading"><font color="yellow">&nbsp;&nbsp;<?php echo ($form['valor_total']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" value="<? print number_format($form['valor_total']->getValue())?>" readonly/>
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]" /> </th>
  </tr>  

  <tr>  <td colspan="3" align="center"> <br> <input type="button" value="Guardar" name="guardar" onClick="javascript:validar_expediente()"/></td></tr>  
</table>
</td>
</tr>
</table>


<!--<input type="hidden" value="<?php// echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>-->

<?echo $form->renderHiddenFields(); ?>
<input type="hidden" name="formulario" value="edit_tesorero">
</form>







<script>
function calcular(honorarios, ivaP,forma){
    if(forma==1) id="";
    if(forma==2) id=2;
    if(forma==3) id=3;
 
  var honorarios=document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera
  var entidad = document.getElementById("gca_pagos_entidad");
  var entidadT = document.getElementById("gca_pagos_entidadT");  
  var total = document.getElementById("gca_pagos_valor_total");  
  
   var  vlr="gca_pagos_Formas"+id+"_valor";
   var  vlrT="gca_pagos_Formas"+id+"_valorT";
   var  ent="gca_pagos_Formas"+id+"_entidad";  
   var  entT="gca_pagos_Formas"+id+"_entidadT";
   var  hnr="gca_pagos_Formas"+id+"_honorarios";
   var  hnrT="gca_pagos_Formas"+id+"_honorariosT";
   var  iva="gca_pagos_Formas"+id+"_iva";
   var  ivaT="gca_pagos_Formas"+id+"_ivaT";
   var  cpm="gca_pagos_Formas"+id+"_cpm";
   var  cpmF="gca_pagos_Formas"+id+"_cpmT";
   
   var  otros="gca_pagos_Formas"+id+"_otros";
   var  otrosT="gca_pagos_Formas"+id+"_otrosT";
   var  abog="gca_pagos_Formas"+id+"_abogados";
   var  abogT="gca_pagos_Formas"+id+"_abogadosT";
 
  var f1 = document.getElementById(vlrT).value == ''?0:document.getElementById(vlrT).value.replace(/,/g,'');
  var  valorForma=document.getElementById(vlr).value = f1;
  document.getElementById(vlrT).value = CurrencyFormatted(f1);   
 
  //otrosT = document.getElementById("gca_pagos_otros").value == ''?0:document.getElementById("gca_pagos_otros").value;
 // cpmT = document.getElementById("gca_pagos_cpm").value == ''?0:document.getElementById("gca_pagos_cpm").value;   
  //document.getElementById("gca_pagos_cpm").value = CurrencyFormatted(cpmT)   
  
  //calculos parciales por cada forma de pago 
  //var valor_entidadForma=Math.round(parseFloat((valorForma - parseFloat(otrosT))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpmT)))); 
  var valor_entidadForma=Math.round(parseFloat((valorForma - 0)/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + 0))); 
    
  var valor_honorariosForma=Math.round(valor_entidadForma*parseFloat(honorarios))
  document.getElementById(entT).value=CurrencyFormatted(valor_entidadForma)
  document.getElementById(ent).value=valor_entidadForma 
  document.getElementById(hnrT).value=CurrencyFormatted(valor_honorariosForma)
  document.getElementById(hnr).value=valor_honorariosForma
  document.getElementById(ivaT).value=CurrencyFormatted(Math.round(valor_honorariosForma*parseFloat(ivaP)))  
  document.getElementById(iva).value=Math.round(valor_honorariosForma*parseFloat(ivaP))  
    
  var cpm1=document.getElementById(cpmF).value.replace(/,/g,'');
  document.getElementById(cpm).value=cpm1.replace(/,/g,'');
  
  var otr=document.getElementById(otrosT).value.replace(/,/g,'');
  document.getElementById(otros).value=otr.replace(/,/g,'');
  
  var abg=document.getElementById(abogT).value.replace(/,/g,'');
  document.getElementById(abog).value=abg.replace(/,/g,'');
  
  //Los totales, son las sumatorias de cada forma de pago
  
  total.value = total.value == ''?0:total.value;   
  var totalF1=  document.getElementById("gca_pagos_Formas_valor").value == ''?0: document.getElementById("gca_pagos_Formas_valor").value;
  var totalF2=document.getElementById("gca_pagos_Formas2_valor").value==''?0:document.getElementById("gca_pagos_Formas2_valor").value
  var totalF3=document.getElementById("gca_pagos_Formas3_valor").value==''?0:document.getElementById("gca_pagos_Formas3_valor").value
  
 // total.value = parseFloat(document.getElementById("gca_pagos_Formas_valor").value)+ parseFloat( document.getElementById("gca_pagos_Formas2_valor").value)+parseFloat(document.getElementById("gca_pagos_Formas3_valor").value);
  total.value = parseFloat(totalF1)+ parseFloat( totalF2)+parseFloat(totalF3);    
  document.getElementById("gca_pagos_valor_totalT").value= CurrencyFormatted(total.value); 

  //calculo entidad 
  var entF1=  document.getElementById("gca_pagos_Formas_entidad").value == ''?0: document.getElementById("gca_pagos_Formas_entidad").value;
  var entF2=document.getElementById("gca_pagos_Formas2_entidad").value==''?0:document.getElementById("gca_pagos_Formas2_entidad").value
  var entF3=document.getElementById("gca_pagos_Formas3_entidad").value==''?0:document.getElementById("gca_pagos_Formas3_entidad").value  
  //entidad.value = Math.round(parseFloat((total.value - parseFloat(otrosT))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpmT))));     
  entidad.value =Math.round(parseFloat(entF1)+parseFloat(entF2)+parseFloat(entF3),0);

  //calculo honor
  var hnoF1=  document.getElementById("gca_pagos_Formas_honorarios").value == ''?0: document.getElementById("gca_pagos_Formas_honorarios").value;
  var hnoF2=document.getElementById("gca_pagos_Formas2_honorarios").value==''?0:document.getElementById("gca_pagos_Formas2_honorarios").value
  var hnoF3=document.getElementById("gca_pagos_Formas3_honorarios").value==''?0:document.getElementById("gca_pagos_Formas3_honorarios").value 
  //var valor_honorarios=Math.round(parseFloat(entidad.value) * parseFloat(honorarios));
  var valor_honorarios=Math.round(parseFloat(hnoF1)+parseFloat(hnoF2)+parseFloat(hnoF3),0);
	
	
  //calculo iva
  var ivaF1=  document.getElementById("gca_pagos_Formas_iva").value == ''?0: document.getElementById("gca_pagos_Formas_iva").value;
  var ivaF2=document.getElementById("gca_pagos_Formas2_iva").value==''?0:document.getElementById("gca_pagos_Formas2_iva").value
  var ivaF3=document.getElementById("gca_pagos_Formas3_iva").value==''?0:document.getElementById("gca_pagos_Formas3_iva").value 
  //var valor_iva= Math.round(parseFloat(ivaP) * parseFloat(valor_honorarios),0);   
  var valor_iva=Math.round(parseFloat(ivaF1)+parseFloat(ivaF2)+parseFloat(ivaF3),0);
  
  document.getElementById("gca_pagos_entidadT").value=CurrencyFormatted(entidad.value); 
  document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valor_honorarios);    
  document.getElementById("gca_pagos_honorarios").value =valor_honorarios; 
  document.getElementById("gca_pagos_ivaT").value =CurrencyFormatted(valor_iva);   
  document.getElementById("gca_pagos_iva").value =valor_iva;   
}


/*recalcula valores totales, cuando se ingresan valores manuales para entidad, cpm y otros*/
function recalcularValores(){
	var honorarios=parseFloat(document.getElementById('honorarios').value); //document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera  
	var iva=parseFloat(0.16);
	var entidadT = parseFloat(document.getElementById("gca_pagos_entidadT").value);
	var total = parseFloat(document.getElementById("gca_pagos_valor_total").value);  
	var cpm= parseFloat(document.getElementById("gca_pagos_cpm").value);
	var otros= parseFloat(document.getElementById("gca_pagos_otros").value);
	var abogados= parseFloat(document.getElementById("gca_pagos_abogados").value);
	
	restante=Math.round(total-entidadT-cpm-otros-abogados);
	
	if(restante>=0){
		valor_iva=Math.round(restante*iva);       
		valor_honorarios=Math.round(restante-valor_iva);

		document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valor_honorarios);
		document.getElementById("gca_pagos_iva").value=CurrencyFormatted(valor_iva);
	}else{
	  alert("El valor de la entidad, 4 x mil y otros, no debe superar la cantidad cancelada ") 
    }	  
}

/*Permite calcular valores totales,cuando se ingresan valores manuales para las formas de pago */
function calcularValores(porcHon,porcIva,forma){ 
 if(forma==1) id="";
if(forma==2) id=2;
if(forma==3) id=3;
 
 var entT="gca_pagos_Formas"+id+"_entidadT";
 var ent="gca_pagos_Formas"+id+"_entidad";
 
  var cpmT="gca_pagos_Formas"+id+"_cpmT";
  var cpm="gca_pagos_Formas"+id+"_cpm";
  
  //var vlrT="gca_pagos_Formas"+id+"_valorT";
  var vlr="gca_pagos_Formas"+id+"_valor";
  
  var ivaT="gca_pagos_Formas"+id+"_ivaT";
  var iva="gca_pagos_Formas"+id+"_iva";
  
  var honT="gca_pagos_Formas"+id+"_honorariosT";
  var hon="gca_pagos_Formas"+id+"_honorarios";
  
  var otrosT="gca_pagos_Formas"+id+"_otrosT";
  var otros="gca_pagos_Formas"+id+"_otros";
  
  var abogT="gca_pagos_Formas"+id+"_abogadosT";
  var abog="gca_pagos_Formas"+id+"_abogados";
 
  //formateo///
	 document.getElementById(entT).value=CurrencyFormatted(document.getElementById(entT).value);
	 var v1=document.getElementById(entT).value;
	 var valorEntidad1=document.getElementById(ent).value=v1.replace(/,/g,'');  
  
	 document.getElementById(otrosT).value=CurrencyFormatted(document.getElementById(otrosT).value); 
	 var otr=document.getElementById(otrosT).value
	 var vlr_otros=document.getElementById(otros).value=otr.replace(/,/g,'');
	 
	 document.getElementById(abogT).value=CurrencyFormatted(document.getElementById(abogT).value); 
	 var abg=document.getElementById(abogT).value
	 var vlr_abog=document.getElementById(abog).value=abg.replace(/,/g,''); 
	 
	 document.getElementById(cpmT).value=CurrencyFormatted(document.getElementById(cpmT).value)
	 var cpm1=document.getElementById(cpmT).value;
	 var cpmForma1=document.getElementById(cpm).value=cpm1.replace(/,/g,'');
 
	 //Calculos....    
	  var entF1=  document.getElementById("gca_pagos_Formas_entidad").value == ''?0: document.getElementById("gca_pagos_Formas_entidad").value;
	  var entF2=document.getElementById("gca_pagos_Formas2_entidad").value==''?0:document.getElementById("gca_pagos_Formas2_entidad").value
	  var entF3=document.getElementById("gca_pagos_Formas3_entidad").value==''?0:document.getElementById("gca_pagos_Formas3_entidad").value
  
	  // var valorTotalEntidad=parseFloat(document.getElementById("gca_pagos_Formas_entidad").value)+parseFloat(document.getElementById("gca_pagos_Formas2_entidad").value)+parseFloat(document.getElementById("gca_pagos_Formas3_entidad").value);
	  var valorTotalEntidad=parseFloat(entF1)+parseFloat(entF2)+parseFloat(entF3);
	 
	  document.getElementById("gca_pagos_entidadT").value=CurrencyFormatted(valorTotalEntidad)
	  document.getElementById("gca_pagos_entidad").value=valorTotalEntidad; 
	 
	 
	  //calculos sobre el valor a la entidad-4xmil-abogados
	  var total_f=document.getElementById(vlr).value
	  var restante=parseFloat(total_f-valorEntidad1-cpmForma1-vlr_abog) 
	 
	  //calculo iva
	  var ivaForma=Math.round(parseFloat(restante)*parseFloat(porcIva)/parseFloat(1+porcIva),0);
	  document.getElementById(ivaT).value=CurrencyFormatted(ivaForma);
	  document.getElementById(iva).value=ivaForma;
	  var ivaF1=  document.getElementById("gca_pagos_Formas_iva").value == ''?0: document.getElementById("gca_pagos_Formas_iva").value;
	  var ivaF2=document.getElementById("gca_pagos_Formas2_iva").value==''?0:document.getElementById("gca_pagos_Formas2_iva").value
	  var ivaF3=document.getElementById("gca_pagos_Formas3_iva").value==''?0:document.getElementById("gca_pagos_Formas3_iva").value
	 
	  //var valorTotalIva=parseFloat(document.getElementById("gca_pagos_Formas_iva").value)+parseFloat(document.getElementById("gca_pagos_Formas2_iva").value)+parseFloat(document.getElementById("gca_pagos_Formas3_iva").value);
	  var valorTotalIva=Math.round(parseFloat(ivaF1)+parseFloat(ivaF2)+parseFloat(ivaF3),0);
	  document.getElementById("gca_pagos_ivaT").value=CurrencyFormatted (valorTotalIva);
	  document.getElementById("gca_pagos_iva").value=valorTotalIva;
 

    //calculo honorarios... al  hacerse manual.. no aplica el porc de honorario..
	var honForma=Math.round(parseFloat(restante)-parseFloat(vlr_otros)-ivaForma,0);
	document.getElementById(honT).value=CurrencyFormatted(honForma);
	document.getElementById(hon).value=honForma;
 
	var hnoF1=  document.getElementById("gca_pagos_Formas_honorarios").value == ''?0: document.getElementById("gca_pagos_Formas_honorarios").value;
	var hnoF2=document.getElementById("gca_pagos_Formas2_honorarios").value==''?0:document.getElementById("gca_pagos_Formas2_honorarios").value
	var hnoF3=document.getElementById("gca_pagos_Formas3_honorarios").value==''?0:document.getElementById("gca_pagos_Formas3_honorarios").value
 
	//var valorTotalHon=parseFloat(document.getElementById("gca_pagos_Formas_honorarios").value)+parseFloat(document.getElementById("gca_pagos_Formas2_honorarios").value)+parseFloat(document.getElementById("gca_pagos_Formas3_honorarios").value);
	var valorTotalHon=Math.round(parseFloat(hnoF1)+parseFloat(hnoF2)+parseFloat(hnoF3),0);
	document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valorTotalHon)
	document.getElementById("gca_pagos_honorarios").value=valorTotalHon; 
		
	//calculo otros
	var otrF1=  document.getElementById("gca_pagos_Formas_otros").value == ''?0: document.getElementById("gca_pagos_Formas_otros").value;
	var otrF2=document.getElementById("gca_pagos_Formas2_otros").value==''?0:document.getElementById("gca_pagos_Formas2_otros").value
	var otrF3=document.getElementById("gca_pagos_Formas3_otros").value==''?0:document.getElementById("gca_pagos_Formas3_otros").value
	 
	var valorTotalOtros=Math.round(parseFloat(otrF1)+parseFloat(otrF2)+parseFloat(otrF3),0); 
	document.getElementById("gca_pagos_otrosT").value=CurrencyFormatted(valorTotalOtros);
	document.getElementById("gca_pagos_otros").value=valorTotalOtros;
	 
	//calculo cpm
	var cpmF1=  document.getElementById("gca_pagos_Formas_cpm").value == ''?0: document.getElementById("gca_pagos_Formas_cpm").value;
	var cpmF2=document.getElementById("gca_pagos_Formas2_cpm").value==''?0:document.getElementById("gca_pagos_Formas2_cpm").value
	var cpmF3=document.getElementById("gca_pagos_Formas3_cpm").value==''?0:document.getElementById("gca_pagos_Formas3_cpm").value
	
	var valorTotaCpm=Math.round(parseFloat(cpmF1)+parseFloat(cpmF2)+parseFloat(cpmF3),0); 
	document.getElementById("gca_pagos_cpmT").value=CurrencyFormatted(valorTotaCpm);
	document.getElementById("gca_pagos_cpm").value=valorTotaCpm;	
	
	//calculo abogados
	var abogF1=  document.getElementById("gca_pagos_Formas_abogados").value == ''?0: document.getElementById("gca_pagos_Formas_abogados").value;
	var abogF2=document.getElementById("gca_pagos_Formas2_abogados").value==''?0:document.getElementById("gca_pagos_Formas2_abogados").value
	var abogF3=document.getElementById("gca_pagos_Formas3_abogados").value==''?0:document.getElementById("gca_pagos_Formas3_abogados").value
	
	var valorTotalAbog=  Math.round(parseFloat(abogF1) + parseFloat(abogF2) + parseFloat(abogF3),0); 
	document.getElementById("gca_pagos_abogadosT").value=CurrencyFormatted(valorTotalAbog)
	document.getElementById("gca_pagos_abogados").value=valorTotalAbog;
}




function CurrencyFormatted(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + num);
}

/*para habilitar fechas de acuerdo a la elección de la forma de pago*/

document.getElementById('gca_pagos_Formas_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_day').disabled=false;  
 }else{	
	document.getElementById('gca_pagos_Formas_fecha_month').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_year').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas2_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas2_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas3_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas3_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
    document.getElementById('gca_pagos_Formas3_fecha_month').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_year').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas3_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_day').disabled=true; 
 }
}

    
/*Permite calcular el honorario de acuerdo a la cartera escogida*/
document.getElementById('gca_pagos_id_cartera').onchange = function(){
var nro_expediente=document.getElementById('gca_pagos_obligacion').value;
$.getJSON("getHonorarios/id_cartera/"+this.value+"/expediente/"+nro_expediente,
				function(data){							
				  $.each(data.registros, function(i,item){			
					document.getElementById('honorarios').value =item.honorarios; 
					document.getElementById('porcentaje_honorarios').innerHTML=document.getElementById('honorarios').value*100+"%";
					if(item.existe_expediente==0){
					 alert("La obligacion no pertenece a la cartera seleccionada!");
					 document.getElementById('ban_expediente').value=0; 
					 document.getElementById('deudor').innerHTML='Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
					}else{
						document.getElementById('ban_expediente').value=1; 
						document.getElementById('deudor').innerHTML=item.nombre; 
					}
				  });
                });

}

function getDeudor(){
	var nro_expediente=document.getElementById('gca_pagos_expediente').value;
	var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
	$.getJSON("getNombreDeudor/id_cartera/"+id_cartera+"/expediente/"+nro_expediente,function(data){
		$.each(data.registros, function(i,item){
			document.getElementById("nombreDeudorFld").value=item.nombre;
		});
	});
}

/*valida en el botón, antes de enviar el form*/
function validar_expediente(){
var mp1; var mp2; var mp3; //medios de pago
	if( document.getElementById('ban_expediente').value==2)alert("Elija una cartera!") 
	else{//se valida por si corrigen el expediente despues de la alerta...
		var nro_expediente=document.getElementById('gca_pagos_obligacion').value;
		var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
		$.getJSON("getHonorarios/id_cartera/"+id_cartera+"/expediente/"+nro_expediente,
					function(data){					   
					  $.each(data.registros, function(i,item){	
				  
						if(item.existe_expediente==0){					 
							alert("La obligacion no pertenece a la cartera seleccionada!");
							document.getElementById('deudor').innerHTML='Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
						 }
						else{ //validar q no ingresen montos q superen el valor pagado por el usr
							document.getElementById('deudor').innerHTML=item.nombre; 
							 fp1=document.getElementById('gca_pagos_Formas_forma_pago').value;
							 fp2=document.getElementById('gca_pagos_Formas2_forma_pago').value;
							 fp3=document.getElementById('gca_pagos_Formas3_forma_pago').value;
							 v1=document.getElementById('gca_pagos_Formas_valorT').value;
							 v2=document.getElementById('gca_pagos_Formas2_valorT').value;
							 v3=document.getElementById('gca_pagos_Formas3_valorT').value;

							/* mp1=document.getElementById('gca_pagos_Formas_medio_pago').value;
							 mp2=document.getElementById('gca_pagos_Formas2_medio_pago').value;
							 mp3=document.getElementById('gca_pagos_Formas3_medio_pago').value;*/
						
						     var error=0; //valida q haya ingresado formas y medios de pago, si existe el valor
							 //if((v1!=0 && (fp1=="" || mp1=="")) || (v2!=0 && (fp2=="" || mp2=="")) || (v3!=0 && (fp3=="" || mp3=="")))
							 if((v1!=0 && (fp1=="" )) || (v2!=0 && (fp2=="")) || (v3!=0 && (fp3=="")))
							 error=1;
							
							if(error==0){							 														 
									var valor_pago= parseFloat(document.getElementById("gca_pagos_entidad").value)+
									parseFloat(document.getElementById("gca_pagos_honorarios").value)+
									parseFloat(document.getElementById("gca_pagos_iva").value)+
									parseFloat(document.getElementById("gca_pagos_cpm").value)+
									parseFloat(document.getElementById("gca_pagos_otros").value)+
									parseFloat(document.getElementById("gca_pagos_abogados").value);																										
							 var valorT=parseFloat(document.getElementById("gca_pagos_valor_total").value); //valor total del pago														 					 
		
							 if(valorT != 0){							 
								 //reajustar a la entidad hasta 5 pesos
								 var ajuste=valorT-valor_pago;							
								 if(Math.abs(ajuste)>=1 && Math.abs(ajuste)<=5) {//puede ser neg o posit
								   document.getElementById("gca_pagos_entidad").value=parseFloat(document.getElementById("gca_pagos_entidad").value)+parseFloat(ajuste)
								   valor_pago=valor_pago+ajuste 
							     }	

							//alert(document.getElementById("gca_pagos_entidad").value)																								 
							 
								//if(valor_pago==valorT){//si es correctoo valida fechas, si el pago es en cheque
								  if(fp1==1 || fp1==4 || fp2==1 || fp2==4 || fp3==1 || fp3==4){//por si eligió cheque o fax cheque						
									   if(confirm("Recuerde revisar las fechas para los cheques!")){
										 document.forms[0].submit();	
										// alert("se va")
										}									 
								  } 
								  else { document.forms[0].submit();	
								   //alert("se va")
								  }					   
								//}
								//else alert("Los valores no coinciden con el pago efectuado!")	
							}else alert("No ha ingresado monto para el pago!")								
						 }else alert("Recuerde llenar las formas y medios de pago, para valores efectuados!")	
						////////////////							
						}								
					  });
					});
	}
	/* alert("ent "+document.getElementById("gca_pagos_entidadT").value.replace(/,/g,''))
							 alert("H "+document.getElementById("gca_pagos_honorariosT").value.replace(/,/g,''))
							 alert("I "+document.getElementById("gca_pagos_iva").value.replace(/,/g,''))
							 alert("o "+document.getElementById("gca_pagos_otros").value.replace(/,/g,''))
							 alert("4 "+document.getElementById("gca_pagos_cpm").value.replace(/,/g,''))*/
							 
	
}

</script>
