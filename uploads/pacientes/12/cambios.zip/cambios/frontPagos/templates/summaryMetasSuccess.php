<table class="lista">
	<tr>
		<th>Indicador</th>
		<th>Realizado</th>		
		<th>Esperado</th>
	</tr>
	<?php foreach($valores as $llave=>$valor){?>
	<tr>
		<th><?php echo strtoupper($llave); ?></th>
		<td><?php echo strtoupper($valor["realizado"]); ?></td>
		<td><?php echo strtoupper($valor["esperado"]); ?></td>
	</tr>
	<?php } ?>
</table>