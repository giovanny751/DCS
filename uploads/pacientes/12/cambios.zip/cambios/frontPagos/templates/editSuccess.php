

<h1>Ver Pagos</h1>


<?php 

print "<font color='red'> *** ". $mensaje." ***</font>";

include_partial('pagos', array('form' => $form, 'honorarios' => $honorarios, 'iva' => $iva, 'formulario'=>$formulario, 'deudor'=>$deudor,'departamento'=>$departamento,'is_tesorero'=>$is_tesorero,'is_tesorero_sucursal'=>$is_tesorero_sucursal,'obligacionesPagos'=>$sf_data->getRaw('obligacionesPagos'), 'asesor'=>$asesor ,'cartera_elejida'=> $cartera_elejida,'estado_elejido'=>$estado_elejido,'opcion'=>$opcion,'is_analista'=>$is_analista )) ?>



<!--
<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
</style>

<form  method="post" action="">
<table class="nuevo">
    <tr>
      <th>**<?php echo ($form['expediente']->renderLabel()) ?> </th>
      <input type="hidden" name="id_gca_pago" name="id_gca_pago" value="<?php echo $gca_pago['0']['id_gca_pagos']?>" />
      <td><input type="text" id="expediente" value="<?php echo $gca_pago['0']['expediente']?>" readonly /></td>
    </tr>
    <tr>
      <th><?php echo ($form['recibido']->renderLabel()) ?> </th>
      <td><input type="text" id="recibido" value="<?php echo $gca_pago['0']['recibido']?>" readonly /></td>
    </tr>
    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?> </th>
      <td><input type="text" id="por_concepto" value="<?php echo $gca_pago['0']['por_concepto']?>" readonly /></td>    
    </tr>
</table>

<table class="nuevo">
    <tr class="listheading">      
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>     
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['fecha']->renderLabel()) ?> </th>      
      <th><?php echo ($form['Formas']['entidad']->renderLabel()) ?> </th>
	  <th><?php echo ($form['Formas']['cpm']->renderLabel()) ?> </th> 
      <th><?php echo ($form['Formas']['abogados']->renderLabel()) ?> </th>      	  	  
	  <th><?php echo ($form['Formas']['honorarios']->renderLabel()) ?> </th>      	  
	  <th><?php echo ($form['Formas']['otros']->renderLabel()) ?> </th>     	  	 
      <th><?php echo ($form['Formas']['iva']->renderLabel()) ?> </th>      
    </tr>
    <?php foreach($gca_pago as $row):?>
    <tr>
    
      
     
      <th><input type="text" id="forma_pago" value="<?php echo $row['forma_pago']?>" readonly size="12"/> </th>
      <th><input type="text" id="id_banco" value="<?php echo $row['id_banco']?>" readonly /></th>
      <th><input type="text" id="num_cheque" value="<?php echo $row['num_cheque']?>" readonly size="15"/></th>
      
      <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" value="<?php echo $row['valor']?>" readonly size="15"/>
      <input type="hidden" id="gca_pagos_Formas_valor" name="gca_pagos[Formas][valor]" /></th>
      <th><input type="text" id="fecha" value="<?php echo $row['fecha']?>" readonly size="12"/></th>   
	  
	  <th><input type="text" id="gca_pagos_Formas_entidadT" name="gca_pagos_Formas_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1'?>)" size="10"  value="<?php echo $row['entidad']?>" />
	  <th><input type="text" id="gca_pagos_Formas_cpmT" name="gca_pagos_Formas_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>);" />          
      <th><input type="text" id="gca_pagos_Formas_abogadosT" name="gca_pagos_Formas_abogadosT" size="10" value="0"  onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>)" /> </th> 	 
	  <th><input type="text" id="gca_pagos_Formas_honorariosT" name="gca_pagos_Formas_honorariosT" size="10" readonly/> </th> 
	  <th><input type="text" id="gca_pagos_Formas_otrosT" name="gca_pagos_Formas_otrosT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>)" /> </th> 
	  
	  <th><input type="text" id="gca_pagos_Formas_ivaT" name="gca_pagos_Formas_ivaT" size="10" readonly />      
	  <input type="hidden" id="gca_pagos_Formas_medio_pago" name="gca_pagos[Formas][medio_pago]" value="1"  />      
    
    </tr>    
    <?php endforeach;?>
</table>
<table  class="nuevo">
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['entidad']->renderLabel()) ?> </th>
    <th><input type="text" id="entidad" name="gca_pagos_entidadT" value="<?php echo $gca_pago['0']['entidad']?>" readonly />
    
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['honorarios']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" value="<?php echo $gca_pago['0']['honorarios']?>" />
        <input type="hidden" id="gca_pagos_honorarios" name="gca_pagos[honorarios]" />
        </th>
    <th><?php /*echo ($honorarios*100).'%';*/?></th>
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['iva']->renderLabel()) ?> </th>
    <th><input type="text" id="iva" value="<?php echo $gca_pago['0']['iva']?>" /></th>
    <th><?php /* echo ($iva*100).'%';*/ ?> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th>4 X 1000 </th>
    <th><input type="text" id="cpm" value="<?php echo $gca_pago['0']['cpm']?>" /></th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['otros']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_otros" value="<?php echo $gca_pago['0']['otros']?>" /> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['valor_total']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" />
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]" /> </th>
  </tr>
  <tr>
    <th width="500" colspan="2"></td>
    <td><input type="button" value="Cancelar" name="cancelar" onclick="window.href = 'frontPagos/index'" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Guardar" name="guardar"/></td></tr>  
</table>



<br>
<table  class="nuevo" border=0 align="right" width="250px">
  <tr>    
    <th class="listheading" width="120px">&nbsp;&nbsp;<?php echo ($form['entidad']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT"   value="<?php echo $gca_pago['0']['entidad']?>"  readonly/>
        <input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" />
	</th>    
	<th>&nbsp;</th>
   </tr>
  <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['cpm']->renderLabel())?>: </th>
	<th><input type="text" id="gca_pagos_cpmT" name="gca_pagos_cpmT"  value="<?php echo $gca_pago['0']['cpm']?>" " onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" readonly/> </th>
	<?php //echo ($form['cpm']->render());?>
	<th>&nbsp;</th>
  </tr>
  <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['otros']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_otrosT" name="gca_pagos_otrosT"  value="<?php echo $gca_pago['0']['otros']?>"  onkeyup="calcular(<?php echo $honorarios.', '.$iva; ?>);" readonly/> 
	<?php //echo ($form['otros']->render());?>
	</th>
	<th>&nbsp;</th>
  </tr>    
   <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['abogados']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_abogadosT" name="gca_pagos_abogadosT"  value="<?php echo $gca_pago['0']['abogados']?>"  readonly/> <?php //echo ($form['abogados']->render());?> </th>
	<th>&nbsp;</th>
  </tr> 
  
  <tr>   
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['honorarios']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" readonly /> </th>
    <th><div id="porcentaje_honorarios"><?php echo ($honorarios*100).'%';?></div></th>
  </tr>
  <tr>   
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['iva']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_ivaT" name="gca_pagos_ivaT" readonly /> <?php //echo ($form['iva']->render()) ?> </th>
    <th><?php echo ($iva*100).'%'; ?></th>
  </tr>      
  <tr>
    
    <th class="listheading"><font color="yellow">&nbsp;&nbsp;<?php echo ($form['valor_total']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" readonly/>
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]" /> </th>
  </tr>  
  
  <tr>
    <td colspan="3" align="center"> 
	<br> <input type="button" value="Guardar" name="guardar" onClick="javascript:validar_expediente()"/></td></tr>  
</table>
</td>
</tr>
</table>


<input type="hidden" value="<?php echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>
</form>

-->
