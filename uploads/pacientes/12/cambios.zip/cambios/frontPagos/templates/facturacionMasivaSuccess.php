<?php include_stylesheets_for_form($form) ?>
<?php include_javascripts_for_form($form) ?>

<form action="<?php echo url_for('frontPagos/facturacionMasiva') ?>" method="post" <?php $form->isMultipart() and print 'enctype="multipart/form-data" ' ?> name="nm_nominas">
<?php if (!$form->getObject()->isNew()): ?>
<input type="hidden" name="sf_method" value="put" />
<?php endif; ?><br><font color="red">

 <b>Nota: </b> <ul> 1. Ingrese  por lo menos una fecha cuando no vaya ning&uacute;n otro dato. </ul> 
<ul>2. No se requieren fechas si va a  imprimir por consecutivos. </ul>
 <ul>3. Si  va  a imprimir solo 1 recibo, ingrese el mismo n&uacute;mero en las casillas de consecutivo desde y hasta</ul></font> 
  <center>
  <table class="nuevo"  border=0>
    <tfoot>
      <tr>
        <td colspan="2">
          <input class="enlace" type="submit" value="Imprimir" name="boton"/>
        </td>
      </tr>
    </tfoot>
    <tbody>
      <?php echo $form ?>
	<!--<tr>
	<th>
	Formato
	</th>
	<td>
	<select name="formato" id="formato">
	<option value="PDF" selected=true>PDF</option>
	<!--<option value="xls" selected=true>EXCEL</option>
	</td>	
	</tr>-->
    </tbody>
  </table>
  </center>
</form>
