<table>
  <tbody>
    <tr>
      <th>Id:</th>
      <td><?php echo $gca_pagos->getid() ?></td>
    </tr>
    <tr>
      <th>Fecha:</th>
      <td><?php echo $gca_pagos->getfecha() ?></td>
    </tr>
    <tr>
      <th>Observaciones:</th>
      <td><?php echo $gca_pagos->getobservaciones() ?></td>
    </tr>
    <tr>
      <th>Estado:</th>
      <td><?php echo $gca_pagos->getestado() ?></td>
    </tr>
    <tr>
      <th>Id funcionario:</th>
      <td><?php echo $gca_pagos->getid_funcionario() ?></td>
    </tr>
    <tr>
      <th>Obligacion:</th>
      <td><?php echo $gca_pagos->getobligacion() ?></td>
    </tr>
  </tbody>
</table>

<hr />

<a href="<?php echo url_for('frontPagos/edit?id='.$gca_pagos->getId()) ?>">Edit</a>
&nbsp;
<a href="<?php echo url_for('frontPagos/index') ?>">List</a>
