<style>
.listrow1 { font-size: 8pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 8pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 8pt; background-color: #4c86ac; color: white; }
select{font-size: 9pt; }
.mensaje{color: red;  font-size: 9pt; }
</style>

<h1>Reembolso...</h1>

<center><br><br>
<table align="center" border=0>
  <form action="<?php echo url_for('frontPagos/searchReembolso') ?>" method="get" >
 <!--  <tr>
      <td><b>Estado</td>
      <td><select name="estado" id="estado">
        <option value="">SELECCIONE...<option>
        <option value="0">SIN APROBAR</option>
        <option value="1">APROBADO</option>
        <option value="2">REGISTRADO</option>
      </select></td>
    </tr>
<tr>
	<td><b>c&eacute;dula / Expediente</td>
        <td> <input type="text" name="keywords" id="search_keywords" /></td> </tr>
   <tr>
    
   </tr>

-->
<tr>
      <td colspan="2" class="mensaje">Permite generar reembolsos desde la fecha del clave  hasta hoy</td>
   <tr>
</tr>

      <td><b>Cartera</td>
      <td><?=$form['id_cartera']->render()?></td> 
	</tr>
 <tr>	<td><b>Fecha Clave</td><td><input type="text" name="fechadesde__String" id="fechadesde_String" value="<?php print $fecha_ini?>" /></td> 
     </tr>
	
     <tr>
      <td> <input type="submit" value="Buscar" /> </form> </td>    
    </tr>

   
</table>


<br><br>

<form action="<?php echo url_for('frontPagos/reembolso') ?>" method="get" name="pagos">
<table border=0 width="90%">
<tr class="listheading" >
<?



if($mensaje=="" and count($pagos)>0 ){?>
  <td width="60px"><b>Num pago</td><td><b>Fecha Pago</td><td><b>Obligaci&oacute;n</td><td align="center"><b>Cartera</td><td width="200px" align="center"><b>Nombre Cliente</td><th width="100px">Forma Pago</th>
<td><b>Valor Pagado</td> <td><b>Valor Entidad</td> <td width="60px"><b>Confirmar</td> <!--<td><b>Imprimir</td></tr>-->

<?$style="listrow0";
   foreach ($pagos as $pago){ 
	if($style=="listrow1")$style="listrow0"; else $style="listrow1";      
	

        ?><tr class="<?=$style?>">
             <td><? print $pago['id_pago'];?>  </td>                       	      
              <td><? print $pago['fecha'];?></td>
	    
	      <td><? print $pago['obligacion']?></td>
	      <td width="150px"><? print $pago['cartera']?></td>
	      <td width="250px"><? print $pago['nombres']?></td>
		 <td><? print $pago['forma_pago']?></td>
	      <td align="right"><? print number_format($pago['valor_fp'])?></td>
	      <td align="right"><? //$valor=substr($pago['reembolso'],0,strpos($pago['reembolso'],".")+3);//toma el valor con 2 posiciones decimales
								print number_format($pago['reembolso'])//ojo... redondea?></td>
              <td align="center"><input type="checkBox" name="pagos[]" value="<? print $pago['id_forma_pago'];?>" checked></td>                    
			  
              <!-- <td>   <a href="<?php echo url_for('frontPagos/search?accion=imprimir&id='.$pago['id_pago']) ?>">  
                *
              </a></td>-->
         </tr>
       <?
    }
 } else if(count($pagos)==0){?>
      <td align="center"> <b>No hay Registros </td>	  </tr>  <?	  
   }else if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td></tr> <?
   }
   ?>	


<br>
<?  if(count($pagos)>0){?>
	<tr><th colspan="10" align="center" class="listheading"><!--Elija una sucursal para relacionar los reembolsos...   <?php echo $departamento['id_sucursal']->render()?>&nbsp; &nbsp;&nbsp; -->
	<input type="button"  value="Guardar" onclick="verificar()" ></td></tr>
<?}?>
</table>


<script>
  function verificar(){
	
        /*var sucursal=document.getElementById('department_id_sucursal').value;
	if(sucursal=='')
	{alert('Debe elegir una sucursal para relacionar los reembolsos');}
      else{*/
    if(confirm("Esta seguro de verificar los pagos seleccionados?"))
     document.pagos.submit();
//	} 
  }

//para recalcular las ventanas
 // var vp = parent.Ext.getCmp("main-container");
 // vp.doLayout();
</script>

<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "fechadesde_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	/*Calendar.setup({
        inputField     :    "fechahasta_String",
        ifFormat       :    "%Y-%m-%d %H:%M",
        showsTime      :    true,
        timeFormat     :    "24"
    });*/
</script>



