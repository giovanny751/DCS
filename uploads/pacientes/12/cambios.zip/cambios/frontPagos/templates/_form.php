<?php include_stylesheets_for_form($form) ?>
<?php include_javascripts_for_form($form) ?>
<html>
<body onLoad="cargarFechas();">
<form action="<?php echo url_for('frontPagos/'.($form->getObject()->isNew() ? 'create' : 'update').(!$form->getObject()->isNew() ? '?id='.$form->getObject()->getId() : '')) ?>" method="post" <?php $form->isMultipart() and print 'enctype="multipart/form-data" ' ?>>
<?php if (!$form->getObject()->isNew()): ?>
<input type="hidden" name="sf_method" value="put" />
<?php endif; ?>
  <table>
    <tfoot>
      <tr>
        <td colspan="2">
          &nbsp;<a href="<?php echo url_for('frontPagos/index') ?>">Cancel</a>
          <?php if (!$form->getObject()->isNew()): ?>
            &nbsp;<?php echo link_to('Delete', 'frontPagos/delete?id='.$form->getObject()->getId(), array('method' => 'delete', 'confirm' => 'Are you sure?')) ?>
          <?php endif; ?>
          <input type="submit" value="Save" />
        </td>
      </tr>
    </tfoot>
    <tbody>
      <?php echo $form ?>
    </tbody>
  </table>
</form>
</body>
</html>
<script>
document.getElementById('gca_pagos_Formas_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_day').disabled=false;  
 }else{	
	document.getElementById('gca_pagos_Formas_fecha_month').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_year').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas2_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas2_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas3_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas3_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
    document.getElementById('gca_pagos_Formas3_fecha_month').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_year').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas3_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_day').disabled=true; 
 }
}

</script>

