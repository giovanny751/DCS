<style>
.td {font-size: 6pt;}
.listrow1 { font-size: 9pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 9pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 8pt; background-color: #4c86ac; color: white; }
</style>



<center><br>
  <form action="<?php echo url_for('frontPagos/facturarLibroClave2') ?>" method="get" >
  <table border=0>
  <?php if($is_tesorero==true){?><tr><td><b>Sucursal:</td> <td><?php echo $form['id_sucursal']->render();  ?></td></tr><?php }?>
   <tr>	<td><b>Fecha Desde:</td><td><input type="text" name="fechadesde__String" id="fechadesde_String" value="<?php print $fecha_ini?>" /></td> </tr>
	 <tr><td><b>Fecha Hasta:</td><td><input type="text" name="fechahasta__String" id="fechahasta_String" value="<?php print $fecha_fin?>" /></td>
 
     <td colspan="2"> <input type="submit" value="Buscar" name="boton"/> </form> </td>
   </tr>
</table>

<br>
<table border=0 width="1200px">
<tr class="listheading" >
<?
$style="listrow0"; $val_monto=0; $val_honorarios=0; $entidad=0; $val_cpm=0; $val_otros=0; $val_comision=0; $val_entidad=0;
if($mensaje=="" and count($pagos)>0 ){?>
  <td width="50px" align="center"><b>RECIBO</td><td width="150px"align="center"><b>ENTIDAD </td><td width="200px"align="center"><b>DEUDOR</td><td width="150px"align="center"><b>OBLIGACION</td>  
  <td align="center" width="50px"><b>IVA</td> <td width="60px" align="center"><b>FORMA PAGO</td> <td  align="center"><b>ASES</td><td  align="center"><b>%</td>
   <td width="60px" align="center"><b>COMISION</td> <td align="center"><b>VALOR</td> <td align="center"><b>HONORAR</td> <!--<td align="center"><b>ENTIDAD</td>--><td><b>ENT/OBLIG</td>  <td align="center"><b>Paz y Salvo</td> 
  <td align="center"><b>OTROS</td><!-- <td align="center"><b>FECHA</td>--> <td align="center"><b>PGO</td><td width="50px" align="center"><b>ESTADO</td>
  </tr>

<?  $cont_pagos=0; 
   foreach ($pagos as $pago){
     if($pago['estado_p']!=6  and $pago['estado_fp']!=4){
	if($style=="listrow1")$style="listrow0"; else $style="listrow1";        			
        ?><tr class="<?=$style?>">
          <td><? print $pago['recibo'];?> </td>  
		  <td><? print $pago['banco']?> </td>    		  
		  <td><? print $pago['nombres'];?> </td>    		  
		  <td><? print $pago['obligacion'];?> </td>    		  
		  <td align="right"><? print number_format($pago['iva']);?> </td>  
		  <td><? print $pago['forma_pago'];?> </td> 		  
		 
		  <td width="40px" align="center"><? print $pago['asesor'];?> </td> 
		  <td><? print $pago['porcentaje_honorarios'];?> </td>  
		  <td align="right"><? print number_format($pago['comision']);?> </td> 		  		  
		  <td align="right"><? print number_format($pago['monto']);?> </td>  			  
		  <td align="right"><? print number_format($pago['honorarios']);?> </td>  			  
		  <!--<td align="right"><? //print number_format($entidad_fp);?> </td>  			  -->
		  <td align="right"><? print number_format($pago['entidad_oblig_fp']);?> </td>  			  
		  <td align="right"><? print number_format($pago['cpm']);?> </td>  			  
		  <td align="right"><? print number_format($pago['otros']);?> </td>  			  
		 <!-- <td align="right"><? print $pago['fecha'];?> </td>  	-->		  
          <td><? print $pago['por_concepto'];?> </td>                                  
          <td><? print $pago['estado'];?> </td> 
         </tr>
		
       <? $val_monto+=$pago['monto'];  $val_honorarios+=$pago['honorarios'];  $val_entidad+=$pago['entidad_oblig_fp'];  $val_cpm+=$pago['cpm']; $val_otros+=$pago['otros']; $val_comision+=$pago['comision'];
       $cont_pagos++;	
      }	 
    }
 ?> <tr class="listheading" ><td colspan="3"><b><?php print($cont_pagos)?></td> <td colspan="5">&nbsp;</td><td align="right"><b><?php print number_format($val_comision);?></td> <td align="right"><b><?php print number_format($val_monto);?></td>
 <td align="right"><b><?php print number_format($val_honorarios);?></td>  <td align="right"><b><?php print number_format($val_entidad);?></td><td align="right"><b><?php print number_format($val_cpm);?></td><td align="right"><b><?php print number_format($val_otros);?></td><td colspan="4">&nbsp;</td></tr><?	
	
 } else if(count($pagos)==0){?>
      <td align="center"> <b><?=$mensaje?></td><?
   }else 
   if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td><?
   }
   
 if($style=="listrow1")$style="listrow0"; else $style="listrow1";   
?>

</tr>
</table>
<br>
<?php if($mensaje==""){?>
<table width="600px">
<tr class="listheading"><td><b>EFECTIVO</b></td><td><b>CHEQUES</b></td><td><b>FAX-EFECTIVO</b></td><td><b>FAX-CHEQUES</b></td><td align="center" ><b>TOTAL</b></td></tr>
<?php 
$fax_ch=0;$efectivo=0; $fax_e= 0;$cheque=0;
foreach($totales as $total){
	if($total['descripcion']=="EFECTIVO") $efectivo= $total['valor'];
	if($total['descripcion']=="FAX-EFECTIVO") $fax_e= $total['valor'];
	if($total['descripcion']=="CHEQUE") $cheque+= $total['valor'];
	if($total['descripcion']=="FAX-CHEQUE") $fax_ch+= $total['valor'];
	 ?> 
	   
 <?}?>
<tr class="<?=$style?>">
 <td align="right"><?php print number_format($efectivo)?> </td>
 <td align="right"><?php print number_format($cheque)?> </td>
 <td align="right"><?php print number_format($fax_e)?> </td>
 <td align="right"><?php print number_format($fax_ch)?> </td> 
 <td align="right"><?php print number_format($efectivo+$fax_e+$cheque+$fax_ch);?></td>
</tr>
<tr><td align="center" colspan="5">&nbsp;</td></tr>
<tr><td align="center" colspan="5"><input type="submit" value="Facturar"  name="boton"></td></tr>
</table>
<?php }?>

<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "fechadesde_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	Calendar.setup({
        inputField     :    "fechahasta_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
</script>




