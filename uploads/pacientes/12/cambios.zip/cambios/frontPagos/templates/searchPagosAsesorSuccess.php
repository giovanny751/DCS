<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; }
</style>

<h1>Buscar Pagos</h1>

<center><br><br>
<table align="center" border=0>
  <form action="<?php echo url_for('frontPagos/searchPagosAsesor') ?>" method="get" >
   <tr>
     
      <td><b>Cartera</td>
      <td><?=$cartera['id_cartera']->render()?></td>
    <td><b>Forma de Pago &nbsp;&nbsp;</td>
      <td><select name="forma_pago">
        <option value="">SELECCIONE...<option>
        <option value="1">CHEQUE</option>
	<option value="2">EFECTIVO</option>
        <option value="3">FAX-EFECTIVO</option>
        <option value="4">FAX-CHEQUE</option>
      </select></td>
    </tr>

   
   
   <tr>
	<td><b>Nro. Pago / C&eacute;dula / Expediente /<br> Obligaci&oacute;n / Nombre deudor</td>
        <td> <input type="text" name="keywords" id="search_keywords"  size="30"/></td> 
 <td><b>Estado</td>
      <td><select name="estado" id="estado">
        <option value="">SELECCIONE...<option>
        <option value="0">SIN APROBAR</option>
        <option value="1">APROBADO</option>
        <option value="2">REGISTRADO</option>
        <option value="3">NO APROBADO</option>
        <option value="4">CONFIRMADO</option>
        <option value="5">REEMBOLSO</option>
        <option value="5">ANULADOS</option>
      </select></td>


</tr>
  <!-- <tr>
	<td><b>Fecha Inicio</td><td><?//print $form['fecha']->render()?></td>
	<td><b>Fecha Fin</td><td><?//print $form['fecha_reembolso']->render(); //es solo para mostrar el obj de fecha?></td>
   </tr>-->

   <tr>


 
     <td colspan="2"> <input type="submit" value="Buscar" /> </form> </td>
   </tr>
</table>


<br><br>


<table border=0 width="98%">
<tr class="listheading" >
<?



if($mensaje=="" and count($pagos)>0 ){?>
  <td width="60px" align="center"><b>Num pago</td><td align="center"><b>Cartera</td><td align="center"><b>Obligaci&oacute;n</td><td align="center"><b>C&eacute;dula</td>  <td width="200px" align="center"><b>Nombre Deudor</td> <td align="center"><b>Fecha Pago</td> <td align="center"><b>Forma Pago</td><td align="center"><b> valor Pago</td> <td align="center"><b>Entidad</td> <td align="center"><b>Honorarios</td>  <td align="center"><b>Iva</td> <td width="70px" align="center"><b>Estado</td> <td width="70px" align="center"><b>Concepto Rechazo</td></tr>

<?$style="listrow0";
//print count($pagos);
   foreach ($pagos as $pago){ 
	if($style=="listrow1")$style="listrow0"; else $style="listrow1";      
	

        ?><tr class="<?=$style?>">
              <td><a href="<?php echo url_for('frontPagos/edit?id='.$pago['id']) ?>"> 
			  <?php if(isset($pago['nro_rc']) and $pago['nro_rc']!="") print $pago['nro_rc']; else  print $pago['id'];?></a> </td>                                 
	      <td><? print $pago['cartera']?></td>             
	      <td><? print $pago['obligacion'];?></td>	
	      <td><? print $pago['cedula']?></td>   
	      <td><? print $pago['nombres']?></td>	    
	      <td><? print $pago['fecha']?></td>
	      <td><? print $pago['forma_pago']?></td>
	      <td align="right"><? print number_format($pago['valor'])?></td>		
	      <td align="right"><? print number_format($pago['reembolso'])?></td>		
	      <td align="right"><? print number_format($pago['honorarios'])?></td>
	      <td align="right"><? print number_format($pago['iva'])?></td>
          <td><? print $pago['estado']?>  </td>
	  <td><? print $pago['concepto_rechazo']?>  </td>
         </tr>
       <?
    }
 } else if(count($pagos)==0){?>
      <td align="center"> <b>No hay Registros &oacute; el pago no pertenece a sus sucursales....</td><?
   }else if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td><?
   }
?>

</tr>
</table>

