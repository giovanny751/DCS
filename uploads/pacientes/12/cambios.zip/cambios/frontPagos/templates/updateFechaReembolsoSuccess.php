<form name="form1" action="" method="post" />
<table class="nuevo">
    <tr>
      <th>Id</th>
      <td></td>
    </tr>
    <tr>
      <th>Fecha</th>
      <td><?php echo $gca_pagos->getFecha()?></td>
    </tr>
    <tr>
      <th>Observaciones</th>
      <td><?php echo $gca_pagos->getObservaciones()?></td>
    </tr>
    <tr>
      <th>Id funcionario</th>
      <td><?php echo $gca_pagos->getIdFuncionario()?></td>
    </tr>
    <tr>
      <th>Obligacion</th>
      <td><?php echo $gca_pagos->getObligacion()?></td>
    </tr>
    <tr>
      <th>Valor Total</th>
      <td><?php echo $gca_pagos->getValorTotal()?></td>
    </tr>
    <tr>
      <th>Recibido</th>
      <td><?php echo $gca_pagos->getRecibido()?></td>
    </tr>
    <tr>
      <th>Expediente</th>
      <td><?php echo $gca_pagos->getExpediente()?></td>
    </tr>
    <tr>
      <th>Honorarios</th>
      <td><?php echo $gca_pagos->getHonorarios()?></td>
    </tr>
    <tr>
      <th>Entidad</th>
      <td><?php echo $gca_pagos->getEntidad()?></td>
    </tr>
    <tr>
      <th>Iva</th>
      <td><?php echo $gca_pagos->getIva()?></td>
    </tr>
    <tr>
      <th>Honorarios</th>
      <td><?php echo $gca_pagos->getHonorarios()?></td>
    </tr>
    <tr>
      <th>Fecha Reembolso</th>
      <td><?php echo ($form['fecha_reembolso']->render())?></td>
      <th><?php echo $form['_csrf_token']->render()?></th>
    </tr>
    <tr>
        <td><input type="submit" name="actualizar" value="Actualizar"/></td>
    </tr>
</table>
</form>
