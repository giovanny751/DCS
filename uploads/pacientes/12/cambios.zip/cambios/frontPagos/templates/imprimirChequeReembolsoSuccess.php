<style>
.listrow1 { font-size: 8pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 8pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 8pt; background-color: #4c86ac; color: white; }
select{font-size: 9pt; }
.mensaje{color: red;  font-size: 8pt; }
</style>
<body onload="validacion();">
<form method='GET' name="cheque" action="<?php echo url_for('frontPagos/imprimirChequeReembolso'); ?>">
<input type="hidden" name="id_cartera">
<input type="hidden" name="fecha_reemb">
<input type="hidden" name="valor">
<input type="hidden" name="opcion">
<input type="hidden" name="accion">
<center><br><font color="red">Ingrese tambi&eacute;n los campos con ** para imprimir  la Relaci&oacute;n adjunta</font>
<br><br>
<table border="0" width="600px">
<tr><td align="right"><b>Fecha Impresi&oacute;n<font size="2"> (yyyy-mm-dd):</font></td><td><input type="text" size="30" name="fecha_impresion" 
value="<?echo date('Y-m-d')?>"><font color="red">**</td></tr>
<tr><td align="right"><b>Descuentos (Opcional):</td> <td><input type="text" size="30" name="descuentos"></td></tr>
<tr><td align="right"><b>No. Cheque:</td> <td><input type="text" size="30" name="nro_cheque"><font color="red">**</td> </tr>
<tr><td align="right"><b>Banco:</td>      <td><input type="text" size="30" name="banco"><font color="red">**</font></td></tr>

</table>
</form>



<br><br>
<table border=0 width="80%">
<tr class="listheading" >
<?
if($mensaje=="" and count($pagos)>0 ){?>
  <td align="center"><b>Cliente</td><td align="center"><b>Fecha Reembolso</td><td align="center"><b>Valor</td> <td align="center"><b>Seleccionar</td></tr>

<?$style="listrow0";
   foreach ($pagos as $pago){ 
	if($style=="listrow1")$style="listrow0"; else $style="listrow1"; 
		  $id_cartera=$pago['id_cartera'];
		  $fecha=$pago['fecha_reembolso'];
		  $valor=round($pago['valor_entidad']);	

        ?><tr class="<?=$style?>">            
	      <td><? print $pago['razon_social']?></td>	                  
	      <td><? print $pago['fecha_reembolso']?></td>
	      <td align="right"><? print number_format($valor)?></td>
		<td align="center"><input type="checkbox" name="<? echo 'reembolso['.$pago['id_cliente'].']['.$pago['fecha_reembolso'].']';?>"></td>
	  </tr>
       <?
    }
 } else if(count($pagos)==0){?>
      <td align="center"> <b>No hay Registros </td><?
   }else if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td><?
   }

?>
<!--<?php //echo url_for('frontPagos/imprimirChequeReembolso?accion=imprimir&id_cartera='.$pago['id_cartera'].'&fecha='.$pago['fecha_reembolso'].'&valor='.number_format($pago['valor_entidad']).'&opc=1')?>-->
</tr>
<tr>
<td colspan=4 class="mensaje">
Imprima primero la relacion Adjunta y luego el cheque
<input type="button" name="imprimirRel" value="Imprimir Relación Adjunta" onClick='javascript:document.cheque.opcion.value=2;document.cheque.accion.value="imprimir";document.cheque.submit();'>
<input type="button" name="imprimir" value="Imprimir Cheque Davivienda" onClick='javascript:document.cheque.opcion.value=1;document.cheque.accion.value="imprimir";document.cheque.submit();'>
<input type="button" name="imprimir" value="Imprimir Cheque Banco Bogotá" onClick='javascript:document.cheque.opcion.value=3;document.cheque.accion.value="imprimir";document.cheque.submit();'></td>



 <!--<td align="center"> <a  href="javascript:validar_campos('<?php echo $id_cartera?>','<?php echo $fecha?>','<?php echo $valor?>','1')"> <img src="<?=image_path('ico_impresora.gif')?>" border=0></img></a></td>	     	      
	      <td align="center"> <a  href="javascript:validar_campos('<?php echo $id_cartera?>','<?php echo $fecha?>','<?php echo $valor?>','2')"> <img src="<?=image_path('ico_impresora.gif')?>" border=0></img></a></td>-->
</tr>
</table>
</body>
<script>
function validacion(){
var mensaje=<?php echo $mens;?>;
if(mensaje=='11')
{
alert('Ha escogido clientes diferentes para imprimir, por favor corrija sus datos');
}
if(mensaje=='12')
{
alert('Debe selecccionar por lo menos un item para imprimir, por favor corrija sus datos');
}
}
</script>
<script>
function validar_campos(id_cartera,fecha_reem,valor,opc){
   //alert("si"+id_cartera+" "+fecha_reem+" "+valor)
   document.cheque.id_cartera.value=id_cartera;
   document.cheque.fecha_reemb.value=fecha_reem;
   document.cheque.valor.value=valor;
   document.cheque.opcion.value=opc;
   document.cheque.accion.value="imprimir";
   //document.cheque.b.value="imprimir";
   //document.cheque.action="imprimirChequeReembolso?accion=imprimir&id_cartera="+id_cartera+"&fecha="+fecha_reem+"&valor="+valor+"&opc=1'";
   document.cheque.action="imprimirChequeReembolso";
   
   var error=0
   if(opc==1 ){
		if(document.cheque.fecha_impresion.value==""){
		 alert("Ingrese fecha de impresi\xF3n del cheque.")
		 error=1;
		}
   }else if(opc==2){
		if(document.cheque.nro_cheque.value=="" || document.cheque.banco.value=="" || document.cheque.fecha_impresion.value=="" ){
			alert("Ingrese Nro. Cheque,nombre del banco y fecha para imprimir la relaci\xF3n adjunta.")
			error=1;
		}
  }
   
   if(error==0)
    if(confirm("Los valores ingresados en la parte superior se imprimiran en el documento. Desea continuar?"))
     document.cheque.submit();
  
}

//para recalcular las ventanas
  //var vp = parent.Ext.getCmp("main-container");
  //vp.doLayout();
</script>


