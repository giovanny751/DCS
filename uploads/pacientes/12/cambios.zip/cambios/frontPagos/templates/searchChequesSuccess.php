<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align="center"}
</style>

<h1>Confirmar Cheques/Fax-Cheque</h1>

<center><br><br>
<form action="<?php echo url_for('frontPagos/searchCheques') ?>" method="get">
<table align="center" border=0 width="530px">
  
   <tr> 
      <td><b>Estado</td>
      <td><select name="estado" id="estado">        
        <option value="0">Por Confirmar</option>
        <option value="3">Devueltos</option>        
      </select></td>
	<td>&nbsp;&nbsp;&nbsp;</td>  
	  <td align="right"><b>Forma de Pago &nbsp;&nbsp;</td>
      <td><select name="forma_pago">
        <option value="">SELECCIONE...<option>
        <option value="1">CHEQUE</option>
        <option value="4">FAX-CHEQUE</option>
        </select>
	 </td>
	  
     <td colspan="2"> <input type="submit" value="Buscar" /> </td>
    </tr>

 <!--  <tr>
      <td><b>Cartera</td>
      <td><?//$cartera['id_cartera']->render()?></td>     
    </tr>
   <tr>
	<td><b>c&eacute;dula / Expediente</td>
        <td> <input type="text" name="keywords" id="search_keywords" /></td> </tr>
   <tr>
     <td colspan="2"> <input type="submit" value="Buscar" /> </form> </td>
   </tr>-->
</table>
</form> 

<br><br>

<form action="<?php echo url_for('frontPagos/cruzarCheques') ?>" method="get" name="cheques">
<table border=0 width="90%">
<tr class="listheading" >
<?if($mensaje=="" and count($cheques)>0 ){?>
  <td><b>Recibo</td><td><b>Cartera</td><td><b>Fecha</td><td><b>PGO</td><td><b>Estado</td><td><b>Forma de Pago</td><td><b>Monto</td> <td><b>ESP</td> <td><b>Asesor</td>
  <td><b>Banco</td><td><b>Verificar</td><td width="60px"><b>Devolver</td><td width="60px"><b>Anular</td></tr>

<?$style="listrow0";
   foreach ($cheques as $cheque){ 
	if($style=="listrow1")$style="listrow0"; else $style="listrow1";      	

        ?><tr class="<?=$style?>">
              <td><? print $cheque['id_pago'];?></td>	      
              <td><? print $cheque['cartera'];?></td>	      
              <td><? print $cheque['fecha_fp'];?></td>
      	      <td><? print $cheque['por_concepto'];?></td>
	      <td><? print $cheque['estado']?></td>              
	      <td width="10%"><? print $cheque['forma_pago']?></td>
	      <td align="right"><? print number_format($cheque['valor'])?></td>
	      <td>&nbsp;</td>
	      <td><? print $cheque['codigo_asesor']?></td>
	      <td><? print $cheque['banco']?></td>
<?php if($cheque['estado']=='POR CONFIRMAR'){?>
              <td align="center" width="50px"><input type="checkBox" name="cheque[]" value="<?=$cheque['id_forma_pago']?>"></td>              
              <td align="center"><input type="checkBox" name="fp_devuelto[]" value="<? print $cheque['id_forma_pago'];?>"></td>
              <td align="center"><input type="checkBox" name="fp_anulada[]" value="<? print $cheque['id_forma_pago'];?>"></td>
<?php }else {?> <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><? } ?>
			  <input type="hidden" name="id_pagos[]"  value="<? print $cheque['id_pago'];?>"><!--envia todos los pagos chequeados o no-->
         </tr>
       <?
    }
 } else if(count($cheques)==0){?>
      <td align="center"> <b>No hay Registros </td><?
   }else if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td><?
   }


?>

</tr>
</table>
<br>
<?if(count($cheques)>0){?>
<input type="button"  value="Guardar" onclick="verificar()" >
<?}?>



<script>
  function verificar(){
    if(confirm("Esta seguro de verificar los pagos seleccionados?"))
     document.cheques.submit(); 
  }
</script>


</form>

