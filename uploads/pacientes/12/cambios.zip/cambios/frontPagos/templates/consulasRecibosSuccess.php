<?php

switch ($_POST['action']) {
    case 'sinaprobar':

        $id = "in ( " . $_POST['ids'] . ")";
        $sql = "update gca_pagos set devolucion_tesoreria='SI',estado=0 where id " . $id;
        echo $sql;
        frontPagosActions::executeConsultasInsert($sql);

        break;
    case 'buscar':
        $sql2 = " select credenciales from gca_datos_funcionarios where id_empleado=$permisos ";
        $credenciales = frontPagosActions::executeConsultasConsul($sql2);
        $credenciales = $credenciales[0]['credenciales'];


        $where = "1=1 ";
        if ($_POST['estado'] != "") {
            $where.=" and gca_pagos.estado='" . $_POST['estado'] . "'";
        }
        if ($_POST['f_final'] != '' && $_POST['f_inicial'] != '') {
            $where.=" and gca_pagos.fecha between ('" . $_POST['f_inicial'] . " 00:00:01') and ('" . $_POST['f_final'] . " 23:59:59')";
        } else {
            if ($_POST['f_final'] != "") {
                $where.=" and gca_pagos.fecha < '" . $_POST['f_final'] . " 23:59:59'";
            }
            if ($_POST['f_inicial'] != "") {
                $where.=" and gca_pagos.fecha > '" . $_POST['f_inicial'] . " 00:00:01'";
            }
        }
        if ($_POST['cartera'] != "") {
            $where.=" and id_cartera='" . $_POST['cartera'] . "'";
        }
        if ($_POST['cedula'] != "") {
            $where.=" and cedula='" . $_POST['cedula'] . "'";
        }
        $SQL = " select '$credenciales' credenciales,gca_pagos.*,gca_forma_pago.forma_pago,gca_forma_pago.valor,gca_banco.nombre bancos,gca_formas_de_pago.descripcion,gca_cartera.nombre cartera "
                . " from gca_pagos "
                . " join gca_forma_pago on gca_forma_pago.id_gca_pagos=gca_pagos.id "
                . " join gca_cartera on gca_cartera.id=gca_pagos.id_cartera "
                . " left join gca_banco  on gca_forma_pago.id_banco=gca_banco.id "
                . " left join gca_formas_de_pago on gca_formas_de_pago.id=gca_forma_pago.forma_pago "
                . " where $where  and gca_forma_pago.medio_pago=1 limit 200";
        $datos = frontPagosActions::executeConsultasConsul($SQL);
        echo json_encode($datos);
        break;
    case 'activar':
        echo $cantidad = count($_POST['aprobar_che']);
        for ($j = 0; $j < $cantidad; $j++) {
            $info = explode(' :: ', $_POST['aprobar_che'][$j]);
//            if ($info[1] == 'UP') {
//                $sql = "update gca_obligacion set saldo_mora=0, estado='6' where obligacion='" . $info[2] . "'";
//                frontPagosActions::executeConsultasInsert($sql); 
//            }
            if ($info[1] == 'UP') {
                $sql = "update gca_obligacion set id_causal='6', estado_causal='Cancelar' where obligacion='" . $info[2] . "'";
                frontPagosActions::executeConsultasInsert($sql);
                $sql="insert into gca_cambios_estado_deudores (cedula,obligacion,estado,causal,fecha,usuario)"
                        . "values ("
                        . "'".$info[4]."',"
                        . "'".$info[2]."',"
                        . "'Cancelar',"
                        . "'PAGO',"
                        . "'".date('Y-m-d')."',"
                        . "'".$id_user."'"
                        . ")";
                frontPagosActions::executeConsultasInsert($sql);
            }
            $sql = "select gca_obligaciones_pagos.*,gca_pagos.id_condonacion "
                    . "from gca_obligaciones_pagos join gca_pagos on gca_pagos.id=gca_obligaciones_pagos.id_pago  where id_pago=" . $info[0];
            $datos = frontPagosActions::executeConsultasConsul($sql);
            for ($i = 0; $i < count($datos); $i++) {
                $sql = "select id,obligacion,saldo_mora,saldo_capital, interes_mora,fecha_calculo_mora "
                        . "from gca_obligacion where  obligacion='" . $datos[$i]['obligacion']."'";
                $datos_obligacion = frontPagosActions::executeConsultasConsul($sql);
                if($datos_obligacion[0]['interes_mora']<$datos[$i]['entidad'] ){
                    $mora=0;
                    $resul=$datos[$i]['entidad']-$datos_obligacion[0]['interes_mora'];
                    $saldo_c=$datos_obligacion[0]['saldo_capital']-$datos[$i]['entidad'];
                    $dd=' , saldo_capital='.$saldo_c;
                }else if($datos_obligacion[0]['interes_mora']>$datos[$i]['entidad'] ){
                    $mora=$datos_obligacion[0]['interes_mora']-$datos[$i]['entidad'];
                    $dd='';
                    $resul=0;
                    $saldo_c=$datos_obligacion[0]['saldo_capital'];
                }
                
                if ($info[1] == 'UP') {
                $sql = "update gca_obligacion set fecha_actualizacion_causal='".date('Y-m-d')."',interes_mora='0' , saldo_capital='0',saldo_mora=0 where obligacion=" . $datos[$i]['obligacion'];
                }else{
                $sql = "update gca_obligacion set fecha_actualizacion_causal='".date('Y-m-d')."',interes_mora='$mora' $dd,saldo_mora=saldo_mora-" . $datos[$i]['entidad'] . " where obligacion=" . $datos[$i]['obligacion'];    
                }
//                frontPagosActions::executeConsultasInsert($sql);
                
    
                
//                //  se mueven los estados de las condonaciones para reducir los valores
//                $sql = "update gca_detalle_solicitud set  	total_condonacion_pago=total_condonacion_pago-" . $datos[$i]['entidad'] . " where obligacion=" . $datos[$i]['obligacion'];
                frontPagosActions::executeConsultasInsert($sql);
                
                if ($info[1] == 'UP') {
                $sql = "insert into gca_obligacion_movimiento (obligacion,saldo_mora,saldo_capital,interes_mora,fecha_corte,detalle,id_pago)"
                        . "values ('" . $datos[$i]['obligacion'] . "','" . 0 . "','". 0 ."','" . 0 . "','" . date('Y-m-j') . "','PAGOS','".$info[0]."') ";
                }else{
                    $sql = "insert into gca_obligacion_movimiento (obligacion,saldo_mora,saldo_capital,interes_mora,fecha_corte,detalle,id_pago)"
                        . "values ('" . $datos[$i]['obligacion'] . "','" . $datos[$i]['entidad'] . "','".$saldo_c."','" . $mora . "','" . date('Y-m-j') . "','PAGOS','".$info[0]."') ";
                }
                frontPagosActions::executeConsultasInsert($sql);
            }
            $sql = "select max(nro_rc) recibido from gca_pagos  ";
            $datos = frontPagosActions::executeConsultasConsul($sql);
            $sql = "update gca_pagos set fecha='".date('Y-m-d H:i:s')."',estado=2,nro_rc='".($datos[0]['recibido']+1)."',devolucion_tesoreria='' where id=" . $info[0];
            frontPagosActions::executeConsultasInsert($sql);
        }
        break;
    case 'reporte_mensual':
        $sql = "select nombre,sucursal,count(id),sum(saldo_capital) capital,sum(saldo_mora) saldo_mora
                from (
                select gca_cartera.nombre,gca_obligacion.sucursal,gca_obligacion.id,
                gca_obligacion.saldo_mora,gca_obligacion.saldo_capital
                from gca_obligacion
                join gca_cartera on gca_cartera.id=gca_obligacion.id_cartera) tabla1
                group by nombre,sucursal";
        $datos = frontPagosActions::executeConsultasConsul($sql);
        echo json_encode($datos);
        break;
}
?>