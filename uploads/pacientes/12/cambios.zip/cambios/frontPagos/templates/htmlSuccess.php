<object type="application/x-java-applet" id="PrintingApplet" 
	code="org/sgm/applets/PrintingApplet.class"  archive="/portal/web/java/postgresql-9.2-1002.jdbc3.jar,/portal/web/java/PrintingApplet.jar" 	
	height="150" width="700"  /> 	
		<param name="urlBase" value="http://192.168.2.5/portal/web/java/" />
		<param name="fecha_desde" value="" />
		<param name="fecha_hasta" value="" />
		<param name="sucursal" value="10733" />
		<param name="recibos" value=" AND op.id_ar >= 100000 AND op.id_ar <=100020" />
</object>
