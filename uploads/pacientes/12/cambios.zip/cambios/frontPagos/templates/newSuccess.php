<h1>Nuevo Pago</h1>

<?php include_partial('pagos', array('form' => $form, 'honorarios' => $honorarios, 'iva' => $iva, 'formulario'=>$formulario, 'deudor'=>$deudor,'departamento'=>$departamento,'is_tesorero'=>$is_tesorero ,'is_tesorero_sucursal'=>$is_tesorero_sucursal,'is_analista'=>$is_analista)) ?>
