<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; }
</style>

<!--<h1>Buscar Pagos</h1>-->

<center><p class="mensajes"> Elija una Cartera*** <p> 
<table align="center" border="0">
  <form action="<?php echo url_for('frontPagos/search') ?>" method="get" name="gca_pagos">
  <?php 
   if($estado==1)$select_1="selected";
   if($estado==2)$select_2="selected";
   if($estado==5)$select_5="selected";
    if($is_tesorero==true or $is_tesorero_sucursal==true){?>   
    <tr>
      <td><b>Estado</td>	  
      <td><select name="estado" id="estado">
       <!--    <option value="0">SIN APROBAR</option>	-->
	<option value="">SELECCIONE...<option>	
        <option value="1"  <?php echo $select_1?> >APROBADO</option>
        <option value="2"  <?php echo $select_2?>>REGISTRADO</option>
 	<option value="5"  <?php echo $select_5?>>REEMBOLSO</option>
       <!-- <option value="6">ANULADOS</option>
        <option value="3">RECHAZADOS</option>	-->	
      </select></td>
    </tr>
<?php }?>
 
   <tr>
	<td><b>Nro Pago / C&eacute;dula /<br> Obligaci&oacute;n</td>
        <td> <input type="text" name="keywords" id="search_keywords" /></td> 
      <td><b>Cartera</td>
      <td><?php echo $form['id_cartera']->render()?></td> 
      </tr>

   <tr>	<td><b>Fecha Desde:</td><td><input type="text" name="fechadesde__String" id="fechadesde_String" value="<?php print $fecha_ini?>" /></td>
	<td><b>Fecha Hasta:</td><td><input type="text" name="fechahasta__String" id="fechahasta_String" value="<?php print $fecha_fin?>" />
	<input type="submit" value="Buscar" /> 
   </td>
   </tr>
  
</table>
</form> 

<br><br>


<table border=0 width="850px">
<tr class="listheading" >
<?


if($mensaje=="" and count($pagos)>0 ){?>
  <th width="50px"><b>Num pago</th> <th width="200px"><b>Cartera</th> <th width="80px"><b>Estado</th><th width="160px"><b>Fecha de Recibo</th><th width="80px"><b>C&eacute;dula</th><th width="180px"><b>Obligaci&oacute;n</th> 
  <?php

 //if($estado!=6 && $is_tesorero=='true'){?>
  <th width="50px"><b>Anular</th><th width="50px"><b>Imprimir</th><th width="50px"><b>Eliminar</th>
  <?php //}?>
  </tr>

<?$style="listrow0"; $anular=0;
  
   foreach ($pagos as $pago){ 
	if($style=="listrow1")$style="listrow0"; else $style="listrow1";      

        ?><tr class="<?=$style?>">
             <td><? //pueden editarse pagos reg, solo si tiene perm el usr			 
              if($pago['estado']<=1 or ( $pago['estado']==2 and $editarPagosReg==true and $pago ['id_ar']==""))
			    { 
				   /*if($pago['estado']==0){//pagos por aprobar
					?><a href="<?php echo url_for('frontPagos/edit?id='.$pago['id_pago']) ?>">   <?php  }
				   else{//aprobados por el coord(estado=1) o ya registrados*/				   
				   
				?> <a href="<?php echo url_for('frontPagos/editarPagosTesorero?id='.$pago['id_pago'].'&estado='.$estado.'&cartera_elejida='.$id_cartera)?>">  <? 
					  //} 
				   if($pago['nro_rc']!="")print $pago['nro_rc']; else print $pago['id_pago'];?></a> <?
			    }else{ if($pago['nro_rc']!="")print $pago['nro_rc']; else print $pago['id_pago'];} ?>
             </td>	
			<td><? print $pago['nombre'];?></td>			 
              <td><? if($pago['estado']==0) $pgo="Por Aprobar";
                     elseif($pago['estado']==1) $pgo="Aprobado";
                     elseif($pago['estado']==2) $pgo="Registrado"; 
					 elseif($pago['estado']==5) $pgo="Reembolso"; 
					 elseif($pago['estado']==6) $pgo="Anulado"; 
					 print $pgo ;?></td>
              <td><? if($pago['estado']<=1) print $pago['fecha'];
		     else print $pago['fecha_recibo'];	?>
	      </td>
	      <td><? print $pago['cedula']?></td>
	      <td><? print $pago['obligacion']?></td>
	      		  
		
		<?php //print ".". $pago['estado_fp'];
		if( ($pago['estado']>=2  && $pago['estado']<5 &&  $pago['estado_fp']!=2 &&  $pago['estado_fp']!=3 ) && ($is_tesorero=='true' or $is_tesorero_sucursal=='true' )){ $anular++;?>
			<td align="center">			  
			  <form  action="<?php echo url_for('frontPagos/anular') ?>" method="get" name="pagos">
				<input type="checkBox" name="anular[]" value="<?php print $pago['id_pago'];?>">				
			</td>
			<td align="center"> 					
				<a href="<?php echo url_for('frontPagos/search?accion=imprimir&id='.$pago['id_pago'])?>">  
				<img src="<?=image_path('ico_impresora.gif')?>" border=0></img>  </a>
			</td>	
		 <?}else{?> <td align="center">&nbsp;x</td> 
		 <?php if(($is_tesorero or $is_tesorero_sucursal)  and ($pago['estado']==2 &&  $pago['estado_fp']!=2 &&  $pago['estado_fp']!=3 || $pago['estado']==5)){ ?>
		    	<td align="center"> 					
				<a href="<?php echo url_for('frontPagos/search?accion=imprimir&id='.$pago['id_pago'])?>">  
				<img src="<?=image_path('ico_impresora.gif')?>" border=0></img>  </a>
			</td>
		   <?php 
		 	}else{?>  <td align="center">&nbsp;x</td> <? }
		 }

		if( ($pago['estado']==1  or $pago['estado']==0)&&($is_tesorero=='true' or $is_tesorero_sucursal=='true' )){  $anular++;?>
			<td align="center">			  
			  <form  action="<?php echo url_for('frontPagos/eliminar') ?>" method="post" name="pagos">
				<input type="checkBox" name="eliminar[]" value="<?php print $pago['id_pago'];?>">				
			</td><?php
		}else{?>  <td align="center">&nbsp;x</td> <? }

?>


	  			  			 
         </tr>
       <?
    }
 } else if(count($pagos)==0){?>
      <td align="center"> <b>No hay Registros para la cartera seleccionada</td><?
   }else if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td><?
   }


?>

</tr>
</table>



<br><br>
<?if(count($pagos)!=0 and $anular>0){

//var_dump($_SERVER);
?>
<input type="button" value="Anular/Eliminar" name="guardar" onClick="javascript:verificar()"/>
 </form>
<?}?>



<script type="text/javascript">
  function verificar(){
    if(confirm("Esta seguro de Anular/Eliminar los pagos seleccionados?")){
	var kw=document.gca_pagos.keywords.value
        var fd=document.gca_pagos.fechadesde__String.value
        var fh=document.gca_pagos.fechahasta__String.value
 	var cartera=document.gca_pagos.gca_pagos_id_cartera.value
	var link="";
	if(document.gca_pagos.keywords.value!=''  && document.gca_pagos.keywords.value!=undefined) link+="/keywords/"+kw;
	if(document.gca_pagos.fechadesde__String.value!='' && document.gca_pagos.fechadesde__String.value!=undefined) link+="/fecha_desde/"+fd;
	if(document.gca_pagos.fechahasta__String.value!='' && document.gca_pagos.fechahasta__String.value!=undefined) link+="/fecha_hasta/"+fh;
	if(document.gca_pagos.gca_pagos_id_cartera.value!='' && document.gca_pagos.gca_pagos_id_cartera.value!=undefined) link+="/id_cartera/"+cartera;


//http://localhost/portal/web/administracion_dev.php/frontPagos/eliminar


     // document.pagos.action=document.pagos.action+"/keywords="+kw+"/fecha_desde="+fd+"/fecha_hasta="+fh+"/id_cartera="+cartera;
 	document.pagos.action=document.pagos.action+link;

//alert(document.pagos.action+link)
       document.pagos.submit(); 
    }
  }


    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "fechadesde_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	Calendar.setup({
        inputField     :    "fechahasta_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
</script>

