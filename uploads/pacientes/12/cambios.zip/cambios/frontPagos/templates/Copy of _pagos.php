<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
</style>
<form  method="post" action="<?php echo url_for('frontPagos/create')?>">


<input type="hidden" name="honorarios" id="honorarios" value="0.2">
<input type="hidden" name="ban_expediente" id="ban_expediente" value="2">
<input type="hidden" name="formas_fecha_year" id="" value="2">

<table class="nuevo">
  <tr>
      <th>Deudor:</th>
      <td><div id="deudor">Digite N&uacute;mero de Obligaci&oacute;n y Seleccione carteraddddddddddddddddddd</div></td>
    </tr>
  
	<tr>	
	  <tr>
    <th><?php echo ($form['obligacion']->renderLabel()) ?>: </th>
      <td><?php echo ($form['obligacion']->render()) ?> </td>
    </tr>
	
	<th><?php echo ($form['id_cartera']->renderLabel())?>:</th>
      <td><?php echo ($form['id_cartera']->render())?></td>
    </tr>
    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?>: </th>
      <td><?php echo ($form['por_concepto']->render()) ?> </td>    
    </tr>

</table>
<?php $nombre_forma="Formas";       
  //echo $form->renderHiddenFields();
?>

<table border="0" align="left" ><tr><td>

<table class="nuevo" border="0" align="left">
    <tr class="listheading">
      <!--<th width="50px"><?php// echo ($form['Formas']['medio_pago']->renderLabel()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
     <!-- <th><?//php echo ($form['Formas']['producto']->renderLabel()) ?> </th>-->
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>
      <th width="145px"><?php echo ($form['Formas']['fecha']->renderLabel()) ?> </th>      
      <th><?php echo ($form['Formas']['entidad']->renderLabel()) ?> </th>
	  <th><?php echo ($form['Formas']['cpm']->renderLabel()) ?> </th>   
	  <th><?php echo ($form['Formas']['honorarios']->renderLabel()) ?> </th>      	  
      <th><?php echo ($form['Formas']['iva']->renderLabel()) ?> </th>      
      
      
    </tr>
    <tr>
      <!--<th><?php //echo ($form['Formas']['medio_pago']->render()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->render()) ?> </th>
      <!--<th><?//php echo ($form['Formas']['producto']->render()) ?> </th>-->
     
      <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" size="10"/>	  
      <input type="hidden" id="gca_pagos_Formas_valor" name="gca_pagos[Formas][valor]" /></th>
      <th><?php echo ($form['Formas']['fecha']->render()) ?> </th>	 	  
	  <?php 
	  echo ($form['Formas']['entidad']->render());
	  echo ($form['Formas']['honorarios']->render());
	  echo ($form['Formas']['cpm']->render());
	  echo ($form['Formas']['iva']->render());
	  ?> 
	  
	  <th><input type="text" id="gca_pagos_Formas_entidadT" name="gca_pagos_Formas_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>)" size="10"/>
	  <th><input type="text" id="gca_pagos_Formas_cpmT" name="gca_pagos_Formas_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" />          
	  <th><input type="text" id="gca_pagos_Formas_honorariosT" name="gca_pagos_Formas_honorariosT" size="10" readonly/>      
	  <th><input type="text" id="gca_pagos_Formas_ivaT" name="gca_pagos_Formas_ivaT" size="10" readonly />      
	  <input type="hidden" id="gca_pagos_Formas_medio_pago" name="gca_pagos[Formas][medio_pago]" value="1"  />      
      </tr>    
    <tr>
    <!--  <th><?php //echo ($form['Formas2']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas2']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['num_cheque']->render()) ?> </th>
      
      <th><input type="text" id="gca_pagos_Formas2_valorT" name="gca_pagos_Formas2_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" size="10"/>
      <input type="hidden" id="gca_pagos_Formas2_valor" name="gca_pagos[Formas2][valor]"/></th>		
      <th><?php echo ($form['Formas2']['fecha']->render()) ?> </th>	
	  <th><input type="text" id="gca_pagos_Formas2_entidadT" name="gca_pagos_Formas2_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>)" size="10"/>
	  <th><input type="text" id="gca_pagos_Formas2_cpmT" name="gca_pagos_Formas2_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" />           
	  <th><input type="text" id="gca_pagos_Formas2_honorariosT" name="gca_pagos_Formas2_honorariosT" size="10" readonly/>	  
	  <th><input type="text" id="gca_pagos_Formas2_ivaT" name="gca_pagos_Formas2_ivaT" size="10" readonly />
	 <input type="hidden" id="gca_pagos_Formas2_medio_pago" name="gca_pagos[Formas2][medio_pago]" value="1"  />   
	<?php 
	  echo ($form['Formas2']['entidad']->render());
	  echo ($form['Formas2']['iva']->render());
	  echo ($form['Formas2']['honorarios']->render());
	  echo ($form['Formas2']['cpm']->render());?> 	  
    </tr>	
	
    <tr>
      <!--<th><?php//echo ($form['Formas3']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas3']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['num_cheque']->render()) ?> </th>      
      <th><input type="text" id="gca_pagos_Formas3_valorT" name="gca_pagos_Formas3_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" size="10"/>
      <input type="hidden" id="gca_pagos_Formas3_valor" name="gca_pagos[Formas3][valor]" /></th>
      <th><?php echo ($form['Formas3']['fecha']->render()) ?> </th>  
	  <th><input type="text" id="gca_pagos_Formas3_entidadT" name="gca_pagos_Formas3_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" size="10"/>
	  <th><input type="text" id="gca_pagos_Formas3_cpmT" name="gca_pagos_Formas3_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" />           
	  <th><input type="text" id="gca_pagos_Formas3_honorariosT" name="gca_pagos_Formas3_honorariosT" size="10" readonly/>	  
	  <th><input type="text" id="gca_pagos_Formas3_ivaT" name="gca_pagos_Formas3_ivaT" size="10" readonly />
	  <input type="hidden" id="gca_pagos_Formas3_medio_pago" name="gca_pagos[Formas3][medio_pago]" value="1"  />   
	  <?php 
	  echo ($form['Formas3']['entidad']->render());
	  echo ($form['Formas3']['iva']->render());
	  echo ($form['Formas3']['honorarios']->render());
	  echo ($form['Formas3']['cpm']->render());?> 	  
    </tr>
	<?php 
	//ocultos del formulario formaPago... por katty*** 
	/*echo ($form['Formas']['id']->render());
	echo ($form['Formas']['id_gca_pagos']->render());*/
        echo ($form['Formas']['estado']->render());	
        echo ($form['Formas2']['estado']->render());	
        echo ($form['Formas3']['estado']->render());			
	 ?> 

</table>

<?php 
	//ocultos del formulario formaPago... por katty*** 
	//echo ($form['Formas']['id']->render());
	echo ($form['fecha']->render());
	//echo ($form['Formas']['id_gca_pagos']->render());
       // echo ($form['Formas']['estado']->render());
	/*echo ($form['Formas2']['id']->render());
	echo ($form['Formas2']['id_gca_pagos']->render());
      //  echo ($form['Formas2']['estado']->render());
	echo ($form['Formas3']['id']->render());
	echo ($form['Formas3']['id_gca_pagos']->render());
       // echo ($form['Formas3']['estado']->render());*/
	 ?>


<br>
<table  class="nuevo" border=0 align="right" width="250px">
  <tr>    
    <th class="listheading" width="120px">&nbsp;&nbsp;<?php echo ($form['entidad']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT" onkeyup="recalcularValores()" />
        <input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" />
	</th>    
	<th>&nbsp;</th>
   </tr>
  <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['cpm']->renderLabel())?>: </th>
	<th><input type="text" id="gca_pagos_cpm" name="gca_pagos[cpm]" value="0" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/> </th>
	<th>&nbsp;</th>
  </tr>
  <tr>    
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['otros']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_otros" name="gca_pagos[otros]" value="0" onkeyup="calcular(<?php echo $honorarios.', '.$iva; ?>);"/> </th>
	<th>&nbsp;</th>
  </tr>    
  <tr>   
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['honorarios']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" readonly />
        <input type="hidden" id="gca_pagos_honorarios" name="gca_pagos[honorarios]" />
        </th>
    <th><div id="porcentaje_honorarios"><?php echo ($honorarios*100).'%';?></div></th>
  </tr>
  <tr>   
    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['iva']->renderLabel())?>: </th>
    <th><?php echo ($form['iva']->render()) ?> </th>
    <th><?php echo ($iva*100).'%'; ?></th>
  </tr>      
  <tr>
    
    <th class="listheading"><font color="yellow">&nbsp;&nbsp;<?php echo ($form['valor_total']->renderLabel())?>: </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" readonly/>
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]" /> </th>
  </tr>  
  
  <tr>
    <td colspan="3" align="center"> 
	<br> <input type="button" value="Guardar" name="guardar" onClick="javascript:validar_expediente()"/></td></tr>  
</table>
</td>
</tr>
</table>


<!--<input type="hidden" value="<?php echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>-->
<?echo $form->renderHiddenFields(); ?>
<input type="hidden" name="formulario" value="<?print $formulario?>">
</form>
<script>
function calcular(honorarios, ivaP){
var honorarios=document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera
  var entidad = document.getElementById("gca_pagos_entidad");
  var entidadT = document.getElementById("gca_pagos_entidadT");  
  var total = document.getElementById("gca_pagos_valor_total");
 
   
  var f1 = document.getElementById("gca_pagos_Formas_valorT").value == ''?0:document.getElementById("gca_pagos_Formas_valorT").value.replace(/,/g,'');
  var  valorForma1=document.getElementById("gca_pagos_Formas_valor").value = f1;//.replace(/,/g,'');
  //valorForma1=document.getElementById("gca_pagos_Formas_valor").value = f1.replace(/,/g,'');
  document.getElementById("gca_pagos_Formas_valorT").value = CurrencyFormatted(f1);

  var f2 = document.getElementById("gca_pagos_Formas2_valorT").value == ''?0:document.getElementById("gca_pagos_Formas2_valorT").value.replace(/,/g,'');
  var valorForma2=document.getElementById("gca_pagos_Formas2_valor").value = f2;//.replace(/,/g,'');
  //valorForma2=document.getElementById("gca_pagos_Formas2_valor").value = valorForma2.replace(/,/g,'');
  document.getElementById("gca_pagos_Formas2_valorT").value = CurrencyFormatted(f2); 

  var f3 = document.getElementById("gca_pagos_Formas3_valorT").value == ''?0:document.getElementById("gca_pagos_Formas3_valorT").value.replace(/,/g,'');
  var valorForma3=document.getElementById("gca_pagos_Formas3_valor").value = f3;//.replace(/,/g,'');
  //valorForma3=document.getElementById("gca_pagos_Formas3_valor").value = valorForma3.replace(/,/g,'');
  document.getElementById("gca_pagos_Formas3_valorT").value = CurrencyFormatted(f3);  
  
  otros = document.getElementById("gca_pagos_otros").value == ''?0:document.getElementById("gca_pagos_otros").value;
  cpm = document.getElementById("gca_pagos_cpm").value == ''?0:document.getElementById("gca_pagos_cpm").value;
  document.getElementById("gca_pagos_cpm").value = CurrencyFormatted(cpm);
 

  //calculos parciales por cada forma de pago 
  var valor_entidadForma1=Math.round(parseFloat((valorForma1 - parseFloat(otros))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpm)))); 
  var valor_honorariosForma1=Math.round(valor_entidadForma1*parseFloat(honorarios))
  
  
  //alert(valorForma1) 
  //alert(valor_entidadForma1);
  //alert(valor_honorariosForma1);//7367179
  
  document.getElementById("gca_pagos_Formas_entidadT").value=CurrencyFormatted(valor_entidadForma1)
  document.getElementById("gca_pagos_Formas_entidad").value=valor_entidadForma1   
  document.getElementById("gca_pagos_Formas_honorariosT").value=CurrencyFormatted(valor_honorariosForma1)
  document.getElementById("gca_pagos_Formas_honorarios").value=valor_honorariosForma1
  document.getElementById("gca_pagos_Formas_ivaT").value=CurrencyFormatted(Math.round(valor_honorariosForma1*parseFloat(ivaP)))  
  document.getElementById("gca_pagos_Formas_iva").value=Math.round(valor_honorariosForma1*parseFloat(ivaP))  
  var cpm1=document.getElementById("gca_pagos_Formas_cpmT").value.replace(/,/g,'');
  document.getElementById("gca_pagos_Formas_cpm").value=cpm1.replace(/,/g,'');
    
  //forma2
  var valor_entidadForma2=Math.round(parseFloat((valorForma2 - parseFloat(otros))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpm)))); 
  var valor_honorariosForma2=Math.round(valor_entidadForma2*parseFloat(honorarios))
  document.getElementById("gca_pagos_Formas2_entidadT").value=CurrencyFormatted(valor_entidadForma2)
  document.getElementById("gca_pagos_Formas2_entidad").value=valor_entidadForma2
  document.getElementById("gca_pagos_Formas2_honorariosT").value=CurrencyFormatted(valor_honorariosForma2)
  document.getElementById("gca_pagos_Formas2_honorarios").value=valor_honorariosForma2
  document.getElementById("gca_pagos_Formas2_ivaT").value=CurrencyFormatted(Math.round(valor_honorariosForma2*parseFloat(ivaP)))
  document.getElementById("gca_pagos_Formas2_iva").value=Math.round(valor_honorariosForma2*parseFloat(ivaP))
  var cpm2=document.getElementById("gca_pagos_Formas2_cpmT").value.replace(/,/g,'');
  document.getElementById("gca_pagos_Formas2_cpm").value=cpm2.replace(/,/g,'');

  
  //formas3
  var valor_entidadForma3=Math.round(parseFloat((valorForma3 - parseFloat(otros))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpm)))); 
  var valor_honorariosForma3=Math.round(valor_entidadForma3*parseFloat(honorarios))
  document.getElementById("gca_pagos_Formas3_entidadT").value=CurrencyFormatted(valor_entidadForma3)
  document.getElementById("gca_pagos_Formas3_entidad").value=valor_entidadForma3
  document.getElementById("gca_pagos_Formas3_honorariosT").value=CurrencyFormatted(valor_honorariosForma3)
  document.getElementById("gca_pagos_Formas3_honorarios").value=valor_honorariosForma3
  document.getElementById("gca_pagos_Formas3_ivaT").value=CurrencyFormatted(Math.round(valor_honorariosForma3*parseFloat(ivaP)))
  document.getElementById("gca_pagos_Formas3_iva").value=Math.round(valor_honorariosForma3*parseFloat(ivaP))
  var cpm3=document.getElementById("gca_pagos_Formas3_cpmT").value.replace(/,/g,'');
  document.getElementById("gca_pagos_Formas3_cpm").value=cpm3.replace(/,/g,'');

//alert(document.getElementById("gca_pagos_Formas3_cpm").value)

  total.value = total.value == ''?0:total.value;  
  // total.value = parseFloat(document.getElementById("gca_pagos_Formas_valor").value.replace(/,/g,''))+ parseFloat( document.getElementById("gca_pagos_Formas2_valor").value.replace(/,/g,'')) + parseFloat(document.getElementById("gca_pagos_Formas3_valor").value.replace(/,/g,''));
  total.value = parseFloat(document.getElementById("gca_pagos_Formas_valor").value)+ parseFloat( document.getElementById("gca_pagos_Formas2_valor").value)+parseFloat(document.getElementById("gca_pagos_Formas3_valor").value);
  
  document.getElementById("gca_pagos_valor_totalT").value= CurrencyFormatted(total.value);
    
  entidad.value = Math.round(parseFloat((total.value - parseFloat(otros))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpm)))); 
  var valor_honorarios=Math.round(parseFloat(entidad.value) * parseFloat(honorarios));
  var valor_iva= Math.round(parseFloat(ivaP) * parseFloat(valor_honorarios),0);
   
  //alert("entidad="+entidad)
  document.getElementById("gca_pagos_entidadT").value=CurrencyFormatted(entidad.value); 
  document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valor_honorarios);    
  document.getElementById("gca_pagos_honorarios").value =valor_honorarios; 
  document.getElementById("gca_pagos_iva").value =valor_iva;  
}



/*recalcula valores totales, cuando se ingresan valores manuales para entidad, cpm y otros*/
function recalcularValores(){
	var honorarios=parseFloat(document.getElementById('honorarios').value); //document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera  
	var iva=parseFloat(0.16);
	var entidadT = parseFloat(document.getElementById("gca_pagos_entidadT").value);
	var total = parseFloat(document.getElementById("gca_pagos_valor_total").value);  
	var cpm= parseFloat(document.getElementById("gca_pagos_cpm").value);
	var otros= parseFloat(document.getElementById("gca_pagos_otros").value);
	
	restante=Math.round(total-entidadT-cpm-otros);
	
	if(restante>=0){
		valor_iva=Math.round(restante*iva);       
		valor_honorarios=Math.round(restante-valor_iva);

		document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valor_honorarios);
		document.getElementById("gca_pagos_iva").value=CurrencyFormatted(valor_iva);
	}else{
	  alert("El valor de la entidad, 4 x mil y otros, no debe superar la cantidad cancelada ") 
    }	  
}

/*Permite calcular valores totales,cuando se ingresan valores manuales para las formas de pago */
function calcularValores(porcHon,porcIva){ 
document.getElementById("gca_pagos_Formas_entidadT").value=CurrencyFormatted(document.getElementById("gca_pagos_Formas_entidadT").value)
document.getElementById("gca_pagos_Formas2_entidadT").value=CurrencyFormatted(document.getElementById("gca_pagos_Formas2_entidadT").value)
document.getElementById("gca_pagos_Formas3_entidadT").value=CurrencyFormatted(document.getElementById("gca_pagos_Formas3_entidadT").value)
var v1=document.getElementById("gca_pagos_Formas_entidadT").value;
var v2=document.getElementById("gca_pagos_Formas2_entidadT").value;
var v3=document.getElementById("gca_pagos_Formas3_entidadT").value;
var valorEntidad1=document.getElementById("gca_pagos_Formas_entidad").value=v1.replace(/,/g,'');
var valorEntidad2=document.getElementById("gca_pagos_Formas2_entidad").value=v2.replace(/,/g,'');
var valorEntidad3=document.getElementById("gca_pagos_Formas3_entidad").value=v3.replace(/,/g,'');
var valorTotalEntidad=parseFloat(valorEntidad1)+parseFloat(valorEntidad2)+parseFloat(valorEntidad3);
document.getElementById("gca_pagos_entidadT").value=CurrencyFormatted(valorTotalEntidad)
document.getElementById("gca_pagos_entidad").value=valorTotalEntidad;

//4 x mil... 
document.getElementById("gca_pagos_Formas_cpmT").value=CurrencyFormatted(document.getElementById("gca_pagos_Formas_cpmT").value)
document.getElementById("gca_pagos_Formas2_cpmT").value=CurrencyFormatted(document.getElementById("gca_pagos_Formas2_cpmT").value)
document.getElementById("gca_pagos_Formas3_cpmT").value=CurrencyFormatted(document.getElementById("gca_pagos_Formas3_cpmT").value)
var cpm1=document.getElementById("gca_pagos_Formas_cpmT").value;
var cpm2=document.getElementById("gca_pagos_Formas2_cpmT").value;
var cpm3=document.getElementById("gca_pagos_Formas3_cpmT").value;
var cpmForma1=document.getElementById("gca_pagos_Formas_cpm").value=cpm1.replace(/,/g,'');
var cpmForma2=document.getElementById("gca_pagos_Formas2_cpm").value=cpm2.replace(/,/g,'');
var cpmForma3=document.getElementById("gca_pagos_Formas3_cpm").value=cpm3.replace(/,/g,'');


//calculos sobre el valor a la entidad-4xmil

var total_f1=(document.getElementById("gca_pagos_Formas_valor").value)
var total_f2=(document.getElementById("gca_pagos_Formas2_valor").value)
var total_f3=(document.getElementById("gca_pagos_Formas3_valor").value)

//alert(total_f1)
var restante1=parseFloat(total_f1-valorEntidad1-cpmForma1)
var restante2=parseFloat(total_f2-valorEntidad2-cpmForma2)
var restante3=parseFloat(total_f3-valorEntidad3-cpmForma3)

//calculo iva
var ivaForma1=parseFloat(restante1)*parseFloat(porcIva)/parseFloat(1+porcIva);
var ivaForma2=parseFloat(restante2)*parseFloat(porcIva)/parseFloat(1+porcIva);
var ivaForma3=parseFloat(restante3)*parseFloat(porcIva)/parseFloat(1+porcIva);
document.getElementById("gca_pagos_Formas_ivaT").value=CurrencyFormatted(ivaForma1);
document.getElementById("gca_pagos_Formas2_ivaT").value=CurrencyFormatted(ivaForma2);
document.getElementById("gca_pagos_Formas3_ivaT").value=CurrencyFormatted(ivaForma3);
document.getElementById("gca_pagos_Formas_iva").value=ivaForma1;
document.getElementById("gca_pagos_Formas2_iva").value=ivaForma2;
document.getElementById("gca_pagos_Formas3_iva").value=ivaForma3;

var valorTotalIva=parseFloat(ivaForma1)+parseFloat(ivaForma2)+parseFloat(ivaForma3);
//document.getElementById("gca_pagos_ivaT").value=CurrencyFormatted(valorTotalIva)
document.getElementById("gca_pagos_iva").value=Math.round(valorTotalIva,0);

//calculo honorarios... parece q al hacerse a mano.. no aplica el porc de honorario
/*var honForma1=parseFloat(restante1)*parseFloat(porcHon);
var honForma2=parseFloat(restante2)*parseFloat(porcHon);
var honForma3=parseFloat(restante3)*parseFloat(porcHon);*/

var honForma1=parseFloat(restante1)-ivaForma1;
var honForma2=parseFloat(restante2)-ivaForma2;
var honForma3=parseFloat(restante3)-ivaForma3;
document.getElementById("gca_pagos_Formas_honorariosT").value=CurrencyFormatted(honForma1);
document.getElementById("gca_pagos_Formas2_honorariosT").value=CurrencyFormatted(honForma2);
document.getElementById("gca_pagos_Formas3_honorariosT").value=CurrencyFormatted(honForma3);
document.getElementById("gca_pagos_Formas_honorarios").value=honForma1;
document.getElementById("gca_pagos_Formas2_honorarios").value=honForma2;
document.getElementById("gca_pagos_Formas3_honorarios").value=honForma3;
var valorTotalHon=parseFloat(honForma1)+parseFloat(honForma2)+parseFloat(honForma3);
document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valorTotalHon)
document.getElementById("gca_pagos_honorarios").value=valorTotalHon;

//alert(valorEntidad1)
}




function CurrencyFormatted(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + num);
}

/*para habilitar fechas de acuerdo a la elecci�n de la forma de pago*/

document.getElementById('gca_pagos_Formas_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_day').disabled=false;  
 }else{	
	document.getElementById('gca_pagos_Formas_fecha_month').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_year').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas2_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas2_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas3_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas3_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
    document.getElementById('gca_pagos_Formas3_fecha_month').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_year').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas3_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_day').disabled=true; 
 }
}

    
/*Permite calcular el honorario de acuerdo a la cartera escogida*/
document.getElementById('gca_pagos_id_cartera').onchange = function(){
var nro_expediente=document.getElementById('gca_pagos_obligacion').value;
$.getJSON("getHonorarios/id_cartera/"+this.value+"/expediente/"+nro_expediente,
				function(data){							
				  $.each(data.registros, function(i,item){			
					document.getElementById('honorarios').value =item.honorarios; 
					document.getElementById('porcentaje_honorarios').innerHTML=document.getElementById('honorarios').value*100+"%";
					if(item.existe_expediente==0){
					 alert("La obligacion no pertenece a la cartera seleccionada!");
					 document.getElementById('ban_expediente').value=0; 
					 document.getElementById('deudor').innerHTML='Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
					}else{
						document.getElementById('ban_expediente').value=1; 
						document.getElementById('deudor').innerHTML=item.nombre; 
					}
				  });
                });

}

function getDeudor(){
	var nro_expediente=document.getElementById('gca_pagos_expediente').value;
	var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
	$.getJSON("getNombreDeudor/id_cartera/"+id_cartera+"/expediente/"+nro_expediente,function(data){
		$.each(data.registros, function(i,item){
			document.getElementById("nombreDeudorFld").value=item.nombre;
		});
	});
}

/*valida en el bot�n, antes de enviar el form*/
function validar_expediente(){
var mp1; var mp2; var mp3; //medios de pago
	if( document.getElementById('ban_expediente').value==2)alert("Elija una cartera!") 
	else{//se valida por si corrigen el expediente despues de la alerta...
		var nro_expediente=document.getElementById('gca_pagos_obligacion').value;
		var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
		$.getJSON("getHonorarios/id_cartera/"+id_cartera+"/expediente/"+nro_expediente,
					function(data){					   
					  $.each(data.registros, function(i,item){	
				  
						if(item.existe_expediente==0){					 
							alert("La obligacion no pertenece a la cartera seleccionada!");
							document.getElementById('deudor').innerHTML='Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
						 }
						else{ //validar q no ingresen montos q superen el valor pagado por el usr
							document.getElementById('deudor').innerHTML=item.nombre; 
							 fp1=document.getElementById('gca_pagos_Formas_forma_pago').value;
							 fp2=document.getElementById('gca_pagos_Formas2_forma_pago').value;
							 fp3=document.getElementById('gca_pagos_Formas3_forma_pago').value;
							 v1=document.getElementById('gca_pagos_Formas_valorT').value;
							 v2=document.getElementById('gca_pagos_Formas2_valorT').value;
							 v3=document.getElementById('gca_pagos_Formas3_valorT').value;

							/* mp1=document.getElementById('gca_pagos_Formas_medio_pago').value;
							 mp2=document.getElementById('gca_pagos_Formas2_medio_pago').value;
							 mp3=document.getElementById('gca_pagos_Formas3_medio_pago').value;*/
						
						     var error=0; //valida q haya ingresado formas y medios de pago, si existe el valor
							 //if((v1!=0 && (fp1=="" || mp1=="")) || (v2!=0 && (fp2=="" || mp2=="")) || (v3!=0 && (fp3=="" || mp3=="")))
							 if((v1!=0 && (fp1=="" )) || (v2!=0 && (fp2=="")) || (v3!=0 && (fp3=="")))
							 error=1;
							
							if(error==0){							 														 
									var valor_pago= parseFloat(document.getElementById("gca_pagos_entidad").value)+
									parseFloat(document.getElementById("gca_pagos_honorarios").value)+
									parseFloat(document.getElementById("gca_pagos_iva").value)+
									parseFloat(document.getElementById("gca_pagos_cpm").value)+
									parseFloat(document.getElementById("gca_pagos_otros").value);																										
							 var valorT=parseFloat(document.getElementById("gca_pagos_valor_total").value); //valor total del pago														 					 
		
							 if(valorT != 0){							 
								 //reajustar a la entidad hasta 5 pesos
								 var ajuste=valorT-valor_pago;							
								 if(Math.abs(ajuste)>=1 && Math.abs(ajuste)<=5) {//puede ser neg o posit
								   document.getElementById("gca_pagos_entidad").value=parseFloat(document.getElementById("gca_pagos_entidad").value)+parseFloat(ajuste)
								   valor_pago=valor_pago+ajuste 
							     }	

							//alert(document.getElementById("gca_pagos_entidad").value)																								 
							 
								if(valor_pago==valorT){//si es correctoo valida fechas, si el pago es en cheque
								  if(fp1==1 || fp1==4 || fp2==1 || fp2==4 || fp3==1 || fp3==4){//por si eligi� cheque o fax cheque						
									   if(confirm("Recuerde revisar las fechas para los cheques!")){
										 document.forms[0].submit();	
										// alert("se va")
										}									 
								  } 
								  else { document.forms[0].submit();	
								   //alert("se va")
								  }					   
								}
								else alert("Los valores no coinciden con el pago efectuado!")	
							}else alert("No ha ingresado monto para el pago!")								
						 }else alert("Recuerde llenar las formas y medios de pago, para valores efectuados!")	
						////////////////							
						}								
					  });
					});
	}
	/* alert("ent "+document.getElementById("gca_pagos_entidadT").value.replace(/,/g,''))
							 alert("H "+document.getElementById("gca_pagos_honorariosT").value.replace(/,/g,''))
							 alert("I "+document.getElementById("gca_pagos_iva").value.replace(/,/g,''))
							 alert("o "+document.getElementById("gca_pagos_otros").value.replace(/,/g,''))
							 alert("4 "+document.getElementById("gca_pagos_cpm").value.replace(/,/g,''))*/
							 
	
}

</script>
