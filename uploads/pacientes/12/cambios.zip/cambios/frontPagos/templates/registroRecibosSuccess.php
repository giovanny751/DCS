


<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="../../js/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>


<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.js"></script>
<p><br></p>

<div style="width: 80%;margin: 0 auto;">
    <form id="form1" method="post">
        <div style="display: none"><input type="hidden" name="action" id="action" value="buscar"></div>
        <table width="100%">
            <tr>
                <th width="10%">
                    Cedula
                </th>
                <td width="40%">
                    <input type="text" name="cedula" id="cedula" class="limpiar">
                </td>
                <th width="10%">
                    Fecha Inicial
                </th >
                <td width="40%">
                    <input type="text" class="fecha" name="f_inicial" id="f_inicial" readonly="readonly" class="limpiar">
                </td>
            </tr>
            <tr>
                <th>
                    Cartera
                </th>
                <td>
                    <select  name="cartera" id="cartera" style="width: 50%" tabindex="1" class="vacio desabilitar limpiar">
                        <option value="">SELECCIONE...</option>
                        <?php foreach ($cartera as $car): ?>
                            <option value="<?php echo $car['id'] ?>" ><?php echo $car['nombre'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <th>
                    Fecha Final
                </th>
                <td>
                    <input type="text" class="fecha" name="f_final" id="f_final" readonly="readonly" class="limpiar">
                </td>
            </tr>
            <tr>
                <th>
                    Estado
                </th>
                <td>
                    <select id="estado" name="estado"  class="limpiar">
                        <option value="">SELECCIONE...</option>
                        <option value="0">SIN APROBAR</option>
                        <option value="1">APROBADO</option>
                        <option value="2">REGISTRADO</option>
                        <option value="3">NO APROBADO</option>
                        <option value="4">CONFIRMADO</option>
                        <option value="5">REEMBOLSO</option>
                        <option value="6">ANULADOS</option>
                        <option value="7">RECHAZADOS</option>
                    </select>
                </td>
            </tr>
        </table>
    </form>
    <table width="100%">
        <tr>
            <td>
        <center><button type="button" class="limpiarcampos" id="limpiarcampos">Limpiar</button>&nbsp;&nbsp;
            <!--<button type="button" class="buscar_car" id="buscar_car">Buscar</button>-->
            <span class="cargando" style="display: none">Cargando...</span>
            <span id="no_cargando">
                <button id="buscar_car">Buscar</button>
            </span>
        </center>
        </td>
        </tr>
    </table>
    <p><br></p>
    <form id="form2" method="post">
        <table style="width: 100%" id="mitable">
            <thead  style="background-color: #4c86ac;color: white;">
            <th><input type="checkbox" id="principal" name="principal"></th>
            <th>Codigo</th>
            <th>Recibo de Caja</th>
            <th>Devolución Tesoreria</th>
            <th>Cedula</th>
            <th>Nombre del Titular</th>
            <th>Cartera</th>
            <th>Concepto</th>
            <th>Forma Pago</th>
            <th>Banco</th>
            <th>No Cuenta</th>
            <th>Valor</th>
            <th>Estado</th>
            <th>Fecha de Pago</th>

            </thead>
            <tbody id="cuerpo">
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        <div style="display: none"><input type="hidden" name="action" id="action" value="activar"></div>
    </form>
    <div align="right">
        <span class="cargando" style="display: none">Cargando...</span>
        <button type="button" id="sinaprobar">Sin Aprobar</button>
        <button type="button" id="registrar">Registrar</button>
    </div>
</div>
<script>

    $("#sinaprobar").click(function() {
        $('.cargando').show();
        $('#sinaprobar').hide();
        $('#registrar').hide();
        var id = "";
        var num = 0;
        $(".aprobadocheck").each(function() {
            if ($(this).is(":checked"))
                id = $(this).attr("checkid") + "," + id;
        });
        var ids = id.substring(0, id.length - 1);
        var action = "sinaprobar";
        var url = "consulasRecibos";
        var confirmacion = confirm("Esta seguro de cambiar el estado?");
        if (confirmacion == true)
        {
            $.post(url, {ids: ids, action: action}).done(function(msg) {

                alert("Registros Sin Aprobar " + ids);
                $('.buscar_car').trigger('click');
                $('.cargando').hide();
                $('#sinaprobar').show();
                $('#registrar').show();
            }).fail(function() {
                alert("Error del Sistema por favor comunicarse con el administrador");
            });
        }
    });


    $('body').delegate('#principal', 'click', function() {

        if ($(this).is(':checked')) {
            //$("input[type=checkbox]").prop('checked', true); //todos los check
            $("#cuerpo input[type=checkbox]").prop('checked', true); //solo los del objeto #diasHabilitados
        } else {
            //$("input[type=checkbox]").prop('checked', false);//todos los check
            $("#cuerpo input[type=checkbox]").prop('checked', false);//solo los del objeto #diasHabilitados
        }

    });


    $(document).ready(function() {
        $('.fecha').datepicker({
            dateFormat: "yy-mm-dd"
        });
        $('#mitable').DataTable();
    });
    $('.limpiarcampos').click(function() {
        $('#f_final').val('');
        $('#f_inicial').val('');
        $('.limpiar').val('');
    });
    $('#registrar').click(function() {
        $('.cargando').show();
        $('#sinaprobar').hide();
        $('#registrar').hide(); 
        var url = 'consulasRecibos';
        $.post(url, $('#form2').serialize())
                .done(function(msg) {
                    $('#buscar_car').click();
                    $('.cargando').hide();
                    $('#sinaprobar').show();
                    $('#registrar').show();
                })
                .fail(function(msg) {
                    alert('Error al consultar');
                })
    })
    $('#buscar_car').click(function() {
        $('.cargando').show();
        $('#no_cargando').hide();
        var url = 'consulasRecibos';
//        $('#mitable').DataTable().rows().remove();
        $('#mitable').DataTable().clear().draw();
        $.post(url, $('#form1').serialize())
                .done(function(msg) {
                    if ($('#estado').val() == "1") {
                        $('#principal').show();
                    } else {
                        $('#principal').hide();
                    }

                    var datos = jQuery.parseJSON(msg);
                    $.each(datos, function(key, val) {
                        estado = val.estado
                        val.estado = (val.estado == 0 ? 'SIN APROBAR' : val.estado)
                        val.estado = (val.estado == 1 ? 'APROBADO' : val.estado)
                        val.estado = (val.estado == 2 ? 'REGISTRADO' : val.estado)
                        val.estado = (val.estado == 3 ? 'NO APROBADO' : val.estado)
                        val.estado = (val.estado == 4 ? 'CONFIRMADO' : val.estado)
                        val.estado = (val.estado == 5 ? 'REEMBOLSO' : val.estado)
                        val.estado = (val.estado == 6 ? 'ANULADOS' : val.estado)
                        val.estado = (val.estado == 7 ? 'RECHAZADOS' : val.estado)

//                        credenciales
                        var gg = val.credenciales;
                        if (gg.indexOf('editar_pagos') > -1) {
                            opcion = "";
                        } else
                            opcion = "?action_gene=1";

                        id = "<a href='editarPagosTesorero/id/" + val.id + "/estado/" + estado + "/cartera_elejida/" + opcion + "'>" + val.id + "</a>"
                        if (estado == 1)
                            check = '<input class="aprobadocheck" type="checkbox" checkid="' + val.id + '" name="aprobar_che[]" value="' + val.id + ' :: ' + val.por_concepto + ' :: ' + val.obligacion + ' :: ' + val.valor_total + ' :: ' + val.cedula + '">';
                        else
                            check = "";
                        $('#mitable').DataTable().row.add([
                            check,
                            id,
                            val.nro_rc,
                            val.devolucion_tesoreria,
                            val.cedula,
                            val.nombre_deudor,
                            val.cartera,
                            val.por_concepto,
                            val.descripcion,
                            val.bancos,
                            val.cuenta_consignacion,
                            CurrencyFormatted(val.valor),
                            val.estado,
                            val.fecha
                        ]).draw();
                    })
                    $('.cargando').hide();
                    $('#no_cargando').show();
                }).fail(function(msg) {
            $('.cargando').hide();
            $('#no_cargando').show();
            alert('Error al consultar');
        })
    })
    $('#principal').hide();

    function CurrencyFormatted(num) {
        num = num.toString().replace(/\$|\,/g, '');
        if (isNaN(num))
            num = "0";
        sign = (num == (num = Math.abs(num)));
        num = Math.floor(num * 100 + 0.50000000001);
        cents = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10)
            cents = "0" + cents;
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
            num = num.substring(0, num.length - (4 * i + 3)) + ',' +
                    num.substring(num.length - (4 * i + 3));
        return (((sign) ? '' : '-') + num);
    }
</script>


<style>
    input[type="text"]{ 
        width: 50%
    } 
</style>