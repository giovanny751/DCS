<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
</style>

<h1>Editar Pagos</h1>

<form  method="post" action="<?php echo url_for('frontPagos/update?id='.$form->getObject()->getId())?>">



<table class="nuevo">
    <tr>
      <th><?php echo ($form['expediente']->renderLabel()) ?> </th>
      <td><?php echo ($form['expediente']->render()) ?> </td>
    </tr>
   <!-- <tr>
      <th><?php// echo ($form['recibido']->renderLabel()) ?> </th>
      <td><?php// echo ($form['recibido']->render()) ?> </td>
    </tr>-->
    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?> </th>
      <td><?php echo ($form['por_concepto']->render()) ?> </td>    
    </tr>
    <tr>
      <th><?php echo ($form['id_cartera']->renderLabel())?></th>
      <td><?php echo ($form['id_cartera']->render())?></td>
    </tr>

</table>

<table class="nuevo">

    <tr class="listheading">
      <!--<th><?php//echo ($form['Formas']['medio_pago']->renderLabel()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['producto']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>
	  <th><?php echo ($form['Formas']['fecha']->renderLabel()) ?> </th>
	  <th><?php echo ($form['Formas']['entidad']->renderLabel()) ?> </th>
	  <th><?php echo ($form['Formas']['cpm']->renderLabel()) ?> </th>   
	  <th><?php echo ($form['Formas']['abogados']->renderLabel()) ?> </th>      	  	  
	  <th><?php echo ($form['Formas']['honorarios']->renderLabel()) ?> </th>      	  
	  <th><?php echo ($form['Formas']['otros']->renderLabel()) ?> </th>     	  	 
      <th><?php echo ($form['Formas']['iva']->renderLabel()) ?> </th>      
      <th><?php echo ($form['Formas']['concepto_rechazo']->renderLabel()) ?> </th>	  
    </tr>

    <tr>
     <!-- <th><?php//echo ($form['Formas']['medio_pago']->render()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->render()) ?> </th>
      <th><?php echo ($form['Formas']['producto']->render()) ?> </th>    
      <th><input type="text" size="12" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT"  value="<?= $form['Formas']['valor']->getValue()?>"    
            onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/>
           <input type="hidden" id="gca_pagos_Formas_valor" name="gca_pagos[Formas][valor]" value="<?= $form['Formas']['valor']->getValue()?>"/></th>      
	  
	  <th><?php echo ($form['Formas']['fecha']->render()) ?> </th>
	  <?php 
	  echo ($form['Formas']['entidad']->render());
          echo ($form['Formas']['cpm']->render());
	  echo ($form['Formas']['abogados']->render());
	  echo ($form['Formas']['honorarios']->render());
	  echo ($form['Formas']['otros']->render());
	  echo ($form['Formas']['iva']->render()); ?> 
	  <th><input type="text" id="gca_pagos_Formas_entidadT" name="gca_pagos_Formas_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>)" size="10"/>
	  <th><input type="text" id="gca_pagos_Formas_cpmT" name="gca_pagos_Formas_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" />          
	  <th><input type="text" id="gca_pagos_Formas_honorariosT" name="gca_pagos_Formas_honorariosT" size="10" readonly/>      
	  <th><input type="text" id="gca_pagos_Formas_ivaT" name="gca_pagos_Formas_ivaT" size="10" readonly />   
      <th><?php echo ($form['Formas']['concepto_rechazo']->render()) ?> </th>	  
    </tr>    
	
<?php
?>
    <tr>
      <!--<th><?php //echo ($form['Formas2']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas2']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['num_cheque']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['producto']->render()) ?> </th>
      <th><input type="text" size="12" id="gca_pagos_Formas2_valorT" name="gca_pagos_Formas2_valorT" value="<?= $form['Formas2']['valor']->getValue()?>" 
            onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/>
          <input type="hidden" id="gca_pagos_Formas2_valor" name="gca_pagos[Formas2][valor]" value="<?= $form['Formas2']['valor']->getValue()?>" /></th>
      <th><?php echo ($form['Formas2']['fecha']->render()) ?> </th>
	  <th><input type="text" id="gca_pagos_Formas2_entidadT" name="gca_pagos_Formas2_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>)" size="10"/>
	  <th><input type="text" id="gca_pagos_Formas2_cpmT" name="gca_pagos_Formas2_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" />           
	  <th><input type="text" id="gca_pagos_Formas2_honorariosT" name="gca_pagos_Formas2_honorariosT" size="10" readonly/>	  
	  <th><input type="text" id="gca_pagos_Formas2_ivaT" name="gca_pagos_Formas2_ivaT" size="10" readonly />
	  <th><?php echo ($form['Formas2']['concepto_rechazo']->render()) ?> </th>
	<?php 
	  echo ($form['Formas2']['entidad']->render());
	  echo ($form['Formas2']['iva']->render());
	  echo ($form['Formas2']['honorarios']->render());
	  echo ($form['Formas2']['cpm']->render());?> 	  
    </tr>	
	  
    </tr>

    <tr>
     <!-- <th><?php //echo ($form['Formas3']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas3']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['num_cheque']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['producto']->render()) ?> </th>
      <th><input type="text" size="12" id="gca_pagos_Formas3_valorT" name="gca_pagos_Formas3_valorT" value="<?= $form['Formas3']['valor']->getValue()?>" 
      		onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" />
      	  <input type="hidden" id="gca_pagos_Formas3_valor" name="gca_pagos[Formas3][valor]" value="<?= $form['Formas3']['valor']->getValue()?>"/></th>
      <th><?php echo ($form['Formas3']['fecha']->render()) ?> </th>
	  <th><input type="text" id="gca_pagos_Formas3_entidadT" name="gca_pagos_Formas3_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" size="10"/>
	  <th><input type="text" id="gca_pagos_Formas3_cpmT" name="gca_pagos_Formas3_cpmT" size="10" value="0" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva;?>);" />           
	  <th><input type="text" id="gca_pagos_Formas3_honorariosT" name="gca_pagos_Formas3_honorariosT" size="10" readonly/>	  
	  <th><input type="text" id="gca_pagos_Formas3_ivaT" name="gca_pagos_Formas3_ivaT" size="10" readonly />	  
	  <?php 
	  echo ($form['Formas3']['entidad']->render());
	  echo ($form['Formas3']['iva']->render());
	  echo ($form['Formas3']['honorarios']->render());
	  echo ($form['Formas3']['cpm']->render());?> 	  
	  <th><?php echo ($form['Formas3']['concepto_rechazo']->render()) ?> </th>
    </tr>
<?//*/?>

<?php 
	//ocultos del formulario formaPago... por katty*** 
	echo ($form['Formas']['id']->render());
	echo ($form['Formas']['id_gca_pagos']->render());
        echo ($form['Formas']['estado']->render());
	echo ($form['Formas2']['id']->render());
	echo ($form['Formas2']['id_gca_pagos']->render());
        echo ($form['Formas2']['estado']->render());
	echo ($form['Formas3']['id']->render());
	echo ($form['Formas3']['id_gca_pagos']->render());
        echo ($form['Formas3']['estado']->render());
	 ?> 

</table>



<table  class="nuevo">
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['entidad']->renderLabel()); ?> </th>
    <th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT" value="<?=$form['entidad']->getValue()?>" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" />
        <input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" value="<?=$form['entidad']->getValue()?>"/></th>    
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['honorarios']->renderLabel())?> </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT"  value="<?=$form['honorarios']->getValue()?>" readonly />
        <input type="hidden" id="gca_pagos_honorarios" name="gca_pagos[honorarios]" value="<?=$form['honorarios']->getValue()?>" />
        </th>
    <th><?php echo ($honorarios*100).'%';?></th>
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['iva']->renderLabel()) ?> </th>
    <th><?php echo ($form['iva']->render()) ?> </th>
    <th><?php echo ($iva*100).'%'; ?></th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th>4 X 1000 </th>
    <!--<th><?//php echo ($form['cpm']->render()) ?> </th>-->
	<th><input type="text" id="gca_pagos_cpm" name="gca_pagos[cpm]" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['otros']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_otros" name="gca_pagos[otros]" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" value="<?=$form['otros']->getValue()?>"/> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['valor_total']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" value="<?=$form['valor_total']->getValue()?>" readonly/>
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]"    value="<?=$form['valor_total']->getValue()?>"/> </th>
  </tr>
  <tr>
    <td colspan="2"></td>
    <td><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="submit" value="Registrar" name="guardar"/></td></tr>  
</table>


<!--<input type="hidden" value="<?php// echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>-->

<?echo $form->renderHiddenFields(); ?>
<input type="hidden" name="formulario" value="edit_tesorero">
</form>
<script>
function calcular(honorarios, ivaP){
  
  entidad = document.getElementById("gca_pagos_entidad");
  total = document.getElementById("gca_pagos_valor_total");  

  f1 = document.getElementById("gca_pagos_Formas_valorT").value == ''?0:document.getElementById("gca_pagos_Formas_valorT").value.replace(',','');
  document.getElementById("gca_pagos_Formas_valor").value = f1;
  document.getElementById("gca_pagos_Formas_valorT").value = CurrencyFormatted(f1);
  
  f2 = document.getElementById("gca_pagos_Formas2_valorT").value == ''?0:document.getElementById("gca_pagos_Formas2_valorT").value.replace(',','');
  document.getElementById("gca_pagos_Formas2_valor").value = f2;
  document.getElementById("gca_pagos_Formas2_valorT").value = CurrencyFormatted(f2);
  
  f3 = document.getElementById("gca_pagos_Formas3_valor").value == ''?0:document.getElementById("gca_pagos_Formas3_valorT").value.replace(',','');
  document.getElementById("gca_pagos_Formas3_valor").value = f3;
  document.getElementById("gca_pagos_Formas3_valorT").value = CurrencyFormatted(f3);
  
  otros = document.getElementById("gca_pagos_otros").value == ''?0:document.getElementById("gca_pagos_otros").value;
  cpm = document.getElementById("gca_pagos_cpm").value == ''?0:document.getElementById("gca_pagos_cpm").value;
  document.getElementById("gca_pagos_cpm").value = CurrencyFormatted(cpm);
  total.value = total.value == ''?0:total.value;
  
  total.value = parseFloat(document.getElementById("gca_pagos_Formas_valor").value.replace(',',''))+ parseFloat( document.getElementById("gca_pagos_Formas2_valor").value.replace(',','')) + parseFloat(document.getElementById("gca_pagos_Formas3_valor").value.replace(',',''));
  
  document.getElementById("gca_pagos_valor_totalT").value= CurrencyFormatted(total.value);
    
  entidad.value = parseFloat((total.value - parseFloat(otros))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpm)));
  document.getElementById("gca_pagos_entidadT").value= CurrencyFormatted(entidad.value);
  document.getElementById("gca_pagos_honorarios").value = parseInt(parseFloat(entidad.value) * parseFloat(honorarios));
  document.getElementById("gca_pagos_iva").value = parseInt(parseFloat(ivaP) * parseFloat(document.getElementById("gca_pagos_honorarios").value));
  document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(document.getElementById("gca_pagos_honorarios").value);
  
}


function CurrencyFormatted(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + num);
}
  
</script>
