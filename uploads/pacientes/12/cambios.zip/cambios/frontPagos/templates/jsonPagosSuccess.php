<?php
 echo $sf_data->getRaw('json_pagos');
?>
