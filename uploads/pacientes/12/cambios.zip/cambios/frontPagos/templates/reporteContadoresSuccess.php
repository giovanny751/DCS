<style>
.td {font-size: 6pt;}
.listrow1 { font-size: 9pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 9pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 8pt; background-color: #4c86ac; color: white; }
</style>


<center><br>
  <form action="<?php echo url_for('frontPagos/reporteContadores') ?>" method="get" >
  <table border=0>
  <?php if($is_tesorero==true){?><tr><td><b>Sucursal:</td> <td><?php echo $form['id_sucursal']->render();  ?></td></tr><?php }?>
   <tr>	<td><b>Reporte:</td>
   <td><select name="reporte">
   <option value="listado_facturacion">Listado Facturaci&oacute;n</option>
   <option value="pagos_anul_dev">Anulados y Devueltos</option>
   <option value="pagos_directos">Pagos Directos</option>
  <option value="resumen_entidades">Resumen Entidades</option>
   </select></td> </tr>
   <tr>	<td><b>Fecha Desde:</td><td><input type="text" name="fechadesde__String" id="fechadesde_String" value="<?php print $fecha_ini?>" /></td> </tr>
	 <tr><td><b>Fecha Hasta:</td><td><input type="text" name="fechahasta__String" id="fechahasta_String" value="<?php print $fecha_fin?>" /></td>
 
     <td colspan="2"> <input type="submit" value="Imprimir" name="boton"/> </form> </td>
   </tr>
</table>


<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "fechadesde_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	Calendar.setup({
        inputField     :    "fechahasta_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
</script>




