<style>
.listrow1 { font-size: 8pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 8pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 8pt; background-color: #4c86ac; color: white; }
text{font-size: 9pt; }
select{font-size: 8pt; }
.submit{font-size: 8pt; }
.mensaje{color: red;  font-size: 9pt; }
</style>

<h1>Buscar Pagos</h1>

<center><br><br>
<table align="center" border=0>
  <form action="<?php echo url_for('frontPagos/searchPagos') ?>" method="get" >
   <tr>
     
      <td><b>Cartera</td>
      <td><?php echo $form['id_cartera']->render()?></td>
    <td><b>Forma de Pago &nbsp;&nbsp;</td>
      <td><select name="forma_pago">
        <option value="">SELECCIONE...<option>
        <option value="1">CHEQUE</option>
	<option value="2">EFECTIVO</option>
        <option value="3">FAX-EFECTIVO</option>
        <option value="4">FAX-CHEQUE</option>
      </select></td>
    </tr>

   
   
   <tr>
	<td><b>Nro. Pago / C&eacute;dula /<br> Obligaci&oacute;n / Nombre deudor</td>
        <td> <input type="text" name="keywords" id="search_keywords"  size="30"/></td> 
 <td><b>Estado</td>
      <td><select name="estado" id="estado">
        <option value="">SELECCIONE...<option>
        <option value="0">SIN APROBAR</option>
        <option value="1">APROBADO</option>
        <option value="2">REGISTRADO</option>
        <option value="3">NO APROBADO</option>
        <option value="4">CONFIRMADO</option>
        <option value="5">REEMBOLSO</option>
        <option value="6">ANULADOS</option>
        <option value="7">RECHAZADOS</option> <!-- indicador  para buscar rechaz -->
      </select></td>


</tr>

<tr>	<td><b>Fecha Desde:</td><td><input type="text" name="fechadesde__String" id="fechadesde_String" value="<?php print $fecha_ini?>" /></td> 
	<td><b>Fecha Hasta:</td><td><input type="text" name="fechahasta__String" id="fechahasta_String" value="<?php print $fecha_fin?>" /></td>


   </tr>


 
     <td colspan="2"> <input type="submit" value="Buscar" /> </form> </td>
   </tr>
</table>


<br><br>


<table border=0 width="98%">
<tr class="listheading" >
<?



if($mensaje=="" and count($pagos)>0 ){?>
  <td width="60px" align="center"><b>Num pago</td><td align="center"><b>Cartera</td><td align="center"><b>Obligaci&oacute;n</td><td align="center"><b>C&eacute;dula</td>  <td width="200px" align="center"><b>Nombre Deudor</td> <td  align="center"><b>Asesor</td> <td align="center"><b>Fecha Recibo</td> <td align="center"><b>Forma Pago</td><td align="center"><b> valor Pago</td> <td align="center"><b>Entidad</td> 
<td align="center"><b>Honorarios</td> <td align="center"><b>Abogados</td><td align="center"><b>Paz y Salvo</td> <td align="center"><b>Otros</td>
<td align="center"><b>Iva</td> <td width="70px" align="center"><b>Estado</td> 
<td width="70px" align="center"><b>Concepto Rechazo</td>
<td width="70px" align="center"><b>Nro. Factura</td>
<td width="70px" align="center"><b>Concepto Pago</td>
</tr>

<?$style="listrow0";
//print count($pagos);
   foreach ($pagos as $pago){ 
	if($style=="listrow1")$style="listrow0"; else $style="listrow1";      
	

        ?><tr class="<?=$style?>">
              <td><a href="<?php echo url_for('frontPagos/edit?id='.$pago['id'].'&opcion=searchPagos') ?>"> 
			  <?php if(isset($pago['nro_rc']) and $pago['nro_rc']!="") print $pago['nro_rc']; else  print $pago['id'];?></a> </td>                                  
	      <td><? print $pago['cartera']?></td>
	      <td><? print $pago['obligacion'];?></td>	
	      <td><? print $pago['cedula']?></td>   
	      <td><? print $pago['nombres']?></td>	
    	      <td><? print $pago['codigo_asesor']?></td>    
	      <td><? print $pago['fecha_recibo']?></td>
	      <td><? print $pago['forma_pago']?></td>
	      <td align="right"><? print number_format($pago['valor'])?></td>		
	      <td align="right"><? print number_format($pago['reembolso'])?></td>		
	      <td align="right"><? print number_format($pago['honorarios'])?></td>
		<td align="right"><? print number_format($pago['abogados'])?></td>
		<td align="right"><? print number_format($pago['cpm']); //el paz y salvo se maneja  en cpm?></td>
		<td align="right"><? print number_format($pago['otros'])?></td>
	      <td align="right"><? print number_format($pago['iva'])?></td>
          <td><? print $pago['estado']?>  </td>
	  <td><? print $pago['concepto_rechazo']?>  </td>
	  <td align="right"><? print $pago['factura']?>  </td>
	  <td align="right"><? print $pago['por_concepto']?>  </td>
         </tr>
       <?
    }
 } else if(count($pagos)==0){?>
      <td align="center"> <b>No hay Registros o&oacute; el pago no pertenece a sus sucursales....</td><?
   }else if($mensaje!=""){?>
      <td align="center"> <b><?=$mensaje?> </td><?
   }
?>

</tr>
</table>

<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "fechadesde_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	Calendar.setup({
        inputField     :    "fechahasta_String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
</script>

