<?php $credenciales=$sf_data->getRaw('credenciales');?>
<form name="form1" action="" method="post">
  <table class="nuevo">
    <tr>
      <td>Estado</td>
      <td><select name="estado" id="estado">
        <option value="">SELECCIONE...<option>
        <option value="0">SIN APROBAR</option>
        <option value="1">APROBADO</option>
        <option value="2">REGISTRADO</option>
      </select></td>
    </tr>
    <tr>
      <td>Obligaci&oacute;n</td>
      <td><input type="text" name="obligacion" value=""></td>
    </tr>
    <tr>
      <td><input type="submit" name="ver" value="Ver" /></td>
    </tr>
  </table>      
</form>
<?php if(isset($_POST['ver'])):?>
<?php if(count($gca_pagos_list)>0):?>
<table class="lista">
  <thead>
    <tr>
      <th>Id</th>
      <th>Fecha</th>
      <th>Observaciones</th>
      <th>Id funcionario</th>
      <th>Obligacion</th>
      <th>Valor Total</th>
      <th>Recibido</th>
      <th>Expediente</th>
      <th>Honorarios</th>
      <th>Entidad</th>
      <th>Iva</th>
      <th>Honorarios</th>
      <th>Opciones</th>
    </tr>
  </thead>

  <tbody>
    <?php foreach ($gca_pagos_list as $gca_pagos): ?>
    <tr>
      <td><a href="<?php echo url_for('frontPagos/'.(in_array('director',$credenciales)||in_array('gerente',$credenciales)?'aprobar':'edit').'?id='.$gca_pagos->getId()) ?>"><?php echo $gca_pagos->getId() ?></a></td>
      <td><?php echo $gca_pagos->getFecha() ?></td>
      <td><?php echo $gca_pagos->getObservaciones() ?></td>
      <td><?php echo $gca_pagos->getIdFuncionario() ?></td>
      <td><?php echo $gca_pagos->getObligacion() ?></td>
      <td><?php echo $gca_pagos->getValorTotal() ?></td>
      <td><?php echo $gca_pagos->getRecibido() ?></td>
      <td><?php echo $gca_pagos->getExpediente() ?></td>
      <td><?php echo $gca_pagos->getHonorarios() ?></td>
      <td><?php echo $gca_pagos->getEntidad() ?></td>
      <td><?php echo $gca_pagos->getIva() ?></td>
      <td><?php echo $gca_pagos->getHonorarios() ?></td>
      <td>
        <?php if(in_array('tesoreria',$credenciales)):?>
        <a href="<?php echo url_for('frontPagos/updateFechaReembolso?id='.$gca_pagos->getId())?>"><img border="0" src="../../../web/images/calendar.gif" title="Fecha Reembolso" /></a>
        <?php endif;?>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php endif;?>  
<?php endif;?>
