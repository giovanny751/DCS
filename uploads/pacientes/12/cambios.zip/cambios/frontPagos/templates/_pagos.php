<style>
    .listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
    .listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
    .listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
    th { align:center;}
</style>
<body onload="cargarFechas();">

    <form id="form1" action="<?php echo url_for('frontPagos/' . ($form->getObject()->isNew() ? 'create' : 'update') . (!$form->getObject()->isNew() ? '?id=' . $form->getObject()->getId() : '')) ?>" method="post" <?php $form->isMultipart() and print 'enctype="multipart/form-data" ' ?>>
        <?php
        if ($deudor == "")
            $deudor = "Digite N&uacute;mero de la (Cedula o Obligación) y Seleccione cartera";
        $urlJson = url_for("frontPagos/getHonorarios");
        $urlJson2 = url_for("bancoCuenta/GetCuentas");
        ?>
        <input type="hidden" name="honorarios" id="honorarios" value="0.2">
        <input type="hidden" name="ban_expediente" id="ban_expediente" value="2">
        <input type="hidden" name="formas_fecha_year" id="" value="2">
        <table class="nuevo" border="0">
            <?php
            if (!$form->getObject()->isNew()) {
                $pago = Doctrine::getTable('GcaPagos')->find($form->getObject()->getId());
                $sql = "select oo.id,ee.est_estado estado, oo.total_a_pago, sum(dd.total_condonacion) total_condonacion, "
                        . "sum(dd.saldo_credito) saldo_credito"
                        . " from gca_pagos "
                        . "join gca_solicitud_condonacion oo on oo.id=gca_pagos.id_condonacion "
                        . "join gca_detalle_solicitud dd on dd.id_solicitud_condonacion=oo.id "
                        . "join gca_estados ee on ee.est_id=oo.estado "
                        . "where gca_pagos.id=" . $pago . " group by oo.id,ee.est_estado, oo.total_a_pago";
                $condonacion = frontPagosActions::executeConsultasConsul($sql);
                if ($condonacion[0]['id']) {
                    $id_condonacion = $condonacion[0]['id'];
                    $total_condonacion = number_format($condonacion[0]['total_condonacion']);
                    $saldo_credito = number_format($condonacion[0]['saldo_credito']);
                    $estado = $condonacion[0]['estado'];
                } else {
                    $id_condonacion = "";
                    $total_condonacion = "";
                    $saldo_credito = "";
                    $estado = "";
                }
                ?>
                <tr>
                    <th>Pago No:</th>
                    <td> <font color="red"><b><?php
                            if ($form['nro_rc']->getValue() != "")
                                echo $form['nro_rc']->getValue();
                            else
                                echo ($form['id']->getValue())
                                ?></font></td>
                </tr><?php } ?>
            <tr>
                <th>Deudor:</th>
                <td><div id="deudor"><?php print $deudor ?></div></td>
                <td  width="20px">&nbsp;</td>
                <td colspan="2" class="listheading" align="center">Ingrese estos datos solo para Fax-Cheque y Fax-Efectivo</td>
            </tr>	
            <tr>
                <th>
                    Cedula:
                </th>
                <td>
                    <input id="gca_pagos_cedula2" type="text" value="<?php print $cedula ?>" name="gca_pagos[cedula]">
                </td>
            </tr>
            <tr>
                <th><?php echo ($form['obligacion']->renderLabel()) ?>: </th>
                <td><?php
                    echo ($form['obligacion']->render());
                    if ($is_tesorero or $is_tesorero_sucursal or $is_analista) {
                        ?>
                        &nbsp;&nbsp;&nbsp;<nobr>Hist&oacute;rico:  <input type="checkBox" name="oblig_dia" id="oblig_dia"> <nobr>
                    <?php } else { ?>
                        <input type="hidden" name="oblig_dia" id="oblig_dia" value="false"> 
                    <?php } ?>
                    </td>
                    <td  width="20px">&nbsp;</td>
                    <th>Banco Consignaci&oacute;n  / Caja</th>
                    <td><?php echo ($form['banco_consignacion']->render()); ?></td>	  
                    </tr>
                    <tr>
                        <th><?php echo ($form['id_cartera']->renderLabel()) ?>:</th>
                        <td><?php echo ($form['id_cartera']->render()); ?></td>
                        <td  width="20px">&nbsp;</td>
                        <th>Fecha Consignaci&oacute;n</th>
                        <td><?php echo ($form['fecha_consignacion']->render()) ?></td>	  
                    </tr>
                    <tr>
                        <th><?php echo ($form['por_concepto']->renderLabel()) ?>: </th>
                        <td><?php echo ($form['por_concepto']->render()) ?> </td>   
                        <td  width="20px">&nbsp;</td>
                        <th>Sucursal Consignaci&oacute;n</th>
                        <td><?php echo ($form['sucursal_consignacion']->render()) ?></td>	  	  
                    </tr>
                    <tr> <th>Recibo de Pago <br> a nombre de:</th>
                        <td><?php echo ($form['nombre_rc']->render()) ?></td>	
                        <td  width="20px">&nbsp;</td>
                        <th> Cuenta Banco / Caja: </th>
                        <td><?php
                            echo $form['bancocuenta_id']->render();
                            $cuentas = Doctrine::getTable('GcaBancoCuenta')->getCuentas();
                            $totalCuentas = Doctrine::getTable('GcaBancoCuenta')->getTotalCuentas();
                            foreach ($totalCuentas as $tc) {
                                $totalC = $tc['cant'];
                            }
                            $arreglo = null;
                            $cont = 0;
                            foreach ($cuentas as $cta) {
                                $cont++;
                                $banco = $cta['gca_banco_id'];
                                $id = $cta['id'];
                                //$ref=$cta['nombre']." - ".$cta['nro_cuenta']." - ".$cta['tipo_cuenta'];
                                $ref = $cta['nombre'] . " - " . $cta['nro_cuenta'];

                                $arreglo.=" new Array($banco,$id,\"$ref\")";
                                if ($cont < $totalC)
                                    $arreglo.=",\n";
                                else
                                    $arreglo.="\n";
                            }
                            ?>
                            <script>
                                var arrayValores = new Array(<?php echo $arreglo; ?>);
                            </script>
                        </td>
                    </tr>
                    <!--c�digo nuevo alex-->
                    <tr><th>Tipo Documento</th>
                        <td>
                            <?php
                            if (!$form->getObject()->isNew()) {
                                $sel1 = "";
                                $sel2 = "";
                                $sel3 = "";
                                $sel4 = "";
                                if ($pago->getTipoDocumento() == "CC")
                                    $sel1 = "selected";
                                else if ($pago->getTipoDocumento() == "NIT")
                                    $sel2 = "selected";
                                else if ($pago->getTipoDocumento() == "CE")
                                    $sel3 = "selected";
                                else if ($pago->getTipoDocumento() == "Pasaporte")
                                    $sel4 = "selected";

                                $value = $pago->getDocumento();
                            } else
                                $value = "";
                            ?>
                            <select id="gca_pagos_tipo_doc" name="gca_pagos[tipo_doc]">               
                                <option value="CC"  <?php echo $sel1; ?> >CC</option>
                                <option value="NIT" <?php echo $sel2; ?> >NIT</option>
                                <option value="CE"  <?php echo $sel3; ?>>CE</option>
                                <option value="Pasaporte" <?php echo $sel4; ?>>Pasaporte</option>
                            </select></td>
                        <td  width="20px">&nbsp;</td>
                    </tr>
                    <tr>
                        <?php if ($is_tesorero) { ?>      
                            <th>Sucursal: </th>
                            <td><?php echo $departamento['id_sucursal']->render() ?> </td>
                        <?php } ?>
                    </tr>
                    <?php if (isset($asesor)) { ?>   
                        <th>Asesor:</th>
                        <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <?php print Doctrine::getTable('GcaFuncionarios')->find($asesor) ?></th>
                    <?php } ?> 
                    </table>
                    <table border="0" align="left" >
                        <tr>
                            <td>
                                <table class="nuevo" border="0" align="left">
                                    <tr class="listheading">
                                        <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
                                        <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
                                        <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
                                        <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>


                                        <th width="150px" align="center"><?php echo ($form['Formas']['fecha']->renderLabel()) ?><br> Mes/Dia/A&ntilde;o</th>      
                                        <th><?php echo ($form['Formas']['entidad']->renderLabel()) ?> </th>

                                        <th>Paz y Salvos<?php //echo ($form['Formas']['cpm']->renderLabel())                     ?> </th>
                                        <th><?php echo ($form['Formas']['abogados']->renderLabel()) ?> </th>      	  	  
                                        <th><?php echo ($form['Formas']['honorarios']->renderLabel()) ?> </th>      	  
                                        <th><?php echo ($form['Formas']['otros']->renderLabel()) ?> </th>     	  	 
                                        <th><?php echo ($form['Formas']['iva']->renderLabel()) ?> </th>      

                                        <?php if ($formulario == "edit_tesorero") { ?> 
                                            <th><?php echo ($form['Formas']['concepto_rechazo']->renderLabel()) ?> </th>	  
                                        <?php } ?> 
                                    </tr>
                                    <tr>
                                        <th><?php echo ($form['Formas']['forma_pago']->render()) ?> </th>
                                        <th><?php echo ($form['Formas']['id_banco']->render()) ?> </th>
                                        <th><?php echo ($form['Formas']['num_cheque']->render()) ?> </th>
                                        <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" onkeyup="calcular(<?php echo $honorarios . ', ' . $iva . ',1' ?>);" size="10"  value="<?php echo number_format($form['Formas']['valor']->getValue()) ?>"/>    

                                        <th><?php echo ($form['Formas']['fecha']->render()) ?> </th>

                                        <?php
                                        //ocultos
                                        echo ($form['Formas']['valor']->render());
                                        echo ($form['Formas']['entidad']->render());
                                        echo ($form['Formas']['honorarios']->render());
                                        echo ($form['Formas']['cpm']->render());
                                        echo ($form['Formas']['iva']->render());
                                        echo ($form['Formas']['otros']->render());
                                        echo ($form['Formas']['abogados']->render());
                                        ?> 

                                        <th><input type="text" id="gca_pagos_Formas_entidadT" name="gca_pagos_Formas_entidadT"   onchange="entidad_calcular(<?php echo $honorarios . ', ' . $iva . ',1'; ?>);" size="10" value="<?php echo number_format($form['Formas']['entidad']->getValue()) ?>"/>

                                        <th><input type="text" id="gca_pagos_Formas_cpmT" name="gca_pagos_Formas_cpmT" size="10" onchange="otros_paz2(<?php echo $honorarios . ', ' . $iva . ',1'; ?>);"  value="<?php echo number_format($form['Formas']['cpm']->getValue()) ?>"/> 

                                        <th><input type="text" id="gca_pagos_Formas_abogadosT" name="gca_pagos_Formas_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios . ', ' . $iva . ',1'; ?>)" value="<?php echo number_format($form['Formas']['abogados']->getValue()) ?>" /> </th>

                                        <th><input type="text" id="gca_pagos_Formas_honorariosT" name="gca_pagos_Formas_honorariosT" size="10" readonly value="<?php echo number_format($form['Formas']['honorarios']->getValue()) ?>"/> </th> 

                                        <th><input type="text" id="gca_pagos_Formas_otrosT" name="gca_pagos_Formas_otrosT" size="10" onkeyup="otros_paz(<?php echo $honorarios . ', ' . $iva . ',1'; ?>)" value="<?php echo number_format($form['Formas']['otros']->getValue()) ?>"/> </th> 

                                        <th><input type="text" id="gca_pagos_Formas_ivaT" name="gca_pagos_Formas_ivaT" size="10" readonly value="<?php echo number_format($form['Formas']['iva']->getValue()) ?>"/>      
                                            <input type="hidden" id="gca_pagos_Formas_medio_pago" name="gca_pagos[Formas][medio_pago]" value="1"  />      
                                            <?php if ($formulario == "edit_tesorero") { ?>         
                                            <th><?php echo ($form['Formas']['concepto_rechazo']->render()) ?> </th>
                                        <?php } ?>
                                    </tr>    
                                </table>

                                <?php
                                //ocultos del formulario formaPago... por katty***
                                if (!($form->getObject()->isNew())) {
                                    echo ($form['Formas']['id']->render());
                                    echo ($form['Formas']['id_gca_pagos']->render());
                                }
                                ?>
                                <br>
                                <table  border="0" width="100%">
                                    <tr>
                                        <td width="400px" align="left"  valign="top"> <!--Distribuci�n pago... -->
                                            <table class="nuevo"  width="250px" border="0">
                                                <?php
                                                $option[0] = "";
                                                $option[1] = "";
                                                $option[2] = "";
                                                $option[3] = "";
                                                $option[4] = "";
                                                $valores = Array();
                                                $valores[0] = 0;
                                                $valores[1] = 0;
                                                $valores[2] = 0;
                                                $valores[3] = 0;
                                                $valores[4] = 0;
                                                $tipo_pago = array();
                                                $tipo_pago[0] = "";
                                                $tipo_pago[1] = "";
                                                $tipo_pago[2] = "";
                                                $tipo_pago[3] = "";
                                                $tipo_pago[4] = "";
                                                $tipo_pago[5] = "";
                                                $tipo_pago[6] = "";
                                                $tipo_pago[7] = "";
                                                //var_dump($obligacionesPagos);
                                                //exit;
                                                if (isset($obligacionesPagos)) {
                                                    $obligacionesPagos = $sf_data->getRaw('obligacionesPagos'); //para que no se convierta en arrayDecorator...
                                                    for ($i = 0; $i < 5; $i++) {
                                                        $option[$i] = array();
                                                        $option[$i][] = "<option></option>";
                                                        $sel = false;
                                                        foreach ($obligacionesPagos as $obl => $oblig) {
                                                            if ($oblig["entidad"] * 1 > 0 && $obligacionesPagos[$obl]["selected"] == 0 && !$sel) {
                                                                $obligacionesPagos[$obl]["selected"] = 1;
                                                                $sel = true;
                                                                $valores[$i] = $oblig['entidad'];
                                                                $tipo_pago[$i] = $oblig['tipo_pago'];
                                                                $selected = " selected='selected' ";
                                                            } else {
                                                                $selected = "";
                                                            }
                                                            $option[$i][] = "<option $selected value='" . $oblig['obligacion'] . "'>" . $oblig['obligacion'] . "</option>";
                                                        }
                                                        $option[$i] = implode("", $option[$i]);
                                                    }
                                                }
                                                for ($i = 1; $i <= 5; $i++) {
                                                    $nombre = "select_" . $i; //genera el nombre de la variable
                                                    $id = "concepto_" . $i;
                                                    $selpn = "";
                                                    $selpt = "";
                                                    $selho = "";
                                                    $selps = "";
                                                    $selc1 = "";
                                                    $selc3 = "";
                                                    $selc5 = "";
                                                    if ($tipo_pago[$i - 1] == "PN")
                                                        $selpn = "selected";
                                                    if ($tipo_pago[$i - 1] == "PT")
                                                        $selpt = "selected";
                                                    if ($tipo_pago[$i - 1] == "HO")
                                                        $selho = "selected";
                                                    if ($tipo_pago[$i - 1] == "PS")
                                                        $selps = "selected";
                                                    if ($tipo_pago[$i - 1] == "C1")
                                                        $selc1 = "selected";
                                                    if ($tipo_pago[$i - 1] == "C3")
                                                        $selc3 = "selected";
                                                    if ($tipo_pago[$i - 1] == "C5")
                                                        $selc5 = "selected";


                                                    $select_1[] = "<select name=\"concepto[]\" id=\"$id\">
                                                                            <option></option>
                                                                            <option value=\"PN\" " . $selpn . ">Abono</option>
                                                                            <option value=\"PT\" " . $selpt . ">Pago Total</option>
                                                                            <option value=\"HO\" " . $selho . ">Honorarios</option>
                                                                           <!-- <option value=\"PS\" " . $selps . ">Paz y Salvo</option>-->
                                                                            <option value=\"C1\" " . $selc1 . ">C1</option>
                                                                            <option value=\"C3\" " . $selc3 . ">C3</option>
                                                                            <option value=\"C5\" " . $selc5 . ">C5</option>
                                                                            </select>";
                                                }
                                                ?>
                                                <tr><th colspan="3">Distribuya el pago, si va para <font color="blue"> m&aacute;s de una  Obligaci&oacute;n... </font><br></th></tr>
                                                <tr class="listheading">  
                                                    <td>Concepto</td>
                                                    <td>Obligaci&oacute;n</td>  
                                                    <td>Saldo Mora</td>   
                                                    <td>Valor</td>  
                                                </tr> 
                                                <tr> <td><?php echo $select_1[0]; ?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones1"><?php echo $option[0]; ?></select></td>  <td align="right" ><input type="text" name="saldo_m[]" id="saldo_m1" value="" readonly="readonly"></td><td align="right" ><input type="text" name="valorT[]" id="obl1T" value="<?php echo number_format($valores[0]); ?>" onkeyup="javascript:formatear('obl1T', 'obl1')"><input type="hidden" name="valor[]" id="obl1" value="<?php echo $valores[0]; ?>"></td></tr> 
                                                <tr> <td><?php echo $select_1[1]; ?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones2"><?php echo $option[1]; ?></select></td>  <td align="right" ><input type="text" name="saldo_m[]" id="saldo_m2" value="" readonly="readonly"></td><td align="right" ><input type="text" name="valorT[]" id="obl2T" value="<?php echo number_format($valores[1]); ?>" onkeyup="javascript:formatear('obl2T', 'obl2')"><input type="hidden" name="valor[]" id="obl2" value="<?php echo $valores[1]; ?>"></td></tr>
                                                <tr> <td><?php echo $select_1[2]; ?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones3"><?php echo $option[2]; ?></select></td>  <td align="right" ><input type="text" name="saldo_m[]" id="saldo_m3" value="" readonly="readonly"></td><td align="right" ><input type="text" name="valorT[]" id="obl3T" value="<?php echo number_format($valores[2]); ?>" onkeyup="javascript:formatear('obl3T', 'obl3')"><input type="hidden" name="valor[]" id="obl3" value="<?php echo $valores[2]; ?>"></td></tr>
                                                <tr> <td><?php echo $select_1[3]; ?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones4"><?php echo $option[3]; ?></select></td>  <td align="right" ><input type="text" name="saldo_m[]" id="saldo_m4" value="" readonly="readonly"></td><td align="right" ><input type="text" name="valorT[]" id="obl4T" value="<?php echo number_format($valores[3]); ?>" onkeyup="javascript:formatear('obl4T', 'obl4')"><input type="hidden" name="valor[]" id="obl4" value="<?php echo $valores[3]; ?>"></td></tr>
                                                <tr> <td><?php echo $select_1[4]; ?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones5"><?php echo $option[4]; ?></select></td>  <td align="right" ><input type="text" name="saldo_m[]" id="saldo_m5" value="" readonly="readonly"></td><td align="right" ><input type="text" name="valorT[]" id="obl5T" value="<?php echo number_format($valores[4]); ?>" onkeyup="javascript:formatear('obl5T', 'obl5')"><input type="hidden" name="valor[]" id="obl5" value="<?php echo $valores[4]; ?>"></td></tr>  
                                            </table>
                                        </td>
                                        <td width="300px"><!--subtotales -->
                                            <table  class="nuevo"  align="right" width="250px" border="0" >
                                                <tr>    
                                                    <th class="listheading" width="120px">&nbsp;&nbsp;<?php echo ($form['entidad']->renderLabel()) ?>: </th>
                                                    <th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT" value="<?php echo number_format($form['entidad']->getValue()) ?>"
                                                               readonly  />
                                                        <input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" value="<?php echo $form['entidad']->getValue(); ?>" />
                                                    </th>    
                                                    <th>&nbsp;</th>
                                                </tr>
                                                <tr>    
                                                    <th class="listheading"> Paz  y Salvo <?php //echo ($form['cpm']->renderLabel())                   ?>: </th>
                                                    <th><input type="text" id="gca_pagos_cpmT" name="gca_pagos_cpmT"  onkeyup="calcular(<?php echo $honorarios . ', ' . $iva; ?>);"  value="<?php echo number_format($form['cpm']->getValue()) ?>" readonly/> </th>	
                                                    <th>&nbsp;</th>
                                                </tr>
                                                <tr>    
                                                    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['otros']->renderLabel()) ?>: </th>
                                                    <th><input type="text" id="gca_pagos_otrosT" name="gca_pagos_otrosT"  onkeyup="calcular(<?php echo $honorarios . ', ' . $iva; ?>);" value="<?php echo number_format($form['otros']->getValue()) ?>" readonly/> 
                                                    </th>
                                                    <th>&nbsp;</th>
                                                </tr>    
                                                <tr>    
                                                    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['abogados']->renderLabel()) ?>: </th>
                                                    <th><input type="text" id="gca_pagos_abogadosT" name="gca_pagos_abogadosT" value="<?php echo number_format($form['abogados']->getValue()) ?>" readonly/> 
                                                    </th>
                                                    <th>&nbsp;</th>
                                                </tr> 

                                                <tr>   
                                                    <th class="listheading">&nbsp;&nbsp;<?php echo ($form['honorarios']->renderLabel()) ?>: </th>
                                                    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" value="<?php echo number_format($form['honorarios']->getValue()) ?>" readonly /> </th>
                                                    <th><div id="porcentaje_honorarios"><?php echo ($honorarios * 100) . '%'; ?></div></th>
                                    </tr>
                                    <tr>   
                                        <th class="listheading">&nbsp;&nbsp;<?php echo ($form['iva']->renderLabel()) ?>: </th>
                                        <th><input type="text" id="gca_pagos_ivaT" name="gca_pagos_ivaT" value="<?php echo number_format($form['iva']->getValue()) ?>" readonly />  </th>
                                        <th><?php echo ($iva * 100) . '%'; ?></th>
                                    </tr>      
                                    <tr>

                                        <th class="listheading"><font color="yellow">&nbsp;&nbsp;<?php echo ($form['valor_total']->renderLabel()) ?>: </th>
                                        <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" value="<?php echo number_format($form['valor_total']->getValue()) ?>" readonly/>   </th>
                                    </tr> 

                                    <tr>
                                        <td colspan="3" align="center"> 	 <br>
                                            <?php
                                            if ($is_tesorero == false or $is_tesorero == "")
                                                $is_tesorero = 0;

                                            if ($form->getObject()->isNew() or $formulario == "edit_tesorero" or $formulario == 'editar_pagos') {
                                                if ($form->getObject()->isNew())
                                                    $boton = "Guardar";
                                                elseif ($formulario == "edit_tesorero") {
                                                    if ($is_tesorero == true and $form['nro_rc']->getValue() != null)
                                                        $boton = "Modificar";
                                                    elseif ($is_tesorero == true or $is_tesorero_sucursal == true and $form['nro_rc']->getValue() == null)
                                                        $boton = "Registrar";

                                                    elseif ($is_coordinador == true)
                                                        $boton = "Aprobar";
                                                }
                                                if ($_GET['action_gene']) {
                                                    
                                                } else {
                                                    ?> 	    
                                                    <br><input type="button" value="<?php print $boton ?>" name="guardar" onClick="javascript:validar_expediente('<?php echo $is_tesorero ?>')"/>	
                                                    <?php
                                                }
                                            }

                                            if (!$form->getObject()->isNew()) {
                                                if (($is_tesorero == true or $is_tesorero_sucursal == true) and $pago->getEstado() == 2) {

                                                    $url = url_for('frontPagos/search?accion=imprimir&id=' . $pago->getId());
                                                    ?><input type="button" value="Imprimir" name="imprimir" onClick="javascript:enviar('<?php echo $url ?>')" ><?php
                                                }
                                                if ($is_tesorero == true and $pago->getEstado() == 6) {//solo anulaados  para Mery
                                                    $url = url_for('frontPagos/search?accion=imprimir&id=' . $pago->getId());
                                                    ?><input type="button" value="Imprimir" name="imprimir" onClick="javascript:enviar('<?php echo $url ?>')" ><?php
                                                }


                                                if (($is_tesorero == true or $is_tesorero_sucursal == true)) {
                                                    $condicion = "";
                                                    if ($opcion == "searchPagos")
                                                        $url = url_for('frontPagos/searchPagos?1=1' . $condicion);
                                                    else
                                                        $url = url_for('frontPagos/search?1=1' . $condicion);
                                                    ?>	
                                                    <input type="button" value="Volver" name="Volver" onClick="javascript:enviar('<?php echo $url ?>')" >			
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </td></tr>
                                </table>
                            </td>
                            <td width="280px" align='right'>
                                <table  width='80%' >
                                    <tr>
                                        <td colspan="4" class="listheading">Solicitud de Condonación</td>
                                    </tr>
                                    <tr>
                                        <td class="listheading">No. Solicitud</td>
                                        <td><input type="text" name="id_condonacion" id="solicitud" readonly="readonly" value="<?php echo $id_condonacion; ?>"></td>
                                        <!--                                    </tr>
                                                                            <tr>-->
                                        <td class="listheading">Estado</td>
                                        <td><input type="text" name="solicitud2" id="solicitud2" readonly="readonly" value="<?php echo $estado; ?>"></td>
                                    </tr>
                                    <tr>
                                        <td class="listheading">Total Condonación</td>
                                        <td>
                                            <input type="text" name="total_solicitud" id="total_solicitud" readonly="readonly" value="<?php echo $total_condonacion; ?>">
                                        </td>
                                        <td rowspan="2" colspan="2">
                                    <center><a href="#openModal"><button type="button" class="consultar_con" onclick="consultar_con()">Consultar</button></a></center></td>
                        </tr>
                        <tr>
                            <td class="listheading">Total a Pagar</td>
                            <td><input type="text" name="total_pagar" readonly="readonly" id="total_pagar" value="<?php echo $saldo_credito; ?>"></td>
                        </tr>
                    </table>
                    </td>
                    </tr>
                    </table>
                    </td>
                    </tr>
                    </table>
                    <?php echo $form->renderHiddenFields(); ?>
                    <input type="hidden" name="formulario" id="formulario"  value="<?print $formulario?>">
                    <!--para cuando va al registro, conserve los parametros iniciales-->
                    <input type="hidden" name="cartera_elejida"  value="<?php echo $cartera_elejida; ?>"> 
                    <input type="hidden" name="estado"  value="<?php echo $estado_elejido; ?>"> 
                    <input type="hidden" name="number" id="number">
                    <input type="hidden" name="versolicitud" id="versolicitud">
                    </form>
                    </body>


                    <script>

                        function enviar(url) {
                            location.href = url;
                        }


                        function formatear(id, id2) {
                            document.getElementById(id).value = CurrencyFormatted(document.getElementById(id).value);
                            var v1 = document.getElementById(id).value;
                            document.getElementById(id2).value = v1.replace(/,/g, '');

                        }
                        function formatear2(id) {
                            document.getElementById(id).value = CurrencyFormatted(document.getElementById(id).value);
                        }
                        function entidad_calcular(honorarios, iva) {
                            entidad = $('#gca_pagos_Formas_entidadT').val();
                            entidad = entidad.replace(/,/g, '');
                            honorario = parseFloat(entidad) * parseFloat(honorarios);
                            iva = parseFloat(honorario) * parseFloat(iva);
                            suma = parseInt(entidad) + parseInt(iva) + parseInt(honorario);
                            console.log(suma)
                            $('#gca_pagos_Formas_valorT').val(suma);
                            $('#gca_pagos_Formas_valor').val(suma);
                            calcular(0.2, 0.16, 1);
                        }

                        function calcular(honorarios, ivaP, forma) {

                            if (forma == 1)
                                id = "";
                            if (forma == 2)
                                id = 2;
                            if (forma == 3)
                                id = 3;


                            $('#gca_pagos_Formas_cpmT').val('0')
                            $('#gca_pagos_Formas_cpm').val('0')
                            $('#gca_pagos_Formas_otrosT').val('0')
                            $('#gca_pagos_Formas_otros').val('0')

                            $('#gca_pagos_cpmT').val('0')
                            $('#gca_pagos_cpm').val('0')
                            $('#gca_pagos_otrosT').val('0')
                            $('#gca_pagos_otros').val('0')

                            var honorarios = document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera
                            var entidad = document.getElementById("gca_pagos_entidad");
                            var entidadT = document.getElementById("gca_pagos_entidadT");
                            var total = document.getElementById("gca_pagos_valor_total");

                            var vlr = "gca_pagos_Formas" + id + "_valor";
                            var vlrT = "gca_pagos_Formas" + id + "_valorT";
                            var ent = "gca_pagos_Formas" + id + "_entidad";
                            var entT = "gca_pagos_Formas" + id + "_entidadT";
                            var hnr = "gca_pagos_Formas" + id + "_honorarios";
                            var hnrT = "gca_pagos_Formas" + id + "_honorariosT";
                            var iva = "gca_pagos_Formas" + id + "_iva";
                            var ivaT = "gca_pagos_Formas" + id + "_ivaT";
                            var cpm = "gca_pagos_Formas" + id + "_cpm";
                            var cpmF = "gca_pagos_Formas" + id + "_cpmT";

                            var otros = "gca_pagos_Formas" + id + "_otros";
                            var otrosT = "gca_pagos_Formas" + id + "_otrosT";
                            var abog = "gca_pagos_Formas" + id + "_abogados";
                            var abogT = "gca_pagos_Formas" + id + "_abogadosT";

                            var f1 = document.getElementById(vlrT).value == '' ? 0 : document.getElementById(vlrT).value.replace(/,/g, '');
                            var valorForma = document.getElementById(vlr).value = f1;
                            document.getElementById(vlrT).value = CurrencyFormatted(f1);
                            var valor_entidadForma = Math.round(parseFloat((valorForma - 0) / (1 + parseFloat(honorarios) + parseFloat(ivaP) * parseFloat(honorarios) + 0)));

                            var valor_honorariosForma = Math.round(valor_entidadForma * parseFloat(honorarios))
                            document.getElementById(entT).value = CurrencyFormatted(valor_entidadForma)
                            document.getElementById(ent).value = valor_entidadForma
                            document.getElementById(hnrT).value = CurrencyFormatted(valor_honorariosForma)
                            document.getElementById(hnr).value = valor_honorariosForma
                            document.getElementById(ivaT).value = CurrencyFormatted(Math.round(valor_honorariosForma * parseFloat(ivaP)))
                            document.getElementById(iva).value = Math.round(valor_honorariosForma * parseFloat(ivaP))

                            var cpm1 = document.getElementById(cpmF).value.replace(/,/g, '');
                            document.getElementById(cpm).value = cpm1.replace(/,/g, '');

                            var otr = document.getElementById(otrosT).value.replace(/,/g, '');
                            document.getElementById(otros).value = otr.replace(/,/g, '');

                            var abg = document.getElementById(abogT).value.replace(/,/g, '');
                            document.getElementById(abog).value = abg.replace(/,/g, '');

                            //Los totales, son las sumatorias de cada forma de pago

                            total.value = total.value == '' ? 0 : total.value;
                            var totalF1 = document.getElementById("gca_pagos_Formas_valor").value == '' ? 0 : document.getElementById("gca_pagos_Formas_valor").value;
                            total.value = parseFloat(totalF1);//+ parseFloat( totalF2)+parseFloat(totalF3);    
                            document.getElementById("gca_pagos_valor_totalT").value = CurrencyFormatted(total.value);

                            //calculo entidad 
                            var entF1 = document.getElementById("gca_pagos_Formas_entidad").value == '' ? 0 : document.getElementById("gca_pagos_Formas_entidad").value;
                            entidad.value = Math.round(parseFloat(entF1), 0);//+parseFloat(entF2)+parseFloat(entF3),0);

                            //calculo honor
                            var hnoF1 = document.getElementById("gca_pagos_Formas_honorarios").value == '' ? 0 : document.getElementById("gca_pagos_Formas_honorarios").value;
                            var valor_honorarios = Math.round(parseFloat(hnoF1), 0);//+parseFloat(hnoF2)+parseFloat(hnoF3),0);


                            //calculo iva
                            var ivaF1 = document.getElementById("gca_pagos_Formas_iva").value == '' ? 0 : document.getElementById("gca_pagos_Formas_iva").value;
                            var valor_iva = Math.round(parseFloat(ivaF1), 0);//+parseFloat(ivaF2)+parseFloat(ivaF3),0);

                            document.getElementById("gca_pagos_entidadT").value = CurrencyFormatted(entidad.value);
                            document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valor_honorarios);
                            document.getElementById("gca_pagos_honorarios").value = valor_honorarios;
                            document.getElementById("gca_pagos_ivaT").value = CurrencyFormatted(valor_iva);
                            document.getElementById("gca_pagos_iva").value = valor_iva;
                            var total_valor = 0;
                            if ($('#saldo_m1').val() != 0) {
                                var rr = 0;
                                for (i = 1; i < 5; i++) {
                                    if ($('#saldo_m' + i + '').val() != 0) {
                                        saldo = $('#saldo_m' + i + '').val();
                                        saldo = saldo.replace(/,/g, '');
                                        total_valor += parseInt(saldo)
                                        rr++;
                                    }
                                }
//                                var total=$('#gca_pagos_Formas_valorT').val();
                                var total = document.getElementById('gca_pagos_Formas_entidadT').value.replace(/,/g, '');
                                saldo_ya = 0;
                                for (i = 1; i < 5; i++) {
                                    if ($('#saldo_m' + i + '').val() != 0) {
                                        saldo = $('#saldo_m' + i + '').val();
                                        saldo = saldo.replace(/,/g, '');
                                        porcentaje = (saldo * 100) / total_valor
                                        porcentaje = Math.round(porcentaje);
                                        resultado = Math.round((total * porcentaje) / 100);
//                                        saldo cons=$('#gca_pagos_Formas_entidadT').val();
//                                        saldo = saldo.replace(/,/g, '');
                                        if ($('#gca_pagos_por_concepto').val() == 'UP') {
                                            if (resultado != saldo) {

                                                $('#obl' + i + '').val((Math.round(saldo)));
                                                $('#obl' + i + 'T').val(CurrencyFormatted(Math.round(saldo)));
                                            } else {
                                                $('#obl' + i + '').val((Math.round(resultado)));
                                                $('#obl' + i + 'T').val(CurrencyFormatted(Math.round(resultado)));
                                            }
                                        } else {
                                            $('#obl' + i + '').val(Math.round(resultado));
                                            $('#obl' + i + 'T').val(CurrencyFormatted(Math.round(resultado)));
                                        }
                                        saldo_ya += Math.round(resultado);
                                        $('#obl' + i + '').val();
                                        t = i;
//                                        $('#obl' + i + 'T').val(CurrencyFormatted(Math.round(total / rr)));
                                    }
                                }
                                if (saldo_ya != total) {
                                    sa = parseInt(total) - parseInt(saldo_ya);
                                    nn = $('#obl' + t + '').val();
                                    resul = parseInt(sa) + parseInt(nn)
                                    $('#obl' + t + '').val(Math.round(resul));
                                    $('#obl' + t + 'T').val(CurrencyFormatted(Math.round(resul)));
                                }
                            }
                            uuuu=0;
                        }


                        /*recalcula valores totales, cuando se ingresan valores manuales para entidad, cpm y otros*/
                        function recalcularValores() {
                            var honorarios = parseFloat(document.getElementById('honorarios').value); //document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera  
                            var iva = parseFloat(0.16);
                            var entidadT = parseFloat(document.getElementById("gca_pagos_entidadT").value);
                            var total = parseFloat(document.getElementById("gca_pagos_valor_total").value);
                            var cpm = parseFloat(document.getElementById("gca_pagos_cpm").value);
                            var otros = parseFloat(document.getElementById("gca_pagos_otros").value);
                            var abogados = parseFloat(document.getElementById("gca_pagos_abogados").value);

                            restante = Math.round(total - entidadT - cpm - otros - abogados);

                            if (restante >= 0) {
                                valor_iva = Math.round(restante * iva);
                                valor_honorarios = Math.round(restante - valor_iva);

                                document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valor_honorarios);
                                document.getElementById("gca_pagos_iva").value = CurrencyFormatted(valor_iva);
                            } else {
                                alert("El valor de la entidad, 4 x mil y otros, no debe superar la cantidad cancelada ")
                            }
                            otros_paz()
                        }

                        /*Permite calcular valores totales,cuando se ingresan valores manuales para las formas de pago */
                        function calcularValores(porcHon, porcIva, forma) {
                            if (forma == 1)
                                id = "";
                            if (forma == 2)
                                id = 2;
                            if (forma == 3)
                                id = 3;

                            var entT = "gca_pagos_Formas" + id + "_entidadT";
                            var ent = "gca_pagos_Formas" + id + "_entidad";

                            var cpmT = "gca_pagos_Formas" + id + "_cpmT";
                            var cpm = "gca_pagos_Formas" + id + "_cpm";

                            //var vlrT="gca_pagos_Formas"+id+"_valorT";
                            var vlr = "gca_pagos_Formas" + id + "_valor";

                            var ivaT = "gca_pagos_Formas" + id + "_ivaT";
                            var iva = "gca_pagos_Formas" + id + "_iva";

                            var honT = "gca_pagos_Formas" + id + "_honorariosT";
                            var hon = "gca_pagos_Formas" + id + "_honorarios";

                            var otrosT = "gca_pagos_Formas" + id + "_otrosT";
                            var otros = "gca_pagos_Formas" + id + "_otros";

                            var abogT = "gca_pagos_Formas" + id + "_abogadosT";
                            var abog = "gca_pagos_Formas" + id + "_abogados";

                            //formateo///
                            document.getElementById(entT).value = CurrencyFormatted(document.getElementById(entT).value);
                            var v1 = document.getElementById(entT).value;
                            var valorEntidad1 = document.getElementById(ent).value = v1.replace(/,/g, '');

                            document.getElementById(otrosT).value = CurrencyFormatted(document.getElementById(otrosT).value);
                            var otr = document.getElementById(otrosT).value
                            var vlr_otros = document.getElementById(otros).value = otr.replace(/,/g, '');

                            document.getElementById(abogT).value = CurrencyFormatted(document.getElementById(abogT).value);
                            var abg = document.getElementById(abogT).value
                            var vlr_abog = document.getElementById(abog).value = abg.replace(/,/g, '');

                            document.getElementById(cpmT).value = CurrencyFormatted(document.getElementById(cpmT).value)
                            var cpm1 = document.getElementById(cpmT).value;
                            var cpmForma1 = document.getElementById(cpm).value = cpm1.replace(/,/g, '');

                            //Calculos....    
                            var entF1 = document.getElementById("gca_pagos_Formas_entidad").value == '' ? 0 : document.getElementById("gca_pagos_Formas_entidad").value;

                            var valorTotalEntidad = parseFloat(entF1);//+parseFloat(entF2)+parseFloat(entF3);

                            document.getElementById("gca_pagos_entidadT").value = CurrencyFormatted(valorTotalEntidad)
                            document.getElementById("gca_pagos_entidad").value = valorTotalEntidad;


                            //calculos sobre el valor a la entidad-4xmil-abogados
                            var total_f = document.getElementById(vlr).value
                            var restante = parseFloat(total_f - valorEntidad1 - cpmForma1 - vlr_abog - vlr_otros)

                            //calculo iva
                            var ivaForma = Math.round(parseFloat(restante) * parseFloat(porcIva) / parseFloat(1 + porcIva), 0);
                            document.getElementById(ivaT).value = CurrencyFormatted(ivaForma);
                            document.getElementById(iva).value = ivaForma;
                            var ivaF1 = document.getElementById("gca_pagos_Formas_iva").value == '' ? 0 : document.getElementById("gca_pagos_Formas_iva").value;

                            var valorTotalIva = Math.round(parseFloat(ivaF1), 0);//+parseFloat(ivaF2)+parseFloat(ivaF3),0);
                            document.getElementById("gca_pagos_ivaT").value = CurrencyFormatted(valorTotalIva);
                            document.getElementById("gca_pagos_iva").value = valorTotalIva;


                            //calculo honorarios... al  hacerse manual.. no aplica el porc de honorario..
                            var honForma = Math.round(parseFloat(restante) - ivaForma, 0);
                            document.getElementById(honT).value = CurrencyFormatted(honForma);
                            document.getElementById(hon).value = honForma;

                            var hnoF1 = document.getElementById("gca_pagos_Formas_honorarios").value == '' ? 0 : document.getElementById("gca_pagos_Formas_honorarios").value;
                            var valorTotalHon = Math.round(parseFloat(hnoF1), 0);//+parseFloat(hnoF2)+parseFloat(hnoF3),0);
                            document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valorTotalHon)
                            document.getElementById("gca_pagos_honorarios").value = valorTotalHon;

                            //calculo otros
                            var otrF1 = document.getElementById("gca_pagos_Formas_otros").value == '' ? 0 : document.getElementById("gca_pagos_Formas_otros").value;

                            var valorTotalOtros = Math.round(parseFloat(otrF1), 0);//+parseFloat(otrF2)+parseFloat(otrF3),0); 
                            document.getElementById("gca_pagos_otrosT").value = CurrencyFormatted(valorTotalOtros);
                            document.getElementById("gca_pagos_otros").value = valorTotalOtros;

                            //calculo cpm
                            var cpmF1 = document.getElementById("gca_pagos_Formas_cpm").value == '' ? 0 : document.getElementById("gca_pagos_Formas_cpm").value;

                            var valorTotaCpm = Math.round(parseFloat(cpmF1), 0);//+parseFloat(cpmF2)+parseFloat(cpmF3),0); 
                            document.getElementById("gca_pagos_cpmT").value = CurrencyFormatted(valorTotaCpm);
                            document.getElementById("gca_pagos_cpm").value = valorTotaCpm;

                            //calculo abogados
                            var abogF1 = document.getElementById("gca_pagos_Formas_abogados").value == '' ? 0 : document.getElementById("gca_pagos_Formas_abogados").value;

                            var valorTotalAbog = Math.round(parseFloat(abogF1), 0);// + parseFloat(abogF2) + parseFloat(abogF3),0); 
                            document.getElementById("gca_pagos_abogadosT").value = CurrencyFormatted(valorTotalAbog)
                            document.getElementById("gca_pagos_abogados").value = valorTotalAbog;
                        }
                        uuuu = 0;
                        function otros_paz2() {
                            var paz = $('#gca_pagos_Formas_cpmT').val();// paz y salvo
                            var entidad = $('#gca_pagos_Formas_valorT').val();// entidad
                            entidad=entidad.replace(/,/g, '')
                            paz=paz.replace(/,/g, '')
                            if(paz==""){
                               paz=0; 
                            }
                            entidad=(parseInt(paz)+parseInt(entidad))-uuuu;
                            uuuu=paz
                            console.log(uuuu)
                            
                            $('#gca_pagos_Formas_cpmT').val(CurrencyFormatted(paz));// paz
                            $('#gca_pagos_cpmT').val(CurrencyFormatted(paz));// paz
                            $('#gca_pagos_Formas_valorT').val(CurrencyFormatted(entidad));// entidad
                            $('#gca_pagos_valor_totalT').val(CurrencyFormatted(entidad));// entidad
//                            $('#gca_pagos_Formas_cpmT').val(paz)
//                            var entidad = $('#gca_pagos_Formas_valorT').val();// entidad
//                            if (entidad != 0) {
//                                paz = parseInt(paz) / 10;
//                                entidad = parseInt(entidad) - parseInt(paz);
//                            }
//                            console.log(entidad)
//                            $('#gca_pagos_Formas_valorT').val((parseInt(entidad) + parseInt(paz)))
//                            $('#gca_pagos_Formas_valorT').val(CurrencyFormatted(entidad))
                        }
                        function otros_paz() {
                            ///////////////////////////////////////

                            if ($('#gca_pagos_Formas_cpmT').val() != 0 ||
                                    $('#gca_pagos_Formas_otrosT').val() != 0) {
                                var entidad = $('#gca_pagos_Formas_entidadT').val();// entidad
                                var paz = $('#gca_pagos_Formas_cpmT').val();// paz y salvo
                                var honorarios = $('#gca_pagos_Formas_honorariosT').val();// Honorarios
                                var otros = $('#gca_pagos_Formas_otrosT').val();// otros
                                var iva = $('#gca_pagos_Formas_ivaT').val();// iva
                                var abogados = $('#gca_pagos_Formas_abogadosT').val();// abogados
                                var valor = $('#gca_pagos_Formas_valorT').val();// valor
                                paz = paz.replace(/,/g, '');
                                honorarios = honorarios.replace(/,/g, '');
                                otros = otros.replace(/,/g, '');
                                iva = iva.replace(/,/g, '');
                                abogados = abogados.replace(/,/g, '');
                                valor = valor.replace(/,/g, '');
                                //Entidad = Valor – (Paz y salvo + Honorarios + Otros + Iva + Abogados) 
                                entidad = parseInt(valor) - (parseInt(honorarios) + parseInt(otros) + parseInt(iva) + parseInt(abogados));
                                $('#gca_pagos_Formas_entidadT').val(CurrencyFormatted(entidad))
                                $('#gca_pagos_Formas_entidad').val(entidad)
                                $('#gca_pagos_Formas_cpmT').val(paz)
                                $('#gca_pagos_Formas_cpm').val(CurrencyFormatted(paz))
                                $('#gca_pagos_Formas_otrosT').val(otros)
                                $('#gca_pagos_Formas_otros').val(CurrencyFormatted(otros))


                                $('#gca_pagos_entidadT').val(CurrencyFormatted(entidad))
                                $('#gca_pagos_entidad').val(entidad)
                                $('#gca_pagos_cpmT').val(CurrencyFormatted(paz))
                                $('#gca_pagos_cpm').val(paz)
                                $('#gca_pagos_otrosT').val(CurrencyFormatted(otros))
                                $('#gca_pagos_otros').val(otros)
                            }
                        }

                        function cargarFechas()
                        {
                            var forma_pago = document.getElementById('gca_pagos_Formas_forma_pago').value;
                            if (forma_pago == 1 || forma_pago == 4) {
                                document.getElementById('gca_pagos_Formas_fecha_month').disabled = false;
                                document.getElementById('gca_pagos_Formas_fecha_year').disabled = false;
                                document.getElementById('gca_pagos_Formas_fecha_day').disabled = false;
                            } else {
                                document.getElementById('gca_pagos_Formas_fecha_month').disabled = true;
                                document.getElementById('gca_pagos_Formas_fecha_year').disabled = true;
                                document.getElementById('gca_pagos_Formas_fecha_day').disabled = true;
                            }

                        }


                        function CurrencyFormatted(num) {
                            num = num.toString().replace(/\$|\,/g, '');
                            if (isNaN(num))
                                num = "0";
                            sign = (num == (num = Math.abs(num)));
                            num = Math.floor(num * 100 + 0.50000000001);
                            cents = num % 100;
                            num = Math.floor(num / 100).toString();
                            if (cents < 10)
                                cents = "0" + cents;
                            for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
                                num = num.substring(0, num.length - (4 * i + 3)) + ',' +
                                        num.substring(num.length - (4 * i + 3));
                            return (((sign) ? '' : '-') + num);
                        }

                        /*para habilitar fechas de acuerdo a la elecci�n de la forma de pago*/

                        document.getElementById('gca_pagos_Formas_forma_pago').onchange = function() {
                            var forma_pago = document.getElementById('gca_pagos_Formas_forma_pago').value;
                            if (forma_pago == 1 || forma_pago == 4) {
                                document.getElementById('gca_pagos_Formas_fecha_month').disabled = false;
                                document.getElementById('gca_pagos_Formas_fecha_year').disabled = false;
                                document.getElementById('gca_pagos_Formas_fecha_day').disabled = false;
                            } else {
                                document.getElementById('gca_pagos_Formas_fecha_month').disabled = true;
                                document.getElementById('gca_pagos_Formas_fecha_year').disabled = true;
                                document.getElementById('gca_pagos_Formas_fecha_day').disabled = true;
                            }
                        }
                        abogado = "";

                        /*Permite calcular el honorario, y traer  deudor de acuerdo a la cartera escogida*/
                        var cambio_cartera = function(obj) {
                            var nro_expediente = document.getElementById('gca_pagos_obligacion').value;
                            var oblig_dia = document.getElementById('oblig_dia').checked;
                            var id_cartera = document.getElementById('gca_pagos_id_cartera').value;
                            var cedula = document.getElementById('gca_pagos_cedula2').value;

                            if (cedula == "" && nro_expediente == "") {
                                $('#gca_pagos_obligacion').removeAttr('disabled');
                                $('#gca_pagos_cedula2').removeAttr('disabled');
                                return false;
                            }
                            if (cedula == "") {
                                $('#gca_pagos_cedula2').attr('disabled', true);
                                $('#gca_pagos_obligacion').removeAttr('disabled');
                            }
                            if (nro_expediente == "") {
                                $('#gca_pagos_obligacion').attr('disabled', true);
                                $('#gca_pagos_cedula2').removeAttr('disabled');
                            }
                            if (id_cartera == "") {
                                return false;
                            }
                            if (nro_expediente == "") {
                                nro_expediente = "0";
                            }
                            if (cedula == "") {
                                cedula = "0";
                            }
                            $.getJSON("<?php echo $urlJson; ?>/id_cartera/" + id_cartera + "/expediente/" + nro_expediente + "/oblig_dia/" + oblig_dia + "/cedula/" + cedula,
                                    function(data) {
                                        $.each(data.registros, function(i, item) {
                                            //alert("hola"+item.existe_expediente)		
                                            document.getElementById('honorarios').value = item.honorarios;
                                            document.getElementById('porcentaje_honorarios').innerHTML = document.getElementById('honorarios').value * 100 + "%";
                                            if (item.existe_expediente == 0) {
                                                alert("La obligacion no pertenece a la cartera seleccionada!");
                                                document.getElementById('ban_expediente').value = 0;
                                                document.getElementById('deudor').innerHTML = 'Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
                                            } else {
                                                document.getElementById('ban_expediente').value = 1;
                                                document.getElementById('deudor').innerHTML = item.nombre;
                                                document.getElementById('gca_pagos_nombre_rc').value = item.nombre;
                                                document.getElementById('gca_pagos_nombre_deudor').value = item.nombre;
                                                document.getElementById('gca_pagos_cedula').value = item.cedula;
                                                abogado = abogado;
                                                //alert("si"+item.obligaciones.length)
                                                var oblig1 = document.getElementById('obligaciones1');
                                                var oblig2 = document.getElementById('obligaciones2');
                                                var oblig3 = document.getElementById('obligaciones3');
                                                var oblig4 = document.getElementById('obligaciones4');
                                                var oblig5 = document.getElementById('obligaciones5');
                                                oblig1.length = item.obligaciones.length + 1;
                                                oblig2.length = item.obligaciones.length + 1;
                                                oblig3.length = item.obligaciones.length + 1;
                                                oblig4.length = item.obligaciones.length + 1;
                                                oblig5.length = item.obligaciones.length + 1;
                                                var total_valor = 0;
                                                for (var i = 1; i <= item.obligaciones.length; i++) {
                                                    oblig1.selectedIndex = i;
                                                    oblig2.selectedIndex = i;
                                                    oblig3.selectedIndex = i;
                                                    oblig4.selectedIndex = i;
                                                    oblig5.selectedIndex = i;
                                                    oblig1.options[i].text = item.obligaciones[i - 1];
                                                    oblig2.options[i].text = item.obligaciones[i - 1];
                                                    oblig3.options[i].text = item.obligaciones[i - 1];
                                                    oblig4.options[i].text = item.obligaciones[i - 1];
                                                    oblig5.options[i].text = item.obligaciones[i - 1];
                                                    $('#obl' + i + 'T').val(CurrencyFormatted(item.saldos[i - 1]));
                                                    $('#saldo_m' + i + '').val(CurrencyFormatted(item.saldos[i - 1]));
                                                    $('#obl' + i).val(item.saldos[i - 1]);
                                                    total_valor += parseInt(item.saldos[i - 1]);
                                                }

                                                if (i > 1)
                                                    oblig1.options[1].selected = true;
                                                else
                                                    oblig1.options[0].selected = true;
                                                if (i > 2)
                                                    oblig2.options[2].selected = true;
                                                else
                                                    oblig2.options[0].selected = true;
                                                if (i > 3)
                                                    oblig3.options[3].selected = true;
                                                else
                                                    oblig3.options[0].selected = true;
                                                if (i > 4)
                                                    oblig4.options[4].selected = true;
                                                else
                                                    oblig4.options[0].selected = true;
                                                if (i > 5)
                                                    oblig5.options[5].selected = true;
                                                else
                                                    oblig5.options[0].selected = true;

                                                var tipo = $('#gca_pagos_por_concepto').val();
                                                if (tipo == 'UP' || tipo == 'PN') {
                                                    $('#solicitud').val(CurrencyFormatted(item.solicitud))
                                                    $('#solicitud2').val(item.estado)
                                                    $('#total_pagar').val(CurrencyFormatted(item.total_condonacion))
                                                    $('#total_solicitud').val(CurrencyFormatted(item.total_pagar2))
                                                }
                                                if ($('#solicitud').val() != "" && $('#solicitud').val() != 0) {
                                                    $('.consultar_con').show();
                                                } else {
                                                    $('.consultar_con').hide();
                                                }

                                                if (item.estado_num == 6 && tipo == 'UP') {
                                                    var honorarios = parseFloat(item.total_pagar) * parseFloat(0.20);
                                                    var iva = parseFloat(honorarios) * parseFloat(0.16);
                                                    var total_pagar = parseFloat(item.total_pagar) + parseFloat(honorarios) + parseFloat(iva);

                                                    $('#gca_pagos_Formas_valorT').val(CurrencyFormatted(Math.round(total_pagar)))
                                                    calcular(0.2, 0.16, 1);
                                                } else if (tipo == 'UP') {
                                                    var honorarios = parseFloat(total_valor) * parseFloat(0.20);
                                                    var iva = parseFloat(honorarios) * parseFloat(0.16);
                                                    var total_pagar = parseFloat(total_valor) + parseFloat(honorarios) + parseFloat(iva);
                                                    $('#gca_pagos_Formas_valorT').val(CurrencyFormatted(Math.round(total_pagar)))
                                                    calcular(0.2, 0.16, 1);
                                                } else {
                                                    $('#gca_pagos_Formas_valorT').val(0)
                                                    calcular(0.2, 0.16, 1);
                                                }

                                            }
                                        });
                                    });

                        }
                        $('.consultar_con').hide();
                        function consultar_con() {
                            var number = $('#solicitud').val();
                            $('#iframe1').attr('src', "<?php echo url_for('condonaciones/nuevasolicitud'); ?>?number=" + number + "&versolicitud=" + number);
                        }
                        var cargar_cuenta = function(obj) {
                            var valor = document.getElementById('gca_pagos_banco_consignacion').value;
                            var cuenta = document.getElementById('gca_pagos_bancocuenta_id').value;
                            var nuevaOpcion;
                            // eliminamos todos los posibles valores que contenga el select2
                            document.getElementById("gca_pagos_bancocuenta_id").options.length = 0;

                            // a�adimos los nuevos valores al select2
                            document.getElementById("gca_pagos_bancocuenta_id").options[0] = new Option("Selecciona una cuenta", "0");
                            for (i = 0; i < arrayValores.length; i++)
                            {
                                // unicamente a�adimos las opciones que pertenecen al id seleccionado
                                // del primer select
                                if (arrayValores[i][0] == valor)
                                {
                                    document.getElementById("gca_pagos_bancocuenta_id").options[document.getElementById("gca_pagos_bancocuenta_id").options.length] = new Option(arrayValores[i][2], arrayValores[i][1]);
                                }
                            }
                        }


                        document.getElementById('gca_pagos_banco_consignacion').onchange = cargar_cuenta;
                        document.getElementById('gca_pagos_id_cartera').onchange = cambio_cartera;
                        document.getElementById('gca_pagos_por_concepto').onchange = cambio_cartera;
                        document.getElementById('gca_pagos_obligacion').onblur = cambio_cartera;
                        document.getElementById('gca_pagos_cedula2').onblur = cambio_cartera;
                        function getDeudor() {
                            var nro_expediente = document.getElementById('gca_pagos_expediente').value;
                            var id_cartera = document.getElementById('gca_pagos_id_cartera').value;
                            $.getJSON("getNombreDeudor/id_cartera/" + id_cartera + "/expediente/" + nro_expediente, function(data) {
                                $.each(data.registros, function(i, item) {
                                    document.getElementById("nombreDeudorFld").value = item.nombre;
                                });
                            });
                        }

                        /*valida en el bot�n, antes de enviar el form*/
                        function validar_expediente(isTesorero) {
                            var mp1;
                            var mp2;
                            var mp3; //medios de pago
                            if (document.getElementById('gca_pagos_id_cartera').value == "")
                                alert("Elija una cartera!")
                            else {//se valida por si corrigen oblig despues de la alerta...

                                var nro_expediente = document.getElementById('gca_pagos_obligacion').value;
                                var id_cartera = document.getElementById('gca_pagos_id_cartera').value;
                                var oblig_dia = document.getElementById('oblig_dia').checked;
                                var cedula = document.getElementById('gca_pagos_cedula2').value;
                                if (id_cartera == "") {
                                    return false;
                                }
                                if (nro_expediente == "") {
                                    nro_expediente = "0";
                                }
                                if (cedula == "") {
                                    cedula = "0";
                                }
//                                $.getJSON("<?php echo $urlJson; ?>/id_cartera/" + id_cartera + "/expediente/" + nro_expediente + "/oblig_dia/" + oblig_dia,
                                $.getJSON("<?php echo $urlJson; ?>/id_cartera/" + id_cartera + "/expediente/" + nro_expediente + "/oblig_dia/" + oblig_dia + "/cedula/" + cedula,
                                        function(data) {
                                            $.each(data.registros, function(i, item) {
                                                if ($('#gca_pagos_Formas_abogadosT').val() == 0 && item.abogado != '') {
                                                    alert('Debe asignar un valor en abogados')
                                                    return false;
                                                }

                                                if (item.existe_expediente == 0) {
                                                    alert("La obligacion no pertenece a la cartera seleccionada!");
                                                    document.getElementById('deudor').innerHTML = 'Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
                                                }
                                                else {
                                                    //validar q no ingresen montos q superen el valor pagado por el usr
                                                    document.getElementById('deudor').innerHTML = item.nombre;
                                                    fp1 = document.getElementById('gca_pagos_Formas_forma_pago').value;
                                                    v1 = document.getElementById('gca_pagos_Formas_valorT').value;
                                                    var error = 0; //valida q haya ingresado formas y medios de pago, si existe el valor
                                                    if ((v1 != 0 && (fp1 == "")) /*|| (v2!=0 && (fp2=="")) || (v3!=0 && (fp3==""))*/)
                                                        error = 1;

                                                    if (error == 0) {
                                                        var valor_pago = parseFloat(document.getElementById("gca_pagos_entidad").value) +
                                                                parseFloat(document.getElementById("gca_pagos_honorarios").value) +
                                                                parseFloat(document.getElementById("gca_pagos_iva").value) +
                                                                parseFloat(document.getElementById("gca_pagos_cpm").value) +
                                                                parseFloat(document.getElementById("gca_pagos_otros").value) +
                                                                parseFloat(document.getElementById("gca_pagos_abogados").value);
                                                        var valorT = parseFloat(document.getElementById("gca_pagos_valor_total").value); //valor total del pago														 					 


                                                        if (valorT != 0) {
                                                            //reajustar a la entidad hasta 5 pesos
                                                            var ajuste = valorT - valor_pago;
                                                            if (Math.abs(ajuste) >= 1 && Math.abs(ajuste) <= 5) {//puede ser neg o posit
                                                                document.getElementById("gca_pagos_entidad").value = parseFloat(document.getElementById("gca_pagos_entidad").value) + parseFloat(ajuste)
                                                                valor_pago = valor_pago + ajuste
                                                            }

                                                            //valida la sucursal para el tesorero
                                                            if (isTesorero == 1) {
                                                                if (document.getElementById("department_id_sucursal").value == "") {
                                                                    alert("Ingrese la Sucursal");
                                                                    error = 1;
                                                                }
                                                            }

                                                            //valida si hay por lo menos una forma de pago en cheque � F-E... solicita llene datos de consignacion...
                                                            var contFp = 0;
                                                            if (fp1 == 1 || fp1 == 3 || fp1 == 4)
                                                                contFp = contFp + 1;

                                                            if (contFp == 1) {
                                                                if (document.getElementById("gca_pagos_banco_consignacion").value == "" || document.getElementById("gca_pagos_fecha_consignacion").value == "" || document.getElementById("gca_pagos_bancocuenta_id").value == 0 || document.getElementById("gca_pagos_sucursal_consignacion").value == "")
                                                                {
                                                                    if (document.getElementById("formulario").value == "edit_tesorero") { //edici�n
                                                                        if (document.getElementById("gca_pagos_Formas_concepto_rechazo").value == "") {
                                                                            alert("Ingrese los datos de la parte superior derecha");
                                                                            error = 1;
                                                                        }//else No exige los datos si se rechaza una de las formas...
                                                                    }
                                                                    else {
                                                                        alert("Ingrese los datos de la parte superior derecha");
                                                                        error = 1;
                                                                    }
                                                                }
                                                            } else { ////FP efectivo/cheque y datos diligenciados 			   
                                                                if (document.getElementById('gca_pagos_Formas_forma_pago').value == 2 &&
                                                                        (document.getElementById("gca_pagos_banco_consignacion").value != "" || document.getElementById("gca_pagos_fecha_consignacion").value != "" || document.getElementById("gca_pagos_bancocuenta_id").value != 0 || document.getElementById("gca_pagos_sucursal_consignacion").value != ""))
                                                                {
                                                                    alert("Si paga en efectivo no diligencie los datos de la parte superior derecha.");
                                                                    error = 1;
                                                                }

                                                            }

                                                            //valida.. si hay distribucion del pago entre dif obligaciones... si es asi, la suma de estas no puede superar el total entidad
                                                            if (document.getElementById("obligaciones1"))
                                                                var oblig1 = eval(document.getElementById("obligaciones1").value);
                                                            if (document.getElementById("obligaciones2"))
                                                                var oblig2 = eval(document.getElementById("obligaciones2").value);
                                                            if (document.getElementById("obligaciones3"))
                                                                var oblig3 = eval(document.getElementById("obligaciones3").value);
                                                            if (document.getElementById("obligaciones4"))
                                                                var oblig4 = eval(document.getElementById("obligaciones4").value);
                                                            if (document.getElementById("obligaciones5"))
                                                                var oblig5 = eval(document.getElementById("obligaciones5").value);

                                                            var concepto1 = document.getElementById("concepto_1").value
                                                            var concepto2 = document.getElementById("concepto_2").value
                                                            var concepto3 = document.getElementById("concepto_3").value
                                                            var concepto4 = document.getElementById("concepto_4").value
                                                            var concepto5 = document.getElementById("concepto_5").value


                                                            var contOblig = 0;

                                                            if (oblig1 != undefined || oblig2 != undefined || oblig3 != undefined || oblig4 != undefined || oblig5 != undefined)
                                                                contOblig = 1;

                                                            if (contOblig == 1) {	//indica q hay por lo menos una obligacion para distribuir				

                                                                var sumaDistribucion = 0;
                                                                if (oblig1 != undefined && concepto1 != "PS")
                                                                    sumaDistribucion = sumaDistribucion + eval(document.getElementById("obl1").value);
                                                                if (oblig2 != undefined && concepto2 != "PS")
                                                                    sumaDistribucion = sumaDistribucion + eval(document.getElementById("obl2").value);
                                                                if (oblig3 != undefined && concepto3 != "PS")
                                                                    sumaDistribucion = sumaDistribucion + eval(document.getElementById("obl3").value);
                                                                if (oblig4 != undefined && concepto4 != "PS")
                                                                    sumaDistribucion = sumaDistribucion + eval(document.getElementById("obl4").value);
                                                                if (oblig5 != undefined && concepto5 != "PS")
                                                                    sumaDistribucion = sumaDistribucion + eval(document.getElementById("obl5").value);
                                                                if ((sumaDistribucion != document.getElementById("gca_pagos_entidad").value)) {
                                                                    alert("La suma de valores para las obligaciones no equivale al valor de la entidad")
                                                                    error = 1
                                                                }
                                                            }
                                                            if (error == 0) {
                                                                //*************************
                                                                if (fp1 == 1 || fp1 == 4 /*|| fp2==1 || fp2==4 || fp3==1 || fp3==4*/) {//por si eligi� cheque o fax cheque						
                                                                    if (confirm("Recuerde revisar las fechas para los cheques!")) {
                                                                        document.forms[0].submit();
                                                                    }
                                                                }
                                                                else {
                                                                    document.forms[0].submit();
                                                                }
                                                            }
                                                        } else
                                                            alert("No ha ingresado monto para el pago!")
                                                    } else
                                                        alert("Recuerde llenar las formas y medios de pago, para valores efectuados!")
                                                }
                                            });
                                        });
                            }
                        }

                    </script>



                    <script type="text/javascript">
                        function catcalc(cal) {
                            var date = cal.date;
                            var time = date.getTime()
                            // use the _other_ field
                            var field = document.getElementById("f_calcdate");
                            if (field == cal.params.inputField) {
                                field = document.getElementById("f_date_a");
                                time -= Date.WEEK; // substract one week
                            } else {
                                time += Date.WEEK; // add one week
                            }
                            var date2 = new Date(time);
                            field.value = date2.print("%Y-%m-%d");
                        }

                        Calendar.setup({
                            inputField: "gca_pagos_fecha_consignacion",
                            ifFormat: "%Y-%m-%d",
                            showsTime: true,
                            timeFormat: "24"
                        });
                        $('#gca_pagos_cedula2').val($('#gca_pagos_cedula').val())
                    </script>

                    <div id="openModal" class="modalDialog">
                        <div>
                            <a href="#close" title="Close" class="close">X</a>
                            <iframe id="iframe1" src="" width="100%" height="100%">
                            </iframe>
                        </div>
                    </div>
                    <style>
                        .modalDialog {
                            position: fixed;
                            font-family: Arial, Helvetica, sans-serif;
                            top: 0;
                            right: 0;
                            bottom: 0;
                            left: 0;
                            background: rgba(0,0,0,0.8);
                            z-index: 99999;
                            opacity:0;
                            -webkit-transition: opacity 400ms ease-in;
                            -moz-transition: opacity 400ms ease-in;
                            transition: opacity 400ms ease-in;
                            pointer-events: none;
                        }
                        .modalDialog:target {
                            opacity:1;
                            pointer-events: auto;
                        }

                        .modalDialog > div {
                            width: 1000px;
                            height: 500px;
                            position: relative;
                            margin: 3% auto;
                            padding: 5px 20px 13px 20px;
                            border-radius: 10px;
                            background: #fff;
                            background: -moz-linear-gradient(#fff, #999);
                            background: -webkit-linear-gradient(#fff, #999);
                            background: -o-linear-gradient(#fff, #999);
                        }
                        .close {
                            background: #606061;
                            color: #FFFFFF;
                            line-height: 25px;
                            position: absolute;
                            right: -12px;
                            text-align: center;
                            top: -10px;
                            width: 24px;
                            text-decoration: none;
                            font-weight: bold;
                            -webkit-border-radius: 12px;
                            -moz-border-radius: 12px;
                            border-radius: 12px;
                            -moz-box-shadow: 1px 1px 3px #000;
                            -webkit-box-shadow: 1px 1px 3px #000;
                            box-shadow: 1px 1px 3px #000;
                        }

                        .close:hover { background: #00d9ff; }

                    </style>