<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
th { align:center;}
</style>
<body onload="cargarFechas();">
<form action="<?php echo url_for('frontPagos/'.($form->getObject()->isNew() ? 'create' : 'update').(!$form->getObject()->isNew() ? '?id='.$form->getObject()->getId() : '')) ?>" method="post" <?php $form->isMultipart() and print 'enctype="multipart/form-data" ' ?>>

<?php if($deudor=="") $deudor="Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera";
 $urlJson=url_for("frontPagos/getHonorarios");

?>

<input type="hidden" name="honorarios" id="honorarios" value="0.2">
<input type="hidden" name="ban_expediente" id="ban_expediente" value="2">
<input type="hidden" name="formas_fecha_year" id="" value="2">

<table class="nuevo" border="0">

	<?php if(!$form->getObject()->isNew()){
	$pago=Doctrine::getTable('GcaPagos')->find($form->getObject()->getId()); 
		?>
	     <tr>
	      <th>Pago No:</th>
	     <td> <font color="red"><b><?php if($form['nro_rc']->getValue()!="") echo $form['nro_rc']->getValue(); else echo ($form['id']->getValue())?></font></td>
	    </tr><?
	}
	
 ?>
 <tr>
      <th>Deudor:</th>
      <td><div id="deudor"><?php print $deudor?></div></td>
	  <td  width="20px">&nbsp;</td>
	  <td colspan="2" class="listheading" align="center">Ingrese estos datos si realiza alg&uacute;n pago en Consignaci&oacute;n o Cheque</td>
	  
    </tr>
  
    <tr>	
	  <tr>
    <th><?php echo ($form['obligacion']->renderLabel()) ?>: </th>
      <td><?php echo ($form['obligacion']->render());
	if($is_tesorero or $is_tesorero_sucursal or $is_analista){  ?>
   	 &nbsp;&nbsp;&nbsp;<nobr>Hist&oacute;rico:  <input type="checkBox" name="oblig_dia" id="oblig_dia"> <nobr><?php }
	else {  ?>
		<input type="hidden" name="oblig_dia" id="oblig_dia" value="false"> <?php 
	}?>    
 </td>
	    <td  width="20px">&nbsp;</td>
	 <th>Banco Consignaci&oacute;n</th>
	 <td><?php echo ($form['banco_consignacion']->render()) ?></td>	  
    </tr>
	
	<th><?php echo ($form['id_cartera']->renderLabel())?>:</th>
        <td>
		<?php  echo ($form['id_cartera']->render()); ?>		
	</td>
	    <td  width="20px">&nbsp;</td>
	 <th>Fecha Consignaci&oacute;n</th>
	 <td><?php echo ($form['fecha_consignacion']->render()) ?></td>	  
    </tr>
    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?>: </th>
      <td><?php echo ($form['por_concepto']->render()) ?> </td>   
	  <td  width="20px">&nbsp;</td>
	 <th>Sucursal Consignaci&oacute;n</th>
	 <td><?php echo ($form['sucursal_consignacion']->render()) ?></td>	  	  
    </tr>
   <tr> <th>Recibo de Pago <br> a nombre de:</th>
      <td><?php echo ($form['nombre_rc']->render()) ?></td>	
	<td  width="20px">&nbsp;</td>
	<th>Cuenta Consignaci&oacute;n</th>
	 <td><?php echo ($form['cuenta_consignacion']->render()) ?></td> 
    </tr>
	
	<tr>
	<?php if($is_tesorero){?>      
	<th>Sucursal: </th>
        <td><?php echo $departamento['id_sucursal']->render()?> </td>
	<th>&nbsp;</th>
	<th>&nbsp;</th>

	<?} ?>
			 	
        </tr>

  

      <?php if(isset($asesor)){?>   
		<th>Asesor:</th>
		<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<?php print Doctrine::getTable('GcaFuncionarios')->find($asesor)?></th>
	<?php }?> 

</table>

<table border="0" align="left" ><tr><td>

<table class="nuevo" border="0" align="left">
    <tr class="listheading">
      <!--<th width="50px"><?php// echo ($form['Formas']['medio_pago']->renderLabel()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
     <!-- <th><?//php echo ($form['Formas']['producto']->renderLabel()) ?> </th>-->
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>


      <th width="150px" align="center"><?php echo ($form['Formas']['fecha']->renderLabel()) ?><br> Mes/Dia/A&ntilde;o</th>      
      <th><?php echo ($form['Formas']['entidad']->renderLabel()) ?> </th>
	 
 	<th>Paz y Salvos<?php //echo ($form['Formas']['cpm']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['abogados']->renderLabel()) ?> </th>      	  	  
	  <th><?php echo ($form['Formas']['honorarios']->renderLabel()) ?> </th>      	  
	  <th><?php echo ($form['Formas']['otros']->renderLabel()) ?> </th>     	  	 
      <th><?php echo ($form['Formas']['iva']->renderLabel()) ?> </th>      
    
       <?php if($formulario=="edit_tesorero"){?> 
          <th><?php echo ($form['Formas']['concepto_rechazo']->renderLabel()) ?> </th>	  
       <?}?> 
    </tr>
    <tr>
      <!--<th><?php //echo ($form['Formas']['medio_pago']->render()) ?></th>-->
      <th><?php echo ($form['Formas']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->render()) ?> </th>
      <!--<th><?//php echo ($form['Formas']['producto']->render()) ?> </th>-->
     
      <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva.',1'?>);" size="10"  value="<? print number_format($form['Formas']['valor']->getValue())?>"/>    

      <th><?php echo ($form['Formas']['fecha']->render()) ?> </th>
	 	  
	  <?php //ocultos
		  echo ($form['Formas']['valor']->render());
		  echo ($form['Formas']['entidad']->render());
		  echo ($form['Formas']['honorarios']->render());
		  echo ($form['Formas']['cpm']->render());
		  echo ($form['Formas']['iva']->render());
		  echo ($form['Formas']['otros']->render());
		  echo ($form['Formas']['abogados']->render());    ?> 
	  
	  <th><input type="text" id="gca_pagos_Formas_entidadT" name="gca_pagos_Formas_entidadT"   onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1'?>)" size="10" value="<? print number_format($form['Formas']['entidad']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas_cpmT" name="gca_pagos_Formas_cpmT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>);"  value="<? print number_format($form['Formas']['cpm']->getValue())?>"/> 
         
      <th><input type="text" id="gca_pagos_Formas_abogadosT" name="gca_pagos_Formas_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>)" value="<? print number_format($form['Formas']['abogados']->getValue())?>" /> </th>
	 
	  <th><input type="text" id="gca_pagos_Formas_honorariosT" name="gca_pagos_Formas_honorariosT" size="10" readonly value="<? print number_format($form['Formas']['honorarios']->getValue())?>"/> </th> 

	  <th><input type="text" id="gca_pagos_Formas_otrosT" name="gca_pagos_Formas_otrosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',1';?>)" value="<? print number_format($form['Formas']['otros']->getValue())?>"/> </th> 
	  
	  <th><input type="text" id="gca_pagos_Formas_ivaT" name="gca_pagos_Formas_ivaT" size="10" readonly value="<? print number_format($form['Formas']['iva']->getValue())?>"/>      
	  <input type="hidden" id="gca_pagos_Formas_medio_pago" name="gca_pagos[Formas][medio_pago]" value="1"  />      
        <?php if($formulario=="edit_tesorero"){?>         
	  <th><?php echo ($form['Formas']['concepto_rechazo']->render()) ?> </th>
       <?}?>
      </tr>    
    <tr>
    <!--  <th><?php //echo ($form['Formas2']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas2']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['num_cheque']->render()) ?> </th>
      
      <th><input type="text" id="gca_pagos_Formas2_valorT" name="gca_pagos_Formas2_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva.',2';?>);" size="10" value="<? print number_format($form['Formas2']['valor']->getValue())?>"/>      
	
      <th><?php echo ($form['Formas2']['fecha']->render()) ?> </th>	
	  <th><input type="text" id="gca_pagos_Formas2_entidadT" name="gca_pagos_Formas2_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>)" size="10" value="<? print number_format($form['Formas2']['entidad']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas2_cpmT" name="gca_pagos_Formas2_cpmT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>);" value="<? print number_format($form['Formas2']['cpm']->getValue())?>"/>      
     
	  <th><input type="text" id="gca_pagos_Formas2_abogadosT" name="gca_pagos_Formas2_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>)"  value="<? print number_format($form['Formas2']['abogados']->getValue())?>"/> </th> 

	  <th><input type="text" id="gca_pagos_Formas2_honorariosT" name="gca_pagos_Formas2_honorariosT" size="10" readonly value="<? print number_format($form['Formas2']['honorarios']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas2_otrosT" name="gca_pagos_Formas2_otrosT" size="10"  onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',2';?>)" value="<? print number_format($form['Formas2']['otros']->getValue())?>"/> </th> 
	  
		  
	  <th><input type="text" id="gca_pagos_Formas2_ivaT" name="gca_pagos_Formas2_ivaT" size="10" readonly value="<? print number_format($form['Formas2']['iva']->getValue())?>" />
     <?php if($formulario=="edit_tesorero"){?>         
	  <th><?php echo ($form['Formas2']['concepto_rechazo']->render()) ?> </th>
       <?}?>
	 <input type="hidden" id="gca_pagos_Formas2_medio_pago" name="gca_pagos[Formas2][medio_pago]" value="1"  />   
	  
	<?php 
	  echo ($form['Formas2']['valor']->render());
	  echo ($form['Formas2']['entidad']->render());
	  echo ($form['Formas2']['iva']->render());
	  echo ($form['Formas2']['honorarios']->render());
	  echo ($form['Formas2']['cpm']->render());
	  echo ($form['Formas2']['otros']->render());
	  echo ($form['Formas2']['abogados']->render());
	  ?> 	  
    </tr>	
	
    <tr>
      <!--<th><?php//echo ($form['Formas3']['medio_pago']->render()) ?> </th>-->
      <th><?php echo ($form['Formas3']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['num_cheque']->render()) ?> </th>      
      <th><input type="text" id="gca_pagos_Formas3_valorT" name="gca_pagos_Formas3_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva.',3';?>);" size="10" value="<? print number_format($form['Formas3']['valor']->getValue())?>"/>

      <th><?php echo ($form['Formas3']['fecha']->render()) ?> </th>  

	  <th><input type="text" id="gca_pagos_Formas3_entidadT" name="gca_pagos_Formas3_entidadT" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>);" size="10" value="<? print number_format($form['Formas3']['entidad']->getValue())?>"/>

	  <th><input type="text" id="gca_pagos_Formas3_cpmT" name="gca_pagos_Formas3_cpmT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>);" value="<? print number_format($form['Formas3']['iva']->getValue())?>"/>           

	  <th><input type="text" id="gca_pagos_Formas3_abogadosT" name="gca_pagos_Formas3_abogadosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>)" value="<? print number_format($form['Formas3']['abogados']->getValue())?>"/> </th> 

	  <th><input type="text" id="gca_pagos_Formas3_honorariosT" name="gca_pagos_Formas3_honorariosT" size="10" readonly value="<? print number_format($form['Formas3']['honorarios']->getValue())?>"/>
	
	  <th><input type="text" id="gca_pagos_Formas3_otrosT" name="gca_pagos_Formas3_otrosT" size="10" onkeyup="calcularValores(<?php echo $honorarios.', '.$iva.',3';?>)" value="<? print number_format($form['Formas3']['otros']->getValue())?>"/> </th> 
	  
		  
	  <th><input type="text" id="gca_pagos_Formas3_ivaT" name="gca_pagos_Formas3_ivaT" size="10" readonly value="<? print number_format($form['Formas3']['iva']->getValue())?>"/>
      <?php if($formulario=="edit_tesorero"){?>         
	  <th><?php echo ($form['Formas3']['concepto_rechazo']->render()) ?> </th>
       <?}?>
	  <input type="hidden" id="gca_pagos_Formas3_medio_pago" name="gca_pagos[Formas3][medio_pago]" value="1"  /> 
		  
	  <?php
	  echo ($form['Formas3']['valor']->render()); 
	  echo ($form['Formas3']['entidad']->render());
	  echo ($form['Formas3']['iva']->render());
	  echo ($form['Formas3']['honorarios']->render());
	  echo ($form['Formas3']['cpm']->render());
	  echo ($form['Formas3']['otros']->render());
	  echo ($form['Formas3']['abogados']->render());  

	  echo ($form['fecha']->render());		
          echo ($form['Formas']['estado']->render());	
          echo ($form['Formas2']['estado']->render());	
          echo ($form['Formas3']['estado']->render());
?> 	  
    </tr>

</table>

<?php 
	//ocultos del formulario formaPago... por katty***
      if(!($form->getObject()->isNew())) {
	echo ($form['Formas']['id']->render());
	echo ($form['Formas']['id_gca_pagos']->render());
       
	echo ($form['Formas2']['id']->render());
	echo ($form['Formas2']['id_gca_pagos']->render());
      
	echo ($form['Formas3']['id']->render());
	echo ($form['Formas3']['id_gca_pagos']->render());
      }  
	   //echo "***".$form['obligacion2']->render();
	   //echo "***".$form['obligacion2']->getOptions();  85559
	  ?>


<br>
<table  border="0" width="1020px">
<tr>
<td width="700px" align="left"  valign="top"> <!--Distribuci�n pago... -->



<table class="nuevo"  width="250px" border="0">
 <?php  
 
 
 $option[0]=""; $option[1]="";  $option[2]=""; $option[3]=""; $option[4]="";   $valores=Array(); $valores[0]=0;$valores[1]=0;$valores[2]=0;$valores[3]=0;$valores[4]=0;
 $tipo_pago=array();$tipo_pago[0]="";$tipo_pago[1]="";$tipo_pago[2]="";$tipo_pago[3]="";$tipo_pago[4]="";$tipo_pago[5]="";$tipo_pago[6]="";$tipo_pago[7]="";
 //var_dump($obligacionesPagos);
 //exit;
 if(isset($obligacionesPagos)){ 
 $obligacionesPagos=$sf_data->getRaw('obligacionesPagos');//para que no se convierta en arrayDecorator...
 for($i=0;$i<5;$i++){
	$option[$i] = array();
	$option[$i][]= "<option></option>";
	$sel = false;
	foreach($obligacionesPagos as $obl=>$oblig){	
		if($oblig["entidad"]*1>0 && $obligacionesPagos[$obl]["selected"] == 0  && !$sel ){
			$obligacionesPagos[$obl]["selected"] = 1;
			$sel=true;
			$valores[$i]=$oblig['entidad'];  
			$tipo_pago[$i]=$oblig['tipo_pago'];  
			$selected=" selected='selected' ";
		}else{ $selected="";
		 //$tipo_pago[$i]="";
		}
		$option[$i][]= "<option $selected value='".$oblig['obligacion']."'>".$oblig['obligacion']."</option>"; 
	}		
	$option[$i] = implode("",$option[$i]);
 }
 
 } 
 //var_dump($tipo_pago);
 //if($form->getObject()->isNew()){
 
 for($i=1; $i<=5; $i++){
	 $nombre="select_".$i;//genera el nombre de la variable
	 $id="concepto_".$i;
	  $selpn="";$selpt="";$selho="";$selps=""; $selc1=""; $selc3=""; $selc5="";
	 if($tipo_pago[$i-1]=="PN")$selpn="selected";
	 if($tipo_pago[$i-1]=="PT")$selpt="selected";
	 if($tipo_pago[$i-1]=="HO")$selho="selected";
	 if($tipo_pago[$i-1]=="PS")$selps="selected"; 
	 if($tipo_pago[$i-1]=="C1")$selc1="selected"; 
	 if($tipo_pago[$i-1]=="C3")$selc3="selected"; 
	 if($tipo_pago[$i-1]=="C5")$selc5="selected"; 
	
	 
	 $$nombre="<select name=\"concepto[]\" id=\"$id\">
	 <option></option>
	 <option value=\"PN\" ".$selpn.">Abono</option>
	 <option value=\"PT\" ".$selpt.">Pago Total</option>
	 <option value=\"HO\" ".$selho.">Honorarios</option>
	<!-- <option value=\"PS\" ".$selps.">Paz y Salvo</option>-->
	 <option value=\"C1\" ".$selc1.">C1</option>
	 <option value=\"C3\" ".$selc3.">C3</option>
	 <option value=\"C5\" ".$selc5.">C5</option>
	 </select>"; 
} ?>
<tr><th colspan="3">Distribuya el pago, si es necesario...<br></th></tr>
 <tr class="listheading">  <td>Concepto</td>  <td>Obligaci&oacute;n</td>   <td>Valor</td>  </tr> 
 <tr> <td><?php echo $select_1;?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones1"><?php echo $option[0];?></select></td>  <td align="right" ><input type="text" name="valorT[]" id="obl1T" value="<?php echo number_format($valores[0]);?>" onkeyup="javascript:formatear('obl1T','obl1')"><input type="hidden" name="valor[]" id="obl1" value="<?php echo $valores[0];?>"></td></tr>
 <tr> <td><?php echo $select_2;?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones2"><?php echo $option[1];?></select></td>  <td align="right" ><input type="text" name="valorT[]" id="obl2T" value="<?php echo number_format($valores[1]);?>" onkeyup="javascript:formatear('obl2T','obl2')"><input type="hidden" name="valor[]" id="obl2" value="<?php echo $valores[1];?>"></td></tr>
 <tr> <td><?php echo $select_3;?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones3"><?php echo $option[2];?></select></td>  <td align="right" ><input type="text" name="valorT[]" id="obl3T" value="<?php echo number_format($valores[2]);?>" onkeyup="javascript:formatear('obl3T','obl3')"><input type="hidden" name="valor[]" id="obl3" value="<?php echo $valores[2];?>"></td></tr>
 <tr> <td><?php echo $select_4;?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones4"><?php echo $option[3];?></select></td>  <td align="right" ><input type="text" name="valorT[]" id="obl4T" value="<?php echo number_format($valores[3]);?>" onkeyup="javascript:formatear('obl4T','obl4')"><input type="hidden" name="valor[]" id="obl4" value="<?php echo $valores[3];?>"></td></tr>
 <tr> <td><?php echo $select_5;?></td> <td align="right" > <select name='obligacionesPagos[]' id="obligaciones5"><?php echo $option[4];?></select></td>  <td align="right" ><input type="text" name="valorT[]" id="obl5T" value="<?php echo number_format($valores[4]);?>" onkeyup="javascript:formatear('obl5T','obl5')"><input type="hidden" name="valor[]" id="obl5" value="<?php echo $valores[4];?>"></td></tr>
<?php 


/*}else{
    $style="listrow1";
    if( count($obligacionesPagos)>1){?>
		<tr><th colspan="2">Distribuci&oacute;n del pago...<br></th></tr>
		<tr class="listheading">  <td>Obligaci&oacute;n</td>   <td>Valor</td> </tr>
		<?php foreach($obligacionesPagos as $datos){  if($style=="listrow1") $style="listrow0"; else $style="listrow1";?>		  
		   <tr class="<?php echo $style?>"> <td align="right"><?php echo $datos['obligacion']?> </td><td align="right"> <?php echo number_format($datos['entidad'])?></td></tr>
		  <?php		
		}?>

<?php }

}*/ ?>
 
 </table>



</td>
<td width="300px"><!--subtotales -->
	<table  class="nuevo"  align="right" width="250px" border="0" >
	  <tr>    
		<th class="listheading" width="120px">&nbsp;&nbsp;<?php echo ($form['entidad']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT" value="<? print number_format($form['entidad']->getValue())?>"
	readonly  />
			<input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" value="<?php echo $form['entidad']->getValue(); ?>" />
		</th>    
		<th>&nbsp;</th>
	   </tr>
	  <tr>    
		<th class="listheading"> Paz  y Salvo <?php //echo ($form['cpm']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_cpmT" name="gca_pagos_cpmT"  onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"  value="<? print number_format($form['cpm']->getValue())?>" readonly/> </th>	
		<th>&nbsp;</th>
	  </tr>
	  <tr>    
		<th class="listheading">&nbsp;&nbsp;<?php echo ($form['otros']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_otrosT" name="gca_pagos_otrosT"  onkeyup="calcular(<?php echo $honorarios.', '.$iva; ?>);" value="<? print number_format($form['otros']->getValue())?>"
	 readonly/> 
		
		</th>
		<th>&nbsp;</th>
	  </tr>    
	   <tr>    
		<th class="listheading">&nbsp;&nbsp;<?php echo ($form['abogados']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_abogadosT" name="gca_pagos_abogadosT" value="<? print number_format($form['abogados']->getValue())?>" readonly/> 
	</th>
		<th>&nbsp;</th>
	  </tr> 
	  
	  <tr>   
		<th class="listheading">&nbsp;&nbsp;<?php echo ($form['honorarios']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" value="<? print number_format($form['honorarios']->getValue())?>" readonly /> </th>
		<th><div id="porcentaje_honorarios"><?php echo ($honorarios*100).'%';?></div></th>
	  </tr>
	  <tr>   
		<th class="listheading">&nbsp;&nbsp;<?php echo ($form['iva']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_ivaT" name="gca_pagos_ivaT" value="<? print number_format($form['iva']->getValue())?>" readonly />  </th>
		<th><?php echo ($iva*100).'%'; ?></th>
	  </tr>      
	  <tr>
		
		<th class="listheading"><font color="yellow">&nbsp;&nbsp;<?php echo ($form['valor_total']->renderLabel())?>: </th>
		<th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" value="<? print number_format($form['valor_total']->getValue())?>" readonly/>   </th>
	  </tr> 

<tr><td colspan="3" align="center"> 	 <br>
	 <?php 
	  if($is_tesorero==false or $is_tesorero=="") $is_tesorero=0;
	   
		  if($form->getObject()->isNew() or $formulario=="edit_tesorero"){
			 if( $form->getObject()->isNew() ) $boton="Guardar";
			 elseif($formulario=="edit_tesorero"){ 			   
			  if($is_tesorero==true or $is_tesorero_sucursal==true)   $boton="Registrar";
			  elseif($is_coordinador==true) $boton="Aprobar";
	         }		 
			 ?> 	    
		<br><input type="button" value="<?php print $boton?>" name="guardar" onClick="javascript:validar_expediente('<?php echo $is_tesorero?>')"/>	
<?php 

}

	if(!$form->getObject()->isNew()){
		if(($is_tesorero==true or $is_tesorero_sucursal==true)  and $pago->getEstado()==2){

			$url=url_for('frontPagos/search?accion=imprimir&id='.$pago->getId());
			?><input type="button" value="Imprimir" name="imprimir" onClick="javascript:enviar('<?php echo $url?>')" ><?php
		}

		if(($is_tesorero==true or $is_tesorero_sucursal==true)  and  $opcion!="searchPagos"){  $condicion="";	
			//if($estado_elegido!=""  and $estado_elegido!=null) $condicion =	"&estado=".$estado_elegido;
			//if($cartera_elejida!=""  and $cartera_elejida!=null) $condicion .="&gca_pagos[id_cartera]=".$cartera_elejida;
			//print $condicion;
		
			//?gca_pagos[id_cartera]='.$cartera_elejida.'&boton=volver&estado='.$estado_elejido
	
			$url=url_for('frontPagos/search?1=1'.$condicion);   
?>	

	
			<input type="button" value="Volver" name="Volver" onClick="javascript:enviar('<?php echo $url?>')" >
			
			<?php
                  }

	?>    
       <?php
       }

 ?>

</td></tr>
</table>
</td>
</tr>
</table>





</td>
</tr>
</table>


<!--<input type="hidden" value="<?php echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>-->
<?echo $form->renderHiddenFields();


?>
<input type="hidden" name="formulario" id="formulario"  value="<?print $formulario?>">
<!--para cuando va al registro, conserve los parametros iniciales-->
<input type="hidden" name="cartera_elejida"  value="<?php echo $cartera_elejida; ?>"> 
<input type="hidden" name="estado"  value="<?php echo $estado_elejido; ?>"> 
</form>
</body>


<script>
function enviar(url){
  location.href=url;
}
	

function formatear(id,id2){
     document.getElementById(id).value=CurrencyFormatted(document.getElementById(id).value);
	 var v1=document.getElementById(id).value;
	 document.getElementById(id2).value=v1.replace(/,/g,'');  
  
}

function calcular(honorarios, ivaP,forma){
    if(forma==1) id="";
    if(forma==2) id=2;
    if(forma==3) id=3;
 
  var honorarios=document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera
  var entidad = document.getElementById("gca_pagos_entidad");
  var entidadT = document.getElementById("gca_pagos_entidadT");  
  var total = document.getElementById("gca_pagos_valor_total");  
  
   var  vlr="gca_pagos_Formas"+id+"_valor";
   var  vlrT="gca_pagos_Formas"+id+"_valorT";
   var  ent="gca_pagos_Formas"+id+"_entidad";  
   var  entT="gca_pagos_Formas"+id+"_entidadT";
   var  hnr="gca_pagos_Formas"+id+"_honorarios";
   var  hnrT="gca_pagos_Formas"+id+"_honorariosT";
   var  iva="gca_pagos_Formas"+id+"_iva";
   var  ivaT="gca_pagos_Formas"+id+"_ivaT";
   var  cpm="gca_pagos_Formas"+id+"_cpm";
   var  cpmF="gca_pagos_Formas"+id+"_cpmT";
   
   var  otros="gca_pagos_Formas"+id+"_otros";
   var  otrosT="gca_pagos_Formas"+id+"_otrosT";
   var  abog="gca_pagos_Formas"+id+"_abogados";
   var  abogT="gca_pagos_Formas"+id+"_abogadosT";
 
  var f1 = document.getElementById(vlrT).value == ''?0:document.getElementById(vlrT).value.replace(/,/g,'');
  var  valorForma=document.getElementById(vlr).value = f1;
  document.getElementById(vlrT).value = CurrencyFormatted(f1);   
 
  //otrosT = document.getElementById("gca_pagos_otros").value == ''?0:document.getElementById("gca_pagos_otros").value;
 // cpmT = document.getElementById("gca_pagos_cpm").value == ''?0:document.getElementById("gca_pagos_cpm").value;   
  //document.getElementById("gca_pagos_cpm").value = CurrencyFormatted(cpmT)   
  
  //calculos parciales por cada forma de pago 
  //var valor_entidadForma=Math.round(parseFloat((valorForma - parseFloat(otrosT))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpmT)))); 
  var valor_entidadForma=Math.round(parseFloat((valorForma - 0)/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + 0))); 
    
  var valor_honorariosForma=Math.round(valor_entidadForma*parseFloat(honorarios))
  document.getElementById(entT).value=CurrencyFormatted(valor_entidadForma)
  document.getElementById(ent).value=valor_entidadForma 
  document.getElementById(hnrT).value=CurrencyFormatted(valor_honorariosForma)
  document.getElementById(hnr).value=valor_honorariosForma
  document.getElementById(ivaT).value=CurrencyFormatted(Math.round(valor_honorariosForma*parseFloat(ivaP)))  
  document.getElementById(iva).value=Math.round(valor_honorariosForma*parseFloat(ivaP))  
    
  var cpm1=document.getElementById(cpmF).value.replace(/,/g,'');
  document.getElementById(cpm).value=cpm1.replace(/,/g,'');
  
  var otr=document.getElementById(otrosT).value.replace(/,/g,'');
  document.getElementById(otros).value=otr.replace(/,/g,'');
  
  var abg=document.getElementById(abogT).value.replace(/,/g,'');
  document.getElementById(abog).value=abg.replace(/,/g,'');
  
  //Los totales, son las sumatorias de cada forma de pago
  
  total.value = total.value == ''?0:total.value;   
  var totalF1=  document.getElementById("gca_pagos_Formas_valor").value == ''?0: document.getElementById("gca_pagos_Formas_valor").value;
  var totalF2=document.getElementById("gca_pagos_Formas2_valor").value==''?0:document.getElementById("gca_pagos_Formas2_valor").value
  var totalF3=document.getElementById("gca_pagos_Formas3_valor").value==''?0:document.getElementById("gca_pagos_Formas3_valor").value
  
 // total.value = parseFloat(document.getElementById("gca_pagos_Formas_valor").value)+ parseFloat( document.getElementById("gca_pagos_Formas2_valor").value)+parseFloat(document.getElementById("gca_pagos_Formas3_valor").value);
  total.value = parseFloat(totalF1)+ parseFloat( totalF2)+parseFloat(totalF3);    
  document.getElementById("gca_pagos_valor_totalT").value= CurrencyFormatted(total.value); 

  //calculo entidad 
  var entF1=  document.getElementById("gca_pagos_Formas_entidad").value == ''?0: document.getElementById("gca_pagos_Formas_entidad").value;
  var entF2=document.getElementById("gca_pagos_Formas2_entidad").value==''?0:document.getElementById("gca_pagos_Formas2_entidad").value
  var entF3=document.getElementById("gca_pagos_Formas3_entidad").value==''?0:document.getElementById("gca_pagos_Formas3_entidad").value  
  //entidad.value = Math.round(parseFloat((total.value - parseFloat(otrosT))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpmT))));     
  entidad.value =Math.round(parseFloat(entF1)+parseFloat(entF2)+parseFloat(entF3),0);

  //calculo honor
  var hnoF1=  document.getElementById("gca_pagos_Formas_honorarios").value == ''?0: document.getElementById("gca_pagos_Formas_honorarios").value;
  var hnoF2=document.getElementById("gca_pagos_Formas2_honorarios").value==''?0:document.getElementById("gca_pagos_Formas2_honorarios").value
  var hnoF3=document.getElementById("gca_pagos_Formas3_honorarios").value==''?0:document.getElementById("gca_pagos_Formas3_honorarios").value 
  //var valor_honorarios=Math.round(parseFloat(entidad.value) * parseFloat(honorarios));
  var valor_honorarios=Math.round(parseFloat(hnoF1)+parseFloat(hnoF2)+parseFloat(hnoF3),0);
	
	
  //calculo iva
  var ivaF1=  document.getElementById("gca_pagos_Formas_iva").value == ''?0: document.getElementById("gca_pagos_Formas_iva").value;
  var ivaF2=document.getElementById("gca_pagos_Formas2_iva").value==''?0:document.getElementById("gca_pagos_Formas2_iva").value
  var ivaF3=document.getElementById("gca_pagos_Formas3_iva").value==''?0:document.getElementById("gca_pagos_Formas3_iva").value 
  //var valor_iva= Math.round(parseFloat(ivaP) * parseFloat(valor_honorarios),0);   
  var valor_iva=Math.round(parseFloat(ivaF1)+parseFloat(ivaF2)+parseFloat(ivaF3),0);
  
  document.getElementById("gca_pagos_entidadT").value=CurrencyFormatted(entidad.value); 
  document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valor_honorarios);    
  document.getElementById("gca_pagos_honorarios").value =valor_honorarios; 
  document.getElementById("gca_pagos_ivaT").value =CurrencyFormatted(valor_iva);   
  document.getElementById("gca_pagos_iva").value =valor_iva;   
}


/*recalcula valores totales, cuando se ingresan valores manuales para entidad, cpm y otros*/
function recalcularValores(){
	var honorarios=parseFloat(document.getElementById('honorarios').value); //document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera  
	var iva=parseFloat(0.16);
	var entidadT = parseFloat(document.getElementById("gca_pagos_entidadT").value);
	var total = parseFloat(document.getElementById("gca_pagos_valor_total").value);  
	var cpm= parseFloat(document.getElementById("gca_pagos_cpm").value);
	var otros= parseFloat(document.getElementById("gca_pagos_otros").value);
	var abogados= parseFloat(document.getElementById("gca_pagos_abogados").value);
	
	restante=Math.round(total-entidadT-cpm-otros-abogados);
	
	if(restante>=0){
		valor_iva=Math.round(restante*iva);       
		valor_honorarios=Math.round(restante-valor_iva);

		document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valor_honorarios);
		document.getElementById("gca_pagos_iva").value=CurrencyFormatted(valor_iva);
	}else{
	  alert("El valor de la entidad, 4 x mil y otros, no debe superar la cantidad cancelada ") 
    }	  
}

/*Permite calcular valores totales,cuando se ingresan valores manuales para las formas de pago */
function calcularValores(porcHon,porcIva,forma){ 
 if(forma==1) id="";
if(forma==2) id=2;
if(forma==3) id=3;
//alert(porcHon+"--"+porcIva)  
 
 var entT="gca_pagos_Formas"+id+"_entidadT";
 var ent="gca_pagos_Formas"+id+"_entidad";
 
  var cpmT="gca_pagos_Formas"+id+"_cpmT";
  var cpm="gca_pagos_Formas"+id+"_cpm";
  
  //var vlrT="gca_pagos_Formas"+id+"_valorT";
  var vlr="gca_pagos_Formas"+id+"_valor";
  
  var ivaT="gca_pagos_Formas"+id+"_ivaT";
  var iva="gca_pagos_Formas"+id+"_iva";
  
  var honT="gca_pagos_Formas"+id+"_honorariosT";
  var hon="gca_pagos_Formas"+id+"_honorarios";
  
  var otrosT="gca_pagos_Formas"+id+"_otrosT";
  var otros="gca_pagos_Formas"+id+"_otros";
  
  var abogT="gca_pagos_Formas"+id+"_abogadosT";
  var abog="gca_pagos_Formas"+id+"_abogados";
 
  //formateo///
	 document.getElementById(entT).value=CurrencyFormatted(document.getElementById(entT).value);
	 var v1=document.getElementById(entT).value;
	 var valorEntidad1=document.getElementById(ent).value=v1.replace(/,/g,'');  
  
	 document.getElementById(otrosT).value=CurrencyFormatted(document.getElementById(otrosT).value); 
	 var otr=document.getElementById(otrosT).value
	 var vlr_otros=document.getElementById(otros).value=otr.replace(/,/g,'');
	 
	 document.getElementById(abogT).value=CurrencyFormatted(document.getElementById(abogT).value); 
	 var abg=document.getElementById(abogT).value
	 var vlr_abog=document.getElementById(abog).value=abg.replace(/,/g,''); 
	 
	 document.getElementById(cpmT).value=CurrencyFormatted(document.getElementById(cpmT).value)
	 var cpm1=document.getElementById(cpmT).value;
	 var cpmForma1=document.getElementById(cpm).value=cpm1.replace(/,/g,'');
 
	 //Calculos....    
	  var entF1=  document.getElementById("gca_pagos_Formas_entidad").value == ''?0: document.getElementById("gca_pagos_Formas_entidad").value;
	  var entF2=document.getElementById("gca_pagos_Formas2_entidad").value==''?0:document.getElementById("gca_pagos_Formas2_entidad").value
	  var entF3=document.getElementById("gca_pagos_Formas3_entidad").value==''?0:document.getElementById("gca_pagos_Formas3_entidad").value
  
	  // var valorTotalEntidad=parseFloat(document.getElementById("gca_pagos_Formas_entidad").value)+parseFloat(document.getElementById("gca_pagos_Formas2_entidad").value)+parseFloat(document.getElementById("gca_pagos_Formas3_entidad").value);
	  var valorTotalEntidad=parseFloat(entF1)+parseFloat(entF2)+parseFloat(entF3);
	 
	  document.getElementById("gca_pagos_entidadT").value=CurrencyFormatted(valorTotalEntidad)
	  document.getElementById("gca_pagos_entidad").value=valorTotalEntidad; 
	 
	 
	  //calculos sobre el valor a la entidad-4xmil-abogados
	  var total_f=document.getElementById(vlr).value
	  var restante=parseFloat(total_f-valorEntidad1-cpmForma1-vlr_abog-vlr_otros) 
	 
	  //calculo iva
	  var ivaForma=Math.round(parseFloat(restante)*parseFloat(porcIva)/parseFloat(1+porcIva),0);
	  document.getElementById(ivaT).value=CurrencyFormatted(ivaForma);
	  document.getElementById(iva).value=ivaForma;
	  var ivaF1=  document.getElementById("gca_pagos_Formas_iva").value == ''?0: document.getElementById("gca_pagos_Formas_iva").value;
	  var ivaF2=document.getElementById("gca_pagos_Formas2_iva").value==''?0:document.getElementById("gca_pagos_Formas2_iva").value
	  var ivaF3=document.getElementById("gca_pagos_Formas3_iva").value==''?0:document.getElementById("gca_pagos_Formas3_iva").value
	 
	  //var valorTotalIva=parseFloat(document.getElementById("gca_pagos_Formas_iva").value)+parseFloat(document.getElementById("gca_pagos_Formas2_iva").value)+parseFloat(document.getElementById("gca_pagos_Formas3_iva").value);
	  var valorTotalIva=Math.round(parseFloat(ivaF1)+parseFloat(ivaF2)+parseFloat(ivaF3),0);
	  document.getElementById("gca_pagos_ivaT").value=CurrencyFormatted (valorTotalIva);
	  document.getElementById("gca_pagos_iva").value=valorTotalIva;
 

    //calculo honorarios... al  hacerse manual.. no aplica el porc de honorario..
	var honForma=Math.round(parseFloat(restante)-ivaForma,0);
	document.getElementById(honT).value=CurrencyFormatted(honForma);
	document.getElementById(hon).value=honForma;
 
	var hnoF1=  document.getElementById("gca_pagos_Formas_honorarios").value == ''?0: document.getElementById("gca_pagos_Formas_honorarios").value;
	var hnoF2=document.getElementById("gca_pagos_Formas2_honorarios").value==''?0:document.getElementById("gca_pagos_Formas2_honorarios").value
	var hnoF3=document.getElementById("gca_pagos_Formas3_honorarios").value==''?0:document.getElementById("gca_pagos_Formas3_honorarios").value
 
	//var valorTotalHon=parseFloat(document.getElementById("gca_pagos_Formas_honorarios").value)+parseFloat(document.getElementById("gca_pagos_Formas2_honorarios").value)+parseFloat(document.getElementById("gca_pagos_Formas3_honorarios").value);
	var valorTotalHon=Math.round(parseFloat(hnoF1)+parseFloat(hnoF2)+parseFloat(hnoF3),0);
	document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valorTotalHon)
	document.getElementById("gca_pagos_honorarios").value=valorTotalHon; 
		
	//calculo otros
	var otrF1=  document.getElementById("gca_pagos_Formas_otros").value == ''?0: document.getElementById("gca_pagos_Formas_otros").value;
	var otrF2=document.getElementById("gca_pagos_Formas2_otros").value==''?0:document.getElementById("gca_pagos_Formas2_otros").value
	var otrF3=document.getElementById("gca_pagos_Formas3_otros").value==''?0:document.getElementById("gca_pagos_Formas3_otros").value
	 
	var valorTotalOtros=Math.round(parseFloat(otrF1)+parseFloat(otrF2)+parseFloat(otrF3),0); 
	document.getElementById("gca_pagos_otrosT").value=CurrencyFormatted(valorTotalOtros);
	document.getElementById("gca_pagos_otros").value=valorTotalOtros;
	 
	//calculo cpm
	var cpmF1=  document.getElementById("gca_pagos_Formas_cpm").value == ''?0: document.getElementById("gca_pagos_Formas_cpm").value;
	var cpmF2=document.getElementById("gca_pagos_Formas2_cpm").value==''?0:document.getElementById("gca_pagos_Formas2_cpm").value
	var cpmF3=document.getElementById("gca_pagos_Formas3_cpm").value==''?0:document.getElementById("gca_pagos_Formas3_cpm").value
	
	var valorTotaCpm=Math.round(parseFloat(cpmF1)+parseFloat(cpmF2)+parseFloat(cpmF3),0); 
	document.getElementById("gca_pagos_cpmT").value=CurrencyFormatted(valorTotaCpm);
	document.getElementById("gca_pagos_cpm").value=valorTotaCpm;	
	
	//calculo abogados
	var abogF1=  document.getElementById("gca_pagos_Formas_abogados").value == ''?0: document.getElementById("gca_pagos_Formas_abogados").value;
	var abogF2=document.getElementById("gca_pagos_Formas2_abogados").value==''?0:document.getElementById("gca_pagos_Formas2_abogados").value
	var abogF3=document.getElementById("gca_pagos_Formas3_abogados").value==''?0:document.getElementById("gca_pagos_Formas3_abogados").value
	
	var valorTotalAbog=  Math.round(parseFloat(abogF1) + parseFloat(abogF2) + parseFloat(abogF3),0); 
	document.getElementById("gca_pagos_abogadosT").value=CurrencyFormatted(valorTotalAbog)
	document.getElementById("gca_pagos_abogados").value=valorTotalAbog;
}

function cargarFechas()
{
//alert('qqqq');
var forma_pago=document.getElementById('gca_pagos_Formas_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_day').disabled=false;  
 }else{	
	document.getElementById('gca_pagos_Formas_fecha_month').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_year').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_day').disabled=true; 
 }
var forma_pago=document.getElementById('gca_pagos_Formas3_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
    document.getElementById('gca_pagos_Formas3_fecha_month').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_year').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas3_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_day').disabled=true; 
 }
var forma_pago=document.getElementById('gca_pagos_Formas2_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=true; 
 }

}


function CurrencyFormatted(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + num);
}

/*para habilitar fechas de acuerdo a la elecci�n de la forma de pago*/

document.getElementById('gca_pagos_Formas_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_day').disabled=false;  
 }else{	
	document.getElementById('gca_pagos_Formas_fecha_month').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_year').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas2_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas2_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas3_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas3_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
    document.getElementById('gca_pagos_Formas3_fecha_month').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_year').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas3_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_day').disabled=true; 
 }
}

    
/*Permite calcular el honorario, y traer  deudor de acuerdo a la cartera escogida*/
var cambio_cartera=function(obj){ 
var nro_expediente=document.getElementById('gca_pagos_obligacion').value;
var oblig_dia=document.getElementById('oblig_dia').checked; 
var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
$.getJSON("<?php echo $urlJson; ?>/id_cartera/"+id_cartera+"/expediente/"+nro_expediente+"/oblig_dia/"+oblig_dia,
				function(data){							
				  $.each(data.registros, function(i,item){			
					document.getElementById('honorarios').value =item.honorarios; 
					document.getElementById('porcentaje_honorarios').innerHTML=document.getElementById('honorarios').value*100+"%";
					if(item.existe_expediente==0){
					 alert("La obligacion no pertenece a la cartera seleccionada!");
					 document.getElementById('ban_expediente').value=0; 
					 document.getElementById('deudor').innerHTML='Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
					}else{ 
						document.getElementById('ban_expediente').value=1; 
						document.getElementById('deudor').innerHTML=item.nombre; 
						document.getElementById('gca_pagos_nombre_rc').value=item.nombre; 
						document.getElementById('gca_pagos_nombre_deudor').value=item.nombre; 
						document.getElementById('gca_pagos_cedula').value=item.cedula; 
						//
						//alert("si"+item.obligaciones.length)
						var oblig1= document.getElementById('obligaciones1');
						var oblig2= document.getElementById('obligaciones2');
						var oblig3= document.getElementById('obligaciones3');
						var oblig4= document.getElementById('obligaciones4');
						var oblig5= document.getElementById('obligaciones5');
						oblig1.length=item.obligaciones.length+1;
						oblig2.length=item.obligaciones.length+1;
						oblig3.length=item.obligaciones.length+1;
						oblig4.length=item.obligaciones.length+1;
						oblig5.length=item.obligaciones.length+1;  
						
						for(var i=1; i<=item.obligaciones.length; i++){
						  oblig1.selectedIndex=i;
						  oblig2.selectedIndex=i;
						  oblig3.selectedIndex=i;
						  oblig4.selectedIndex=i;
						  oblig5.selectedIndex=i;
						  oblig1.options[i].text=item.obligaciones[i-1];
						  oblig2.options[i].text=item.obligaciones[i-1];
						  oblig3.options[i].text=item.obligaciones[i-1];
						  oblig4.options[i].text=item.obligaciones[i-1];
						  oblig5.options[i].text=item.obligaciones[i-1];
						}
						oblig1.options[0].selected=true;
						oblig2.options[0].selected=true;
						oblig3.options[0].selected=true;
						oblig4.options[0].selected=true;
						oblig5.options[0].selected=true;
						
						//
					}
				  });
                });			

}

document.getElementById('gca_pagos_id_cartera').onchange = cambio_cartera;
document.getElementById('gca_pagos_obligacion').onblur = cambio_cartera;


function getDeudor(){
	var nro_expediente=document.getElementById('gca_pagos_expediente').value;
	var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
	$.getJSON("getNombreDeudor/id_cartera/"+id_cartera+"/expediente/"+nro_expediente,function(data){
		$.each(data.registros, function(i,item){
			document.getElementById("nombreDeudorFld").value=item.nombre;
		});
	});
}

/*valida en el bot�n, antes de enviar el form*/
function validar_expediente(isTesorero){
var mp1; var mp2; var mp3; //medios de pago
	if( document.getElementById('gca_pagos_id_cartera').value=="")alert("Elija una cartera!") 
	else{//se valida por si corrigen oblig despues de la alerta...

		var nro_expediente=document.getElementById('gca_pagos_obligacion').value;
		var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
		var oblig_dia=document.getElementById('oblig_dia').checked; 
		$.getJSON("<?php echo $urlJson;?>/id_cartera/"+id_cartera+"/expediente/"+nro_expediente+"/oblig_dia/"+oblig_dia,
					function(data){					   
					  $.each(data.registros, function(i,item){	
				  
						if(item.existe_expediente==0){					 
							alert("La obligacion no pertenece a la cartera seleccionada!");
							document.getElementById('deudor').innerHTML='Digite N&uacute;mero de Obligaci&oacute;n y Seleccione cartera'
						 }
						else{ 
					            //validar q no ingresen montos q superen el valor pagado por el usr
							document.getElementById('deudor').innerHTML=item.nombre; 
							 fp1=document.getElementById('gca_pagos_Formas_forma_pago').value;
							 fp2=document.getElementById('gca_pagos_Formas2_forma_pago').value;
							 fp3=document.getElementById('gca_pagos_Formas3_forma_pago').value;
							 v1=document.getElementById('gca_pagos_Formas_valorT').value;
							 v2=document.getElementById('gca_pagos_Formas2_valorT').value;
							 v3=document.getElementById('gca_pagos_Formas3_valorT').value;

							/* mp1=document.getElementById('gca_pagos_Formas_medio_pago').value;
							 mp2=document.getElementById('gca_pagos_Formas2_medio_pago').value;
							 mp3=document.getElementById('gca_pagos_Formas3_medio_pago').value;*/
						
						     var error=0; //valida q haya ingresado formas y medios de pago, si existe el valor
							 //if((v1!=0 && (fp1=="" || mp1=="")) || (v2!=0 && (fp2=="" || mp2=="")) || (v3!=0 && (fp3=="" || mp3=="")))
							 if((v1!=0 && (fp1=="" )) || (v2!=0 && (fp2=="")) || (v3!=0 && (fp3=="")))
							 error=1;
							
							if(error==0){							 														 
									var valor_pago= parseFloat(document.getElementById("gca_pagos_entidad").value)+
									parseFloat(document.getElementById("gca_pagos_honorarios").value)+
									parseFloat(document.getElementById("gca_pagos_iva").value)+
									parseFloat(document.getElementById("gca_pagos_cpm").value)+
									parseFloat(document.getElementById("gca_pagos_otros").value)+
									parseFloat(document.getElementById("gca_pagos_abogados").value);																										
							 var valorT=parseFloat(document.getElementById("gca_pagos_valor_total").value); //valor total del pago														 					 
		
							 if(valorT != 0){							 
								 //reajustar a la entidad hasta 5 pesos
								 var ajuste=valorT-valor_pago;							
								 if(Math.abs(ajuste)>=1 && Math.abs(ajuste)<=5) {//puede ser neg o posit
								   document.getElementById("gca_pagos_entidad").value=parseFloat(document.getElementById("gca_pagos_entidad").value)+parseFloat(ajuste)
								   valor_pago=valor_pago+ajuste 
							     }
							  
							  //valida la sucursal para el tesorero
							  if(isTesorero==1 ){
							    if(document.getElementById("department_id_sucursal").value==""){
								   alert("Ingrese la Sucursal");  error=1;
								 }
							  }
							  					  
							 //valida si hay por lo menos una forma de pago en cheque � F-E... solicita llene datos de consignacion...
							var contFp=0;					
						    if(fp1 == 1 || fp1 == 3 || fp1 == 4|| fp2 == 1 || fp2 == 3 || fp2 == 4 || fp3 == 1 || fp3 == 3 || fp3 == 4 ) contFp=contFp+1;
							
							if(contFp==1) {							   
							  if(document.getElementById("gca_pagos_banco_consignacion").value =="" || document.getElementById("gca_pagos_fecha_consignacion").value =="" || document.getElementById("gca_pagos_banco_consignacion").value =="" || document.getElementById("gca_pagos_cuenta_consignacion").value ==""){
							     //alert("Ingrese los datos de consignacion en la parte superior");  error=1;
								 if(document.getElementById("formulario").value=="edit_tesorero"){ //edici�n
									if(document.getElementById("gca_pagos_Formas_concepto_rechazo").value=="" && document.getElementById("gca_pagos_Formas2_concepto_rechazo").value=="" && document.getElementById("gca_pagos_Formas3_concepto_rechazo").value==""){
										alert("Ingrese los datos de consignacion en la parte superior");  error=1;
									 }//else No exige los datos si se rechaza una de las formas...
								 }
								 else  { 
										alert("Ingrese los datos de consignacion en la parte superior");  error=1;
									}
							  }				    
							}
							 							 
							//valida.. si hay distribucion del pago entre dif obligaciones... si es asi, la suma de estas no puede superar el total entidad
							if(document.getElementById("obligaciones1")) var oblig1=eval(document.getElementById("obligaciones1").value);
							if(document.getElementById("obligaciones2")) var oblig2=eval(document.getElementById("obligaciones2").value);
							if(document.getElementById("obligaciones3")) var oblig3=eval(document.getElementById("obligaciones3").value);
							if(document.getElementById("obligaciones4")) var oblig4=eval(document.getElementById("obligaciones4").value);
							if(document.getElementById("obligaciones5")) var oblig5=eval(document.getElementById("obligaciones5").value);

var concepto1=document.getElementById("concepto_1").value
var concepto2=document.getElementById("concepto_2").value
var concepto3=document.getElementById("concepto_3").value
var concepto4=document.getElementById("concepto_4").value
var concepto5=document.getElementById("concepto_5").value

							
var contOblig=0;						
							
							if(oblig1!=undefined || oblig2!=undefined || oblig3!=undefined || oblig4!=undefined || oblig5!=undefined ) contOblig=1; 													
							
		if(contOblig ==1){	//indica q hay por lo menos una obligacion para distribuir				

			var sumaDistribucion=0;
			if(oblig1!=undefined && concepto1!="PS") sumaDistribucion=sumaDistribucion+eval(document.getElementById("obl1").value);
			if(oblig2!=undefined && concepto2!="PS") sumaDistribucion=sumaDistribucion+eval(document.getElementById("obl2").value);
			if(oblig3!=undefined && concepto3!="PS") sumaDistribucion=sumaDistribucion+eval(document.getElementById("obl3").value);
			if(oblig4!=undefined && concepto4!="PS") sumaDistribucion=sumaDistribucion+eval(document.getElementById("obl4").value);
			if(oblig5!=undefined && concepto5!="PS") sumaDistribucion=sumaDistribucion+eval(document.getElementById("obl5").value);
			//alert(sumaDistribucion +"--"+document.getElementById("gca_pagos_entidad").value)			
			if((sumaDistribucion!=document.getElementById("gca_pagos_entidad").value)){
			  	alert("La suma de valores para las obligaciones no equivale al valor de la entidad")					   
			    error=1
			}
		}				 
							 						 
							// error=1;						 
								if(error==0){							  															   
								   //*************************
										//if(valor_pago==valorT){//si es correctoo valida fechas, si el pago es en cheque
									  if(fp1==1 || fp1==4 || fp2==1 || fp2==4 || fp3==1 || fp3==4){//por si eligi� cheque o fax cheque						
										   if(confirm("Recuerde revisar las fechas para los cheques!")){
											document.forms[0].submit();	
											//alert("se va")
											}									 
									  } 
									  else { 
									   document.forms[0].submit();	
									  // alert("se va")
									  }					   
									//}
									//else alert("Los valores no coinciden con el pago efectuado!")	
								   //*************************																 
								} 
							 
						
							}else alert("No ha ingresado monto para el pago!")								
						 }else alert("Recuerde llenar las formas y medios de pago, para valores efectuados!")	
						////////////////							
						}								
					  });
					});
	}
	/* alert("ent "+document.getElementById("gca_pagos_entidadT").value.replace(/,/g,''))
							 alert("H "+document.getElementById("gca_pagos_honorariosT").value.replace(/,/g,''))
							 alert("I "+document.getElementById("gca_pagos_iva").value.replace(/,/g,''))
							 alert("o "+document.getElementById("gca_pagos_otros").value.replace(/,/g,''))
							 alert("4 "+document.getElementById("gca_pagos_cpm").value.replace(/,/g,''))*/
							 
	
}
	
</script>



<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "gca_pagos_fecha_consignacion",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });



	
</script>

