<table class="list">
	<tr>
		<td>Total Llamadas</td>
		<td>1500</td>
	</tr>
</table>