<form  method="post" action="">
<table class="nuevo">
    <tr>
      <th>**<?php echo ($form['expediente']->renderLabel()) ?> </th>
      <input type="hidden" name="id_gca_pago" name="id_gca_pago" value="<?php echo $gca_pago['0']['id_gca_pagos']?>" />
      <td><input type="text" id="expediente" value="<?php echo $gca_pago['0']['expediente']?>" readonly /></td>
    </tr>
    <tr>
      <th><?php echo ($form['recibido']->renderLabel()) ?> </th>
      <td><input type="text" id="recibido" value="<?php echo $gca_pago['0']['recibido']?>" readonly /></td>
    </tr>
    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?> </th>
      <td><input type="text" id="por_concepto" value="<?php echo $gca_pago['0']['por_concepto']?>" readonly> /></td>    
    </tr>
</table>
<table class="nuevo">
    <tr>
      <th><?php echo ($form['Formas']['medio_pago']->renderLabel()) ?></th>
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['producto']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['fecha']->renderLabel()) ?> </th>
    </tr>
    <?php foreach($gca_pago as $row):?>
    <tr>
      <th><input type="text" id="medio_pago" value="<?php echo $row['medio_pago']=='0'?'CONSIGNACIÓN':$gca_pago['0']['medio_pago']=='1'?'RECIBO DE CAJA':''?>" readonly size="12" /></th>
      <th><input type="text" id="forma_pago" value="<?php echo $row['forma_pago']?>" readonly size="12"/> </th>
      <th><input type="text" id="id_banco" value="<?php echo $row['id_banco']?>" readonly /></th>
      <th><input type="text" id="num_cheque" value="<?php echo $row['num_cheque']?>" readonly size="15"/></th>
      <th><input type="text" id="producto" value="<?php echo $row['producto']?>" readonly size="15" /></th>
      <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" value="<?php echo $row['valor']?>" readonly size="15"/>
      <input type="hidden" id="gca_pagos_Formas_valor" name="gca_pagos[Formas][valor]" /></th>
      <th><input type="text" id="fecha" value="<?php echo $row['fecha']?>" readonly size="12"/></th>
    </tr>    
    <?php endforeach;?>
</table>
<table  class="nuevo">
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['entidad']->renderLabel()) ?> </th>
    <th><input type="text" id="entidad" name="gca_pagos_entidadT" value="<?php echo $gca_pago['0']['entidad']?>" readonly />
    
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['honorarios']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" value="<?php echo $gca_pago['0']['honorarios']?>" />
        <input type="hidden" id="gca_pagos_honorarios" name="gca_pagos[honorarios]" />
        </th>
    <th><?php /*echo ($honorarios*100).'%';*/?></th>
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['iva']->renderLabel()) ?> </th>
    <th><input type="text" id="iva" value="<?php echo $gca_pago['0']['iva']?>" /></th>
    <th><?php /* echo ($iva*100).'%';*/ ?> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th>4 X 1000 </th>
    <th><input type="text" id="cpm" value="<?php echo $gca_pago['0']['cpm']?>" /></th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['otros']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_otros" value="<?php echo $gca_pago['0']['otros']?>" /> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['valor_total']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" />
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]" /> </th>
  </tr>
  <tr>
    <th width="500" colspan="2"></td>
    <td><input type="button" value="Cancelar" name="cancelar" onclick="window.href = 'frontPagos/index'" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Guardar" name="guardar"/></td></tr>  
</table>


<input type="hidden" value="<?php echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>
</form>
