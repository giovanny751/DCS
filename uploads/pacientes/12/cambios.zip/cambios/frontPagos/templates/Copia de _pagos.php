<form  method="post" action="<?php echo url_for('frontPagos/create')?>">


<input type="hidden" name="honorarios" id="honorarios" value="0.2">
<input type="hidden" name="ban_expediente" id="ban_expediente" value="2">
<input type="hidden" name="formas_fecha_year" id="" value="2">

<table class="nuevo">
    <tr>
      <th><?php echo ($form['expediente']->renderLabel()) ?> </th>
      <td><?php echo ($form['expediente']->render()) ?> </td>
    </tr>
	    <tr>
    <th><?php echo ($form['id_cartera']->renderLabel())?></th>
      <td><?php echo ($form['id_cartera']->render())?></td>
    </tr>
    <tr>
      <th><?php echo ($form['recibido']->renderLabel()) ?> </th>
      <td><?php echo ($form['recibido']->render()) ?> </td>
    </tr>
    <tr>
      <th><?php echo ($form['por_concepto']->renderLabel()) ?> </th>
      <td><?php echo ($form['por_concepto']->render()) ?> </td>    
    </tr>

</table>
<table class="nuevo">
    <tr>
      <th><?php echo ($form['Formas']['medio_pago']->renderLabel()) ?></th>
      <th><?php echo ($form['Formas']['forma_pago']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['producto']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['valor']->renderLabel()) ?> </th>
      <th><?php echo ($form['Formas']['fecha']->renderLabel()) ?> </th>      
    </tr>
    <tr>
      <th><?php echo ($form['Formas']['medio_pago']->render()) ?></th>
      <th><?php echo ($form['Formas']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas']['num_cheque']->render()) ?> </th>
      <th><?php echo ($form['Formas']['producto']->render()) ?> </th>
      <th><input type="text" id="gca_pagos_Formas_valorT" name="gca_pagos_Formas_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/>
      <input type="hidden" id="gca_pagos_Formas_valor" name="gca_pagos[Formas][valor]" /></th>
      <th><?php echo ($form['Formas']['fecha']->render()) ?> </th>	  
    </tr>    
    <tr>
      <th><?php echo ($form['Formas2']['medio_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['num_cheque']->render()) ?> </th>
      <th><?php echo ($form['Formas2']['producto']->render()) ?> </th>
      <th><input type="text" id="gca_pagos_Formas2_valorT" name="gca_pagos_Formas2_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/>
      <input type="hidden" id="gca_pagos_Formas2_valor" name="gca_pagos[Formas2][valor]"/></th>
		<!-- <input type="hidden" id="id_gca_pagos" name="gca_pagos[Formas2][id_gca_pagos]" />-->
      <th><?php echo ($form['Formas2']['fecha']->render()) ?> </th>	  
    </tr>
    <tr>
      <th><?php echo ($form['Formas3']['medio_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['forma_pago']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['id_banco']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['num_cheque']->render()) ?> </th>
      <th><?php echo ($form['Formas3']['producto']->render()) ?> </th>
      <th><input type="text" id="gca_pagos_Formas3_valorT" name="gca_pagos_Formas3_valorT" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);" />
      <input type="hidden" id="gca_pagos_Formas3_valor" name="gca_pagos[Formas3][valor]" /></th>
      <th><?php echo ($form['Formas3']['fecha']->render()) ?> </th>  	  
    </tr>
	<?php 
	//ocultos del formulario formaPago... por katty*** 
	/*echo ($form['Formas']['id']->render());
	echo ($form['Formas']['id_gca_pagos']->render());*/
        echo ($form['Formas']['estado']->render());	
        echo ($form['Formas2']['estado']->render());	
        echo ($form['Formas3']['estado']->render());
	 ?> 

</table>

<?php 
	//ocultos del formulario formaPago... por katty*** 
	//echo ($form['Formas']['id']->render());
	echo ($form['fecha']->render());
	//echo ($form['Formas']['id_gca_pagos']->render());
       // echo ($form['Formas']['estado']->render());
	/*echo ($form['Formas2']['id']->render());
	echo ($form['Formas2']['id_gca_pagos']->render());
      //  echo ($form['Formas2']['estado']->render());
	echo ($form['Formas3']['id']->render());
	echo ($form['Formas3']['id_gca_pagos']->render());
       // echo ($form['Formas3']['estado']->render());*/
	 ?>



<table  class="nuevo">
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['entidad']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_entidadT" name="gca_pagos_entidadT" onkeyup="recalcularValores()" />
        <input type="hidden" id="gca_pagos_entidad" name="gca_pagos[entidad]" /></th>    
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['honorarios']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_honorariosT" name="gca_pagos_honorariosT" readonly />
        <input type="hidden" id="gca_pagos_honorarios" name="gca_pagos[honorarios]" />
        </th>
    <th><div id="porcentaje_honorarios"><?php echo ($honorarios*100).'%';?></div></th>
  </tr>
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['iva']->renderLabel()) ?> </th>
    <th><?php echo ($form['iva']->render()) ?> </th>
    <th><?php echo ($iva*100).'%'; ?></th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th>4 X 1000 </th>
    <!--<th><?//php echo ($form['cpm']->render()) ?> </th>-->
	<th><input type="text" id="gca_pagos_cpm" name="gca_pagos[cpm]" value="0" onkeyup="calcular(<?php echo $honorarios.', '.$iva;?>);"/> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['otros']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_otros" name="gca_pagos[otros]" value="0" onkeyup="calcular(<?php echo $honorarios.', '.$iva; ?>);"/> </th>
  </tr>  
  <tr>
    <th width="600"></th>
    <th><?php echo ($form['valor_total']->renderLabel()) ?> </th>
    <th><input type="text" id="gca_pagos_valor_totalT" name="gca_pagos_valor_totalT" readonly/>
    <input type="hidden" id="gca_pagos_valor_total" name="gca_pagos[valor_total]" /> </th>
  </tr>  
  
  <tr>
    <td colspan="2"></td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<br> <input type="button" value="Guardar" name="guardar" onClick="javascript:validar_expediente()"/></td></tr>  
</table>


<!--<input type="hidden" value="<?php echo ($form->getCSRFToken())  ?>" name="gca_pagos[<?php echo ($form->getCSRFFieldName() )  ?>]"/>-->
<?echo $form->renderHiddenFields(); ?>
<input type="hidden" name="formulario" value="<?print $formulario?>">
</form>
<script>
function calcular(honorarios, ivaP){
  honorarios=document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera
  entidad = document.getElementById("gca_pagos_entidad");
  entidadT = document.getElementById("gca_pagos_entidadT");
  total = document.getElementById("gca_pagos_valor_total");  

  f1 = document.getElementById("gca_pagos_Formas_valorT").value == ''?0:document.getElementById("gca_pagos_Formas_valorT").value.replace(',','');
  document.getElementById("gca_pagos_Formas_valor").value = f1;
  document.getElementById("gca_pagos_Formas_valorT").value = CurrencyFormatted(f1);
  
  f2 = document.getElementById("gca_pagos_Formas2_valorT").value == ''?0:document.getElementById("gca_pagos_Formas2_valorT").value.replace(',','');
  document.getElementById("gca_pagos_Formas2_valor").value = f2;
  document.getElementById("gca_pagos_Formas2_valorT").value = CurrencyFormatted(f2);
  
  f3 = document.getElementById("gca_pagos_Formas3_valor").value == ''?0:document.getElementById("gca_pagos_Formas3_valorT").value.replace(',','');
  document.getElementById("gca_pagos_Formas3_valor").value = f3;
  document.getElementById("gca_pagos_Formas3_valorT").value = CurrencyFormatted(f3);
  
  otros = document.getElementById("gca_pagos_otros").value == ''?0:document.getElementById("gca_pagos_otros").value;
  cpm = document.getElementById("gca_pagos_cpm").value == ''?0:document.getElementById("gca_pagos_cpm").value;
  document.getElementById("gca_pagos_cpm").value = CurrencyFormatted(cpm);
  total.value = total.value == ''?0:total.value;
  
  total.value = parseFloat(document.getElementById("gca_pagos_Formas_valor").value.replace(',',''))+ parseFloat( document.getElementById("gca_pagos_Formas2_valor").value.replace(',','')) + parseFloat(document.getElementById("gca_pagos_Formas3_valor").value.replace(',',''));
  
  document.getElementById("gca_pagos_valor_totalT").value= CurrencyFormatted(total.value);
    
  entidad.value = Math.round(parseFloat((total.value - parseFloat(otros))/(1 + parseFloat(honorarios) + parseFloat(ivaP)*parseFloat(honorarios) + parseFloat(cpm)))); 
  var valor_honorarios=Math.round(parseFloat(entidad.value) * parseFloat(honorarios));
  var valor_iva= Math.round(parseFloat(ivaP) * parseFloat(valor_honorarios));
  
  
  document.getElementById("gca_pagos_entidadT").value= CurrencyFormatted(entidad.value); 
  document.getElementById("gca_pagos_honorariosT").value = CurrencyFormatted(valor_honorarios);    
  document.getElementById("gca_pagos_honorarios").value =valor_honorarios; 
  document.getElementById("gca_pagos_iva").value =valor_iva;  
}

function recalcularValores(){
	var honorarios=parseFloat(document.getElementById('honorarios').value); //document.getElementById('honorarios').value //por katty.. no llega por $POST sino q se calcula cada q cambia de cartera  
	var iva=parseFloat(0.16);
	var entidadT = parseFloat(document.getElementById("gca_pagos_entidadT").value);
	var total = parseFloat(document.getElementById("gca_pagos_valor_total").value);  
	var cpm= parseFloat(document.getElementById("gca_pagos_cpm").value);
	var otros= parseFloat(document.getElementById("gca_pagos_otros").value);
	
	restante=Math.round(total-entidadT-cpm-otros);
	if(restante>=0){
		valor_iva=Math.round(restante*iva);       
		valor_honorarios=Math.round(restante-valor_iva);

		document.getElementById("gca_pagos_honorariosT").value=CurrencyFormatted(valor_honorarios);
		document.getElementById("gca_pagos_iva").value=CurrencyFormatted(valor_iva);
	}else{
	  alert("El valor de la entidad, 4 x mil y otros, no debe superar la cantidad cancelada ") 
    }	  
}



function CurrencyFormatted(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + num);
}

/*para habilitar fechas de acuerdo a la elecci�n de la forma de pago*/

document.getElementById('gca_pagos_Formas_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas_fecha_day').disabled=false;  
 }else{	
	document.getElementById('gca_pagos_Formas_fecha_month').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_year').disabled=true;  
	document.getElementById('gca_pagos_Formas_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas2_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas2_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=false;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas2_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas2_fecha_day').disabled=true; 
 }
}

document.getElementById('gca_pagos_Formas3_forma_pago').onchange = function(){
var forma_pago=document.getElementById('gca_pagos_Formas3_forma_pago').value;
 if(forma_pago==1 || forma_pago==4){
    document.getElementById('gca_pagos_Formas3_fecha_month').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_year').disabled=false;  
    document.getElementById('gca_pagos_Formas3_fecha_day').disabled=false;  
 }else{	
  document.getElementById('gca_pagos_Formas3_fecha_month').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_year').disabled=true;  
  document.getElementById('gca_pagos_Formas3_fecha_day').disabled=true; 
 }
}

    
/*Permite calcular el honorario de acuerdo a la cartera escogida*/
document.getElementById('gca_pagos_id_cartera').onchange = function(){
var nro_expediente=document.getElementById('gca_pagos_expediente').value;
$.getJSON("getHonorarios/id_cartera/"+this.value+"/expediente/"+nro_expediente,
				function(data){					   
				  $.each(data.registros, function(i,item){			
					document.getElementById('honorarios').value =item.honorarios; 
					document.getElementById('porcentaje_honorarios').innerHTML=document.getElementById('honorarios').value*100+"%";
					if(item.existe_expediente==0){
					 alert("El expediente no pertenece a la cartera seleccionada!");
					 document.getElementById('ban_expediente').value=0; 
					}else document.getElementById('ban_expediente').value=1; 
				  });
                });

}

/*valida en el bot�n, antes de enviar el form*/
function validar_expediente(){
var mp1; var mp2; var mp3; //medios de pago
	if( document.getElementById('ban_expediente').value==2)alert("Elija una cartera!") 
	else{//se valida por si corrigen el expediente despues de la alerta...
		var nro_expediente=document.getElementById('gca_pagos_expediente').value;
		var id_cartera=document.getElementById('gca_pagos_id_cartera').value;
		$.getJSON("getHonorarios/id_cartera/"+id_cartera+"/expediente/"+nro_expediente,
					function(data){					   
					  $.each(data.registros, function(i,item){	
				  
						if(item.existe_expediente==0){					 
						 alert("El expediente no pertenece a la cartera seleccionada!") 
						 }
						else{ //validar q no ingresen montos q superen el valor pagado por el usr
							 fp1=document.getElementById('gca_pagos_Formas_forma_pago').value;
							 fp2=document.getElementById('gca_pagos_Formas2_forma_pago').value;
							 fp3=document.getElementById('gca_pagos_Formas3_forma_pago').value;
							 v1=document.getElementById('gca_pagos_Formas_valorT').value;
							 v2=document.getElementById('gca_pagos_Formas2_valorT').value;
							 v3=document.getElementById('gca_pagos_Formas3_valorT').value;
							 mp1=document.getElementById('gca_pagos_Formas_medio_pago').value;
							 mp2=document.getElementById('gca_pagos_Formas2_medio_pago').value;
							 mp3=document.getElementById('gca_pagos_Formas3_medio_pago').value;
						
						     var error=0; //valida q haya ingresado formas y medios de pago, si existe el valor
							 if((v1!=0 && (fp1=="" || mp1=="")) || (v2!=0 && (fp2=="" || mp2=="")) || (v3!=0 && (fp3=="" || mp3=="")))
							 error=1;
							
							if(error==0){							 							
							 var valor_pago= parseFloat(document.getElementById("gca_pagos_entidadT").value.replace(',',''))+
									parseFloat(document.getElementById("gca_pagos_honorariosT").value.replace(',',''))+
									parseFloat(document.getElementById("gca_pagos_iva").value.replace(',',''))+
									parseFloat(document.getElementById("gca_pagos_cpm").value.replace(',',''))+
									parseFloat(document.getElementById("gca_pagos_otros").value.replace(',',''));
							 var valorT=	parseFloat(document.getElementById("gca_pagos_valor_total").value); //valor total del pago
						
							 if(valorT != 0){
								if(valor_pago==valorT){//si es correctoo valida fechas, si el pago es en cheque
								  if(fp1==1 || fp1==4 || fp2==1 || fp2==4 || fp3==1 || fp3==4){//por si eligi� cheque o fax cheque						
									   if(confirm("Recuerde revisar las fechas para los cheques!")){
										 document.forms[0].submit();	
										 //alert("se va")
										}									 
								  } 
								  else { document.forms[0].submit();	
								   //alert("se va")
								  }					   
								}
								else alert("Los valores no coinciden con el pago efectuado!")	
							}else alert("No ha ingresado monto para el pago!")								
						 }else alert("Recuerde llenar las formas y medios de pago, para valores efectuados!")	
						////////////////							
						}								
					  });
					});
	}
	/* alert("ent "+document.getElementById("gca_pagos_entidadT").value.replace(',',''))
							 alert("H "+document.getElementById("gca_pagos_honorariosT").value.replace(',',''))
							 alert("I "+document.getElementById("gca_pagos_iva").value.replace(',',''))
							 alert("o "+document.getElementById("gca_pagos_otros").value.replace(',',''))
							 alert("4 "+document.getElementById("gca_pagos_cpm").value.replace(',',''))*/
							 
	
}

</script>
