<?php include_stylesheets_for_form($form) ?>
<?php include_javascripts_for_form($form) ?>

<style>
.listrow1 { font-size: 10pt; background-color: #e6e6fa; color: black; vertical-align: top; }
.listrow0 { font-size: 10pt; background-color: #cddffa; color: black; vertical-align: top; }
.listheading { font-size: 10pt; background-color: #4c86ac; color: white; align:center; font-weight:bold;}
</style>

<script>
function enviar(){
 document.getElementById('boton').value="imprimir";
 document.submit();
}
</script>

<center>
<br><br>

<form action="<?php echo url_for('frontPagos/informesContables')?>" method="get" >
<table>
   <tr><th> Sucursal:</td><td><? print $departamento['id_sucursal']->render()?></th>	 </tr>
   <tr><th> Tipo Reporte:</td><td><select name="tipo_reporte">
	   <option value="reporte_recibo_caja">Recibos de Caja</option> 
	   <option value="reporte_pagos_directos">Pagos Directos</option>
	   <option value="reporte_facturacion">Facturaci&oacute;n</option>	   
	   <option value="reporte_terceros">Terceros</option>	   
      <?php  
      if($id_user==1591   or $id_user==26){ ?>
         <option value="reporte_pagos_completo">Informe Pagos Completo</option>
      <?php
      }
      ?>
   </select></th>	 </tr>
   <tr>	<th>Fecha Desde: </td><td><input type="text" name="fechadesde__String" id="fechadesde__String" value="<?php print $fecha_ini?>" /></th> 
   <tr>	<th>Fecha Hasta: </td><td><input type="text" name="fechahasta__String" id="fechahasta__String" value="<?php print $fecha_fin?>" /></th> 
   <tr><td colspan="2"><!--<input type="hidden"  name="boton" onclick="javascript:enviar()">-->
   <input type="submit" value="Imprimir" name="boton"/> </td></tr>
</table>

 </form>
</center>



<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()
        // use the _other_ field
        var field = document.getElementById("f_calcdate");
        if (field == cal.params.inputField) {
            field = document.getElementById("f_date_a");
            time -= Date.WEEK; // substract one week
        } else {
            time += Date.WEEK; // add one week
        }
        var date2 = new Date(time);
        field.value = date2.print("%Y-%m-%d");
    }

    Calendar.setup({
        inputField     :    "fechadesde__String",
        ifFormat       :    "%Y-%m-%d",
        showsTime      :    true,
        timeFormat     :    "24"
    });
	
	Calendar.setup({
        inputField     :    "fechahasta__String",
        ifFormat       :    "%Y-%m-%d %H:%M",
        showsTime      :    true,
        timeFormat     :    "24"
    });
</script>



