<?php

/**
 * frontPagos actions.
 *
 * @package    prejuridico
 * @subpackage frontPagos
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $im
 */
class frontPagosActions extends sfActions
{
  public function executeIndex(sfWebRequest $request){
    $submit = $request->getparameter('ver');

  if(isset($submit)){
    $where = "'1' ";
    $estado = $request->getParameter('estado');
    $obligacion = trim($request->getParameter('obligacion'));    
    if($obligacion != '')$where .= " and obligacion = '".$obligacion."'";    
    if($estado != '')$where .= "and estado = '".$estado."'";   

    if($this->getUser()->isAuthenticated()){
      $this->credenciales = $this->getUser()->listCredentials();
    }             
    $this->gca_pagos_list = Doctrine::getTable('GcaPagos')
      ->createQuery('a')
      ->where($where)
      ->execute();      
    }   
  }
  
  public function executeUpdateFechaReembolso(sfWebRequest $request){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->form = new GcaPagosForm();
    $this->form->setDefault('fecha_reembolso', date('m/d/Y'));

    $params = $request->getPostParameters();
    if(isset($params['actualizar'])){
      $fecha = $request->getParameter("gca_pagos[fecha_reembolso]");
      $this->gca_pagos->setFechaReembolso($fecha["year"]."-".$fecha["month"]."-".$fecha["day"]);
      $this->gca_pagos->save();
      $this->redirect('frontPagos/index');
    }    
  } 
  

  public function executeShow(sfWebRequest $request)
  {
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->forward404Unless($this->gca_pagos);
  }

  public function executeNew(sfWebRequest $request)
  {
    $this->departamento=new DepartmentForm();
    $this->departamento->configure();
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $id_user = $this->getUser()->getAttribute('usuario');
    $this->is_tesorero=false;    $this->is_tesorero_sucursal=false;
    $this->form = new GcaPagosForm();
    $this->form->configure2();
    
    if($this->getUser()->isAuthenticated()){
		if($this->getUser()->hasCredential('tesorero'))		 
		  $this->is_tesorero=true;   
		if($this->getUser()->hasCredential('tesorero_sucursal'))		 
		  $this->is_tesorero_sucursal=true; 
		if($this->getUser()->hasCredential('analista_portafolios'))		 
		  $this->is_analista=true; 
		if($this->getUser()->hasCredential('coordinador')){
			$this->is_coordinador=true;
			$this->form->setDefault('estado', 1);
		}

			  
    }	
  
    if($this->is_tesorero==false){ //carga solo carteras del asesor o del tesorero suc		  
	  $this->getCarterasAsesor($id_user,$this->form);
    }
    if($this->is_tesorero or $this->is_tesorero_sucursal)
     $this->form->setDefault('id_tesorero',  $id_user );

   //para obtener el porc hono.. de la primera cartera q se ve en el desplegable...	
    $sql = "select id from gca_cartera order by nombre limit 1";        
    $id_cartera = $doctrine->query($sql)->fetchColumn();      
	
    $sql = "select porcentaje_honorarios, cpm from gca_cartera where id= ".$id_cartera;
    $cartera = $doctrine->query($sql)->fetchAll();
    $this->honorarios = $cartera[0]['porcentaje_honorarios'];         
    $this->iva = $doctrine->query("select valor from gca_parametros where campo = 'iva'")->fetchColumn();
    $this->deudor= "";


    //$this->form->setDefault('honorarios', $this->cartera[0]['porcentaje_honorarios']);
    if($this->cartera[0]['cpm'])$this->form->setDefault('gca_pagos_cpm',$cartera[0]['cpm']);
    $this->form->setDefault('iva', $this->iva);
    $this->form->setDefault('otros', 0);    
    
    $forma = $this->form->getDefault('Formas');   	
	$forma['fecha'] = date('m/d/Y');//establece la fecha para las formas de pago en el formulario
	
    $this->form->setDefault('Formas',  $forma);
    $this->form->setDefault('Formas2', $forma);
    $this->form->setDefault('Formas3', $forma);
	
    $this->form->setDefault('fecha', date('Y-m-d H:i'));//fecha del pago...

    //por Katty... para marcar el estado en registrado, si viene por tesorero	
    $this->formulario="";
    if ($request->getParameter('formulario')=="new_tesorero"){
     $this->form->setDefault('estado', 2);
     $this->formulario="new_tesorero";
    }
   //si es tesorero, cambia el estado del pago a confirmado 		
	if($this->is_tesorero==true or $this->is_tesorero_sucursal==true)
	  $this->form->setDefault('estado', 2);  
  }
  
  
  
  

/*Metodo para traer carteras del asesor y tesoreros de sucursales*/
protected function getCarterasAsesor($id_user,$form){ 
  $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();  
  $widgetSchema= $form->getWidgetSchema();	

		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
		$carteras=$doctrine->query($query)->fetchColumn();
		$array_carteras=null;
		
		$carteras_asesor=explode(",",$carteras); 
		
		foreach($carteras_asesor as $id_cartera){
			$query="Select upper(nombre)from gca_cartera where id=$id_cartera";	
			$array_carteras[$id_cartera]=$doctrine->query($query)->fetchColumn();	
		}		
        $array_carteras['0']='';//para poner la primera cartera vacia
		
		asort($array_carteras);  
    		
		$widgetSchema['id_cartera'] = new sfWidgetFormChoice(array(      
		  'choices'  => (array($array_carteras)),
                  	 
		 ));	
		$widgetSchema['id_cartera']->setLabel("Cartera");	
		$form->setWidgetSchema($widgetSchema);	
}


  
  /*metodo para traer el porc honorarios, el deudor y su arreglo de obligaciones, de acuerdo a la cartera escogida*/
  public function executeGetHonorarios(sfWebRequest $request){
     //otro ej de ajax en edwin/ctt/entradaProduccion/entradaProduccionSucces.php
    
      $cartera=Doctrine::getTable('GcaCartera')->find($request->getParameter('id_cartera'));

      //$ban_exp=Doctrine::getTable('GcaCartera')->buscarExpediente($request->getParameter('id_cartera'),$request->getParameter('expediente'));
      $ban_exp=Doctrine::getTable('GcaCartera')->buscarObligacion($request->getParameter('id_cartera'),$request->getParameter('expediente'),"contar",$request->getParameter('oblig_dia'));
     $datos_deudor=Doctrine::getTable('GcaCartera')->obtenerNombreDeudor($request->getParameter('id_cartera'),$request->getParameter('expediente'),null,$request->getParameter('oblig_dia'));
	 
	 foreach($datos_deudor as $key =>$val){
	   $deudor=$val['deudor'];
	   $cedula=$val['cedula'];
	  }
	  $obligaciones=Doctrine::getTable('GcaCartera')->buscarObligacion($request->getParameter('id_cartera'),$request->getParameter('expediente'),"obtener",$request->getParameter('oblig_dia'));
	
	  $obligs=array();
	  foreach($obligaciones as $key =>$oblig){
	     $obligs[]='"'.$oblig["obligacion"].'"';
	  }	
	 
	  $obl="[".implode(',',$obligs)."]";	  //obl debe ser de esta forma....."obl":[121212,1313131,121212]
//var_dump($obl); exit;
	 
        $honorarios=$cartera->getPorcentajeHonorarios();
	if($honorarios=="")$honorarios=0.2;
	echo '{registros:[
						{"honorarios":"'.$honorarios.'",
						 "existe_expediente":"'.$ban_exp.'",
						 "nombre":"'.$deudor.'",						 
						 "cedula":"'.$cedula.'",						 
						 "obligaciones":'.$obl.'
						}
					 ]
		  }';
      exit; //para q cargue porque es invocada la función por ajax... "cedula":"'.$cedula.'",
}


  
  public function executeAprobar(sfWebRequest $request){
    $aprobar = $request->getParameter('aprobar');
    $rechazar = $request->getParameter('rechazar');
    
    if($aprobar !=''){
      $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id_gca_pago'));
	  $this->gca_pagos->setEstado("1");
	  $this->gca_pagos->save();
	  $this->redirect('frontPagos/index');
      }
    if($rechazar !=''){
          $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id_gca_pago'));
	  $this->gca_pagos->setEstado("3");
	  $this->gca_pagos->save();
	  $this->redirect('frontPagos/index');
      }
      
    
    
    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaPagosForm($gca_pagos);
    $this->form->configure2();
    $id_user = $this->getUser()->getAttribute('usuario');
    
    $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))
      //->getSql();
      //echo($this->gca_pagos_list);exit;
      ->execute();
      
      
      //print_r($this->gca_pagos_list);//exit;
      $this->gca_pago = array();
      $i=0;
    foreach($this->gca_pagos_list as $pago){
      //var_dump($pago->getGcaPagos()->obligacion);exit;
      $this->gca_pago[$i]['expediente'] = $pago->getGcaPagos()->expediente;
      $this->gca_pago[$i]['recibido'] = $pago->getGcaPagos()->recibido;
      $this->gca_pago[$i]['por_concepto'] = $pago->getGcaPagos()->por_concepto;
      $this->gca_pago[$i]['medio_pago'] = $pago->medio_pago;
      $this->gca_pago[$i]['forma_pago'] = $pago->getGcaFormasDePago()->descripcion;
      $this->gca_pago[$i]['id_banco'] = $pago->id_banco;
      $this->gca_pago[$i]['num_cheque'] = $pago->num_cheque;
      $this->gca_pago[$i]['producto'] = $pago->producto;
      $this->gca_pago[$i]['valor'] = $pago->valor;
      $this->gca_pago[$i]['fecha'] = $pago->fecha;
      $this->gca_pago[$i]['entidad'] = $pago->getGcaPagos()->entidad;
      $this->gca_pago[$i]['honorarios'] = $pago->getGcaPagos()->honorarios;
      $this->gca_pago[$i]['cpm'] = $pago->getGcaPagos()->cpm;
      $this->gca_pago[$i]['otros'] = $pago->getGcaPagos()->otros;
      $this->gca_pago[$i]['expediente'] = $pago->getGcaPagos()->expediente;
      $this->gca_pago[$i]['iva'] = $pago->getGcaPagos()->iva;
      $this->gca_pago[$i]['id_gca_pagos'] = $pago->getGcaPagos()->id;
      $i++;
    }
    
  }

  public function executeCreate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod('post'));

    $this->form = new GcaPagosForm();
    $this->form->configure2();
    //var_dump($request->getParameter('department[id_sucursal]'));exit;
    $this->processForm($request, $this->form);

    $this->redirect('frontPagos/new');
    //$this->setTemplate('new');
  }


  public function executeEdit(sfWebRequest $request)
  {
    $this->departamento=new DepartmentForm();
    $this->departamento->configure();
    //verificar si es tesorero
     $this->is_tesorero=false; $this->is_tesorero_sucursal= false; $this->is_coordinador=false; //*******************************revisar*********************

	if($this->getUser()->isAuthenticated()){  
		if($this->getUser()->hasCredential('tesorero'))		 
		  $this->is_tesorero=true;   
		if($this->getUser()->hasCredential('tesorero_sucursal'))		 
		  $this->is_tesorero_sucursal=true;   
	        if($this->getUser()->hasCredential('analista_portafolios'))		 
		  $this->is_analista=true;  			  
     }

    $guardar = $request->getParameter('guardar');
	
    $entidad = $request->getParameter('entidad');
    $honorarios= $request->getParameter('honorarios');
    $iva= $request->getParameter('iva');
    $cpm= $request->getParameter('cpm');
    $otros= $request->getParameter('otros');
    $valor_total= $request->getParameter('valor_total');
       
	 
    if($guardar !=''){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id_gca_pago'));
    $this->gca_pagos->setEstado("1");
    $this->gca_pagos->setEntidad($entidad);
    $this->gca_pagos->setHonorarios($honorarios);
    $this->gca_pagos->setIva($iva);
    $this->gca_pagos->setCpm($cpm);
    $this->gca_pagos->setOtros($otros);
    $this->gca_pagos->setValortotal($valor_total);
    $this->gca_pagos->save();
    $this->redirect('frontPagos/index');
    
    }
  
  
    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));     

    $this->asesor=$gca_pagos->getIdFuncOblig();
    $this->form = new GcaPagosForm($gca_pagos);
    $this->departamento->setDefault('id_sucursal',$gca_pagos->getIdSucursal());
    $gca_pagos->getIdSucursal(); 
    $this->form->configure2();


    //$this->departamento;
    $id_user = $this->getUser()->getAttribute('usuario');
	  
    $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')     
      ->where('a.id=?',$request->getParameter('id'))
      //->getSql();
      //echo($this->gca_pagos_list);exit;
      ->execute();
  
    
   //para obtener el porc honor
     $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();   
     $id_cartera = $gca_pagos->getIdCartera();
   
     $sql = "select porcentaje_honorarios, cpm from gca_cartera where id= ".$id_cartera;
     $cartera = $doctrine->query($sql)->fetchAll();
     $this->honorarios = $cartera[0]['porcentaje_honorarios'];         
     $this->iva = $doctrine->query("select valor from gca_parametros where campo = 'iva'")->fetchColumn();  	
   
     $this->formulario="";
     $this->deudor= $gca_pagos->getNombreDeudor();
     $i=0;    
     foreach($this->gca_pagos_list as $pago){
	 
	  if($i==0) $this->form->embedForm('Formas', new GcaFormaPagoForm($pago));		   
	  if($i==1) $this->form->embedForm('Formas2', new GcaFormaPagoForm($pago));
	  if($i==2) $this->form->embedForm('Formas3', new GcaFormaPagoForm($pago));    
       $i++;
     }

   for($i=$i;$i<3;$i++){ //para que instancie con un objeto de tipo GcaFormaPago vacio, para cuando no hayan pagos
	$formaPago=new GcaFormaPago();
	$formaPago->setIdGcaPagos($gca_pagos); 	
	if($i==0)  $this->form->embedForm('Formas', new GcaFormaPagoForm($formaPago));
	if($i==1)  $this->form->embedForm('Formas2', new GcaFormaPagoForm($formaPago));
	if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($formaPago));
    }  

	$this->mensaje=$request->getParameter('mensaje');  

	//consultar si el pago se aplicó a diferentes oblig...
	$this->obligacionesPagos=Doctrine::getTable('GcaObligacionesPagos')->getObligacionesPagadas($request->getParameter('id'),$id_cartera,$gca_pagos->getCedula());   


	//$this->opcion="searchPagos"; 
   $this->cartera_elejida=$request->getParameter('cartera_elejida');//para devolver  a los parametros  iniciales de pantalla
   $this->estado_elejido=$request->getParameter('estado');

 }




  public function executeUpdate(sfWebRequest $request)
  { 
    $this->forward404Unless($request->isMethod('post') || $request->isMethod('put'));
    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaPagosForm($gca_pagos);

   /**********por katty**********/
   //$this->form->configure2();
    $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))     
      ->execute();
    $i=0;
    foreach($this->gca_pagos_list as $pago){
	  if($i==0) $this->form->embedForm('Formas', new GcaFormaPagoForm($pago));
	  //var_dump($this->form['Formas']);exit;	   
	  if($i==1)$this->form->embedForm('Formas2', new GcaFormaPagoForm($pago));
	  if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($pago));    
       $i++;
    }


   for($i=$i;$i<3;$i++){ //para que instancie con un objeto de tipo GcaFormaPago vacio, para cuando no hayan pagos
	$formaPago=new GcaFormaPago();
	$formaPago->setIdGcaPagos($gca_pagos); 	
	if($i==0)  $this->form->embedForm('Formas', new GcaFormaPagoForm($formaPago));
	if($i==1)  $this->form->embedForm('Formas2', new GcaFormaPagoForm($formaPago));
	if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($formaPago));
    }  
/********************/

    $this->processForm($request, $this->form);
    $this->setTemplate('edit');
  }



  public function executeDelete(sfWebRequest $request)
  {
    $request->checkCSRFProtection();

    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $gca_pagos->delete();

    $this->redirect('frontPagos/index');
  }
  
  public function executeSummaryMetas(sfWebRequest $request){
		$this->valores=array();
		$user = $this->getUser()->getAttribute('usuario');	
		$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT cantidadobligacionesasesor($user) as metas");
		$this->valores["wqv"]["esperado"]="";
		$this->valores["wqv"]["realizado"]=$assoc[0]["metas"];
		$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT descripcion,metas,cantidad FROM GCA_V_SUMMARY AS S WHERE OBTENERCARTERAFUNCIONARIO($user)= S.ID_CARTERA AND S.ID_FUNCIONARIO=$user");		
		foreach($assoc as $llave => $valor ){
			$this->valores[$valor["descripcion"]]["esperado"]=$valor["metas"];
			$this->valores[$valor["descripcion"]]["realizado"]=$valor["cantidad"];
		}
		
		$this->setLayout(null);
  }
  
public function executeJsonMeta(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$user = $this->getUser()->getAttribute('usuario');	
	$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT buscarMetas($user,$mes,$anio) as metas");	
  	$this->json = $assoc[0]["metas"];
  	$this->setLayout(null);
  }
  
  public function executeJsonMetaDefinitivos(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$user = $this->getUser()->getAttribute('usuario');	
	$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT buscarmetasdefinitivo($user,$mes,$anio) as metas");	
  	$this->json = $assoc[0]["metas"];
  	$this->setLayout(null);
  }
  
  public function executeJsonIndicadores(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$fechaFin=date("Y-m-d");
	$fechaInicio="$anio-$mes-01";
	if($id!=null)$user=$id;
	else $user = $this->getUser()->getAttribute('usuario');	
	$conn=Doctrine_Manager::getInstance()->getCurrentConnection();
	$conn->beginTransaction();
	//var_dump("SELECT obtenerjsondatos($user,'$fechaInicio','$fechaFin','datos');");
	$conn->fetchAssoc("SELECT obtenerjsondatos($user,'$fechaInicio','$fechaFin','datos');");
	$assoc=$conn->fetchAssoc("FETCH ALL IN datos;");	
	for($i=0;$i<count($assoc);$i++){
		if($assoc[$i]["asignado"]==0 ) $assoc[$i]["valor_porcentaje"] = 100;
		else $assoc[$i]["valor_porcentaje"]= round(100*$assoc[$i]["recaudado"]/$assoc[$i]["asignado"],2);
		$assoc[$i]["asignado"]=round($assoc[$i]["asignado"]);
		$assoc[$i]["recaudado"]=round($assoc[$i]["recaudado"]);
		$assoc[$i]["id_actual"]=$user;
	}
	$conn->commit();
	$retorno=array();
	$retorno["datos"]=$assoc;
	
  	$this->json = json_encode($retorno);
  	$this->setLayout(null);
  }

public function executeJsonIndicadores2(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("m");
	$anio=date("Y");
	$fechaFin=date("Y-m-d");
	//$fechaInicio="$anio-$mes-01";
	$fechaInicio="2009-01-01";
	if($id!=null)$user=$id;
	else $user = $this->getUser()->getAttribute('usuario');	
	$conn=Doctrine_Manager::getInstance()->getCurrentConnection();
	$conn->beginTransaction();
	//var_dump("SELECT * FROM  obtenerjsondatos2($user,'$fechaInicio','$fechaFin','datos');");
	$assoc=$conn->fetchAssoc("SELECT * FROM obtenerjsondatos2($user,'$fechaInicio','$fechaFin','datos');");
	//$assoc=$conn->fetchAssoc("FETCH ALL IN datos;");	
	//var_dump($assoc);
	$sumAsignado=0;
	$sumPromesas=0;
	$indiceJefe=0;
	for($i=0;$i<count($assoc);$i++){
		if($assoc[$i]["asignado"]==0 ) $assoc[$i]["valor_porcentaje"] = 100;
		else $assoc[$i]["valor_porcentaje"]= round(100*$assoc[$i]["recaudado"]/$assoc[$i]["asignado"],2);
		if($assoc[$i]["id"]==$user){
			$indiceJefe=$i;
			//var_dump($indiceJefe);
		}
	//	$assoc[$i]["asignado"]
		$assoc[$i]["asignado"]=round($assoc[$i]["asignado"]);
		$assoc[$i]["recaudado"]=round($assoc[$i]["recaudado"]);
		$assoc[$i]["id_actual"]=$user;		
		$sumAsignado+=$assoc[$i]["asignado"];
		$sumPromesas+=$assoc[$i]["recaudado"];
	}	
	/*$assoc[$indiceJefe]["asignado"]=round($sumAsignado);
	$assoc[$indiceJefe]["recaudado"]=round($sumPromesas);
	$assoc[$indiceJefe]["valor_porcentaje"]=$assoc[$indiceJefe]["asignado"]==0?100:round(100*$sumPromesas/$sumAsignado,2);*/
	$conn->commit();
	$retorno=array();
	$retorno["datos"]=$assoc;
	
  	$this->json = json_encode($retorno);
  	echo $this->json;exit;
  }
  
  public function executeCrearPago(sfWebRequest $request){
   // print_r($request->getPostParameters());
	$this->form = new GcaPagosForm();
	$this->processForm($request, $this->form);
	//echo "hola";
	$this->setLayout(null);
//	$this->form->bind($request->getParameter($this->form->getName()));
//	echo $this->form->isValid();
	exit;
  }


  public function executeJsonPagos(sfWebRequest $request){
    $id = $request->getParameter('id');
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $rs = $doctrine->query("select p.* from gca_pagos p join gca_obligacion o on(p.expediente = o.numero_expediente) where o.id = ".$id)->fetchAll();
    
    
    $arr_pagos = array();
    $arr_pagos['registros'] = array();
    $i = 0;
    foreach($rs as $pago){
      $arr_pagos['registros'][$i]['fecha'] = $pago['fecha'];
      $arr_pagos['registros'][$i]['observaciones'] = $pago['observaciones'];
      $arr_pagos['registros'][$i]['valor_total'] = $pago['valor_total'];
      $arr_pagos['registros'][$i]['recibido'] = $pago['recibido'];
      $arr_pagos['registros'][$i]['por_concepto'] = $pago['por_concepto'];
      $arr_pagos['registros'][$i]['honorarios'] = $pago['honorarios'];
      $arr_pagos['registros'][$i]['entidad'] = $pago['entidad'];
      $arr_pagos['registros'][$i]['otros'] = $pago['otros'];
      $i++;
      
    }
    
    $arr_pagos['cant'] = $i++;
    
    $this->json_pagos = json_encode($arr_pagos);
    
  }
  
  
  public function executeAprobar2(sfWebRequest $request){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->gca_pagos->setEstado("1");
    $this->gca_pagos->save();
    $this->redirect('frontPagos/index');
  }
  
  public function executeRechazar(sfWebRequest $request){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->gca_pagos->setEstado("1");
    $this->gca_pagos->save();
    $this->redirect('frontPagos/index');      
  }


  protected function processForm(sfWebRequest $request, sfForm $form)
  {   
    $form->bind($request->getParameter($form->getName()));	
	$errors=$form->getErrorSchema()->getErrors();	
	
	$datos=$request->getParameter($form->getName());
	$datos['obligacion']=trim($datos['obligacion']);  
	
	foreach($form->getErrorSchema() as $value=>$key){	 
	  //var_dump($key);
  	  print "<hr>error en los datos"; 
	  exit;
	}
	
    $id_user = $this->getUser()->getAttribute('usuario');
    //////////////si la forma pago es efectivo, se confirma el estado solo si es tesorero/////////////***por katty
	// tambien asigna valor de recibo de caja.
	$isTesorero=false; $this->is_tesorero=false;  $is_coordinador=false;
	
    if($this->getUser()->isAuthenticated()){
	  if($this->getUser()->hasCredential('tesorero') or $this->getUser()->hasCredential('tesorero_sucursal')){
		$isTesorero=true;  
		$this->is_tesorero=true; 	
      }	
	  if($this->getUser()->hasCredential('coordinador')) $is_coordinador=true;   
    }
	
	/////////////////////////////////////////////////////////////////////////////////
//var_dump($request->getParameter('oblig_dia'));  exit;
    $form->bind($datos); 	
       if ($form->isValid())
        {  //	print "válido--"; exit;
		    //separamos para guardar...
		   if($request->getParameter('action')=="create"){
 		        $gca_pagos= new GcaPagos();	
			$gca_pagos->setIdFuncionario($id_user);	 //quien registra elpago

			//busca el nro de consecutivo sucursal, de acuerdo al funcionario logueado... para el el recibo de caja
			 $func=Doctrine::getTable('GcaFuncionarios')->find($id_user);

			/* $dep=Doctrine::getTable('Department')->find($func->getIdSucursalGca());//ident de sucrusal
			var_dump($dep);exit;
			 $consec=$dep->getConsecutivoRc()+1;
			 $gca_pagos->setNroRc($consec);

		       */			
			}
		   elseif($request->getParameter('action')=="update"){
			 $gca_pagos=Doctrine::getTable('GcaPagos')->find($datos['id']);
			
			
                    }
				
	   	//$gca_pagos->setExpediente($datos['expediente']);
	   	$gca_pagos->setObligacion($datos['obligacion']);		
		$gca_pagos->setPorConcepto($datos['por_concepto']);
		$gca_pagos->setIdCartera($datos['id_cartera']);
		
		$gca_pagos->setFecha($datos['fecha']);
		$gca_pagos->setEntidad(round($datos['entidad']));
		$gca_pagos->setHonorarios($datos['honorarios']);
		$gca_pagos->setIva($datos['iva']);
		
		if($datos['cpm']!="")
		$gca_pagos->setCpm($datos['cpm']);

		if($datos['otros']!="")
		 $gca_pagos->setOtros($datos['otros']);
		
		if($datos['abogados']!="")
		 $gca_pagos->setAbogados($datos['abogados']);		
		 
		$gca_pagos->setValorTotal($datos['valor_total']);
		$gca_pagos->setEstado($datos['estado']);
		///por katty...
		$gca_pagos->setBancoConsignacion($datos['banco_consignacion']);							
		if($datos['fecha_consignacion']!="")$gca_pagos->setFechaConsignacion($datos['fecha_consignacion']);	
		$gca_pagos->setSucursalConsignacion($datos['sucursal_consignacion']);	
        $gca_pagos->setCuentaConsignacion($datos['cuenta_consignacion']);
        			
        $gca_pagos->setNombreDeudor($datos['nombre_deudor']);			
        $gca_pagos->setCedula($datos['cedula']);

	 if($datos['nombre_rc']!=null)	
		$gca_pagos->setNombreRc($datos['nombre_rc']);
	 else	$gca_pagos->setNombreRc($datos['nombre_deudor']);			
		///por katty...
		
		//var_dump($datos['obligacion']);exit;
               
	       $id_func_obli=Doctrine::getTable('GcaPagos')->getFuncionarioObligacion($datos['obligacion']); //dueño obliga 
		if(!$id_func_obli)
		{
		  $id_func_obli=$id_user;//aplica generalm/ cuando la obligacion es un historico,por tanto marca el pago con el usr  q  lo hace		
		} 
		
		if($gca_pagos->getIdFuncOblig()==""  or $gca_pagos->getIdFuncOblig()==null) $gca_pagos->setIdFuncOblig($id_func_obli);

		//validar si es tesorero o un usuario corriente para guardar la sucursal propia o la elegida
		if($request->getParameter('action')=="create"){
			$func=Doctrine::getTable('GcaFuncionarios')->find($id_user);
			$gca_pagos->setIdSucursal($func->getIdSucursalGca());
	
			if($isTesorero)
			{  // de una vez asigna consecutivo de recibo siendo el tesorero.... NO pq no se sabe si se vaya a rechazar
				
				if($this->getUser()->hasCredential('tesorero')){
				  $dep=Doctrine::getTable('Department')->find($request->getParameter('department[id_sucursal]'));//ident de sucusal
 				  $gca_pagos->setIdSucursal($request->getParameter('department[id_sucursal]'));
				}
				elseif($this->getUser()->hasCredential('tesorero_sucursal')){	
				  $dep=Doctrine::getTable('Department')->find($func->getIdSucursalGca());
				}

				 $consec=$dep->getConsecutivoRc()+1; 
				 $gca_pagos->setNroRc($consec);			
				 
				 $dep->setConsecutivoRc($consec);
				 $dep->save();			 
			}
		
		}


              if($isTesorero==true){
                $gca_pagos->setIdTesorero($datos['id_tesorero']);
		//si el cliente es citibank.... manda consecutivo 
		$cart=Doctrine::getTable('GcaCartera') ->find($datos['id_cartera']);
		if($cart->getIdCliente()==sfConfig::get('app_cliente_citibank_consecutivo')){						
			$cliente_citi=Doctrine::getTable('GcaCliente')->find($cart->getIdCliente());
			$consec_citi=$cliente_citi->getConsecutivoCitibank()+1;
		 	$gca_pagos->setNroCitibank($consec_citi); 
		}
	      }
         	 $gca_pagos->save();
		 $id_pago=$gca_pagos->getId();		

		//esta parte debe hacerse cuando se actualiza y debe sacar el valor del consecutivo de los recibos de caja
		// por cada sucursal modificar cuando se establezcan las sequencias mientras funciona igual. pero es al update.
 		if($request->getParameter('action')=="update"  and  $isTesorero  ){
			 //$id_pago=Doctrine::getTable('GcaPagos')->getUltimoGuardado();  //traer el id del pago q se guardó
			
			//poner el consecutivo de acuerdo a la persona que registra				
			$func=Doctrine::getTable('GcaFuncionarios')->find($id_user);
			if($func->getIdSucursalGca()){
			 $dep=Doctrine::getTable('Department')->find($func->getIdSucursalGca());//ident de sucursal
			 $consec=$dep->getConsecutivoRc()+1;
			}
			else{
			//colocamos el id del tesorero ya que el que el dueño de la obligacion no tiene una sucursal asociada
			 $func=Doctrine::getTable('GcaFuncionarios')->find($id_user);
			 $dep=Doctrine::getTable('Department')->find($func->getIdSucursalGca());//ident de sucursal
			 $consec=$dep->getConsecutivoRc()+1;
			}
			
			//pone el consec unicamente si no se rechazó ninguna forma--- y si no es coord
			if($datos['Formas']['concepto_rechazo']==""  and $datos['Formas2']['concepto_rechazo']=="" and $datos['Formas3']['concepto_rechazo']=="")
			{			 
				$q = Doctrine_Query::create()
				->update('GcaPagos')
				->set('nro_rc=?', $consec)
				->where('id=?',$id_pago);
				$filas=$q->execute();
				
				 $dpt=Doctrine::getTable('Department')->find($func->getIdSucursalGca());
				 $dpt->setConsecutivoRc($consec);
				 $dpt->save();
					 // act consc citibank
						 /*if($consec_citi !=0) {
						   $cliente_citi->setConsecutivoCitibank($consec_citi);
						   $cliente_citi->save();
						}*/
			}
        }

       	//guardar las formas de pago
		$pagoRechazado=false;
		foreach($datos as $forma=>$datos_fp){	         		  
		if(is_array($datos_fp)){	//es forma de pago
            if($request->getParameter('action')=="create"){
 		      $gca_forma_pago= new GcaFormaPago();
		      $gca_forma_pago->setIdGcaPagos($id_pago);
		   }   
		   elseif($request->getParameter('action')=="update" and $datos_fp['id']!=""){
			$gca_forma_pago=Doctrine::getTable('GcaFormaPago')->find($datos_fp['id']);
		   } 

				if($datos_fp['forma_pago']!='' && $datos_fp['valor']!='0')
				{  
				$gca_forma_pago->setMedioPago($datos_fp['medio_pago']);
				$gca_forma_pago->setFormaPago($datos_fp['forma_pago']);

				if(($datos_fp['forma_pago']==2 or  $datos_fp['forma_pago']==3) and $isTesorero==true){//si es ef o fax-efect, queda confirmado
					$gca_forma_pago->setEstado(1);//print "<hr>";
					$gca_forma_pago->setFechaConfirmado(date('Y-m-d h:i'));
					$gca_forma_pago->setFechaRecibo(date('Y-m-d h:i'));
				}elseif(($datos_fp['forma_pago']==1 or  $datos_fp['forma_pago']==4) and $isTesorero==true){
					//$gca_forma_pago->setEstado($datos_fp['estado']);
					$gca_forma_pago->setFechaRecibo(date('Y-m-d h:i'));
				}//else $gca_forma_pago->setEstado($datos_fp['estado']);
				

			    if(isset($datos_fp['concepto_rechazo']) and $datos_fp['concepto_rechazo']!=""){				
					$gca_forma_pago->setConceptoRechazo($datos_fp['concepto_rechazo']);
					$gca_forma_pago->setEstado(2);  //rechaz
					$pagoRechazado=true;
				}

				if($datos_fp['id_banco']!="")
				  $gca_forma_pago->setIdBanco($datos_fp['id_banco']);			

				$gca_forma_pago->setNumCheque($datos_fp['num_cheque']);
				//$gca_forma_pago->setProducto($datos_fp['producto']);
				$gca_forma_pago->setValor($datos_fp['valor']);
				$gca_forma_pago->setEntidad($datos_fp['entidad']);
				$gca_forma_pago->setIva($datos_fp['iva']);
				$gca_forma_pago->setCpm($datos_fp['cpm']);
				$gca_forma_pago->setHonorarios($datos_fp['honorarios']);							
				$gca_forma_pago->setOtros($datos_fp['otros']);							
				$gca_forma_pago->setAbogados($datos_fp['abogados']);									
				$fecha="";	          
				
				
				//validar pq cuando son pagos en efect, la fecha no llega pq el campo esta disabled.. por tanto se llena con la fecha del dia
				if(isset($datos_fp['fecha']['year'])){//está habilitada la fecha				
                   if($datos_fp['fecha']['year']!="" and $datos_fp['forma_pago']!=""){								
				     $fecha=$datos_fp['fecha']['year']."-".$datos_fp['fecha']['month']."-".$datos_fp['fecha']['day'];
					 $gca_forma_pago->setFecha($fecha);							 				
					 $gca_forma_pago->save();	
				   }else $fecha=date("Y-m-d",time());  		  				  
				}else{//NO está habilitada la fecha				
					if($request->getParameter('action')=="create")  $fecha=date("Y-m-d",time());
					else $fecha=$gca_forma_pago->getFecha();
						$gca_forma_pago->setFecha($fecha);	
						$gca_forma_pago->save();					 
				     }								 
				}							
			 }	
		    }//termina de guardar formas de pago 
			
	
			//guarda la distribucion, es decir el valor que se asigna a cada obligacion *******por katty
			$banDistribuir=false;
			
			$datos_obligacionesPagos=Array();
			$datos_obligacionesPagosValue=Array();
			if(isset($_POST['obligacionesPagos'])){
				array_walk($_POST['obligacionesPagos'], function(&$n, $arr) {
					if(trim($n)==""){//quita los vacios.. del post
						unset($_POST['obligacionesPagos'][$arr]);
					}
				}); 
			}
			if(!isset($_POST['obligacionesPagos']) || count($_POST['obligacionesPagos'])==0 ) //no existe cuando el pago no se distribuye.. por tanto se asigna la obligacion escogida en el pago
			 {
					$datos_obligacionesPagos[0]=$datos['obligacion'];
					$datos_obligacionesPagosValue[0]=$datos['entidad'];
					$datos_obligacionesPagosConcepto[0]=$datos['por_concepto'];
			 }		
			else		
			{ 
				$datos_obligacionesPagos=$_POST['obligacionesPagos'];
				$datos_obligacionesPagosValue=$_POST['valor'];
			    $datos_obligacionesPagosConcepto=$_POST['concepto'];
			}
			//var_dump($datos_obligacionesPagosConcepto); 			EXIT;
			
			
			if($request->getParameter('action')=="create")$distribuir=true;
			else $distribuir=false;		
			 
			  //borra posibles guardados y vuelve a grabar				
			  Doctrine::getTable('GcaObligacionesPagos')->deleteObligacionesPago($id_pago);
			  foreach($datos_obligacionesPagos as $key=>$obligacion){
                 $obligacion=trim($obligacion);		  
				if($obligacion!=""){								
					 $obligPagos=new GcaObligacionesPagos();						 
					  $obligPagos->setIdCartera($datos['id_cartera']);
					  $obligPagos->setIdPago($id_pago);
					  $obligPagos->setObligacion($obligacion);
					  $obligPagos->setEntidad($datos_obligacionesPagosValue[$key]);
					  $obligPagos->setTipoPago($datos_obligacionesPagosConcepto[$key]);
					  $obligPagos->save();					 
				}	  
	//print"distribuir=".$distribuir."--e".$datos['estado']."t ".$isTesorero;	exit;	
				//la obligacion se distribuye si existe en GcaDistribuirPagos(este es un reg que se llena manualmente)	

		
					if($obligacion!="" and $distribuir==true){// print "siii"; exit;
						  $existe_obligacion=Doctrine::getTable('GcaDistribuirPagos')->searchObligacion($datos['id_cartera'],$obligacion);													  
					 
						 if($existe_obligacion>=1){					  
							 $pagosDist=new GcaDistribuirPagos();
							 $pagosDist->setIdPago($id_pago);						
							 $pagosDist->setTotalRecaudo($datos['valor_total']);
							 $pagosDist->setSaldoTotal($datos_obligacionesPagosValue[$key]);
							 $pagosDist->setSaldoCapital(0);
							 $pagosDist->setInteresesCorrientes(0);
							 $pagosDist->setInteresesMora(0);
							 $pagosDist->setOtros(0);
							 $pagosDist->setFechaRecaudo($datos['fecha']);
							 $pagosDist->setIdCartera($datos['id_cartera']);
							 $pagosDist->setObligacion($obligacion);
							 if($datos_obligacionesPagosConcepto[$key]=="C1" or $datos_obligacionesPagosConcepto[$key]=="C3" or $datos_obligacionesPagosConcepto[$key]=="C5")
							   $tipo_pago="PT"; 
							 else $tipo_pago=$datos_obligacionesPagosConcepto[$key];
							 $pagosDist->setTipoPago($tipo_pago);
							 $pagosDist->setEstado('1');
							 $pagosDist->save();		
							 $banDistribuir=true;		
						  }
					 }				 
				
			  }		
				//*******por katty
				if ($request->getParameter('action')=="create"){
				   if($isTesorero) 
			                $this->mensaje="Pago registrado con éxito, con número: ".$consec;	
				   else $this->mensaje="Pago guardado con éxito, con número: ".$id_pago;	
				 }
				elseif ($request->getParameter('action')=="update"){
				  if($pagoRechazado==false){
					  if($isTesorero) 
						$this->mensaje="Pago Registrado con éxito, con número: ".$consec;	
					  else $this->mensaje="Pago Aprobado con éxito, con número: ".$id_pago;
				  }else	$this->mensaje="Pago rechazado con éxito!";	  
				}
			     //redirecciona para distribuir el pago ... YA NO PQ NO LO HACEN ASESORES... SE LLAMARA POR OPCION DE MENU			   
               // if(	$banDistribuir==true)		   				 
				 // $this->redirect('distribuirPagos/new?id_cartera='.$datos['id_cartera'].'&obligacion='.$datos['obligacion'].'&total_entidad='.$datos['entidad'].'&mensaje='.$this->mensaje.'&id_pago='.$id_pago);
				//else{
				   /* if($request->getParameter('formulario')=="edit_tesorero" or  $request->getParameter('formulario')=="new_tesorero") //por katty
			            $this->redirect('frontPagos/search');
			        else */


			$cartera_elejida=$request->getParameter('cartera_elejida');//para devolver  a los parametros  iniciales de pantalla
			$estado_elejido=$request->getParameter('estado');

  				      $this->redirect('frontPagos/edit?id='.$gca_pagos->getId().'&mensaje='.$this->mensaje.'&cartera_elejida='.$cartera_elejida.'&estado='.$estado_elejido);	

				//}				  
			
			
		  }
		  //no valido		
        }
		
		
  

/*Por Katty--- REGISTRO DE PAGOS....por esta accion entrarán tanto tesoreros como coordinadores,, los ultimos para aprobar pagos con estado sin aprobar..*/

 public function executeSearch(sfWebRequest $request){ 
    sfLoader::LoadHelpers(array('Red'));
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $this->form=new GcaPagosForm(); 
	
    $id_user = $this->getUser()->getAttribute('usuario');
    $id_cartera=$request->getParameter('gca_pagos[id_cartera]');

    $opcion=$request->getParameter('boton');
    
  // if($opcion!="volver") //ees  diferente cuando viene por el menu
     $this->id_cartera=$request->getParameter('gca_pagos[id_cartera]');
   //else    $this->id_cartera=$request->getParameter('cartera_elejida');


    $this->form->setDefault('id_cartera',$id_cartera) ;
    $accion=$request->getParameter('accion');   

    $this->estado=$request->getParameter('estado');
       $this->fecha_ini=$request->getParameter('fechadesde__String'); 
       $this->fecha_fin=$request->getParameter('fechahasta__String'); 

    if($this->fecha_fin!="") $fecha_fin= $this->fecha_fin." 23:59:59"; 

    $this->mensaje="";
    $dato=$request->getParameter('keywords'); 

  //ver si el usr tiene permiso para editar pagos ya registrados    
   $this->editarPagosReg=false;  
   $this->is_tesorero=false;  $this->is_tesorero_sucursal=false; $this->is_coordinador=false;
   
   if($this->getUser()->isAuthenticated()){
	if($this->getUser()->hasCredential('editar_pagos_registrados')){		  
	  $this->editarPagosReg=true;      
	}

	   if($this->getUser()->hasCredential('tesorero')){		  
		  $this->is_tesorero=true; 
		  $carteras="";     
	   }elseif($this->getUser()->hasCredential('tesorero_sucursal') or $this->getUser()->hasCredential('coordinador'))
		{ 
			if($this->getUser()->hasCredential('tesorero_sucursal')) $this->is_tesorero_sucursal=true;
			elseif($this->getUser()->hasCredential('coordinador'))
			{ 
			 $this->is_coordinador=true;
			 $this->estado=0; 
			}
			$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
			$carteras=$doctrine->query($query)->fetchColumn(); 
			$this->getCarterasAsesor($id_user,$this->form);		
	
		}		
}
 
    $this->pagos=null;
    /*if($this->estado==null  and $id_cartera==null and  $dato==null){
        $this->estado=1;
 	$this->form->setDefault('id_cartera',33);
	$id_cartera=33;
    }*/

    if(is_numeric($dato) or $dato=="" ){  
      $this->pagos=Doctrine::getTable('GcaPagos')->getPagos($dato,$id_cartera,$this->estado,$carteras,$this->fecha_ini,$fecha_fin);
	  }
    elseif(!is_numeric($dato))  $this->mensaje="Ingrese solo Números";

    if($accion=="imprimir"){
       $id_pago=$request->getParameter('id');
       $pago=Doctrine::getTable('GcaPagos')->find($id_pago);
       $valor_letras=Doctrine::getTable('GcaPagos')->txt_completo($pago->getValorTotal());
      $dir_reportes=redireccion_reportes();
       $url= $dir_reportes."?reporte=reporte_pagos&id_pago__long=".$id_pago."&valor_letras__string=".$valor_letras."&formato=PDF"; 	
       $this->redirect($url);
   }   
 
 }


 
 /*Anular pagos,, aplica para pagos que ya tienen recibo*/
 public function executeAnular(sfWebRequest $request){ 
	$link="";
 	if($request->getParameter('id_cartera')!=null  and  $request->getParameter('id_cartera')!='') 
	$link.="&gca_pagos[id_cartera]=".$request->getParameter('id_cartera');

 	if($request->getParameter('fecha_desde')!=null  and  $request->getParameter('fecha_desde')!='') 
	$link.="&fechadesde__String=".$request->getParameter('fecha_desde');


	if($request->getParameter('fecha_hasta')!=null  and  $request->getParameter('fecha_hasta')!='') 
	$link.="&fechahasta__String=".$request->getParameter('fecha_hasta');

	if($request->getParameter('keywords')!=null  and  $request->getParameter('keywords')!='') 
	$link.="&keywords=".$request->getParameter('keywords');
 	 if(count($request->getParameter('anular'))>0){		 
	   foreach($request->getParameter('anular') as $key=>$id_pago){
	     $obj_pago=Doctrine::getTable('GcaPagos')->find($id_pago);
	     $obj_pago->setEstado(6);	     
	     $obj_pago->save();          
	   }
	 }
   $this->redirect("frontPagos/search?estado=2".$link);  
 }

/*Elimina un pago que no haya  sido registrado por tesoreria.. */
 public function executeEliminar(sfWebRequest $request){ 
	$link="";
 	if($request->getParameter('id_cartera')!=null  and  $request->getParameter('id_cartera')!='') 
	$link.="&gca_pagos[id_cartera]=".$request->getParameter('id_cartera');

 	if($request->getParameter('fecha_desde')!=null  and  $request->getParameter('fecha_desde')!='') 
	$link.="&fechadesde__String=".$request->getParameter('fecha_desde');


	if($request->getParameter('fecha_hasta')!=null  and  $request->getParameter('fecha_hasta')!='') 
	$link.="&fechahasta__String=".$request->getParameter('fecha_hasta');

	if($request->getParameter('keywords')!=null  and  $request->getParameter('keywords')!='') 
	$link.="&keywords=".$request->getParameter('keywords');

 	if(count($request->getParameter('eliminar'))>0){		 
	   foreach($request->getParameter('eliminar') as $key=>$id_pago){
	     Doctrine::getTable('GcaPagos')->eliminarPago($id_pago);	        
	   }
	 }
   $this->redirect("frontPagos/search?estado=1".$link);  
 }




public function executeEditarPagosTesorero(sfWebRequest $request){
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();

    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));  

    $this->departamento=new DepartmentForm();
    $this->departamento->configure();

    $this->form = new GcaPagosForm($gca_pagos);
    $this->asesor=$gca_pagos->getIdFuncOblig();
    $id_user = $this->getUser()->getAttribute('usuario');   
    	
    $this->is_tesorero=false; $this->is_coordinador=false;  $this->is_tesorero_sucursal=false;
	
    if($this->getUser()->isAuthenticated()){		
		
		if($this->getUser()->hasCredential('tesorero'))		 
		$this->is_tesorero=true;
		if($this->getUser()->hasCredential('tesorero_sucursal')){	
		  $this->getCarterasAsesor($id_user,$this->form);	 $this->is_tesorero_sucursal=true;
		}
		if($this->getUser()->hasCredential('coordinador')){ 
			$this->is_coordinador=true;	$this->getCarterasAsesor($id_user,$this->form);
		}
		if($this->getUser()->hasCredential('analista_portafolios'))		 
		  $this->is_analista=true;  
		
    }


    $this->cartera_elejida=$request->getParameter('cartera_elejida');//para devolver  a los parametros  iniciales de pantalla
    $this->estado_elejido=$request->getParameter('estado');


    $id_cartera = $gca_pagos->getIdCartera();    
    $sql = "select porcentaje_honorarios, cpm from gca_cartera where id= ".$id_cartera;
    $cartera = $doctrine->query($sql)->fetchAll();
    $this->honorarios = $cartera[0]['porcentaje_honorarios'];
   
    $this->iva = $doctrine->query("select valor from gca_parametros where campo = 'iva'")->fetchColumn();

    if($this->cartera[0]['cpm'])$this->form->setDefault('gca_pagos_cpm',$cartera[0]['cpm']);
    //$this->form->setDefault('iva', $this->iva);
    $this->form->setDefault('otros', 0);

    
    $this->deudor= $gca_pagos->getNombreDeudor(); 
    
    $forma = $this->form->getDefault('Formas');
    $forma['fecha'] = date('m/d/Y');
    $this->form->setDefault('Formas', $forma);  

    //$forma['valor']->setAttribute('readonly');  
	
	if($this->getUser()->hasCredential('tesorero') or $this->getUser()->hasCredential('tesorero_sucursal')  )
      $this->form->setDefault('estado', 2); //registrado 
	else  $this->form->setDefault('estado', 1); //aprobado	  
	  
    $this->form->setDefault('id_tesorero',  $id_user );

     $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))  
      ->execute();
           
     $i=0;

      foreach($this->gca_pagos_list as $pago){
	  if($i==0) $this->form->embedForm('Formas', new GcaFormaPagoForm($pago));
	  //var_dump($this->form['Formas']);//exit;	   
	  if($i==1) $this->form->embedForm('Formas2', new GcaFormaPagoForm($pago));
	  if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($pago));    
       $i++;
      }

    for($i=$i;$i<3;$i++){ //para que instancie con un objeto de tipo GcaFormaPago vacio, para cuando no hayan pagos
	$formaPago=new GcaFormaPago();
	$formaPago->setIdGcaPagos($gca_pagos); 	
	if($i==0)  $this->form->embedForm('Formas', new GcaFormaPagoForm($formaPago));
	if($i==1)  $this->form->embedForm('Formas2', new GcaFormaPagoForm($formaPago));
	if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($formaPago));
    }
   
    $this->obligacionesPagos=Doctrine::getTable('GcaObligacionesPagos')->getObligacionesPagadas($request->getParameter('id'), $gca_pagos->getIdCartera(),$gca_pagos->getCedula());
	
}


public function executeSearchCheques(sfWebRequest $request){
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
   $this->mensaje="";
   $forma_pago=$request->getParameter('forma_pago');
   $estado=$request->getParameter('estado');
   $carteras=null;
   if($this->getUser()->hasCredential('tesorero_sucursal')){ 
		$this->is_tesorero_sucursal=true;
		$id_user = $this->getUser()->getAttribute('usuario');
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 
		//$this->getCarterasAsesor($id_user,$this->form);
	    }		
   //exit;
   $this->cheques= Doctrine::getTable('GcaPagos')->getCheques($forma_pago,$estado,$carteras);
}

/*Confirmar cheques..... si alguno se devuelve o anula, el pago sigue en estado 2*/
 public function executeCruzarCheques(sfWebRequest $request){
       //cambia estado y fecha de confirmacion
        $i=0;
	 if(count($request->getParameter('cheque'))>0){
	   foreach($request->getParameter('cheque') as $key=>$id_formaPago){
	     $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_formaPago);
	     $obj_forma_pago->setEstado(1);
	     $obj_forma_pago->setFechaConfirmado(date("Y-m-d h:i",time())); 
	     $obj_forma_pago->save();

             //llena arreglo con pagos seleccionados
             $array_id_pagos[$i]=$obj_forma_pago->getIdGcaPagos();
	     $i++;
	   }
	 }
	 
	//devolver formas de pago chequeadas--
	 if(count($request->getParameter('fp_devuelto'))>0){
	       foreach($request->getParameter('fp_devuelto') as $key=>$id_formaPago){
		   $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_formaPago);
		   $obj_forma_pago->setEstado(3);//devolver
		   $obj_forma_pago->setFechaConfirmado(date("Y-m-d h:i",time())); 
		   $obj_forma_pago->save();
		
		   $array_id_pagos[$i]=$obj_forma_pago->getIdGcaPagos();
		   $i++;
		}	           
	 } 

	//anular formas de pago chequeados
	 if(count($request->getParameter('fp_anulada'))>0){	 
	        foreach($request->getParameter('fp_anulada') as $key=>$id_formaPago){
		   $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_formaPago);
		   $obj_forma_pago->setEstado(4);//anular
		   $obj_forma_pago->setFechaConfirmado(date("Y-m-d h:i",time())); 
		   $obj_forma_pago->save();
		
		   $array_id_pagos[$i]=$obj_forma_pago->getIdGcaPagos();
		   $i++;
		}	           
	 }


	  //verifica para ver si se puede confirmar el pago como tal
	   foreach($array_id_pagos as $id_pago){  	   
	   	   $datos=Doctrine::getTable('GcaPagos')->verificarCheques($id_pago);
		   foreach($datos as $dato)  
	 		 $cant_cheques=$dato['cant'];//nro de cheques por confirmar

		   if( $cant_cheques==0){//No hay mas cheques x confirmar
	   		$obj_pago=Doctrine::getTable('GcaPagos')->find($id_pago);
			$obj_pago->setEstado(2);
			$obj_pago->save();
		   }
	    }
   $this->redirect('frontPagos/searchCheques');
  }


/*Busca los pagos para reembolsar*/
 public function executeSearchReembolso(sfWebRequest $request){
    $this->departamento=new DepartmentForm();
    $this->departamento->configure(); 
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $this->form=new GcaPagosForm();   

    $id_cartera=$request->getParameter('gca_pagos[id_cartera]'); 

    $this->fecha_ini=$request->getParameter('fechadesde__String');
    $this->fecha_fin=$request->getParameter('fechahasta__String');
    
    if($this->fecha_ini=="")$this->fecha_ini=date("Y-m-d");
    if($this->fecha_fin=="")$this->fecha_fin=date("Y-m-d");	


    $this->mensaje="";
    $this->form->setDefault('id_cartera',$id_cartera);
    $carteras=null;
    if($this->getUser()->hasCredential('tesorero_sucursal')){ 
		$this->is_tesorero_sucursal=true;
		$id_user = $this->getUser()->getAttribute('usuario');
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 
		$this->getCarterasAsesor($id_user,$this->form);
    }
   $this->pagos= Doctrine::getTable('GcaPagos')->getPagosReembolso($id_cartera,$carteras,$this->fecha_ini,$this->fecha_fin);  		

 }



/*cambia el estado a pagos: de confirmados a reembolsados y genera la factura al deudor*/
 public function executeReembolso(sfWebRequest $request){ 
	
  $usr_logueado= $this->getUser()->getAttribute('usuario');
  $sucursal=$request->getParameter('department[id_sucursal]');	

  if(count($request->getParameter('pagos'))>0){
   foreach($request->getParameter('pagos') as $key=>$id_forma_pago){

   //print"--". $id_forma_pago;  

    $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_forma_pago);
    $obj_forma_pago->setFechaReembolso(date("Y-m-d h:i",time())); 
    $obj_forma_pago->setEstado(1);
    $obj_forma_pago->save();

      $id_pago=$obj_forma_pago->getIdGcaPagos(); 
     //verificar si ya se reembolsaron todas las formas de pago, para cambiar estado al pago   
	$cant_por_reemb=Doctrine::getTable('GcaPagos')->cant_fp_reembolsar($id_pago);

	if($cant_por_reemb==0){
		  $obj_pago=Doctrine::getTable('GcaPagos')->find($id_pago);
		   $obj_pago->setEstado(5);//reemb
		   $obj_pago->setFechaReembolso(date("Y-m-d h:i",time()));    
		   $obj_pago->save(); //print "si";exit;

		/*  *********LA FACTURACION SE HACE DESPUES DE VERIFICAR EL CLAVE... CREO Q NO ES NECESARIO HACERLA EN EL ERP************
		
		
		//buscar el cliente,para llevarlo a customer
		   $datos_cliente= Doctrine::getTable('GcaPagos')->findObligacion($id_pago);

		    foreach($datos_cliente as $cliente) {
		     //validar que no exista en customer
		     $existe_customer=Doctrine::getTable('Customer')->findCustomer($cliente['cedula']);
			 

		     if(count($existe_customer)==0){
			  $datos_cust=Doctrine::getTable('Customer')->createCustomer($cliente['nombres'],$cliente['cedula']);
			  foreach($datos_cust as $customer)
			      $id_customer=$customer['id'];
			   //se crea en addres
			   Doctrine::getTable('Customer')->createAddres($id_customer);
		      }else{//traer el id
			foreach($existe_customer as $cust)
			 $id_customer= $cust->getId();
		    } 

		    }

	     //se genera una sola factura x los pagos q hizo el deudor...
	     $valor_honorarios=0;$valor_iva=0;
	     $dato= Doctrine::getTable('GcaPagos')->getValorFactura($id_pago);//trae los valores reales de los pagos efectuados..
         foreach($dato as $inf){
 		  $valor_honorarios=round($inf['honorarios'],2);
		  $valor_iva=$inf['iva'];
		}
	     
	     $total_factura=$valor_honorarios+$valor_iva;
		 
	     $factura=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc('SELECT crear_factura('. $id_customer.','.$total_factura.','
	     .$usr_logueado.','.$sucursal.')');
	     $id_factura=$factura[0]['crear_factura']; 

	     //crear el detalle, el cual es una linea x honorario
	     $part=Doctrine::getTable('Parts')->findParts('honorarios');//traer el id de la cuenta;
	     foreach($part as $p){ 
	       $parts_id= $p->getId();
	       $part_name=$p->getDescription();
	     }
	      Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc('SELECT crear_detalles_factura('.$id_factura.','.$parts_id.',\''.      
	      $part_name.'\','.$valor_honorarios.')');	
	   
	     //grabar en acc_trans el Iva y el honorario
	      $char_id=sfConfig::get('app_id_cuenta_iva');
	      Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT acc_trans(".$id_factura.",".$char_id.",". $obj_pago->getIva().")");
	      $char_id=sfConfig::get('app_id_cuenta_honorarios');
	      Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT acc_trans(".$id_factura.",".$char_id.",".$valor_honorarios .")");

	    //actualizar cada linea de pago con su respectiva factura
	    $obj_pago->setIdAr($id_factura);
	    $obj_pago->save();*/
	}
   }
 }
  //exit;
  $this->redirect('frontPagos/searchReembolso');
}


/*Muestra los pagos reembolsados, para que el usr genere cheque  al cliente corresp*/
public function executeImprimirChequeReembolso(sfWebRequest $request){

    sfLoader::LoadHelpers(array('Red'));
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $carteras=null;
    if($this->getUser()->hasCredential('tesorero_sucursal')){ 		
		$id_user = $this->getUser()->getAttribute('usuario');
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 		
    }

  $this->pagos=Doctrine::getTable('GcaPagos')->getPagosReembolsados($carteras); 
  $this->mensaje=""; 
   $this->mens='0';
  $this->mens=$request->getParameter('mensaje')?$request->getParameter('mensaje'):0;
	//var_dump($request->getParameter('accion'));exit;
	  if($request->getParameter('accion')=="imprimir") {
	$this->mens='1';
	
       $id_cartera=$request->getParameter('id_cartera');
       $fecha_reemb=$request->getParameter('fecha_reemb');      
       $opcion=$request->getParameter('opcion');  
       $fechaImp=$request->getParameter('fecha_impresion');
       $descuentos=$request->getParameter('descuentos');  

       if($descuentos==null) $descuentos=0;

       $valor_entidad=$request->getParameter('valor')-$descuentos;        
      
       $monto= Doctrine::getTable('GcaPagos')->txt_completo(round($valor_entidad)); //convertir monto a texto
	function agregarComillas(&$elemento){
		$elemento="'$elemento'";
	}
	
	

		$reembolsos=$request->getParameter('reembolso'); 




			//desarmar array
					$id_cliente=(array_keys($reembolsos));
					$id_cliente=$id_cliente[0];

					$fechas=array_keys($reembolsos[$id_cliente]);
					$fecha2=$fechas[0];
//var_dump($fechas);  exit;				

					array_walk($fechas,'agregarComillas');
					$fechas=implode(",",$fechas);
					
					$valor_entidad=Doctrine::getTable('gcaPagos')->getValorCheque($id_cliente,$fechas)-$descuentos;
					$monto= Doctrine::getTable('GcaPagos')->txt_completo(round($valor_entidad));

	
		$numero=count($reembolsos); 


			if($numero>1)
			{
				$this->mens='11';
				$url='frontPagos/imprimirChequeReembolso?mensaje=11';
			}
			else if($numero<1  or $numero == null)
			{
				$this->mens='12';
				$url='frontPagos/imprimirChequeReembolso?mensaje=12';
			}
			else{	
			    if($opcion==1 or $opcion==3){ //imprime cheque	
				
				  $pg= Doctrine::getTable('GcaPagos')->getRelacionAdjunta($id_cliente, $fechas);  	//para la relacion de pagos adjunta.... 									
				   $relacion_adjunta="";
				   foreach($pg as $p){  $relacion_adjunta.=$p['nro_pago']."/";}

				     $relacion_adjunta=substr($relacion_adjunta,0,strlen($relacion_adjunta)-1); //quitar el ultimo slash

					$dir_reportes=redireccion_reportes();
					if($opcion==1) $nombre_reporte="cheque_reembolso_davivienda";
					elseif($opcion==3) $nombre_reporte="cheque_reembolso_bogota";

				   $url= $dir_reportes."?reporte=".$nombre_reporte."&id_cliente__long=".$id_cliente."&fecha_reemb__String=".$fechas."&monto__String=".$monto."&valor_entidad__long=".$valor_entidad."&rel_adj__String=".$relacion_adjunta."&fecha_impresion__String=".$fechaImp."&formato=XLS";			   
				
				   //marcar los pagos impresos
				  Doctrine::getTable('gcaPagos')->marcarPagosreembolsados($fechas /*$id_cartera,$fecha_reemb*/);
		            }
		    elseif($opcion==2){ //para imprimir relacion de pagos adjunta....
		          $numCheque=$request->getParameter('nro_cheque');   
			  $banco=$request->getParameter('banco'); 
				$dir_reportes=redireccion_reportes();		
			  $url= $dir_reportes."?reporte=rel_adj_reembolso&id_cliente__long=".$id_cliente."&fecha_reemb__String=".$fecha2."&monto__String=".$monto."&valor_entidad__long=".$valor_entidad."&fecha_impresion__String=".$fechaImp."&cheque__String=".$numCheque."&banco__String=".$banco."&descuentos__long=".$descuentos."&formato=XLS";	
	           }
}
//var_dump($url);exit;
     $this->redirect($url);
  }
}


/*Consultar pagos a traves de filtros*/
public function executeSearchPagos(sfWebRequest $request){ 
  $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
  $this->form=new GcaCarteraForm();
  $id_user = $this->getUser()->getAttribute('usuario');
  $this->form->configure2();   $sucursal=null;  $fecha_fin="";
  
  $id_cartera=$request->getParameter('gca_cartera[id_cartera]');  
  $estado=$request->getParameter('estado'); 
  $forma_pago=$request->getParameter('forma_pago');
  $this->mensaje=""; 
  $dato=$request->getParameter('keywords');

    $this->fecha_ini=$request->getParameter('fechadesde__String'); 
    $this->fecha_fin=$request->getParameter('fechahasta__String'); 
    if($this->fecha_fin!="") $fecha_fin= $this->fecha_fin." 23:59:59"; 



 if($this->getUser()->isAuthenticated()){
		if($this->getUser()->hasCredential('tesorero'))		 
		  $this->is_tesorero=true; 		
		elseif($this->getUser()->hasCredential('tesorero_sucursal'))		 
		  $this->is_tesorero_sucursal=true; 
		elseif($this->getUser()->hasCredential('coordinador')){
			$this->is_coordinador=true;
			$this->form->setDefault('estado', 1);
		}			  
    }	
	
    if($this->is_tesorero==false){ //carga solo carteras del asesor o del tesorero suc		
   	   $this->getCarterasAsesor($id_user,$this->form);
	   $sucursal=Doctrine::getTable('GcaFuncionarios')->find($id_user)->getIdSucursalGca();
	   $query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";   	  
           if($id_cartera==0 )$carteras=$doctrine->query($query)->fetchColumn();  
    }

  $this->pagos=Doctrine::getTable('GcaPagos')->searchPagos($id_cartera,$estado,$forma_pago,$dato,$this->fecha_ini,$fecha_fin,$sucursal,$carteras);  
  
}



/*public function executeSearchPagosAsesor(sfWebRequest $request){  print "-- creo q esto no se usa";
  $this->cartera=new GcaCarteraForm();
  $this->cartera->configure3($this->getUser()->getAttribute('usuario'));
  $id_cartera=$request->getParameter('gca_cartera[id_cartera]');  
  $estado=$request->getParameter('estado'); 
  $forma_pago=$request->getParameter('forma_pago');
  $this->mensaje=""; 
  $dato=$request->getParameter('keywords');  
  $fecha_ini=$request->getParameter('gca_pagos[fecha][year]')."-".$request->getParameter('gca_pagos[fecha][month]')."-".$request->getParameter('gca_pagos[fecha][day]');
  $fecha_fin=$request->getParameter('gca_pagos[fecha_reembolso][year]')."-".$request->getParameter('gca_pagos[fecha_reembolso][month]')."-".$request->getParameter('gca_pagos[fecha_reembolso][day]');

//var_dump($fecha_ini); exit;

  $this->pagos=Doctrine::getTable('GcaPagos')->searchPagosAsesor($this->getUser()->getAttribute('usuario'),$id_cartera,$estado,$forma_pago,$dato,$fecha_ini,$fecha_fin);
  $this->form=new GcaPagosForm();
  $this->form2=new GcaPagosForm();
}*/





//carga una sesion del ERP, para ver e imprimir las facturas
public function executeLlamarERP(){
  //la dir fisica, está en el .5 en /usr/local/sql-ledger 
  sfLoader::LoadHelpers(array('Red'));
  $dir_erp=redireccion_reportes('erp'); 
//$this->redirect("http://190.60.204.238/erp/menu.pl?login=tesorero&path=bin/mozilla&action=display&main=company_logo&js=1&password=tesorero");
  $this->redirect($dir_erp."/erp/menu.pl?login=tesorero&path=bin/mozilla&action=display&main=company_logo&js=1&password=tesorero");
  //$this->redirect("http://127.0.0.1/erp/menu.pl?login=tesorero&path=bin/mozilla&action=display&main=company_logo&js=1&password=tesorero");
}



/*Consignaciones o pagos realizados*/ 
 public function executeConsignacionDiaria(sfWebRequest $request){
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $accion=$request->getParameter('boton');
     $this->fecha_ini=$request->getParameter('fechadesde__String');   
     $this->fecha_fin=$request->getParameter('fechahasta__String');   
    
    if($this->fecha_ini=="") $this->fecha_ini=date("Y-m-d");
    if($this->fecha_fin=="") $this->fecha_fin=date("Y-m-d");
	
    
    $carteras=null;
	$id_user = $this->getUser()->getAttribute('usuario');
	$sucursal=Doctrine::getTable('GcaFuncionarios')->find($id_user)->getIdSucursalGca();   
  
    if($this->getUser()->hasCredential('tesorero')){ 		   
		  $this->is_tesorero=true;
		  $this->form = new DepartmentForm();
		  if($request->getParameter('department[id_sucursal]')!=""){
		    $sucursal=$request->getParameter('department[id_sucursal]');	
		  }			
		  $this->form->setDefault('id_sucursal',$sucursal);	  
    }  
    elseif($this->getUser()->hasCredential('tesorero_sucursal')){ 	
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 
		$this->is_tesorero=false;	//print $sucursal; exit;			
    }  
	$tipo_consulta="consignacion";	
  
   $this->pagos   =Doctrine::getTable('GcaPagos')->getConsignacionDiaria($this->fecha_ini,$this->fecha_fin,$carteras,$sucursal);
   $this->totales =Doctrine::getTable('GcaPagos')->getConsignacionDiariaTotales($this->fecha_ini,$this->fecha_fin,$carteras,$tipo_consulta,$sucursal);
   $this->mensaje="";  
   if(count ($this->pagos)==0)  $this->mensaje="No hay registros";

   if($accion=="Imprimir"){	  
	  $fecha=explode("-",$this->fecha_ini);
	  $fecha2=explode("-",$this->fecha_fin);
	  
	    $fechaMk=mktime(0,0,0,$fecha[1],$fecha[2],$fecha[0]);		
	    $fechaMk2=mktime(0,0,0,$fecha2[1],$fecha2[2],$fecha2[0]);
		
		$fecha_desde1= date("Y-m-d 00:00:00",$fechaMk -(1*24*60*60));
		$fecha_hasta1= date("Y-m-d 23:59:59",$fechaMk2-(1*24*60*60));	
		
	    $fecha_desde=$this->fecha_ini." 00:00:00";
	    $fecha_hasta=$this->fecha_fin." 23:59:59";
		
		/*		
		$dia=date("w",$fechaMk);   //VALIDA SI LA FECHA  ES LUNES    
	
	    if($dia==1){ //lunes         		
		  $fecha_desde1= date("Y-m-d 00:00:00",$fechaMk2-(2*24*60*60));
		  $fecha_hasta1= date("Y-m-d 23:59:59",$fechaMk-(2*24*60*60));		 
	     }		
		
		else{ //si no es lunes el intervalo es de menos un dia 	      
	     	  $fecha_desde1=date("Y-m-d 00:00:00",$fechaMk-(1*24*60*60));
		      $fecha_hasta1=date("Y-m-d 23:59:59",$fechaMk-(1*24*60*60)); 		      
            }
        */
		
       $fax_ch=0;$efectivo=0; $fax_e= 0;$cheque=0;	
      
       foreach($this->totales as $t){	
	 if($t['descripcion']=="EFECTIVO") $efectivo= $t['valor'];
	 if($t['descripcion']=="FAX-EFECTIVO") $fax_e= $t['valor'];
	 if($t['descripcion']=="CHEQUE") $cheque+= $t['valor'];
	 if($t['descripcion']=="FAX-CHEQUE") $fax_ch+= $t['valor'];	
       }
   	$cantPagos=Doctrine::getTable('GcaPagos')->contarPagos($this->fecha_ini,$carteras);
	sfLoader::LoadHelpers(array('Red'));
	
	$url= redireccion_reportes()."?reporte=consignacion_diaria&fechadesde__String=".$this->fecha_ini."&fechahasta__String=".
	      $fecha_hasta."&vlr_efectivo__Double=".$efectivo."&vlr_fax_e__Double=".$fax_e."&vlr_fax_ch__Double=".$fax_ch."&vlr_cheque__Double=".	
	      $cheque."&cant_pagos__String=".count($this->pagos)."&sucursal__String=".$sucursal."&formato=PDF";
	  
	$this->redirect($url);
   }    
 }
 

 
  /*Resumen de pagos realizados*/
 public function executeLibroClave(sfWebRequest $request){  
  $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
  $this->fecha_ini=$request->getParameter('fechadesde__String'); 
  $this->fecha_fin=$request->getParameter('fechahasta__String'); 
  
  if($this->fecha_ini=="") $this->fecha_ini=date("Y-m-d");
  if($this->fecha_fin=="") $this->fecha_fin=date("Y-m-d");  
  $accion=$request->getParameter('boton'); 
  
  $carteras=null;
  $id_user = $this->getUser()->getAttribute('usuario');
  $sucursal=Doctrine::getTable('GcaFuncionarios')->find($id_user)->getIdSucursalGca(); 	  
  
    if($this->getUser()->hasCredential('tesorero')){ 		   
		  $this->is_tesorero=true;
		  $this->form = new DepartmentForm();
		  if($request->getParameter('department[id_sucursal]')!=""){
		    $sucursal=$request->getParameter('department[id_sucursal]');	
		  }			
		  $this->form->setDefault('id_sucursal',$sucursal);	  
    }  
    elseif($this->getUser()->hasCredential('tesorero_sucursal')){ 		
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 
		$this->is_tesorero=false;			
    }  
  $tipo_consulta="libro_clave";
  $this->pagos=Doctrine::getTable('GcaPagos')->getLibroClave($this->fecha_ini,$this->fecha_fin,$carteras,$tipo_consulta,$sucursal);
  $this->totales=Doctrine::getTable('GcaPagos')->getConsignacionDiariaTotales($this->fecha_ini,$this->fecha_fin,$carteras, $tipo_consulta,$sucursal);
  $this->mensaje="";  
  if(count ($this->pagos)==0) $this->mensaje="No hay registros";
  
  if($accion=="Imprimir"){  
      $fecha=explode("-",$this->fecha_ini);
	  $fecha2=explode("-",$this->fecha_fin);
	  
		$fechaMk=mktime(0,0,0,$fecha[1],$fecha[2],$fecha[0]);		
	    $fechaMk2=mktime(0,0,0,$fecha2[1],$fecha2[2],$fecha2[0]);
		
		$fecha_desde1= date("Y-m-d 00:00:00",$fechaMk -(1*24*60*60));
		$fecha_hasta1= date("Y-m-d 23:59:59",$fechaMk2-(1*24*60*60));	
		
	    $fecha_desde=$this->fecha_ini." 00:00:00";
	    $fecha_hasta=$this->fecha_fin." 23:59:59"; 
  
		/*  
	  $dia=date("w",$fechaMk);        

	    if($dia==1){ //lunes           
		  $fecha_desde1= date("Y-m-d 00:00:00",$fechaMk-(3*24*60*60));// "- cast('3 days' as interval)";//viernes
		  $fecha_hasta1= date("Y-m-d 23:59:59",$fechaMk-(2*24*60*60));//"- cast('2 days' as interval)";//sabado
	     }
	    else{  //si no es lunes el intervalo es de menos un dia 
	      $fecha_desde1=date("Y-m-d 00:00:00",$fechaMk-(1*24*60*60));
		  $fecha_hasta1=date("Y-m-d 23:59:59",$fechaMk-(1*24*60*60)); //"- cast('1 days' as interval)";
             }*/
			 
			 
   
	$fax_ch=0;$efectivo=0; $fax_e= 0;$cheque=0;	$total_otros=0;
	foreach($this->totales as $t){	
		if($t['descripcion']=="EFECTIVO") $efectivo= $t['valor'];
		if($t['descripcion']=="FAX-EFECTIVO") $fax_e= $t['valor'];
		if($t['descripcion']=="CHEQUE") $cheque+= $t['valor'];
		if($t['descripcion']=="FAX-CHEQUE") $fax_ch+= $t['valor'];	
	}
	$total_otros=$fax_e+$fax_ch;
	
	$cantPagos=Doctrine::getTable('GcaPagos')->contarPagos($this->fecha_ini,$carteras);
	sfLoader::LoadHelpers(array('Red'));
	$url= redireccion_reportes()."?reporte=libro_mayor&fechadesde__String=".$this->fecha_ini."&fechahasta__String=".
 	$fecha_hasta."&vlr_efectivo__Double=".$efectivo."&vlr_fax_e__Double=".$fax_e."&vlr_fax_ch__Double=".$fax_ch."&vlr_cheque__Double=".
	$cheque."&cant_pagos__String=".$cantPagos."&sucursal__String=".$sucursal."&vlr_otros__Double=".$total_otros."&formato=PDF";
        $this->redirect($url);
  } 
 }
 
 /*Genera la facturación masiva para la misma información del clave*/
  public function executeFacturarLibroClave(sfWebRequest $request){  
  $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
  $this->fecha_ini=$request->getParameter('fechadesde__String'); 
  $this->fecha_fin=$request->getParameter('fechahasta__String'); 
  
  if($this->fecha_ini=="") $this->fecha_ini=date("Y-m-d");
  if($this->fecha_fin=="") $this->fecha_fin=date("Y-m-d"); 
  
  $accion=$request->getParameter('boton'); 
  
  $carteras=null; 
  $id_user = $this->getUser()->getAttribute('usuario');
  $sucursal=Doctrine::getTable('GcaFuncionarios')->find($id_user)->getIdSucursalGca(); 	
  
  
    if($this->getUser()->hasCredential('tesorero')){ 		   
		  $this->is_tesorero=true;
		  $this->form = new DepartmentForm();
		  if($request->getParameter('department[id_sucursal]')!=""){
		    $sucursal=$request->getParameter('department[id_sucursal]');	
		  }			
		  $this->form->setDefault('id_sucursal',$sucursal);	  
    }  
    elseif($this->getUser()->hasCredential('tesorero_sucursal')){ 		
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 
		$this->is_tesorero=false;				
    }  

  $this->pagos=Doctrine::getTable('GcaPagos')->getLibroClave($this->fecha_ini,$this->fecha_fin,$carteras,"facturar",$sucursal);
  $this->totales=Doctrine::getTable('GcaPagos')->getConsignacionDiariaTotales($this->fecha_ini,$this->fecha_fin,$carteras,"facturar",$sucursal);
  $this->mensaje="";  
  if(count ($this->pagos)==0) $this->mensaje="Los pagos de esta fecha ya han sido facturados ó no hay para facturar!";
  
  if($accion=="Facturar"){    
   $datos_sucursal=Doctrine::getTable('Department')->find($sucursal);
   $consecutivo_fact_ini=$consecutivo_fact=$datos_sucursal->getConsecutivoFacCont();     
   
   $cont_pagos=0;
   foreach($this->pagos as $pagos){	
		$pago=Doctrine::getTable('GcaPagos')->find($pagos['id']);	 
		//el pago se factura solo si genera Iva... anulados ni devueltos se aceptan 
		if($pagos['estado_fp']!=2  and $pagos['estado_fp']!=4  and $pagos['estado_fp']!=3  and $pago['estado']!=6 and $pagos['iva']!=0 and $pagos['iva']!=null and  $pagos['iva']!=''){
			 $consecutivo_fact++;			
			 $sql="Update gca_obligaciones_pagos set id_ar=". $consecutivo_fact ." where id= ".$pagos['id_op'];
			 $doctrine->query($sql); 
			 $cont_pagos++;		 
		}else{			
			//aplica para cuando el recibo tiene 2 lineas y la primera pudo haberse facturado ya..
			$sql="Select id_ar from  gca_obligaciones_pagos where id =". $pagos['id_op'];
			$id_ar=$doctrine->query($sql)->fetchColumn(); 
			if($id_ar==""){			
			  $sql="Update gca_obligaciones_pagos set id_ar= -1 where id =". $pagos['id_op'];
			  $doctrine->query($sql); 
			}
		}
	        $pago->setIdAr(1);//indicar q se facturó el pago
		$pago->save();  
		
   }

 
   $datos_sucursal->setConsecutivoFacCont($consecutivo_fact);
   $datos_sucursal->save(); 
   if($cont_pagos==1)
     $this->mensaje="Se ha facturado ".$cont_pagos." pago, con número  " .($consecutivo_fact_ini+1);
   if($cont_pagos==0)
     $this->mensaje="Ok!! ";// cuando los pagos fueron dev o anul o eran directos
   else
     $this->mensaje="Se han facturado ".$cont_pagos." pagos, con números  " .($consecutivo_fact_ini+1)." al ".$consecutivo_fact;  
  } 
 }
 
 
public function executeReporteContadores(sfWebRequest $request){  
  $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
  $this->fecha_ini=$request->getParameter('fechadesde__String'); 
  $this->fecha_fin=$request->getParameter('fechahasta__String'); 
   
  if($this->fecha_ini=="") $this->fecha_ini=date("Y-m-d");
  if($this->fecha_fin=="") $this->fecha_fin=date("Y-m-d"); 

  $carteras=null; 
  $id_user = $this->getUser()->getAttribute('usuario');
  $sucursal=Doctrine::getTable('GcaFuncionarios')->find($id_user)->getIdSucursalGca(); 	
  $this->mensaje="";
  
    if($this->getUser()->hasCredential('tesorero')){ 		   
		  $this->is_tesorero=true;
		  $this->form = new DepartmentForm();
		  if($request->getParameter('department[id_sucursal]')!=""){
		    $sucursal=$request->getParameter('department[id_sucursal]');	
		  }			
		  $this->form->setDefault('id_sucursal',$sucursal);	  
    }  
    elseif($this->getUser()->hasCredential('tesorero_sucursal')){ 		
   		$query="Select carteras from gca_datos_funcionarios where id_empleado=$id_user";
   		$carteras=$doctrine->query($query)->fetchColumn(); 
		$this->is_tesorero=false;				
    }

    if($request->getParameter('boton')=="Imprimir"){
		$fecha=explode("-",$this->fecha_ini);
		$fecha2=explode("-",$this->fecha_fin);
		  
		$fechaMk=mktime(0,0,0,$fecha[1],$fecha[2],$fecha[0]);		
		$fechaMk2=mktime(0,0,0,$fecha2[1],$fecha2[2],$fecha2[0]);
		
		$fecha_desde1= date("Y-m-d 00:00:00",$fechaMk -(1*24*60*60));
		$fecha_hasta1= date("Y-m-d 23:59:59",$fechaMk2-(1*24*60*60));	
		
		$fecha_desde=$this->fecha_ini." 00:00:00";
		$fecha_hasta=$this->fecha_fin." 23:59:59"; 
		
		sfLoader::LoadHelpers(array('Red'));
//		print 
		$url= redireccion_reportes()."?reporte=".$request->getParameter('reporte')."&fechadesde__String=".$this->fecha_ini."&fechahasta__String=".$fecha_hasta."&fechadesde1__String=".$fecha_desde1."&fechahasta1__String=".$fecha_hasta1."&id_sucursal__String=".$sucursal."&formato=PDF";
            $this->redirect($url);
	}	
}
 
 
 
 
/*Método de impresión masiva de facturas*/ 
public function executeFacturacionMasiva(sfWebRequest $request)
 {//revisar la impresion del recibo pq hay casos en que no se imprime el valor a la entidad... Mery me lo aclara luego... nov 29,,
   $this->form = new FacturacionMasivaForm();  

   if($request->getParameter('boton')=="Imprimir"){
     $sucursal=$request->getParameter('facturacion[sucursal]');

     $this->fecha_ini=$request->getParameter('facturacion[Fecha Desde]');
     $this->fecha_fin=$request->getParameter('facturacion[Fecha Hasta]');
     
     $where ="";

     if($consecutivo=$request->getParameter('facturacion[Consecutivo Desde]')!="")
      $where .=" and op.id_ar >= ".$request->getParameter('facturacion[Consecutivo Desde]');
     if($consecutivo=$request->getParameter('facturacion[Consecutivo Hasta]')!="")   
       $where .=" and op.id_ar <= ".$request->getParameter('facturacion[Consecutivo Hasta]');
  

     	$fecha=explode("-",$this->fecha_ini);
	$fecha2=explode("-",$this->fecha_fin);
	  
	$fechaMk=mktime(0,0,0,$fecha[1],$fecha[2],$fecha[0]);		
	$fechaMk2=mktime(0,0,0,$fecha2[1],$fecha2[2],$fecha2[0]);

	$fecha_desde1= date("Y-m-d 00:00:00",$fechaMk -(1*24*60*60));
	$fecha_hasta1= date("Y-m-d 23:59:59",$fechaMk2-(1*24*60*60));	


	if($fecha_desde!="") $fecha_desde=$this->fecha_ini." 00:00:00";
	if($fecha_hasta!="") $fecha_hasta=$this->fecha_fin." 23:59:59"; 

    	// $formato=$request->getParameter('facturacion[formato]');	
    	$formato="PDF";


	// $url=sfConfig::get('app_url_reportes')."?formato=".$formato."&reporte=facturas&fechadesde__String=".$fecha_desde."&fechahasta__String=".$fecha_hasta;
//print $where;
       sfLoader::LoadHelpers(array('Red'));
	//print  
$url= redireccion_reportes()."?reporte=facturas&fechadesde__String=".$fecha_desde."&fechahasta__String=".$fecha_hasta."&id_sucursal__String=".$sucursal."&recibos__String=".$where."&formato=PDF";

//print $url= redireccion_reportes()."?reporte=facturas&id_sucursal__String=".$sucursal."&recibos__String=".$where."&formato=PDF";
           $this->redirect($url);
   }  
 }

 
 
 
 
 
public function executeGenerarFacturacion (sfWebRequest $request){

	$where = '';
	$campos = $request->getParameter('nm_nominas');	

	$formato=$request->getParameter('formato');
	$campos['desde'] = explode ('/', $campos['desde']); 
	$campos['hasta'] = explode ('/', $campos['hasta']); 
	
	$campos['desde'] =  "'".$campos['desde'][2]."-".$campos['desde'][1]."-".$campos['desde'][0]."'";
	$campos['hasta'] =  "'".$campos['hasta'][2]."-".$campos['hasta'][1]."-".$campos['hasta'][0]."'";

	if ($campos['funcionario'] != ''){
		$where .= " AND cedula = '".Doctrine::getTable('Employee')->find($campos['funcionario'])->getSsn()."'";
	}
	if ($campos['reporte'] == 'completo'){
		$url=sfConfig::get('app_url_reportes')."?formato=".$formato."&reporte=nomina_completo&fecha_desde=".str_replace("--","",$campos['desde'])."&fecha_hasta=".str_replace("--","",$campos['hasta'])."&cedula=".urlencode($where);
	}else{
		//funcionario
		$url=sfConfig::get('app_url_reportes')."?formato=".$formato."&reporte=reporte_nom_func&desde=".urlencode($campos['desde'])."&hasta=".urlencode($campos['hasta'])."&cedula=".urlencode($where);
	}
	//var_dump($url);exit;
	$this->redirect ($url); 
  }
 
  /*Resumen de pagos realizados*/
 /*public function executeLibroClave(sfWebRequest $request){  
  $this->fecha_ini=$request->getParameter('fechadesde__String'); 
  $this->fecha_fin=$request->getParameter('fechahasta__String'); 
  $this->fecha_ini_cheq=$request->getParameter('fecha_ini_cheque'); 
  $this->fecha_fin_cheq=$request->getParameter('fecha_fin_cheque'); 


  $accion=$request->getParameter('boton'); 

  if($this->fecha_ini==""){$this->fecha_ini=date("Y-m-d 00:00",time()-86400); $this->fecha_ini_cheq=date("Y-m-d 00:00",time());}
  if($this->fecha_fin==""){$this->fecha_fin=date("Y-m-d 23:00",time()-86400); $this->fecha_fin_cheq=date("Y-m-d 23:00",time());}	

  //print "//".$this->fecha_ini;

  $this->pagos=Doctrine::getTable('GcaPagos')->getLibroClave($this->fecha_ini,$this->fecha_fin,$this->fecha_ini_cheq,$this->fecha_fin_cheq);
  $this->totales=Doctrine::getTable('GcaPagos')->getConsignacionDiariaTotales($this->fecha_ini,$this->fecha_fin,$this->fecha_ini_cheq,$this->fecha_fin_cheq);
  $this->mensaje="";  
  if(count ($this->pagos)==0)
  $this->mensaje="No hay registros";
  
  if($accion=="Imprimir"){   
	$fax_ch=0;$efectivo=0; $fax_e= 0;$cheque=0;	
	foreach($this->totales as $t){	
		if($t['descripcion']=="EFECTIVO") $efectivo= $t['valor'];
		if($t['descripcion']=="FAX-EFECTIVO") $fax_e= $t['valor'];
		if($t['descripcion']=="CHEQUE") $cheque= $t['valor'];
		if($t['descripcion']=="FAX-CHEQUE") $fax_ch= $t['valor'];	
	}
	
	$cantPagos=Doctrine::getTable('GcaPagos')->contarPagos($this->fecha_ini,$this->fecha_fin);
	$url= sfConfig::get('app_url_reportes')."?reporte=libro_mayor&fechadesde__String=".$this->fecha_ini."&fechahasta__String=".$this->fecha_fin."&vlr_efectivo__Double=".$efectivo."&vlr_fax_e__Double=".$fax_e."&vlr_fax_ch__Double=".$fax_ch."&vlr_cheque__Double=".$cheque."&cant_pagos__String=".$cantPagos."&fechadesde_cheque__String=".$this->fecha_ini_cheq."&fechahasta_cheque__String=".$this->fecha_fin_cheq;		  
    $this->redirect($url);
  }  
 }*/

}
