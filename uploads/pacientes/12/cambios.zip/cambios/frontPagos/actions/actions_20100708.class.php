<?php

/**
 * frontPagos actions.
 *
 * @package    prejuridico
 * @subpackage frontPagos
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class frontPagosActions extends sfActions
{
  public function executeIndex(sfWebRequest $request){
    $submit = $request->getparameter('ver');

  if(isset($submit)){
    $where = "'1' ";
    $estado = $request->getParameter('estado');
    $obligacion = $request->getParameter('obligacion');    
    if($obligacion != '')$where .= " and obligacion = '".$obligacion."'";    
    if($estado != '')$where .= "and estado = '".$estado."'";
    

    if($this->getUser()->isAuthenticated()){
      $this->credenciales = $this->getUser()->listCredentials();
    }   
    
      
    $this->gca_pagos_list = Doctrine::getTable('GcaPagos')
      ->createQuery('a')
      ->where($where)
      ->execute();      
    }   
  }
  
  public function executeUpdateFechaReembolso(sfWebRequest $request){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->form = new GcaPagosForm();
    $this->form->setDefault('fecha_reembolso', date('m/d/Y'));

    $params = $request->getPostParameters();
    if(isset($params['actualizar'])){
      $fecha = $request->getParameter("gca_pagos[fecha_reembolso]");
      $this->gca_pagos->setFechaReembolso($fecha["year"]."-".$fecha["month"]."-".$fecha["day"]);
      $this->gca_pagos->save();
      $this->redirect('frontPagos/index');
    }
    
  }
  
  

  public function executeShow(sfWebRequest $request)
  {
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->forward404Unless($this->gca_pagos);
  }

  public function executeNew(sfWebRequest $request)
  {
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $this->form = new GcaPagosForm();
    $this->form->configure2();
    $id_user = $this->getUser()->getAttribute('usuario');
        
    $sql = "select id_cartera from gca_funcionarios where id = ".$id_user;
        
    $id_cartera = $doctrine->query($sql)->fetchColumn();
    
    
    $sql = "select porcentaje_honorarios, cpm from gca_cartera where id= ".$id_cartera;
    $cartera = $doctrine->query($sql)->fetchAll();
    $this->honorarios = $cartera[0]['porcentaje_honorarios'];
    
    $this->iva = $doctrine->query("select valor from gca_parametros where campo = 'iva'")->fetchColumn();
    
    //$this->form->setDefault('honorarios', $this->cartera[0]['porcentaje_honorarios']);
    if($this->cartera[0]['cpm'])$this->form->setDefault('gca_pagos_cpm',$cartera[0]['cpm']);
    //$this->form->setDefault('iva', $this->iva);
    $this->form->setDefault('otros', 0);    
    
    $forma = $this->form->getDefault('Formas');
    $forma['fecha'] = date('m/d/Y');//establece la fecha para las formas de pago en el formulario
    $this->form->setDefault('Formas', $forma);

    $this->form->setDefault('fecha', date('Y-m-d'));//fecha del pago...

    //por Katty... para marcar el estado en registrado, si viene por tesoreria
    $this->formulario="";
    if ($request->getParameter('formulario')=="new_tesorero"){
     $this->form->setDefault('estado', 2);
     $this->formulario="new_tesorero";
    }
   //si es tesorero, cambia el estado del pago a confirmado
    $this->is_tesorero=false;
   if($this->getUser()->isAuthenticated()){
		if($this->getUser()->hasCredential('tesoreria')){
		  $this->form->setDefault('estado', 2);  
		  $this->is_tesorero=true;
                 
		}		
	}  

  }
  
  public function executeAprobar(sfWebRequest $request){
    $aprobar = $request->getParameter('aprobar');
    $rechazar = $request->getParameter('rechazar');
    
    if($aprobar !=''){
          $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id_gca_pago'));
	  $this->gca_pagos->setEstado("1");
	  $this->gca_pagos->save();
	  $this->redirect('frontPagos/index');
      }
    if($rechazar !=''){
          $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id_gca_pago'));
	  $this->gca_pagos->setEstado("3");
	  $this->gca_pagos->save();
	  $this->redirect('frontPagos/index');
      }
      
    
    
    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaPagosForm($gca_pagos);
    $this->form->configure2();
    $id_user = $this->getUser()->getAttribute('usuario');
    
    $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))
      //->getSql();
      //echo($this->gca_pagos_list);exit;
      ->execute();
      
      
      //print_r($this->gca_pagos_list);//exit;
      $this->gca_pago = array();
      $i=0;
    foreach($this->gca_pagos_list as $pago){
      //var_dump($pago->getGcaPagos()->obligacion);exit;
      $this->gca_pago[$i]['expediente'] = $pago->getGcaPagos()->expediente;
      $this->gca_pago[$i]['recibido'] = $pago->getGcaPagos()->recibido;
      $this->gca_pago[$i]['por_concepto'] = $pago->getGcaPagos()->por_concepto;
      $this->gca_pago[$i]['medio_pago'] = $pago->medio_pago;
      $this->gca_pago[$i]['forma_pago'] = $pago->getGcaFormasDePago()->descripcion;
      $this->gca_pago[$i]['id_banco'] = $pago->id_banco;
      $this->gca_pago[$i]['num_cheque'] = $pago->num_cheque;
      $this->gca_pago[$i]['producto'] = $pago->producto;
      $this->gca_pago[$i]['valor'] = $pago->valor;
      $this->gca_pago[$i]['fecha'] = $pago->fecha;
      $this->gca_pago[$i]['entidad'] = $pago->getGcaPagos()->entidad;
      $this->gca_pago[$i]['honorarios'] = $pago->getGcaPagos()->honorarios;
      $this->gca_pago[$i]['cpm'] = $pago->getGcaPagos()->cpm;
      $this->gca_pago[$i]['otros'] = $pago->getGcaPagos()->otros;
      $this->gca_pago[$i]['expediente'] = $pago->getGcaPagos()->expediente;
      $this->gca_pago[$i]['iva'] = $pago->getGcaPagos()->iva;
      $this->gca_pago[$i]['id_gca_pagos'] = $pago->getGcaPagos()->id;
      $i++;
    }
    
  }

  public function executeCreate(sfWebRequest $request)
  {
    $this->forward404Unless($request->isMethod('post'));

    $this->form = new GcaPagosForm();
    $this->form->configure2();

    $this->processForm($request, $this->form);

    $this->redirect('frontPagos/new');
    //$this->setTemplate('new');
  }


  public function executeEdit(sfWebRequest $request)
  {
    $guardar = $request->getParameter('guardar');
    $entidad = $request->getParameter('entidad');
    $honorarios= $request->getParameter('honorarios');
    $iva= $request->getParameter('iva');
    $cpm= $request->getParameter('cpm');
    $otros= $request->getParameter('otros');
    $valor_total= $request->getParameter('valor_total');
       
    if($guardar !=''){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id_gca_pago'));
    $this->gca_pagos->setEstado("0");
    $this->gca_pagos->setEntidad($entidad);
    $this->gca_pagos->setHonorarios($honorarios);
    $this->gca_pagos->setIva($iva);
    $this->gca_pagos->setCpm($cpm);
    $this->gca_pagos->setOtros($otros);
    $this->gca_pagos->setValortotal($valor_total);
    $this->gca_pagos->save();
    $this->redirect('frontPagos/index');
    }
  
    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaPagosForm($gca_pagos);
    $this->form->configure2();
    $id_user = $this->getUser()->getAttribute('usuario');
      
    $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))
      //->getSql();
      //echo($this->gca_pagos_list);exit;
      ->execute();
      
   
      //print_r($this->gca_pagos_list);//exit;
      $this->gca_pago = array();
      $i=0;
    foreach($this->gca_pagos_list as $pago){
      //var_dump($pago->getGcaPagos()->obligacion);exit;
      $this->gca_pago[$i]['expediente'] = $pago->getGcaPagos()->expediente;
      $this->gca_pago[$i]['recibido'] = $pago->getGcaPagos()->recibido;
      $this->gca_pago[$i]['por_concepto'] = $pago->getGcaPagos()->por_concepto;
      $this->gca_pago[$i]['medio_pago'] = $pago->medio_pago;
      $this->gca_pago[$i]['forma_pago'] = $pago->getGcaFormasDePago()->descripcion;
      $this->gca_pago[$i]['id_banco'] = $pago->id_banco;
      $this->gca_pago[$i]['num_cheque'] = $pago->num_cheque;
      $this->gca_pago[$i]['producto'] = $pago->producto;
      $this->gca_pago[$i]['valor'] = $pago->valor;
      $this->gca_pago[$i]['fecha'] = $pago->fecha;
      $this->gca_pago[$i]['entidad'] = $pago->getGcaPagos()->entidad;
      $this->gca_pago[$i]['honorarios'] = $pago->getGcaPagos()->honorarios;
      $this->gca_pago[$i]['cpm'] = $pago->getGcaPagos()->cpm;
      $this->gca_pago[$i]['otros'] = $pago->getGcaPagos()->otros;
      $this->gca_pago[$i]['expediente'] = $pago->getGcaPagos()->expediente;
      $this->gca_pago[$i]['iva'] = $pago->getGcaPagos()->iva;
      $this->gca_pago[$i]['id_gca_pagos'] = $pago->getGcaPagos()->id;
      $i++;
    }

    /**Por Katty **/
      //verificar si es tesorero
      $this->is_tesorero=true;  //*******************************revisar*********************

	if($this->getUser()->isAuthenticated()){
		if($this->getUser()->hasCredential('tesorero')){
			$this->is_tesorero=true;
		}		
	}
  
    
  }

  public function executeUpdate(sfWebRequest $request)
  { 
    $this->forward404Unless($request->isMethod('post') || $request->isMethod('put'));
    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $this->form = new GcaPagosForm($gca_pagos);

   /**********por katty**********/
   //$this->form->configure2();
    $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))     
      ->execute();
    $i=0;
    foreach($this->gca_pagos_list as $pago){
	  if($i==0) $this->form->embedForm('Formas', new GcaFormaPagoForm($pago));
	  //var_dump($this->form['Formas']);exit;	   
	  if($i==1)$this->form->embedForm('Formas2', new GcaFormaPagoForm($pago));
	  if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($pago));    
       $i++;
    }


   for($i=$i;$i<3;$i++){ //para que instancie con un objeto de tipo GcaFormaPago vacio, para cuando no hayan pagos
	$formaPago=new GcaFormaPago();
	$formaPago->setIdGcaPagos($gca_pagos); 	
	if($i==0)  $this->form->embedForm('Formas', new GcaFormaPagoForm($formaPago));
	if($i==1)  $this->form->embedForm('Formas2', new GcaFormaPagoForm($formaPago));
	if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($formaPago));
    }  
/********************/

    $this->processForm($request, $this->form);
    $this->setTemplate('edit');
  }



  public function executeDelete(sfWebRequest $request)
  {
    $request->checkCSRFProtection();

    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));
    $gca_pagos->delete();

    $this->redirect('frontPagos/index');
  }
  
  public function executeSummaryMetas(sfWebRequest $request){
		$this->valores=array();
		$user = $this->getUser()->getAttribute('usuario');	
		$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT cantidadobligacionesasesor($user) as metas");
		$this->valores["wqv"]["esperado"]="";
		$this->valores["wqv"]["realizado"]=$assoc[0]["metas"];
		$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT descripcion,metas,cantidad FROM GCA_V_SUMMARY AS S WHERE OBTENERCARTERAFUNCIONARIO($user)= S.ID_CARTERA AND S.ID_FUNCIONARIO=$user");		
		foreach($assoc as $llave => $valor ){
			$this->valores[$valor["descripcion"]]["esperado"]=$valor["metas"];
			$this->valores[$valor["descripcion"]]["realizado"]=$valor["cantidad"];
		}
		
		$this->setLayout(null);
  }
  
public function executeJsonMeta(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$user = $this->getUser()->getAttribute('usuario');	
	$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT buscarMetas($user,$mes,$anio) as metas");	
  	$this->json = $assoc[0]["metas"];
  	$this->setLayout(null);
  }
  
  public function executeJsonMetaDefinitivos(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$user = $this->getUser()->getAttribute('usuario');	
	$assoc=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT buscarmetasdefinitivo($user,$mes,$anio) as metas");	
  	$this->json = $assoc[0]["metas"];
  	$this->setLayout(null);
  }
  
  public function executeJsonIndicadores(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$fechaFin=date("Y-m-d");
	$fechaInicio="$anio-$mes-01";
	if($id!=null)$user=$id;
	else $user = $this->getUser()->getAttribute('usuario');	
	$conn=Doctrine_Manager::getInstance()->getCurrentConnection();
	$conn->beginTransaction();
	//var_dump("SELECT obtenerjsondatos($user,'$fechaInicio','$fechaFin','datos');");
	$conn->fetchAssoc("SELECT obtenerjsondatos($user,'$fechaInicio','$fechaFin','datos');");
	$assoc=$conn->fetchAssoc("FETCH ALL IN datos;");	
	for($i=0;$i<count($assoc);$i++){
		if($assoc[$i]["asignado"]==0 ) $assoc[$i]["valor_porcentaje"] = 100;
		else $assoc[$i]["valor_porcentaje"]= round(100*$assoc[$i]["recaudado"]/$assoc[$i]["asignado"],2);
		$assoc[$i]["asignado"]=round($assoc[$i]["asignado"]);
		$assoc[$i]["recaudado"]=round($assoc[$i]["recaudado"]);
		$assoc[$i]["id_actual"]=$user;
	}
	$conn->commit();
	$retorno=array();
	$retorno["datos"]=$assoc;
	
  	$this->json = json_encode($retorno);
  	$this->setLayout(null);
  }
  
  public function executeJsonIndicadores2(sfWebRequest $request){
  	$id= $request->getParameter("id");
  	$mes=date("n");
	$anio=date("Y");
	$fechaFin=date("Y-m-d");
	$fechaInicio="$anio-$mes-01";
	if($id!=null)$user=$id;
	else $user = $this->getUser()->getAttribute('usuario');	
	$conn=Doctrine_Manager::getInstance()->getCurrentConnection();
	$conn->beginTransaction();
	//var_dump("SELECT * FROM  obtenerjsondatos2($user,'$fechaInicio','$fechaFin','datos');");
	$assoc=$conn->fetchAssoc("SELECT * FROM obtenerjsondatos2($user,'$fechaInicio','$fechaFin','datos');");
	//$assoc=$conn->fetchAssoc("FETCH ALL IN datos;");	
	//var_dump($assoc);
	$sumAsignado=0;
	$sumPromesas=0;
	$indiceJefe=0;
	for($i=0;$i<count($assoc);$i++){
		if($assoc[$i]["asignado"]==0 ) $assoc[$i]["valor_porcentaje"] = 100;
		else $assoc[$i]["valor_porcentaje"]= round(100*$assoc[$i]["recaudado"]/$assoc[$i]["asignado"],2);
		if($assoc[$i]["id"]==$user){
			$indiceJefe=$i;
			//var_dump($indiceJefe);
		}
	//	$assoc[$i]["asignado"]
		$assoc[$i]["asignado"]=round($assoc[$i]["asignado"]);
		$assoc[$i]["recaudado"]=round($assoc[$i]["recaudado"]);
		$assoc[$i]["id_actual"]=$user;		
		$sumAsignado+=$assoc[$i]["asignado"];
		$sumPromesas+=$assoc[$i]["recaudado"];
	}	
	/*$assoc[$indiceJefe]["asignado"]=round($sumAsignado);
	$assoc[$indiceJefe]["recaudado"]=round($sumPromesas);
	$assoc[$indiceJefe]["valor_porcentaje"]=$assoc[$indiceJefe]["asignado"]==0?100:round(100*$sumPromesas/$sumAsignado,2);*/
	$conn->commit();
	$retorno=array();
	$retorno["datos"]=$assoc;
	
  	$this->json = json_encode($retorno);
  	echo $this->json;exit;
  }
  
  public function executeCrearPago(sfWebRequest $request){
   // print_r($request->getPostParameters());
	$this->form = new GcaPagosForm();
	$this->processForm($request, $this->form);
	//echo "hola";
	$this->setLayout(null);
//	$this->form->bind($request->getParameter($this->form->getName()));
//	echo $this->form->isValid();
	exit;
  }


  public function executeJsonPagos(sfWebRequest $request){
    $id = $request->getParameter('id');
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
    $rs = $doctrine->query("select p.* from gca_pagos p join gca_obligacion o on(p.expediente = o.numero_expediente) where o.id = ".$id)->fetchAll();
    
    
    $arr_pagos = array();
    $arr_pagos['registros'] = array();
    $i = 0;
    foreach($rs as $pago){
      $arr_pagos['registros'][$i]['fecha'] = $pago['fecha'];
      $arr_pagos['registros'][$i]['observaciones'] = $pago['observaciones'];
      $arr_pagos['registros'][$i]['valor_total'] = $pago['valor_total'];
      $arr_pagos['registros'][$i]['recibido'] = $pago['recibido'];
      $arr_pagos['registros'][$i]['por_concepto'] = $pago['por_concepto'];
      $arr_pagos['registros'][$i]['honorarios'] = $pago['honorarios'];
      $arr_pagos['registros'][$i]['entidad'] = $pago['entidad'];
      $arr_pagos['registros'][$i]['otros'] = $pago['otros'];
      $i++;
      
    }
    
    $arr_pagos['cant'] = $i++;
    
    $this->json_pagos = json_encode($arr_pagos);
    
  }
  
  
  public function executeAprobar2(sfWebRequest $request){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->gca_pagos->setEstado("1");
    $this->gca_pagos->save();
    $this->redirect('frontPagos/index');
  }
  
  public function executeRechazar(sfWebRequest $request){
    $this->gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id'));
    $this->gca_pagos->setEstado("1");
    $this->gca_pagos->save();
    $this->redirect('frontPagos/index');      
  }


  protected function processForm(sfWebRequest $request, sfForm $form)
  {   
        $form->bind($request->getParameter($form->getName()));	
	$errors=$form->getErrorSchema()->getErrors();	
	foreach($form->getErrorSchema() as $value=>$key){
	  var_dump($value,$key);
	}
        
	$datos=$request->getParameter($form->getName());
        //////////////si la forma pago es efectivo, se confirma el estado solo si es tesorero/////////////***por katty
	$isTesorero=false;
        if($this->getUser()->isAuthenticated()){
	 if($this->getUser()->hasCredential('tesoreria'))
		$isTesorero=true;                
        }
	/////////////////////////////////////////////////////////////////////////////////
//var_dump($datos);
//exit;
       $form->bind($datos);  
       if ($form->isValid())
        {   			
		//separamos para guardar...
		   if($request->getParameter('action')=="create")
 		        $gca_pagos= new GcaPagos();			
		   elseif($request->getParameter('action')=="update")
			 $gca_pagos=Doctrine::getTable('GcaPagos')->find($datos['id']);
		
	        $gca_pagos->setExpediente($datos['expediente']);
		$gca_pagos->setRecibido($datos['recibido']);
		$gca_pagos->setPorConcepto($datos['por_concepto']);
		$gca_pagos->setIdCartera($datos['id_cartera']);
		$gca_pagos->setFecha($datos['fecha']);
		$gca_pagos->setEntidad(round($datos['entidad'],2));
		$gca_pagos->setHonorarios($datos['honorarios']);
		$gca_pagos->setIva($datos['iva']);
		$gca_pagos->setCpm($datos['cpm']);

		if($datos['otros']!="")
		 $gca_pagos->setOtros($datos['otros']);
		$gca_pagos->setValorTotal($datos['valor_total']);
		$gca_pagos->setEstado($datos['estado']);	
                $gca_pagos->save();

 		if($request->getParameter('action')=="create")
		 $id_pago=Doctrine::getTable('GcaPagos')->getUltimoGuardado();  //traer el id del pago q se guardó
               

       		//guardar las formas de pago
		foreach($datos as $forma=>$datos_fp){	         		  
		    if(is_array($datos_fp)){	//es forma de pago
                     if($request->getParameter('action')=="create"){
 		        $gca_forma_pago= new GcaFormaPago();
			$gca_forma_pago->setIdGcaPagos($id_pago);
			}   
		      elseif($request->getParameter('action')=="update")
			 $gca_forma_pago=Doctrine::getTable('GcaFormaPago')->find($datos_fp['id']);


			$gca_forma_pago->setMedioPago($datos_fp['medio_pago']);
			$gca_forma_pago->setFormaPago($datos_fp['forma_pago']);

			if($datos_fp['forma_pago']==2  and $isTesorero==true){ //si es efectivo, queda confirmado
				$gca_forma_pago->setEstado(1);//print "<hr>";
				$gca_forma_pago->setFechaConfirmado(date('Y-m-d h:i'));
			}else $gca_forma_pago->setEstado($datos_fp['estado']);

			if($datos_fp['id_banco']!="")
			  $gca_forma_pago->setIdBanco($datos_fp['id_banco']);			

			$gca_forma_pago->setNumCheque($datos_fp['num_cheque']);
			$gca_forma_pago->setProducto($datos_fp['producto']);
			$gca_forma_pago->setValor($datos_fp['valor']);			
			$fecha=$datos_fp['fecha']['year']."-".$datos_fp['fecha']['month']."-".$datos_fp['fecha']['day'];
			$gca_forma_pago->setFecha($fecha); 
//var_dump($gca_forma_pago);								
			$gca_forma_pago->save();	
 
		    }		   
		}
//exit;	

	      if($request->getParameter('formulario')=="edit_tesorero" or  $request->getParameter('formulario')=="new_tesorero") //por katty
		$this->redirect('frontPagos/search');
	      else 
	      $this->redirect('frontPagos/edit?id='.$gca_pagos->getId());
        }
  }

/*Por Katty*/

 public function executeSearch(sfWebRequest $request){
    $this->cartera=new GcaObligacionForm();
    
    $accion=$request->getParameter('accion');
    
    $id_cartera=$request->getParameter('gca_obligacion[id_cartera]');
	$this->cartera->setDefault('id_cartera',$id_cartera) ;
    $estado=$request->getParameter('estado');
    $this->mensaje="";
    $dato=$request->getParameter('keywords');  
    if(is_numeric($dato) or $dato=="" ) 
      $this->pagos=Doctrine::getTable('GcaPagos')->getPagos($dato,$id_cartera,$estado);
    elseif(!is_numeric($dato))  $this->mensaje="Ingrese solo Números";

    if($accion=="imprimir"){
       $id_pago=$request->getParameter('id');
       $url= sfConfig::get('app_url_reportes')."?reporte=reporte_pagos&id_pago__long=".$id_pago;
       $this->redirect($url);
   }
 }


public function executeEditarPagosTesorero(sfWebRequest $request){ 
    $doctrine = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();

    $this->forward404Unless($gca_pagos = Doctrine::getTable('GcaPagos')->find($request->getParameter('id')), sprintf('Object gca_pagos does not exist (%s).', $request->getParameter('id')));


    $this->form = new GcaPagosForm($gca_pagos);
    $this->form->configure2();
    $id_user = $this->getUser()->getAttribute('usuario');    
    
    $sql = "select id_cartera from gca_funcionarios where id = ".$id_user;
        
    $id_cartera = $doctrine->query($sql)->fetchColumn();    
    
    $sql = "select porcentaje_honorarios, cpm from gca_cartera where id= ".$id_cartera;
    $cartera = $doctrine->query($sql)->fetchAll();
    $this->honorarios = $cartera[0]['porcentaje_honorarios'];
    
    $this->iva = $doctrine->query("select valor from gca_parametros where campo = 'iva'")->fetchColumn();
    
   // $this->form->setDefault('honorarios', $this->cartera[0]['porcentaje_honorarios']);
    if($this->cartera[0]['cpm'])$this->form->setDefault('gca_pagos_cpm',$cartera[0]['cpm']);
    //$this->form->setDefault('iva', $this->iva);
    $this->form->setDefault('otros', 0);
    
    $forma = $this->form->getDefault('Formas');
    $forma['fecha'] = date('m/d/Y');
    $this->form->setDefault('Formas', $forma);
    $this->form->setDefault('estado', 2); //registrado

     $this->gca_pagos_list = Doctrine_Query::create()
      ->from('GcaFormaPago f')
      ->innerJoin('f.GcaPagos a')
      ->innerJoin('f.GcaFormasDePago fd')
      ->where('a.id=?',$request->getParameter('id'))   

      ->execute();
           
     $i=0;

      foreach($this->gca_pagos_list as $pago){
	  if($i==0) $this->form->embedForm('Formas', new GcaFormaPagoForm($pago));
	  //var_dump($this->form['Formas']);//exit;	   
	  if($i==1) $this->form->embedForm('Formas2', new GcaFormaPagoForm($pago));
	  if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($pago));    
       $i++;
      }

    for($i=$i;$i<3;$i++){ //para que instancie con un objeto de tipo GcaFormaPago vacio, para cuando no hayan pagos
	$formaPago=new GcaFormaPago();
	$formaPago->setIdGcaPagos($gca_pagos); 	
	if($i==0)  $this->form->embedForm('Formas', new GcaFormaPagoForm($formaPago));
	if($i==1)  $this->form->embedForm('Formas2', new GcaFormaPagoForm($formaPago));
	if($i==2)  $this->form->embedForm('Formas3', new GcaFormaPagoForm($formaPago));
    }  
}


public function executeSearchCheques(sfWebRequest $request){
   $this->mensaje="";
   $forma_pago=$request->getParameter('forma_pago');
   $this->cheques= Doctrine::getTable('GcaPagos')->getCheques($forma_pago);
}

/*Confirmar cheques*/
 public function executeCruzarCheques(sfWebRequest $request){ 
       //cambia estado y fecha de confirmacion
        $i=0;
	 if(count($request->getParameter('cheque'))>0){
	   foreach($request->getParameter('cheque') as $key=>$id_formaPago){
	     $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_formaPago);
	     $obj_forma_pago->setEstado(1);
	     $obj_forma_pago->setFechaConfirmado(date("Y-m-d h:i",time())); 
	     $obj_forma_pago->save();

             //llena arreglo con pagos seleccionados
             $array_id_pagos[$i]=$obj_forma_pago->getIdGcaPagos();
	     $i++;
	   }
	 }

	//anular formas de pago chequeados
	 if(count($request->getParameter('fp_anulada'))>0){
	        foreach($request->getParameter('fp_anulada') as $key=>$id_formaPago){
		   $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_formaPago);
		   $obj_forma_pago->setEstado(2);//anular
		   $obj_forma_pago->setFechaConfirmado(date("Y-m-d h:i",time())); 
		   $obj_forma_pago->save();
		
		   $array_id_pagos[$i]=$obj_forma_pago->getIdGcaPagos();
		   $i++;
		}	           
	 }


	  //verifica para ver si se puede confirmar el pago como tal
	   foreach($array_id_pagos as $id_pago){  	   
	   	   $datos=Doctrine::getTable('GcaPagos')->verificarCheques($id_pago);
		   foreach($datos as $dato)  
	 		 $cant_cheques=$dato['cant'];//nro de cheques por confirmar

		   if( $cant_cheques==0){//No hay mas cheques x confirmar
	   		$obj_pago=Doctrine::getTable('GcaPagos')->find($id_pago);
			$obj_pago->setEstado(2);
			$obj_pago->save();
		   }
	    }
   $this->redirect('frontPagos/searchCheques');
  }


/*Busca los pagos para reembolsar*/
 public function executeSearchReembolso(sfWebRequest $request){
    $this->cartera=new GcaObligacionForm();    
    $id_cartera=$request->getParameter('gca_obligacion[id_cartera]');    
    $this->mensaje="";
    $this->cartera->setDefault('id_cartera',$id_cartera);
    $this->pagos= Doctrine::getTable('GcaPagos')->getPagosReembolso($id_cartera);     
 }



/*cambia el estado a pagos: de confirmados a reembolsados y genera la factura al deudor*/
 public function executeReembolso(sfWebRequest $request){
  $usr_logueado= $this->getUser()->getAttribute('usuario');      
  if(count($request->getParameter('pagos'))>0){
   foreach($request->getParameter('pagos') as $key=>$id_forma_pago){

//print"--". $id_forma_pago;

    $obj_forma_pago=Doctrine::getTable('GcaFormaPago')->find($id_forma_pago);
    $obj_forma_pago->setFechaReembolso(date("Y-m-d h:i",time())); 
    $obj_forma_pago->save();

     $id_pago=$obj_forma_pago->getIdGcaPagos(); 
     //verificar si ya se reembolsaron todas las formas de pago, para cambiar estado al pago
    //print"<br>--". 
	$cant_por_reemb=Doctrine::getTable('GcaPagos')->cant_fp_reembolsar($id_pago);

	if($cant_por_reemb==0){
//  print"<br>". $id_forma_pago; 
		  $obj_pago=Doctrine::getTable('GcaPagos')->find($id_pago);
		   $obj_pago->setEstado(5);//reemb
		   $obj_pago->setFechaReembolso(date("Y-m-d h:i",time()));    
		   $obj_pago->save();

		  //buscar el cliente,para llevarlo a customer
		   $datos_cliente= Doctrine::getTable('GcaPagos')->findObligacion($id_pago);

		    foreach($datos_cliente as $cliente) {
		     //validar que no exista en customer
		     $existe_customer=Doctrine::getTable('Customer')->findCustomer($cliente['cedula']);

		     if(count($existe_customer)==0){
			  $datos_cust=Doctrine::getTable('Customer')->createCustomer($cliente['nombres'],$cliente['cedula']);
			  foreach($datos_cust as $customer)
			      $id_customer=$customer['id'];
		      }else{//traer el id
			foreach($existe_customer as $cust)
			 $id_customer= $cust->getId();
		      } 

		    }

	     //generar factura x cada  pago, al deudor...
	     $valor_honorarios=0;
	     $dato= Doctrine::getTable('GcaPagos')->getValorFactura($id_pago);
             foreach($dato as $inf) $valor_honorarios=$inf['honorarios'];
	     
	     $total_factura=$valor_honorarios+$obj_pago->getIva();


	     $factura=Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc('SELECT crear_factura('. $id_customer.','.$total_factura.','
	     .$usr_logueado.')');
	     $id_factura=$factura[0]['crear_factura']; 

	     //crear el detalle, el cual es una linea x honorario
	     $part=Doctrine::getTable('Parts')->findParts('honorarios');//traer el id de la cuenta;
	     foreach($part as $p){ 
	       $parts_id= $p->getId();
	       $part_name=$p->getDescription();
	     }
	      Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc('SELECT crear_detalles_factura('.$id_factura.','.$parts_id.',\''.      
	      $part_name.'\','.$valor_honorarios.')');	
	   
	     //grabar en acc_trans el Iva y el honorario
	      $char_id=sfConfig::get('app_id_cuenta_iva');
	      Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT acc_trans(".$id_factura.",".$char_id.",". $obj_pago->getIva().")");
	      $char_id=sfConfig::get('app_id_cuenta_honorarios');
	      Doctrine_Manager::getInstance()->getCurrentConnection()->fetchAssoc("SELECT acc_trans(".$id_factura.",".$char_id.",".$valor_honorarios .")");

	    //actualizar cada linea de pago con su respectiva factura
	    $obj_pago->setIdAr($id_factura);
	    $obj_pago->save();
	}
   }
 }
  //exit;
  $this->redirect('frontPagos/searchReembolso');
}


/*Muestra los pagos reembolsados, para que el usr genere cheque  al cliente corresp*/
public function executeImprimirChequeReembolso(sfWebRequest $request){
  $this->pagos=Doctrine::getTable('GcaPagos')->getPagosReembolsados();   

  $this->mensaje=""; 
  if($request->getParameter('accion')=="imprimir") {
       $id_cartera=$request->getParameter('id_cartera');
       $fecha=$request->getParameter('fecha');      
       $monto= Doctrine::getTable('GcaPagos')->txt_completo($request->getParameter('valor'));       //convertir monto a texto

       $url= sfConfig::get('app_url_reportes')."?reporte=cheque_reembolso&id_cartera__long=".$id_cartera."&fecha__String=".$fecha."&monto__String=".$monto;
       $this->redirect($url);
  }

}


/*Consultar pagos a traves de filtros*/
public function executeSearchPagos(sfWebRequest $request){ 
  $this->cartera=new GcaObligacionForm();
  $id_cartera=$request->getParameter('gca_obligacion[id_cartera]');  
  $estado=$request->getParameter('estado'); 
  $forma_pago=$request->getParameter('forma_pago');
  $this->mensaje=""; 
  $dato=$request->getParameter('keywords');  
  $fecha_ini=$request->getParameter('gca_pagos[fecha][year]')."-".$request->getParameter('gca_pagos[fecha][month]')."-".$request->getParameter('gca_pagos[fecha][day]');
  $fecha_fin=$request->getParameter('gca_pagos[fecha_reembolso][year]')."-".$request->getParameter('gca_pagos[fecha_reembolso][month]')."-".$request->getParameter('gca_pagos[fecha_reembolso][day]');

//var_dump($fecha_ini); exit;

  $this->pagos=Doctrine::getTable('GcaPagos')->searchPagos($id_cartera,$estado,$forma_pago,$dato,$fecha_ini,$fecha_fin);
  $this->form=new GcaPagosForm();
  $this->form2=new GcaPagosForm();
}


}
