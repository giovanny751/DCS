<div class="row">
    <table class="table table-bordered table-hover">
        <thead>
        <th>Cod</th>
        <th>Número Inicial</th>
        <th>Número Final</th>
        <th>Opciones</th>
        </thead>
        <tbody>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        </tbody>
    </table>
</div>

<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>Cód cargo</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>N. Inicial cargo</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
</div>
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>Cód.Dim1</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>N.inicial Dim1</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
</div>
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>Cód.Dim2</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>N.inicial Dim2</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
</div>
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>Cód.empleado</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><label>N.inicial Empleado</label></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><input type="text" name="" id="" class="form-control" /></div>
</div>
<script>
    
</script>