<div class="alert alert-info"><center><b>NUEVA TAREA</b></center></div>
<div class="row">
    <form method="post" id="f8">
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="nombre">*Nombre</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="nombre" id="nombre" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="plan">*Plan</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="plan" id="plan" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="actividad">Actividad</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="actividad" id="actividad" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="sucursal">Sucursal (Dim1)</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="sucursal" id="sucursal" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="areadetrabajo">Area de Trabajo (Dim2)</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="areadetrabajo" id="areadetrabajo" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="tipo">Tipo</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="tipo" id="tipo" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="articulosnorma">Articulos Norma</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="articulosnorma" id="articulosnorma" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="fechaIncio">Fecha Incio</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="fechaIncio" id="fechaIncio" class="form-control fecha" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="fechafinalizacion">Fecha Finalizacion</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="fechafinalizacion" id="fechafinalizacion" class="form-control fecha" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="duracionpresupuestada">Duracion Presupuetada</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="duracionpresupuestada" id="duracionpresupuestada" class="form-control" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="calcular">Calcular</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="calcular" id="calcular" class="form-control" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="calcular">Calcular</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="calcular" id="calcular" class="form-control" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="costrospresupuestados">Costos Presupuestados</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="costrospresupuestados" id="costrospresupuestados" class="form-control" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="peso">Peso</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="peso" id="peso" class="form-control" />
            </div> 
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <label for="peso">Peso</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <input type="text" name="peso" id="peso" class="form-control" />
            </div> 
        </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <label for="estado">Estado</label>
                    </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <input type="text" name="estado" id="estado" class="form-control" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <label for="fechacreacion">Fecha Creacion</label>
                    </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <input type="text" name="fechacreacion" id="fechacreacion" class="form-control" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <label for="descripcion">Descripción</label>
                    </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <textarea name="descripcion" id="descripcion" rows="10" class="form-control"></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <label for="comentariosadicionalesalcorreoelectronico">Comentarios adicionales al correo electronico:</label>
                    </div>
                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                        <textarea name="comentariosadicionalesalcorreoelectronico" id="comentariosadicionalesalcorreoelectronico" rows="10" class="form-control"></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
    <div class="row" style="text-align:center">
        <button type="button" id="guardartarea" class="btn btn-success">Guardar</button>
    </div>
<script>
    $('#guardartarea').click(function(){
        
        $.post("<?php echo base_url("index.php/tareas/guardartarea") ?>",
            $('#f8').serialize()
        ).done(function(msg){
            
        }).fail(function(msg){
            
        });
        
    });
</script>    