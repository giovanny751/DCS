<div class="alert alert-info"><center><b>LISTADO PLANES</b></center></div>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="form-group">
            <label for="cedula">Código</label><input type="text" name="cedula" id="cedula" class="form-control">
        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="form-group">
            <label for="nombre">Nombre</label><input type="text" name="nombre" id="nombre" class="form-control">
        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="form-group">
            <label for="apellido">Fecha Inicio</label><input type="text" name="apellido" id="apellido" class="form-control">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="form-group">
            <label for="tipodocumento">Estado</label>
            <select name="tipodocumento" id="tipodocumento" class="form-control">
                <option value="">::Seleccionar::</option>
            </select>
        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="form-group">
            <label for="estado">Responsable</label><input type="text" name="estado" id="estado" class="form-control">
        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="text-align: center">
            <div class="form-group">
            <label>&nbsp;</label><button type="button" class="btn btn-success">Consultar</button>
        </div>
    </div>
</div>
<hr>
<div class="row">
    <table class="table table-bordered table-hover">
        <thead>
            <th>Código</th>
            <th>Nombre</th>
            <th>Fecha inicio</th>
            <th>Fecha fin</th>
            <th>Estado</th>
            <th>Responsable</th>
            <th>Presupuesto</th>
            <th>Descripción</th>
            <th>Opciones</th>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>
</div>    