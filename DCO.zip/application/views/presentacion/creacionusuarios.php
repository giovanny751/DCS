
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
        <label for="cedula">Cedula</label>
    </div>    
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 ">
        <input type="text" id="cedula" name="cedula" class="form-control">
    </div>    
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
        <label for="roles">Roles</label>
    </div>    
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
        <select id="roles" name="roles" class="form-control">
            <option value="">::Seleccionar::</option>
        </select>
    </div>    
</div>